<?php
// download_event_attachment.php
session_start();

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    exit("Akses ditolak.");
}

// Support both `?file=` (current) and legacy `?f=` (older front-end usage)
$raw = $_GET['file'] ?? ($_GET['f'] ?? '');
$file = basename((string)$raw);

if (empty($file) || $file === '.' || $file === '..') {
    http_response_code(400);
    exit("Nama fail tidak sah.");
}

// 3. Define Paths (Matches your folder structure)
$base = __DIR__;
$candidates = [
    $base . '/uploads/events/' . $file,
    $base . '/uploads/proposals/' . $file, // Check legacy folder
    $base . '/uploads/bulletin/' . $file    // Added based on your DB data
];

$path = null;
foreach ($candidates as $p) {
    if (file_exists($p)) { $path = $p; break; }
}

if (!$path) {
    // Optional: Serve a default placeholder image if not found
    // readfile('assets/images/placeholder.png'); 
    http_response_code(404);
    exit("Fail tidak dijumpai.");
}

// 4. Determine MIME Type
$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
$mime = match ($ext) {
    'pdf' => 'application/pdf',
    'jpg', 'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    default => 'application/octet-stream',
};

// 5. Output Headers for DISPLAY (Inline)
header('X-Content-Type-Options: nosniff');
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));

// KEY CHANGE: Use 'inline' to display in browser, 'attachment' to force download
header('Content-Disposition: inline; filename="' . $file . '"');

readfile($path);
exit;
?>