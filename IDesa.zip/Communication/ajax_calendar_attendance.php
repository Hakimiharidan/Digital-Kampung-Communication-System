<?php
// ajax_calendar_attendance.php
session_start();
header('Content-Type: application/json; charset=utf-8');

include "db_connect.php";

/* -------------------------
   JSON helpers
------------------------- */
function json_ok(array $data = [], int $code = 200): void {
    http_response_code($code);
    echo json_encode(["ok" => true, "data" => $data], JSON_UNESCAPED_UNICODE);
    exit();
}

function json_fail(string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(["ok" => false, "error" => $msg], JSON_UNESCAPED_UNICODE);
    exit();
}

/* -------------------------
   Auth helpers
------------------------- */
function is_logged_in(): bool { return isset($_SESSION['user_id']); }
function current_user_id(): int { return (int)($_SESSION['user_id'] ?? 0); }
function current_user_role(): string { return (string)($_SESSION['role'] ?? 'Resident'); }

function require_login(): void {
    if (!is_logged_in()) json_fail("Sila log masuk terlebih dahulu.", 401);
}

function require_role(array $roles): void {
    $role = current_user_role();
    if (!in_array($role, $roles, true)) json_fail("Akses tidak dibenarkan.", 403);
}

/* -------------------------
   Logging
------------------------- */
function activity_log($conn, string $action_details): void {
    $uid = current_user_id();
    if ($uid <= 0) return;
    $stmt = @mysqli_prepare($conn, "INSERT INTO activities (user_id, action_details) VALUES (?, ?)");
    if (!$stmt) return;
    mysqli_stmt_bind_param($stmt, "is", $uid, $action_details);
    @mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/* -------------------------
   Routing
------------------------- */
$action = $_POST['action'] ?? ($_GET['action'] ?? '');
$action = trim($action);

if ($action === '') json_fail("Action tidak sah.");

require_login(); // All attendance actions require login

/* =========================================================
   set_presence (RSVP)
   POST: event_id, rsvp_status
========================================================= */
if ($action === 'set_presence') {
    $eventId = (int)($_POST['event_id'] ?? 0);
    $status  = trim((string)($_POST['rsvp_status'] ?? 'Going'));

    if ($eventId <= 0) json_fail("ID acara tidak sah.");
    if (!in_array($status, ['Going','Interested','Not Going'], true)) json_fail("Status RSVP tidak sah.");

    // Verify event exists & not cancelled
    $chk = mysqli_prepare($conn, "SELECT event_id, status FROM events WHERE event_id = ? LIMIT 1");
    if (!$chk) json_fail("Ralat DB.", 500);
    mysqli_stmt_bind_param($chk, "i", $eventId);
    mysqli_stmt_execute($chk);
    $res = mysqli_stmt_get_result($chk);
    $ev = mysqli_fetch_assoc($res);
    mysqli_stmt_close($chk);

    if (!$ev) json_fail("Acara tidak dijumpai.", 404);
    if (($ev['status'] ?? '') === 'Cancelled') json_fail("Acara telah dibatalkan.", 400);

    $uid = current_user_id();

    // Insert/Update RSVP
    $stmt = mysqli_prepare($conn, "
        INSERT INTO event_attendance (event_id, user_id, rsvp_status, rsvp_date)
        VALUES (?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            rsvp_status = VALUES(rsvp_status),
            rsvp_date   = NOW()
    ");
    if (!$stmt) json_fail("Ralat DB.", 500);

    mysqli_stmt_bind_param($stmt, "iis", $eventId, $uid, $status);
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        json_fail("Gagal kemaskini kehadiran.", 500);
    }
    mysqli_stmt_close($stmt);

    activity_log($conn, "CAL_RSVP|event_id={$eventId}|status={$status}");
    json_ok(["message" => "Kehadiran berjaya dikemaskini."]);
}

/* =========================================================
   get_user_rsvp (Kehadiran Saya - My Presence)
   GET: none
   Returns list of events the current user has RSVP'd to.
========================================================= */
if ($action === 'get_user_rsvp') {
    $uid = current_user_id();

    $sql = "
        SELECT 
            ea.attendance_id, ea.event_id, ea.rsvp_status, ea.rsvp_date,
            e.title, e.start_datetime, e.end_datetime, e.location, e.category, e.status
        FROM event_attendance ea
        JOIN events e ON e.event_id = ea.event_id
        WHERE ea.user_id = ?
          AND e.status <> 'Cancelled'
        ORDER BY e.start_datetime ASC
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_fail("Ralat DB.", 500);

    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $items = [];
    while ($row = mysqli_fetch_assoc($res)) {
        $items[] = $row;
    }
    mysqli_stmt_close($stmt);

    json_ok($items); // Direct array return for easier JS mapping
}

/* =========================================================
   get_event_attendance (AJK/Admin View)
   GET: event_id
========================================================= */
if ($action === 'get_event_attendance') {
    require_role(['AJK','Admin']);

    $eventId = (int)($_GET['event_id'] ?? 0);
    if ($eventId <= 0) json_fail("ID acara tidak sah.");

    $sql = "
        SELECT 
            ea.attendance_id, ea.user_id, ea.rsvp_status, ea.rsvp_date, ea.checked_in_at,
            u.full_name, u.email, u.phone
        FROM event_attendance ea
        JOIN users u ON u.user_id = ea.user_id
        WHERE ea.event_id = ?
        ORDER BY ea.rsvp_date DESC
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_fail("Ralat DB.", 500);

    mysqli_stmt_bind_param($stmt, "i", $eventId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $attendees = [];
    while ($row = mysqli_fetch_assoc($res)) {
        $attendees[] = $row;
    }
    mysqli_stmt_close($stmt);

    json_ok(["attendees" => $attendees]);
}

/* =========================================================
   check_in (AJK/Admin Action)
   POST: attendance_id
========================================================= */
if ($action === 'check_in') {
    require_role(['AJK','Admin']);

    $attendanceId = (int)($_POST['attendance_id'] ?? 0);
    if ($attendanceId <= 0) json_fail("ID attendance tidak sah.");

    $stmt = mysqli_prepare($conn, "UPDATE event_attendance SET checked_in_at = NOW() WHERE attendance_id = ?");
    if (!$stmt) json_fail("Ralat DB.", 500);

    mysqli_stmt_bind_param($stmt, "i", $attendanceId);
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        json_fail("Gagal check-in.", 500);
    }
    mysqli_stmt_close($stmt);

    json_ok(["message" => "Check-in berjaya."]);
}

// Default Fallback
json_fail("Action tidak sah.");
?>