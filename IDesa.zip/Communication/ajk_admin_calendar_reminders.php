<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}

$viewerName = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'AJK/Admin';
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Peringatan Acara</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    /* 1. Global Reset & Box Sizing */
    * { box-sizing: border-box; }
    
    :root { 
        --primary: #2d6a4f; 
        --dark: #143d29; /* Deep Green Theme */
        --brown: #6d4c41; 
        --text: #333; 
        --muted: #6b7280; 
        --bg: #f4f7f6; 
        --card: #fff; 
    }

    body { font-family: 'Poppins', sans-serif; margin: 0; background: var(--bg); color: var(--text); display: flex; }

    /* --- SIDEBAR (Deep Green) --- */
    .sidebar { 
        width: 250px; 
        height: 100vh; 
        background: var(--dark); 
        padding: 25px 18px; 
        position: fixed; 
        display: flex; 
        flex-direction: column; 
        color: #fff; 
        z-index: 100; 
        overflow-y: auto;
        box-shadow: 4px 0 15px rgba(0,0,0,0.05);
    }

    .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
    .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
    .logo-text { display: flex; flex-direction: column; line-height: 1; }
    .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .logo-main span { color: #4ade80; }
    .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

    .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
    .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
    .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
    .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
    .nav-item i { width: 18px; text-align: center; font-size: 16px; }
    .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

    /* --- CONTENT AREA --- */
    .wrap { 
        margin-left: 250px; 
        padding: 30px 8% 60px; 
        width: calc(100% - 250px);
    }

    .card { border:1px solid #e9e9e9; border-radius:16px; padding:25px; background:#fff; box-shadow:0 8px 20px rgba(0,0,0,0.03); max-width:900px; margin-top: 20px; }
    
    h2 { font-weight: 700; color: var(--dark); font-size: 22px; margin-bottom: 5px; }
    .notice { color:var(--muted); font-size:13px; margin-bottom: 20px; }
    
    label { font-size:13px; font-weight:700; display: block; margin-bottom: 8px; color: #444; }
    input, select, textarea { width:100%; padding:12px; border-radius:10px; border:1px solid #ddd; outline: none; font-family: inherit; font-size: 14px; transition: 0.2s; }
    input:focus, select:focus, textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }

    .small { font-size:12px; color:var(--muted); margin-top: 5px; }
    hr { border:none; border-top:1px solid #eee; margin:20px 0; }

    .row { display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
    
    .btn { padding:10px 24px; border-radius:50px; border:0; cursor:pointer; font-weight:600; font-size: 14px; transition: 0.2s; }
    .btn.primary { background:var(--primary); color:#fff; }
    .btn.primary:hover { opacity: 0.9; transform: translateY(-1px); }
    .btn.gray { background:#f3f4f6; color: #555; border: 1px solid #ddd; }
    .btn.gray:hover { background: #e5e7eb; }

    @media (max-width:820px){ 
        .sidebar { display: none; }
        .wrap { margin-left: 0; width: 100%; }
    }
</style>
</head>

<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<div class="wrap">
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <h2 style="margin:0;">Peringatan Acara</h2>
        <a href="ajk_admin_calendar.php" class="btn gray" style="text-decoration:none; font-size:12px;">Kembali ke Kalendar</a>
    </div>
    
    <div class="notice">
      Hantar peringatan manual kepada penduduk. Automasi penuh memerlukan Cron Job.
    </div>

    <hr>

    <div class="row" style="align-items:flex-start; margin-bottom: 20px;">
      <div style="flex:1; min-width:260px">
        <label>Mod Hantar</label>
        <select id="mode">
          <option value="upcoming">Acara terdekat (ikut tetapan hari)</option>
          <option value="range">Julat tarikh (manual)</option>
        </select>
        <div class="small">
          * “Acara terdekat” adalah pilihan terbaik untuk peringatan harian.
        </div>
      </div>

      <div style="flex:1; min-width:260px; display:none;" id="rangeBox">
        <label>Julat Tarikh (manual)</label>
        <div class="row">
          <input type="date" id="dateStart" style="flex:1;">
          <input type="date" id="dateEnd" style="flex:1;">
        </div>
        <div class="small">
          * Sistem akan cari acara antara tarikh ini.
        </div>
      </div>
    </div>

    <div style="margin-top:12px">
      <label>Mesej Tambahan (Opsyenal)</label>
      <textarea id="extraMessage" rows="4" placeholder="Contoh: Sila bawa peralatan sendiri..."></textarea>
      <div class="small">
        Mesej ini akan disertakan dalam notifikasi peringatan.
      </div>
    </div>

    <div class="row" style="justify-content:flex-end; margin-top:25px">
      <button class="btn gray" type="button" onclick="preview()"><i class="far fa-eye"></i> Pratonton</button>
      <button class="btn primary" id="btnSend" type="button"><i class="fas fa-paper-plane"></i> Hantar Sekarang</button>
    </div>

    <div class="notice" id="msg" style="margin-top:15px; font-weight:600; color:var(--primary);"></div>
  </div>

  <div class="card" style="margin-top:20px; background:#f9fafb; border:1px dashed #ccc;">
    <h3 style="margin:0 0 10px; font-size:16px;">Nota Penting</h3>
    <ul class="notice" style="margin:0; padding-left:20px; line-height:1.6;">
      <li>Disarankan untuk menghantar peringatan melalui "notifikasi sistem" terlebih dahulu.</li>
      <li>Penghantaran E-mel pukal memerlukan konfigurasi SMTP server yang stabil.</li>
      <li>Halaman ini berfungsi walaupun tanpa E-mel (data direkodkan dalam notifikasi in-app).</li>
    </ul>
  </div>
</div>

<script>
const msg = document.getElementById('msg');
const btnSend = document.getElementById('btnSend');
const mode = document.getElementById('mode');
const rangeBox = document.getElementById('rangeBox');
const dateStart = document.getElementById('dateStart');
const dateEnd = document.getElementById('dateEnd');
const extraMessage = document.getElementById('extraMessage');

mode.addEventListener('change', ()=>{
  if(mode.value === 'range'){
    rangeBox.style.display = 'block';
  }else{
    rangeBox.style.display = 'none';
  }
});

function buildPayload(){
  const fd = new FormData();
  fd.append('action', 'send_reminders');
  fd.append('mode', mode.value);
  fd.append('extra_message', extraMessage.value || '');

  // Default channels (server will gracefully skip if not configured)
  fd.append('send_inapp', '1');
  fd.append('send_email', '1');
  fd.append('send_whatsapp', '1');

  if(mode.value === 'range'){
    fd.append('start_date', dateStart.value || '');
    fd.append('end_date', dateEnd.value || '');
  }
  return fd;
}

async function preview(){
  const extra = (extraMessage.value || '').trim();
  const text = `[PRATONTON] Peringatan Acara i-Desa:\n\n(Sistem akan senaraikan acara yang layak)\n\n${extra ? ('Mesej tambahan:\n' + extra) : ''}\n\nTerima kasih.`;
  alert(text);
}

btnSend.addEventListener('click', async ()=>{
  if(!confirm("Adakah anda pasti mahu menghantar peringatan ini?")) return;
  
  msg.textContent = 'Memproses...';
  btnSend.disabled = true;
  btnSend.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menghantar...';

  try{
    const fd = buildPayload();
    const res = await fetch('ajax_calendar_notification.php', {method:'POST', body:fd, credentials:'same-origin'});
    const json = await res.json();

    if(!json.ok){
      msg.innerHTML = `<span style="color:red"><i class="fas fa-times-circle"></i> ${json.error || 'Gagal menghantar.'}</span>`;
      return;
    }

    msg.innerHTML = `<span style="color:green"><i class="fas fa-check-circle"></i> ${(json.data && json.data.message) ? json.data.message : 'Selesai.'}</span>`;
  } catch(e){
    console.warn(e);
    msg.innerHTML = '<span style="color:red">Ralat rangkaian / server.</span>';
  } finally {
    btnSend.disabled = false;
    btnSend.innerHTML = '<i class="fas fa-paper-plane"></i> Hantar Sekarang';
  }
});
</script>
</body>
</html>