<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kehadiran Saya</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">

<style>
:root{
  --primary:#2d6a4f;
  --text:#333;
  --muted:#6b7280;
  --bg:#f7faf7;
  --card:#fff;
  --border:#eaeaea;
}
body{ margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); }
header{
  display:flex; gap:12px; align-items:flex-start; justify-content:space-between;
  padding:18px 8%; background:#fff; border-bottom:1px solid var(--border);
}
h2{ margin:0; font-size:22px; }
.notice{ color:var(--muted); font-size:13px; margin-top:4px; }
.wrap{ padding:18px 8%; }
.btn{
  padding:10px 14px; border:1px solid var(--border); border-radius:12px;
  background:#fff; cursor:pointer; text-decoration:none; color:inherit; display:inline-flex; gap:8px; align-items:center;
}
.btn.primary{ background:var(--primary); color:#fff; border-color:var(--primary); }
.btn:disabled{ opacity:.65; cursor:not-allowed; }
.card{
  background:var(--card); border:1px solid var(--border); border-radius:16px;
  padding:12px; box-shadow:0 8px 24px rgba(0,0,0,0.04);
}
table{ width:100%; border-collapse:collapse; }
th,td{ border-bottom:1px solid var(--border); padding:10px; text-align:left; font-size:14px; vertical-align:top; }
th{ font-size:13px; color:#111; background:#fff; position:sticky; top:0; }
small{ color:var(--muted); }
select{ width:100%; padding:9px; border-radius:12px; border:1px solid var(--border); background:#fff; }
.pill{
  display:inline-block; font-size:12px; padding:4px 10px; border-radius:999px; border:1px solid var(--border);
  color:#111; background:#fff;
}
.pill.cancel{ border-color:#f0b4b4; background:#fff5f5; }
.pill.done{ border-color:#b7dcc8; background:#ecf5ef; color:var(--primary); }
.toast{ margin:0 0 12px 0; padding:10px 12px; border-radius:12px; border:1px solid var(--border); background:#fff; display:none; }
.toast.show{ display:block; }
.toast.ok{ border-color:#b7dcc8; background:#ecf5ef; color:var(--primary); }
.toast.err{ border-color:#f0b4b4; background:#fff5f5; color:#b42318; }
</style>
</head>

<body>
<header>
  <div>
    <h2>Kehadiran Saya (RSVP)</h2>
    <div class="notice">Ubah status kehadiran untuk acara yang anda telah RSVP.</div>
  </div>
  <div style="display:flex; gap:10px; flex-wrap:wrap;">
    <a class="btn" href="calendar.php">Kembali Kalendar</a>
    <button class="btn" id="btnRefresh">Muat Semula</button>
  </div>
</header>

<div class="wrap">
  <div id="toast" class="toast"></div>

  <div class="card">
    <table>
      <thead>
        <tr>
          <th style="width:38%">Acara</th>
          <th style="width:26%">Tarikh/Masa</th>
          <th style="width:18%">Status RSVP</th>
          <th style="width:18%">Tindakan</th>
        </tr>
      </thead>
      <tbody id="tbody"></tbody>
    </table>
  </div>
</div>

<script>
const tbody = document.getElementById('tbody');
const toast = document.getElementById('toast');
const btnRefresh = document.getElementById('btnRefresh');

function showToast(type, msg){
  toast.className = 'toast show ' + (type === 'ok' ? 'ok' : 'err');
  toast.textContent = msg;
  window.clearTimeout(showToast._t);
  showToast._t = window.setTimeout(()=>{ toast.className='toast'; toast.textContent=''; }, 2600);
}

// Format "YYYY-MM-DD HH:MM:SS" -> ms-MY
function fmtDT(s){
  if(!s) return '-';
  // convert to ISO-ish: "YYYY-MM-DDTHH:MM:SS"
  const iso = s.replace(' ', 'T');
  const d = new Date(iso);
  if (isNaN(d.getTime())) return s; // fallback
  return d.toLocaleString('ms-MY', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' });
}

function pillForEventStatus(status){
  const span = document.createElement('span');
  span.className = 'pill';
  const st = (status || '').toLowerCase();
  if(st === 'cancelled'){
    span.className = 'pill cancel';
    span.textContent = 'Cancelled';
  } else if(st === 'completed'){
    span.className = 'pill done';
    span.textContent = 'Completed';
  } else {
    span.textContent = status || '-';
  }
  return span;
}

function makeRow(it){
  const tr = document.createElement('tr');

  // Col 1: Acara
  const td1 = document.createElement('td');
  const b = document.createElement('b');
  b.textContent = it.title || '(Tanpa tajuk)';
  td1.appendChild(b);

  const br1 = document.createElement('br');
  td1.appendChild(br1);

  const loc = document.createElement('small');
  loc.textContent = it.location ? it.location : '';
  td1.appendChild(loc);

  const br2 = document.createElement('br');
  td1.appendChild(br2);

  // status event pill
  td1.appendChild(pillForEventStatus(it.status));

  // Col 2: Tarikh/Masa
  const td2 = document.createElement('td');
  td2.innerHTML = `${fmtDT(it.start_datetime)}<br><small>${fmtDT(it.end_datetime)}</small>`;

  // Col 3: RSVP select
  const td3 = document.createElement('td');
  const sel = document.createElement('select');
  [
    ['Going','Hadir'],
    ['Interested','Berminat'],
    ['Not Going','Tidak Hadir']
  ].forEach(([v,label])=>{
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = label;
    sel.appendChild(opt);
  });
  sel.value = it.rsvp_status || 'Going';

  // Jika event cancelled, lock
  if ((it.status || '').toLowerCase() === 'cancelled') {
    sel.disabled = true;
  }

  td3.appendChild(sel);

  // Col 4: button
  const td4 = document.createElement('td');
  const btn = document.createElement('button');
  btn.className = 'btn primary';
  btn.textContent = 'Simpan';

  if (sel.disabled) {
    btn.disabled = true;
    btn.className = 'btn';
    btn.textContent = 'Tidak boleh';
  }

  btn.addEventListener('click', async ()=>{
    btn.disabled = true;
    const oldText = btn.textContent;
    btn.textContent = 'Menyimpan...';

    const ok = await save(it.event_id, sel.value);
    btn.disabled = false;
    btn.textContent = oldText;

    if(ok) showToast('ok', 'Kehadiran dikemaskini.');
  });

  td4.appendChild(btn);

  tr.appendChild(td1);
  tr.appendChild(td2);
  tr.appendChild(td3);
  tr.appendChild(td4);

  return tr;
}

async function load() {
  tbody.innerHTML = `<tr><td colspan="4"><small>Memuat...</small></td></tr>`;

  try{
    const res = await fetch('ajax_calendar_attendance.php?action=get_my_presence', {credentials:'same-origin'});
    const json = await res.json();

    if(!json.ok) {
      tbody.innerHTML = '';
      showToast('err', json.message || 'Gagal memuat data.');
      return;
    }

    const items = (json.data && json.data.items) ? json.data.items : [];
    tbody.innerHTML = '';

    if(items.length === 0) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 4;
      td.innerHTML = `<small>Belum ada rekod RSVP.</small>`;
      tr.appendChild(td);
      tbody.appendChild(tr);
      return;
    }

    items.forEach(it => tbody.appendChild(makeRow(it)));

  } catch(e){
    tbody.innerHTML = '';
    showToast('err', 'Ralat rangkaian / server.');
  }
}

async function save(eventId, status) {
  try{
    const form = new FormData();
    form.append('action','set_presence');
    form.append('event_id', eventId);
    form.append('rsvp_status', status);

    const res = await fetch('ajax_calendar_attendance.php', {
      method:'POST',
      body:form,
      credentials:'same-origin'
    });
    const json = await res.json();

    if(!json.ok) {
      showToast('err', json.message || 'Gagal simpan.');
      return false;
    }
    return true;
  } catch(e){
    showToast('err', 'Ralat rangkaian / server.');
    return false;
  }
}

btnRefresh.addEventListener('click', load);
load();
</script>
</body>
</html>
