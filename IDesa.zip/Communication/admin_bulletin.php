<?php
session_start();
include "db_connect.php";

// 1. Security Check
$role = $_SESSION['role'] ?? 'Resident';
if (!isset($_SESSION['user_id']) || !($role === 'AJK' || $role === 'Admin')) {
  header("Location: homepage.php");
  exit();
}

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$flash = "";
$flash_type = ""; // success or error

// DELETE LOGIC
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
  $id = (int)$_GET['id'];
  $att = null;
  
  // Get attachment path first
  $stmt = mysqli_prepare($conn, "SELECT attachment FROM bulletin_posts WHERE post_id=?");
  if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($res && ($row = mysqli_fetch_assoc($res))) $att = $row['attachment'] ?? null;
    mysqli_stmt_close($stmt);
  }

  // Delete Record
  $stmt = mysqli_prepare($conn, "DELETE FROM bulletin_posts WHERE post_id=?");
  if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    // Remove file
    if ($att && !preg_match('/^https?:\/\//i', $att) && file_exists($att)) {
      @unlink($att);
    }
    $flash = "Posting berjaya dipadam.";
    $flash_type = "success";
  } else {
    $flash = "Ralat: gagal padam posting.";
    $flash_type = "error";
  }
}

// SAVE/UPDATE LOGIC
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_post'])) {
  $post_id = (int)($_POST['post_id'] ?? 0);
  $title = trim((string)($_POST['title'] ?? ''));
  $category = $_POST['category'] ?? 'News';
  $content = trim((string)($_POST['content'] ?? ''));
  $event_date = $_POST['event_date'] ?? null;
  $program_date = $_POST['program_date'] ?? null;
  $location_link = trim((string)($_POST['location_link'] ?? ''));
  $is_pinned = isset($_POST['is_pinned']) ? 1 : 0;

  if ($title === '' || $content === '') {
    $flash = "Sila isi tajuk dan kandungan.";
    $flash_type = "error";
  } else {
    if (!in_array($category, ['News','Event'], true)) $category = 'News';
    $event_date = ($event_date !== '') ? $event_date : null;
    $program_date = ($program_date !== '') ? $program_date : null;
    $location_link = ($location_link !== '') ? $location_link : null;

    // File Upload
    $newAttachment = null;
    if (!empty($_FILES['attachment']['name']) && is_uploaded_file($_FILES['attachment']['tmp_name'])) {
      $uploadDir = __DIR__ . "/uploads/bulletin";
      if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);

      $orig = basename($_FILES['attachment']['name']);
      $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
      $safeBase = preg_replace('/[^a-zA-Z0-9\-_.]+/', '_', pathinfo($orig, PATHINFO_FILENAME));
      $rand = bin2hex(random_bytes(4));
      $fileName = date('Ymd_His') . "_" . $safeBase . "_" . $rand . ($ext ? ".".$ext : "");
      $destAbs = $uploadDir . "/" . $fileName;
      $destRel = "uploads/bulletin/" . $fileName;

      if (move_uploaded_file($_FILES['attachment']['tmp_name'], $destAbs)) {
        $newAttachment = $destRel;
      } else {
        $flash = "Ralat: gagal muat naik lampiran.";
        $flash_type = "error";
      }
    }

    if ($flash === "") {
      if ($post_id > 0) {
        // UPDATE Existing
        $oldAttachment = null;
        $stmt0 = mysqli_prepare($conn, "SELECT attachment FROM bulletin_posts WHERE post_id=?");
        if ($stmt0) {
          mysqli_stmt_bind_param($stmt0, "i", $post_id);
          mysqli_stmt_execute($stmt0);
          $res0 = mysqli_stmt_get_result($stmt0);
          if ($res0 && ($r0 = mysqli_fetch_assoc($res0))) $oldAttachment = $r0['attachment'] ?? null;
          mysqli_stmt_close($stmt0);
        }

        if ($newAttachment !== null) {
          $stmt = mysqli_prepare($conn, "UPDATE bulletin_posts SET title=?, category=?, content=?, event_date=?, location_link=?, attachment=?, program_date=?, is_pinned=? WHERE post_id=?");
          mysqli_stmt_bind_param($stmt, "sssssssii", $title, $category, $content, $event_date, $location_link, $newAttachment, $program_date, $is_pinned, $post_id);
        } else {
          $stmt = mysqli_prepare($conn, "UPDATE bulletin_posts SET title=?, category=?, content=?, event_date=?, location_link=?, program_date=?, is_pinned=? WHERE post_id=?");
          mysqli_stmt_bind_param($stmt, "ssssssii", $title, $category, $content, $event_date, $location_link, $program_date, $is_pinned, $post_id);
        }

        if ($stmt) {
          mysqli_stmt_execute($stmt);
          mysqli_stmt_close($stmt);
          // Cleanup old file if replaced
          if ($newAttachment !== null && $oldAttachment && !preg_match('/^https?:\/\//i', $oldAttachment)) {
            $oldAbs = __DIR__ . "/" . ltrim($oldAttachment, '/');
            if (file_exists($oldAbs)) @unlink($oldAbs);
          }
          $flash = "Posting berjaya dikemaskini.";
          $flash_type = "success";
        } else {
          $flash = "Ralat Database.";
          $flash_type = "error";
        }
      } else {
        // INSERT New
        $stmt = mysqli_prepare($conn, "INSERT INTO bulletin_posts (title, category, content, event_date, location_link, attachment, program_date, is_pinned) VALUES (?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "sssssssi", $title, $category, $content, $event_date, $location_link, $newAttachment, $program_date, $is_pinned);
        if ($stmt) {
          mysqli_stmt_execute($stmt);
          mysqli_stmt_close($stmt);
          $flash = "Posting berjaya ditambah.";
          $flash_type = "success";
        } else {
          $flash = "Ralat Database.";
          $flash_type = "error";
        }
      }
    }
  }
}

// EDIT MODE FETCH
$edit = null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  $stmt = mysqli_prepare($conn, "SELECT * FROM bulletin_posts WHERE post_id=?");
  if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($res) $edit = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);
  }
}

// LIST POSTS
$posts = [];
$res = mysqli_query($conn, "SELECT post_id, title, category, created_at, is_pinned FROM bulletin_posts ORDER BY is_pinned DESC, created_at DESC");
if ($res) while ($r = mysqli_fetch_assoc($res)) $posts[] = $r;
?>

<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Admin Buletin | i-Desa</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    :root { --p-green:#2d6a4f; --dark:#143d29; --bg:#f4f7f6; --card:#fff; --border:#eaeaea; --muted:#6b7280; --primary-btn:#40916c; }
    * { box-sizing:border-box; }
    body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); display:flex; color:#333; }

    /* --- SIDEBAR (Consistent Design) --- */
    .sidebar { width:250px; height:100vh; background:var(--dark); padding:25px 18px; position:fixed; display:flex; flex-direction:column; color:#fff; box-shadow:4px 0 15px rgba(0,0,0,0.05); z-index:100; overflow-y:auto; }
    .idesa-logo { text-decoration:none; display:flex; align-items:center; gap:10px; margin-bottom:35px; padding-left:5px; }
    .logo-mark { width:38px; height:38px; background:linear-gradient(135deg, #22c55e, #16a34a); color:#fff; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:18px; box-shadow:0 4px 10px rgba(0,0,0,0.2); }
    .logo-text { display:flex; flex-direction:column; line-height:1; }
    .logo-main { font-size:20px; font-weight:800; color:#fff; letter-spacing:-0.5px; }
    .logo-main span { color:#4ade80; }
    .logo-sub { font-size:9px; font-weight:600; color:#a3b1aa; text-transform:uppercase; margin-top:3px; letter-spacing:0.5px; }
    
    .nav-menu { display:flex; flex-direction:column; gap:6px; flex:1; }
    .nav-item { display:flex; align-items:center; gap:14px; padding:12px 18px; color:#b4cfc0; text-decoration:none; border-radius:12px; font-size:14px; font-weight:500; transition:all 0.2s ease; }
    .nav-item i { width:18px; text-align:center; font-size:16px; }
    .nav-item:hover { color:#fff; background:rgba(255,255,255,0.05); transform:translateX(3px); }
    .nav-item.active { background:rgba(255,255,255,0.15); color:#fff; font-weight:600; box-shadow:0 4px 12px rgba(0,0,0,0.1); backdrop-filter:blur(5px); }
    .divider { height:1px; background:rgba(255,255,255,0.1); margin:15px 10px; }

    /* --- CONTENT AREA --- */
    .content { margin-left:250px; padding:30px; width:calc(100% - 250px); }
    .page-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:25px; }
    .page-header h1 { margin:0; font-size:24px; color:var(--dark); font-weight:700; }
    
    /* Buttons */
    .btn { background:var(--p-green); color:white; border:none; padding:10px 20px; border-radius:10px; font-weight:600; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; gap:8px; font-size:14px; transition:0.2s; }
    .btn:hover { opacity:0.9; transform:translateY(-1px); }
    .btn.secondary { background:#fff; border:1px solid #ddd; color:#555; }
    .btn.secondary:hover { background:#f9f9f9; }
    .btn.danger { background:#fee2e2; color:#b91c1c; border:1px solid #fecaca; }
    .btn.danger:hover { background:#fecaca; }
    .btn-icon { padding:8px; border-radius:8px; }

    /* Alerts */
    .flash { padding:12px 16px; border-radius:10px; margin-bottom:20px; font-size:14px; display:flex; align-items:center; gap:10px; }
    .flash.success { background:#ecfdf5; color:#065f46; border:1px solid #a7f3d0; }
    .flash.error { background:#fef2f2; color:#991b1b; border:1px solid #fecaca; }

    /* Grid Layout */
    .grid-container { display:grid; grid-template-columns: 1.2fr 0.8fr; gap:25px; }
    @media(max-width:1100px){ .grid-container{ grid-template-columns:1fr; } }

    /* Cards */
    .card { background:var(--card); border-radius:16px; padding:25px; box-shadow:0 4px 20px rgba(0,0,0,0.03); border:1px solid var(--border); }
    .card h3 { margin:0 0 20px; font-size:18px; color:var(--dark); font-weight:600; padding-bottom:15px; border-bottom:1px solid #f0f0f0; }

    /* Form Styles */
    .form-row { display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:15px; }
    .form-group { margin-bottom:15px; }
    .form-group label { font-size:13px; font-weight:600; color:#444; display:block; margin-bottom:6px; }
    input, select, textarea { width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:10px; font-family:inherit; font-size:14px; transition:0.2s; background:#fff; }
    input:focus, select:focus, textarea:focus { border-color:var(--p-green); outline:none; box-shadow:0 0 0 3px rgba(45,106,79,0.1); }
    textarea { min-height:120px; resize:vertical; line-height:1.5; }
    .file-input-wrapper { border:1px dashed #ccc; padding:15px; border-radius:10px; background:#fafafa; text-align:center; }
    .hint { font-size:12px; color:#888; margin-top:5px; }

    /* Table */
    table { width:100%; border-collapse:collapse; font-size:14px; }
    th { text-align:left; padding:12px 15px; background:#f9fafb; color:#666; font-weight:600; border-bottom:1px solid #eee; font-size:13px; text-transform:uppercase; }
    td { padding:12px 15px; border-bottom:1px solid #eee; color:#444; vertical-align:middle; }
    tr:last-child td { border-bottom:none; }
    tr:hover td { background:#fafafa; }

    .pill { display:inline-flex; align-items:center; padding:4px 10px; border-radius:20px; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; }
    .pill.news { background:#e0f2f1; color:#00695c; }
    .pill.event { background:#fff3e0; color:#e65100; }
    .pill.pin { background:#e8eaf6; color:#283593; margin-left:5px; font-size:10px; padding:2px 8px; border:1px solid #c5cae9; }

    .actions-cell { display:flex; gap:6px; }
  </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>


  <main class="content">
    
    <div class="page-header">
      <h1>Pengurusan Buletin</h1>
      <a class="btn secondary" href="bulletin.php" target="_blank"><i class="fas fa-external-link-alt"></i> Lihat Paparan Awam</a>
    </div>

    <?php if ($flash): ?>
      <div class="flash <?php echo $flash_type; ?>">
        <i class="fas <?php echo ($flash_type=='success')?'fa-check-circle':'fa-exclamation-circle'; ?>"></i> 
        <?php echo h($flash); ?>
      </div>
    <?php endif; ?>

    <div class="grid-container">
      
      <section class="card">
        <h3><i class="fas fa-pen-to-square"></i> <?php echo $edit ? "Kemaskini Berita" : "Tambah Berita Baru"; ?></h3>
        
        <form method="post" enctype="multipart/form-data">
          <input type="hidden" name="post_id" value="<?php echo (int)($edit['post_id'] ?? 0); ?>">

          <div class="form-row">
            <div class="form-group">
              <label>Tajuk Utama</label>
              <input type="text" name="title" required placeholder="Cth: Gotong Royong Perdana" value="<?php echo h($edit['title'] ?? ''); ?>">
            </div>
            <div class="form-group">
              <label>Kategori</label>
              <select name="category">
                <option value="News" <?php echo (($edit['category'] ?? '')==='News')?'selected':''; ?>>Berita Umum (News)</option>
                <option value="Event" <?php echo (($edit['category'] ?? '')==='Event')?'selected':''; ?>>Acara (Event)</option>
              </select>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Tarikh Acara (Jika Ada)</label>
              <input type="date" name="event_date" value="<?php echo h($edit['event_date'] ?? ''); ?>">
            </div>
            <div class="form-group">
              <label>Tarikh Program (Lama)</label>
              <input type="date" name="program_date" value="<?php echo h($edit['program_date'] ?? ''); ?>">
            </div>
          </div>

          <div class="form-group">
            <label>Pautan Lokasi (Google Maps)</label>
            <input type="url" name="location_link" placeholder="https://maps.google.com/..." value="<?php echo h($edit['location_link'] ?? ''); ?>">
          </div>

          <div class="form-group">
            <label>Kandungan Berita</label>
            <textarea name="content" required placeholder="Tulis kandungan penuh di sini..."><?php echo h($edit['content'] ?? ''); ?></textarea>
          </div>

          <div class="form-group">
            <label>Lampiran / Gambar</label>
            <div class="file-input-wrapper">
              <input type="file" name="attachment" accept="image/*,.pdf,.doc,.docx">
              <div class="hint">Format: JPG, PNG, PDF. Maks 5MB.</div>
              <?php if (!empty($edit['attachment'])): ?>
                <div style="margin-top:10px; font-size:13px; color:#2d6a4f;">
                  <i class="fas fa-paperclip"></i> <a href="<?php echo h($edit['attachment']); ?>" target="_blank">Lihat Fail Semasa</a>
                </div>
              <?php endif; ?>
            </div>
          </div>

          <div style="display:flex; align-items:center; gap:10px; margin-bottom:20px; padding:10px; background:#f9fafb; border-radius:8px;">
            <input id="pin" type="checkbox" name="is_pinned" <?php echo ((int)($edit['is_pinned'] ?? 0)===1)?'checked':''; ?> style="width:auto; height:16px;">
            <label for="pin" style="margin:0; cursor:pointer;">Pin posting ini (Paparan Teratas)</label>
          </div>

          <div style="display:flex; gap:10px; margin-top:20px;">
            <button class="btn" type="submit" name="save_post"><i class="fas fa-save"></i> Simpan</button>
            
            <?php if ($edit): ?>
              <a class="btn secondary" href="admin_bulletin.php">Batal Edit</a>
            <?php else: ?>
              <button class="btn secondary" type="reset">Reset</button>
            <?php endif; ?>
          </div>

        </form>
      </section>

      <section class="card">
        <h3><i class="fas fa-list-ul"></i> Senarai Berita</h3>
        <div style="overflow-x:auto;">
          <table>
            <thead>
              <tr>
                <th width="50%">Tajuk</th>
                <th>Kategori</th>
                <th>Tindakan</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($posts)): ?>
                <tr><td colspan="3" style="text-align:center; padding:30px; color:#999;">Tiada berita direkodkan.</td></tr>
              <?php else: foreach ($posts as $p): ?>
                <tr>
                  <td>
                    <div style="font-weight:600; color:#333; line-height:1.4;">
                      <?php echo h($p['title']); ?>
                      <?php if ((int)$p['is_pinned']===1): ?>
                        <span class="pill pin"><i class="fas fa-thumbtack"></i> PIN</span>
                      <?php endif; ?>
                    </div>
                    <div style="font-size:11px; color:#888; margin-top:4px;">
                      <?php echo h(date("d M Y", strtotime($p['created_at']))); ?>
                    </div>
                  </td>
                  <td>
                    <span class="pill <?php echo ($p['category']==='Event')?'event':'news'; ?>">
                      <?php echo h($p['category']); ?>
                    </span>
                  </td>
                  <td>
                    <div class="actions-cell">
                      <a class="btn secondary btn-icon" href="admin_bulletin.php?edit=<?php echo (int)$p['post_id']; ?>" title="Edit">
                        <i class="fas fa-pen" style="font-size:12px;"></i>
                      </a>
                      <a class="btn danger btn-icon" href="admin_bulletin.php?action=delete&id=<?php echo (int)$p['post_id']; ?>" onclick="return confirm('Adakah anda pasti?')" title="Padam">
                        <i class="fas fa-trash" style="font-size:12px;"></i>
                      </a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </section>

    </div>
  </main>
</body>
</html>