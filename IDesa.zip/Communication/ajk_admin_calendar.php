<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}

include "db_connect.php";

// Pending Cadangan
$pendingProposals = 0;
$q1 = mysqli_query($conn, "SELECT COUNT(*) AS c FROM activities WHERE action_details LIKE 'CAL_PROPOSAL|STATUS=PENDING|%'");
if ($q1 && ($r=mysqli_fetch_assoc($q1))) $pendingProposals = (int)$r['c'];

// Pending Permintaan Pembatalan
$pendingCancels = 0;
$q2 = mysqli_query($conn, "SELECT COUNT(*) AS c FROM event_cancellation_requests WHERE status='Pending'");
if ($q2 && ($r=mysqli_fetch_assoc($q2))) $pendingCancels = (int)$r['c'];

$current = basename($_SERVER['PHP_SELF']);
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Urus Kalendar</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    /* 1. Global & Reset */
    * { box-sizing: border-box; }
    :root { 
        --primary: #2d6a4f; 
        --dark: #143d29; /* Deep Green Theme */
        --bg: #f4f7f6; 
        --card: #fff; 
        --text: #333; 
        --muted: #6b7280; 
        --border: #e5e7eb;
        --danger: #dc2626;
    }
    
    body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); display:flex; }

    /* --- SIDEBAR --- */
    .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; box-shadow: 4px 0 15px rgba(0,0,0,0.05); }
    
    .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
    .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
    .logo-text { display: flex; flex-direction: column; line-height: 1; }
    .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .logo-main span { color: #4ade80; }
    .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

    .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
    .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
    .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
    .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
    .nav-item i { width: 18px; text-align: center; font-size: 16px; }
    .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

    /* --- CONTENT AREA --- */
    .wrap { 
        margin-left: 250px; 
        padding: 30px 40px 60px; 
        width: calc(100% - 250px);
    }

    /* Buttons */
    .btn { padding: 10px 20px; border-radius: 50px; border: 1px solid #ddd; background: #fff; color: #555; cursor: pointer; font-weight: 600; font-size: 13px; transition: 0.2s; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; }
    .btn:hover { background: #f9fafb; transform: translateY(-1px); }
    .btn.primary { background: var(--primary); border-color: var(--primary); color: #fff; }
    .btn.primary:hover { opacity: 0.9; }
    .btn.danger { background: #fee2e2; border-color: #fecaca; color: var(--danger); }
    .btn.danger:hover { background: #fecaca; }
    .btn.small { padding: 6px 12px; font-size: 12px; }

    /* Cards & Layout */
    .card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); margin-bottom: 20px; }
    .row { display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }
    .between { justify-content: space-between; }

    h2 { margin: 0 0 5px; color: var(--dark); font-size: 24px; font-weight: 700; }
    .notice { color: var(--muted); font-size: 13px; line-height: 1.5; }
    .small { font-size: 12px; color: var(--muted); }

    /* Tabs */
    .tab-container { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
    .tabBtn { border-radius: 12px; padding: 10px 20px; font-size: 14px; border: 1px solid transparent; background: transparent; color: var(--muted); font-weight: 600; position: relative; }
    .tabBtn:hover { background: rgba(0,0,0,0.03); color: var(--primary); }
    .tabActive { background: #ecfdf5; color: var(--primary); border-color: #d1fae5; }
    
    /* Badges */
    .badgeCount { background: var(--danger); color: #fff; font-size: 10px; padding: 2px 6px; border-radius: 10px; position: absolute; top: -5px; right: -5px; box-shadow: 0 2px 5px rgba(220, 38, 38, 0.3); }
    .badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; background: #f3f4f6; color: #4b5563; }

    /* Tables */
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th { text-align: left; padding: 12px 15px; background: #f9fafb; color: #6b7280; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; border-bottom: 1px solid #e5e7eb; }
    td { padding: 14px 15px; border-bottom: 1px solid #f3f4f6; font-size: 14px; color: #374151; vertical-align: top; }
    tr:hover td { background: #fafafa; }

    /* KPI Pills */
    .kpi { display: flex; gap: 10px; margin-top: 10px; }
    .kpi .pill { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }

    /* Dialog/Modal */
    dialog { border: none; border-radius: 16px; width: 90%; max-width: 800px; padding: 30px; box-shadow: 0 20px 50px rgba(0,0,0,0.2); }
    dialog::backdrop { background: rgba(0,0,0,0.4); backdrop-filter: blur(2px); }
    .modalHead { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
    .modalHead h3 { font-size: 18px; color: var(--dark); font-weight: 700; }

    /* Forms */
    .formGrid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; color: #374151; }
    input, select, textarea { width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 10px; font-size: 14px; outline: none; transition: 0.2s; font-family: inherit; }
    input:focus, select:focus, textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }

    @media (max-width: 1000px) {
        .sidebar { display: none; }
        .wrap { margin-left: 0; width: 100%; padding: 20px; }
        .formGrid { grid-template-columns: 1fr; }
    }
</style>
</head>

<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<div class="wrap">
  
  <div class="card">
    <div class="row between">
      <div>
        <h2>Urus Kalendar</h2>
        <div class="notice">Urus acara rasmi, semak kehadiran (RSVP), dan luluskan permintaan pembatalan.</div>
        <div class="kpi">
          <span class="pill" id="pillActiveUsers"><i class="fas fa-users"></i> Pengguna aktif: -</span>
        </div>
      </div>
      
      <button class="btn primary" id="btnNew" type="button"><i class="fas fa-plus"></i> Tambah Acara</button>
    </div>
      
      <div>
            <a href="calendar.php" class="btn btn-gray">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Papan Awam
            </a>
        </div>

    <div class="tab-container">
        <a class="btn tabBtn <?php echo $current==='ajk_admin_calendar.php'?'tabActive':''; ?>" href="ajk_admin_calendar.php">
            <i class="far fa-calendar-alt"></i> Jadual
        </a>
        <a class="btn tabBtn <?php echo $current==='ajk_admin_calendar_proposals.php'?'tabActive':''; ?>" href="ajk_admin_calendar_proposals.php">
            <i class="far fa-lightbulb"></i> Cadangan 
            <?php if($pendingProposals>0): ?><span class="badgeCount"><?php echo $pendingProposals; ?></span><?php endif; ?>
        </a>
        <a class="btn tabBtn <?php echo $current==='ajk_admin_calendar_reminders.php'?'tabActive':''; ?>" href="ajk_admin_calendar_reminders.php">
            <i class="far fa-bell"></i> Peringatan
        </a>
        <a class="btn tabBtn <?php echo $current==='ajk_admin_calendar_settings.php'?'tabActive':''; ?>" href="ajk_admin_calendar_settings.php">
            <i class="fas fa-cog"></i> Tetapan
        </a>
        <a class="btn tabBtn" href="#cancelRequests">
            <i class="fas fa-ban"></i> Pembatalan
            <?php if($pendingCancels>0): ?><span class="badgeCount"><?php echo $pendingCancels; ?></span><?php endif; ?>
        </a>
        <a class="btn tabBtn" href="request_cancel_event.php"><i class="fas fa-file-signature"></i> Borang Batal</a>
    </div>
  </div>

  <div class="card">
    <div class="row between">
      <div>
        <h3 style="margin:0; font-size:18px;">Acara Bulan Ini</h3>
        <div class="small">Senarai acara yang dijadualkan.</div>
      </div>
      <button class="btn small" type="button" onclick="reloadAll()"><i class="fas fa-sync"></i> Refresh</button>
    </div>

    <div style="overflow-x:auto;">
      <table>
        <thead>
          <tr>
            <th style="width:150px">Mula</th>
            <th>Butiran Acara</th>
            <th>Kategori</th>
            <th>Status</th>
            <th>Statistik RSVP</th>
            <th style="width:200px">Tindakan</th>
          </tr>
        </thead>
        <tbody id="tbody">
          <tr><td colspan="6" class="notice" style="text-align:center; padding:20px;">Memuatkan data...</td></tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card" id="cancelRequests">
    <div class="row between">
      <div>
        <h3 style="margin:0; font-size:18px;">Permintaan Pembatalan</h3>
        <div class="small">Semak permintaan pembatalan daripada penganjur acara.</div>
      </div>
      <div class="row">
        <select id="cancelFilter" style="width:150px; padding:8px; border-radius:50px;">
          <option value="Pending" selected>Menunggu</option>
          <option value="Approved">Lulus</option>
          <option value="Rejected">Ditolak</option>
          <option value="All">Semua</option>
        </select>
        <button class="btn small" type="button" onclick="loadCancelRequests()">Tapis</button>
      </div>
    </div>

    <div style="overflow-x:auto;">
      <table>
        <thead>
          <tr>
            <th>Acara</th>
            <th>Pemohon</th>
            <th>Sebab Pembatalan</th>
            <th>Tarikh Mohon</th>
            <th>Tindakan</th>
          </tr>
        </thead>
        <tbody id="tbodyCancel">
          <tr><td colspan="5" class="notice" style="text-align:center;">Memuatkan...</td></tr>
        </tbody>
      </table>
    </div>
  </div>

</div>

<dialog id="dlgEvent">
  <div class="modalHead">
    <h3 id="dlgTitle">Tambah Acara</h3>
    <button class="btn small" type="button" onclick="dlgEvent.close()"><i class="fas fa-times"></i></button>
  </div>

  <form id="formEvent">
    <input type="hidden" name="event_id" id="event_id">

    <div class="formGrid">
      <div><label>Tajuk Acara</label><input name="title" id="title" required></div>
      <div><label>Kategori</label>
        <select name="category" id="category">
          <option>Meeting</option><option>Gotong-royong</option><option>Sports</option><option>Religious</option><option selected>Social</option><option>Emergency</option>
        </select>
      </div>
      <div><label>Tarikh Mula</label><input type="datetime-local" name="start_datetime" id="start_datetime" required></div>
      <div><label>Tarikh Tamat</label><input type="datetime-local" name="end_datetime" id="end_datetime" required></div>
    </div>

    <div style="margin-top:15px"><label>Lokasi</label><input name="location" id="location"></div>
    <div style="margin-top:15px"><label>Penerangan</label><textarea name="description" id="description" rows="3"></textarea></div>

    <div class="formGrid" style="margin-top:15px">
        <div>
            <label>Status</label>
            <select name="status" id="status">
                <option>Scheduled</option><option>Postponed</option><option>Completed</option><option>Cancelled</option>
            </select>
        </div>
        <div>
            <label>Lampiran</label>
            <input type="file" name="attachment" id="attachment" accept=".pdf,.jpg,.jpeg,.png">
        </div>
    </div>

    <div class="row between" style="margin-top:25px">
      <button class="btn danger" type="button" id="btnRequestCancel" style="display:none">Mohon Batal</button>
      <div style="flex:1"></div>
      <button class="btn" type="button" onclick="dlgEvent.close()">Batal</button>
      <button class="btn primary" type="submit">Simpan</button>
    </div>
    <div class="notice" id="msgEvent" style="margin-top:10px; text-align:right;"></div>
  </form>
</dialog>

<dialog id="dlgCancel">
  <div class="modalHead">
    <h3>Semakan Pembatalan</h3>
    <button class="btn small" type="button" onclick="dlgCancel.close()"><i class="fas fa-times"></i></button>
  </div>

  <form id="formCancel">
    <input type="hidden" name="event_id" id="cancel_event_id">
    
    <div style="background:#f9fafb; padding:15px; border-radius:10px; border:1px solid #eee; margin-bottom:15px;">
        <div class="small">ACARA BERKAITAN</div>
        <div id="cancel_event_title" style="font-weight:700; color:var(--dark); font-size:16px;"></div>
    </div>

    <label>Nota Semakan / Sebab Penolakan</label>
    <textarea name="reason" id="cancel_reason" rows="4" placeholder="Tulis nota untuk kelulusan atau sebab penolakan..."></textarea>
    <div class="small">Nota ini akan dihantar kepada pemohon.</div>

    <div class="row" style="justify-content:flex-end; margin-top:20px;">
        <button class="btn" type="button" onclick="dlgCancel.close()">Tutup</button>
        </div>
    <div class="notice" id="msgCancel" style="margin-top:10px"></div>
  </form>
</dialog>

<dialog id="dlgAttendance">
  <div class="modalHead">
    <h3 id="attTitle">Kehadiran</h3>
    <button class="btn small" type="button" onclick="dlgAttendance.close()"><i class="fas fa-times"></i></button>
  </div>

  <div id="attKpi" class="kpi"></div>

  <div style="margin-top:20px; overflow:auto; max-height:400px;">
    <table>
      <thead>
        <tr>
          <th>Nama</th>
          <th>Emel</th>
          <th>Status RSVP</th>
          <th>Masa</th>
        </tr>
      </thead>
      <tbody id="tbodyAtt">
        <tr><td colspan="4" class="notice">Memuatkan...</td></tr>
      </tbody>
    </table>
  </div>
</dialog>

<script>
/* --- Same JS Logic as before, just ensuring IDs match --- */
const tbody = document.getElementById('tbody');
const tbodyCancel = document.getElementById('tbodyCancel');
const tbodyAtt = document.getElementById('tbodyAtt');
const dlgEvent = document.getElementById('dlgEvent');
const dlgCancel = document.getElementById('dlgCancel');
const dlgAttendance = document.getElementById('dlgAttendance');
const formEvent = document.getElementById('formEvent');
const formCancel = document.getElementById('formCancel');
const msgEvent = document.getElementById('msgEvent');
const msgCancel = document.getElementById('msgCancel');
const btnRequestCancel = document.getElementById('btnRequestCancel');
const pillActiveUsers = document.getElementById('pillActiveUsers');
let ACTIVE_USERS_TOTAL = null;

function esc(s){ return (s ?? '').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function toLocalInput(dt){ if(!dt) return ''; return dt.replace(' ', 'T').slice(0,16); }
function fmtLocalDate(d){ return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; }
function monthRange(){
  const now=new Date(); return {startStr: fmtLocalDate(new Date(now.getFullYear(), now.getMonth(), 1))+' 00:00:00', endStr: fmtLocalDate(new Date(now.getFullYear(), now.getMonth()+1, 1))+' 00:00:00'};
}

async function loadEvents(){
  try{
    tbody.innerHTML = '<tr><td colspan="6" class="notice" style="text-align:center">Memuatkan...</td></tr>';
    const {startStr, endStr} = monthRange();
    const res = await fetch(`ajax_calendar.php?action=fetch_events_admin&start=${encodeURIComponent(startStr)}&end=${encodeURIComponent(endStr)}`, {credentials:'same-origin'});
    const json = await res.json();
    if(!json.ok){ tbody.innerHTML = '<tr><td colspan="6" class="notice">Ralat memuat data.</td></tr>'; return; }

    const events = (json.data && json.data.events) ? json.data.events : [];
    ACTIVE_USERS_TOTAL = (json.data && json.data.active_users_total) || '-';
    pillActiveUsers.innerHTML = `<i class="fas fa-users"></i> Pengguna aktif: ${ACTIVE_USERS_TOTAL}`;

    tbody.innerHTML = '';
    if(events.length === 0){ tbody.innerHTML = '<tr><td colspan="6" class="notice" style="text-align:center">Tiada acara bulan ini.</td></tr>'; return; }

    events.forEach(ev=>{
      const totalRsvp = Number(ev.going_count||0) + Number(ev.interested_count||0) + Number(ev.notgoing_count||0);
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><div style="font-weight:600">${esc(ev.start_datetime.slice(0,16))}</div></td>
        <td><b>${esc(ev.title)}</b><div class="small">${esc(ev.location || '')}</div></td>
        <td><span class="badge">${esc(ev.category || '')}</span></td>
        <td><span class="badge" style="background:${ev.status==='Cancelled'?'#fee2e2':''}; color:${ev.status==='Cancelled'?'#b91c1c':''}">${esc(ev.status || '')}</span></td>
        <td>
          <div style="font-size:12px">Going: <b>${ev.going_count}</b> | Interested: <b>${ev.interested_count}</b></div>
          <div class="small">Total: ${totalRsvp} / ${ACTIVE_USERS_TOTAL}</div>
        </td>
        <td>
          <div class="row" style="gap:5px">
            <button class="btn small" type="button" onclick="openEdit(${ev.event_id})"><i class="fas fa-pen"></i></button>
            <button class="btn small danger" type="button" onclick="openCancelRequest(${ev.event_id}, '${esc(ev.title)}')"><i class="fas fa-ban"></i></button>
            <button class="btn small" type="button" onclick="openAttendance(${ev.event_id}, '${esc(ev.title)}')"><i class="fas fa-list"></i></button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }catch(e){ tbody.innerHTML = '<tr><td colspan="6" class="notice">Ralat server.</td></tr>'; }
}

async function openEdit(id){
  try{
    const res = await fetch(`ajax_calendar.php?action=get_event_detail&event_id=${id}`, {credentials:'same-origin'});
    const json = await res.json();
    if(!json.ok) return alert('Gagal.');
    const ev = json.data.event;
    
    document.getElementById('dlgTitle').textContent = 'Edit Acara';
    document.getElementById('event_id').value = ev.event_id;
    document.getElementById('title').value = ev.title;
    document.getElementById('category').value = ev.category;
    document.getElementById('start_datetime').value = toLocalInput(ev.start_datetime);
    document.getElementById('end_datetime').value = toLocalInput(ev.end_datetime);
    document.getElementById('location').value = ev.location;
    document.getElementById('description').value = ev.description;
    document.getElementById('status').value = ev.status;
    
    btnRequestCancel.style.display = 'inline-flex';
    dlgEvent.showModal();
  }catch(e){ alert('Ralat.'); }
}

document.getElementById('btnNew').addEventListener('click', ()=>{
  document.getElementById('dlgTitle').textContent = 'Tambah Acara';
  formEvent.reset();
  document.getElementById('event_id').value = '';
  btnRequestCancel.style.display = 'none';
  dlgEvent.showModal();
});

formEvent.addEventListener('submit', async (e)=>{
  e.preventDefault();
  msgEvent.textContent = 'Menyimpan...';
  const fd = new FormData(formEvent);
  fd.append('action', fd.get('event_id') ? 'update_event' : 'create_event');
  try{
    const res = await fetch('ajax_calendar.php', {method:'POST', body:fd, credentials:'same-origin'});
    const json = await res.json();
    if(!json.ok) throw new Error(json.error);
    msgEvent.textContent = 'Berjaya!';
    dlgEvent.close();
    reloadAll();
  }catch(e){ msgEvent.textContent = e.message; }
});

btnRequestCancel.addEventListener('click', ()=>{
    const id = document.getElementById('event_id').value;
    const title = document.getElementById('title').value;
    if(id) { dlgEvent.close(); openCancelRequest(id, title); }
});

function openCancelRequest(id, title){
    document.getElementById('cancel_event_id').value = id;
    document.getElementById('cancel_event_title').textContent = title;
    document.getElementById('cancel_reason').value = ''; 
    dlgCancel.showModal();
}

async function loadCancelRequests(){
    try{
        tbodyCancel.innerHTML = '<tr><td colspan="5" class="notice">...</td></tr>';
        const st = document.getElementById('cancelFilter').value;
        const res = await fetch(`ajax_calendar.php?action=fetch_cancellation_requests&status=${st}`, {credentials:'same-origin'});
        const json = await res.json();
        const items = json.data?.items || [];
        tbodyCancel.innerHTML = '';
        if(items.length===0) { tbodyCancel.innerHTML = '<tr><td colspan="5" class="notice" style="text-align:center">Tiada permintaan.</td></tr>'; return; }
        
        items.forEach(it=>{
            const canAct = it.status==='Pending';
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><b>${esc(it.title)}</b></td>
                <td>${esc(it.requester_name)}</td>
                <td>${esc(it.reason)}</td>
                <td>${esc(it.requested_at)}</td>
                <td>
                    ${canAct ? `
                    <div class="row" style="gap:5px">
                        <button class="btn small primary" onclick="reviewCancel(${it.request_id}, 'Approved')">Lulus</button>
                        <button class="btn small danger" onclick="reviewCancel(${it.request_id}, 'Rejected')">Tolak</button>
                    </div>` 
                    : `<span class="badge">${esc(it.status)}</span>`}
                </td>
            `;
            tbodyCancel.appendChild(tr);
        });
    }catch(e){ tbodyCancel.innerHTML = '<tr><td colspan="5">Ralat.</td></tr>'; }
}

async function reviewCancel(id, dec){
    if(!confirm(dec + '?')) return;
    const fd = new FormData();
    fd.append('action','review_cancellation_request');
    fd.append('request_id', id);
    fd.append('decision', dec);
    try{
        await fetch('ajax_calendar.php', {method:'POST', body:fd, credentials:'same-origin'});
        loadCancelRequests();
    }catch(e){ alert('Ralat'); }
}

async function openAttendance(id, title){
    document.getElementById('attTitle').textContent = 'Kehadiran: ' + title;
    tbodyAtt.innerHTML = '<tr><td colspan="4">...</td></tr>';
    dlgAttendance.showModal();
    try{
        const res = await fetch(`ajax_calendar_attendance.php?action=get_event_attendance&event_id=${id}`, {credentials:'same-origin'});
        const json = await res.json();
        const att = json.data?.attendees || [];
        tbodyAtt.innerHTML = '';
        if(att.length===0) tbodyAtt.innerHTML = '<tr><td colspan="4" class="notice">Tiada data.</td></tr>';
        
        let counts = {Going:0, Interested:0, 'Not Going':0};
        att.forEach(a=>{
            counts[a.rsvp_status] = (counts[a.rsvp_status]||0)+1;
            const tr = document.createElement('tr');
            tr.innerHTML = `<td>${esc(a.full_name)}</td><td>${esc(a.email)}</td><td><span class="badge">${esc(a.rsvp_status)}</span></td><td>${esc(a.rsvp_date)}</td>`;
            tbodyAtt.appendChild(tr);
        });
        document.getElementById('attKpi').innerHTML = `
            <span class="pill">Hadir: ${counts.Going}</span>
            <span class="pill">Minat: ${counts.Interested}</span>
            <span class="pill">Tidak: ${counts['Not Going']}</span>
        `;
    }catch(e){ tbodyAtt.innerHTML='<tr><td colspan="4">Ralat.</td></tr>'; }
}

function reloadAll(){ loadEvents(); loadCancelRequests(); }
reloadAll();
</script>
</body>
</html>