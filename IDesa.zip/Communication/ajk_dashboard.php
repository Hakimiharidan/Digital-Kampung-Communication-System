<?php 
session_start(); 
include "db_connect.php"; 

// 1. Security Check: Strictly Block Residents
if(!isset($_SESSION['user_id']) || ($_SESSION['role'] !== 'AJK' && $_SESSION['role'] !== 'Admin')) {
    header("Location: homepage.php");
    exit();
}

$role = $_SESSION['role'];

// --- HELPER FUNCTION: CLEAN UP MESSY LOGS ---
function formatActivityLog($raw_action) {
    if (strpos($raw_action, 'CAL_EVENT_CANCEL_APPROVED') !== false) return '<span style="color:#d32f2f;">Pembatalan Acara Diluluskan</span>';
    if (strpos($raw_action, 'CAL_CANCEL_REQUEST') !== false) return 'Permohonan Batal Acara';
    
    if (strpos($raw_action, 'CAL_PROPOSAL_REVIEW') !== false) {
        if (strpos($raw_action, 'APPROVED') !== false) return '<span style="color:#2d6a4f;">Cadangan Aktiviti Diluluskan</span>';
        if (strpos($raw_action, 'REJECTED') !== false) return '<span style="color:#c62828;">Cadangan Ditolak</span>';
        return 'Semakan Cadangan';
    }
    if (strpos($raw_action, 'CAL_PROPOSAL_TRANSFER') !== false) return 'Aktiviti Dipindahkan ke Kalendar';
    if (strpos($raw_action, 'CAL_PROPOSAL') !== false) return 'Menghantar Cadangan Baru';
    if (stripos($raw_action, 'LOGIN') !== false) return 'Log Masuk Sistem';
    if (stripos($raw_action, 'LOGOUT') !== false) return 'Log Keluar';

    $parts = explode('|', $raw_action);
    return ucwords(strtolower(str_replace('_', ' ', $parts[0])));
}

// --- STATISTIC LOGIC ---
$sql_users = "SELECT COUNT(*) as total FROM users WHERE role='Resident'";
$total_users = mysqli_fetch_assoc(mysqli_query($conn, $sql_users))['total'];

$sql_daily_act = "SELECT COUNT(*) as total FROM activities WHERE DATE(created_at) = CURDATE()";
$daily_activities = mysqli_fetch_assoc(mysqli_query($conn, $sql_daily_act))['total'];

$sql_daily_visit = "SELECT COUNT(DISTINCT user_id) as total FROM activities WHERE DATE(created_at) = CURDATE()";
$daily_visitors = mysqli_fetch_assoc(mysqli_query($conn, $sql_daily_visit))['total'];

$sql_live = "SELECT COUNT(DISTINCT user_id) as total FROM activities WHERE created_at >= NOW() - INTERVAL 30 MINUTE";
$live_sessions = mysqli_fetch_assoc(mysqli_query($conn, $sql_live))['total'];
if($live_sessions == 0 && isset($_SESSION['user_id'])) { $live_sessions = 1; }

// Fetch Recent Activities
$sql = "SELECT a.*, u.full_name 
        FROM activities a 
        JOIN users u ON a.user_id = u.user_id 
        ORDER BY a.created_at DESC LIMIT 7"; 
$activities = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>i-Desa | Panel Kawalan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; }
        :root { --p-green: #2d6a4f; --dark: #1b4332; --bg: #f4f7f6; }
        body { margin: 0; font-family: 'Poppins', sans-serif; background: var(--bg); display: flex; }

        /* --- SIDEBAR REFINED DESIGN --- */
        .sidebar { 
            width: 250px; /* Reduced width */
            height: 100vh; 
            background: #143d29; /* Deep Green */
            padding: 25px 18px; 
            position: fixed; 
            display: flex;
            flex-direction: column;
            color: #ffffff;
            box-shadow: 4px 0 15px rgba(0,0,0,0.05);
            z-index: 100;
        }

        /* Logo Area (Slightly smaller) */
        .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
        .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
        .logo-text { display: flex; flex-direction: column; line-height: 1; }
        .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
        .logo-main span { color: #4ade80; }
        .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

        /* Navigation Links */
        .nav-menu { display: flex; flex-direction: column; gap: 6px; }
        
        .nav-item { 
            display: flex; align-items: center; gap: 14px; 
            padding: 12px 18px; 
            color: #b4cfc0; /* Muted text */
            text-decoration: none; 
            border-radius: 12px; 
            font-size: 14px; 
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .nav-item i { width: 18px; text-align: center; font-size: 16px; }

        .nav-item:hover { 
            color: #ffffff; 
            background: rgba(255, 255, 255, 0.05); 
            transform: translateX(3px);
        }

        /* Active State */
        .nav-item.active { 
            background: rgba(255, 255, 255, 0.15); 
            color: #ffffff; 
            font-weight: 600; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            backdrop-filter: blur(5px);
        }

        /* Divider */
        .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

        /* --- CONTENT AREA --- */
        .main-content { margin-left: 250px; padding: 40px; width: calc(100% - 250px); }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        
        /* Stats & Table Styles */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 40px; }
        .stat-card { background: white; padding: 25px; border-radius: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); display: flex; align-items: center; gap: 20px; }
        .stat-icon { width: 55px; height: 55px; border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 22px; }
        
        .icon-green { background: #e7f5ee; color: var(--p-green); }
        .icon-blue { background: #e3f2fd; color: #1976d2; }
        .icon-orange { background: #fff3e0; color: #f57c00; }
        .icon-purple { background: #f3e5f5; color: #7b1fa2; }

        .stat-info h3 { margin: 0; font-size: 28px; color: var(--dark); font-weight: 600; }
        .stat-info p { margin: 0; color: #888; font-size: 13px; font-weight: 500; }

        .table-container { background: white; border-radius: 20px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .table-container h3 { margin-bottom: 20px; color: var(--dark); }
        table { width: 100%; border-collapse: separate; border-spacing: 0 10px; }
        th { text-align: left; padding: 10px 15px; color: #888; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
        tr.data-row { background: #fff; transition: 0.2s; }
        tr.data-row:hover { background: #fcfcfc; transform: translateY(-2px); box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        td { padding: 15px; border-top: 1px solid #f0f2f5; border-bottom: 1px solid #f0f2f5; font-size: 14px; color: #444; vertical-align: middle; }
        td:first-child { border-left: 1px solid #f0f2f5; border-top-left-radius: 10px; border-bottom-left-radius: 10px; }
        td:last-child { border-right: 1px solid #f0f2f5; border-top-right-radius: 10px; border-bottom-right-radius: 10px; }
        
        .user-name { font-weight: 600; color: var(--dark); }
        .user-role { font-size: 11px; color: #999; display: block; }
        .badge { padding: 6px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
        .badge-success { background: #e7f5ee; color: #2d6a4f; }
        .badge-warning { background: #fff8e1; color: #f57c00; }
        .badge-info { background: #e3f2fd; color: #1976d2; }
    </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<div class="main-content">
    <div class="header">
        <div>
            <h1 style="margin:0;">Statistik & Aktiviti</h1>
            <p style="color:#777;">Pantauan masa nyata untuk <?php echo date('d M Y'); ?></p>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon icon-green"><i class="fas fa-wifi"></i></div>
            <div class="stat-info">
                <h3><?php echo number_format($live_sessions); ?></h3>
                <p>Sesi Aktif (Live)</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-blue"><i class="fas fa-walking"></i></div>
            <div class="stat-info">
                <h3><?php echo number_format($daily_visitors); ?></h3>
                <p>Pelawat Hari Ini</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-orange"><i class="fas fa-bolt"></i></div>
            <div class="stat-info">
                <h3><?php echo number_format($daily_activities); ?></h3>
                <p>Aktiviti Hari Ini</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon icon-purple"><i class="fas fa-users"></i></div>
            <div class="stat-info">
                <h3><?php echo number_format($total_users); ?></h3>
                <p>Jumlah Penduduk</p>
            </div>
        </div>
    </div>

    <div class="table-container">
        <h3>Log Aktiviti Terkini</h3>
        <table style="border-collapse: separate; border-spacing: 0 5px;">
            <thead>
                <tr>
                    <th width="25%">Pengguna</th>
                    <th width="45%">Butiran Tindakan</th>
                    <th width="15%">Masa</th>
                    <th width="15%">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if($activities && mysqli_num_rows($activities) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($activities)): 
                        $badgeClass = 'badge-info';
                        $statusText = 'Direkod';
                        if (strpos($row['action_details'], 'APPROVED') !== false) {
                            $badgeClass = 'badge-success';
                            $statusText = 'Selesai';
                        } elseif (strpos($row['action_details'], 'REQUEST') !== false || strpos($row['action_details'], 'PROPOSAL') !== false) {
                            $badgeClass = 'badge-warning';
                            $statusText = 'Pending';
                        }
                    ?>
                    <tr class="data-row">
                        <td>
                            <div class="user-name"><?php echo htmlspecialchars($row['full_name']); ?></div>
                            <span class="user-role">ID: <?php echo $row['user_id']; ?></span>
                        </td>
                        <td style="font-weight: 500;">
                            <?php echo formatActivityLog($row['action_details']); ?>
                        </td>
                        <td style="color:#777;">
                            <i class="far fa-clock" style="font-size:11px; margin-right:5px;"></i>
                            <?php echo date('h:i A', strtotime($row['created_at'])); ?>
                        </td>
                        <td>
                            <span class="badge <?php echo $badgeClass; ?>"><?php echo $statusText; ?></span>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="4" style="text-align:center; padding:30px; color:#999;">Tiada aktiviti direkodkan hari ini.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>