<?php
session_start();
include "db_connect.php";

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Panel AJK (Barang Hilang & Jumpa)</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* FIX: Ensures padding doesn't break the width layout */
        * { box-sizing: border-box; }

        /* Updated Theme Variables to match Dashboard */
        :root { --primary:#2d6a4f; --dark:#143d29; --text:#333; --muted:#6b7280; --bg:#f4f7f6; --card:#fff; }
        
        body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); display:flex; }

        /* --- SIDEBAR REFINED DESIGN --- */
        .sidebar { 
            width: 250px; 
            height: 100vh; 
            background: var(--dark); 
            padding: 25px 18px; 
            position: fixed; 
            display: flex;
            flex-direction: column;
            color: #ffffff;
            box-shadow: 4px 0 15px rgba(0,0,0,0.05);
            z-index: 100;
            overflow-y: auto;
        }

        /* Logo Area */
        .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
        .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
        .logo-text { display: flex; flex-direction: column; line-height: 1; }
        .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
        .logo-main span { color: #4ade80; }
        .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

        /* Navigation Links */
        .nav-menu { display: flex; flex-direction: column; gap: 6px; }
        
        .nav-item { 
            display: flex; align-items: center; gap: 14px; 
            padding: 12px 18px; 
            color: #b4cfc0; 
            text-decoration: none; 
            border-radius: 12px; 
            font-size: 14px; 
            font-weight: 500;
            transition: all 0.2s ease;
        }
        
        .nav-item i { width: 18px; text-align: center; font-size: 16px; }

        .nav-item:hover { 
            color: #ffffff; 
            background: rgba(255, 255, 255, 0.05); 
            transform: translateX(3px);
        }

        /* Active State */
        .nav-item.active { 
            background: rgba(255, 255, 255, 0.15); 
            color: #ffffff; 
            font-weight: 600; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            backdrop-filter: blur(5px);
        }

        /* Divider */
        .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

        /* --- CONTENT AREA --- */
        .wrap { margin-left: 250px; padding: 30px; width: calc(100% - 250px); }
        
        .head { display:flex; justify-content:space-between; align-items:center; gap:16px; flex-wrap:wrap; margin-bottom:20px; }
        .title { margin:0; font-size:24px; color:var(--dark); font-weight:700; }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; max-width:700px; }

        .panel { background:var(--card); border:1px solid #eaeaea; border-radius:16px; padding:20px; box-shadow:0 8px 24px rgba(0,0,0,0.04); }
        .tabs { display:flex; gap:10px; flex-wrap:wrap; }
        .tab { border:1px solid #e5e7eb; background:#fff; padding:8px 16px; border-radius:999px; cursor:pointer; font-weight:600; font-size:13px; color:#374151; transition:0.2s; }
        .tab:hover { background:#f9fafb; }
        .tab.active { border-color:#2d6a4f; background:#ecf5ef; color:#2d6a4f; }
        
        .bar { margin-top:16px; display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; }
        .pill { display:inline-flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; background:#f9fafb; border:1px solid #eee; font-size:12px; color:#666; font-weight:500; }
        
        .btn { padding:10px 16px; border-radius:10px; border:0; cursor:pointer; font-weight:600; font-size:13px; display:inline-flex; gap:8px; align-items:center; transition:0.2s; text-decoration: none; }
        .btn-primary { background:var(--primary); color:#fff; }
        .btn-primary:hover { opacity:0.9; }
        .btn-soft { background:#ecf5ef; color:var(--primary); }
        .btn-soft:hover { background:#dcfce7; }
        .btn-danger { background:#fee2e2; color:#991b1b; }
        .btn-gray { background:#f3f4f6; color:#111827; }
        .btn-gray:hover { background:#e5e7eb; }

        .table-wrap { margin-top:16px; overflow:auto; border:1px solid #eee; border-radius:12px; background:#fff; }
        table { width:100%; border-collapse:collapse; min-width:880px; }
        th, td { padding:14px 16px; text-align:left; border-bottom:1px solid #f0f0f0; font-size:13px; vertical-align:middle; }
        th { background:#f9fafb; color:#666; font-weight:600; text-transform:uppercase; font-size:12px; letter-spacing:0.5px; position:sticky; top:0; z-index:1; }
        tr:hover td { background:#fafafa; }
        
        .small { font-size:12px; color:var(--muted); }
        .badge { display:inline-flex; gap:6px; align-items:center; padding:4px 10px; border-radius:999px; font-weight:700; font-size:11px; text-transform:uppercase; }
        .badge-lost { background:#fff1f2; color:#9f1239; border:1px solid #fecdd3; }
        .badge-found { background:#ecfeff; color:#155e75; border:1px solid #a5f3fc; }
        .badge-pending { background:#fffbeb; color:#92400e; border:1px solid #fde68a; }
        .badge-published { background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; }
        .badge-claimed { background:#eff6ff; color:#1e3a8a; border:1px solid #bfdbfe; }
        .badge-rejected { background:#fef2f2; color:#7f1d1d; border:1px solid #fecaca; }

        .state { margin-top:14px; text-align:center; color:var(--muted); padding:30px; border:1px dashed #d1d5db; border-radius:12px; background:#fafafa; display:none; }

        /* Modal */
        .backdrop { position:fixed; inset:0; background:rgba(0,0,0,.45); display:none; align-items:center; justify-content:center; padding:16px; z-index:2000; }
        .modal { width:min(900px, 100%); background:#fff; border-radius:16px; overflow:hidden; box-shadow:0 30px 70px rgba(0,0,0,.25); }
        .modal-head { padding:16px 20px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #eee; background:#fafafa; }
        .modal-head h3 { margin:0; font-size:16px; color:var(--dark); font-weight:700; }
        .close { background:transparent; border:0; cursor:pointer; font-size:18px; color:#6b7280; }
        .modal-body { padding:20px; display:grid; grid-template-columns: 300px 1fr; gap:20px; }
        .img { background:#f3f4f6; border-radius:12px; overflow:hidden; height:260px; display:flex; align-items:center; justify-content:center; color:#9ca3af; border:1px solid #eee; }
        .img img { width:100%; height:100%; object-fit:cover; }
        .meta { display:flex; flex-wrap:wrap; gap:8px; margin:0 0 16px; }
        .kv { margin:0 0 8px; font-size:14px; color:#111827; }
        .kv span { color:var(--muted); font-weight:500; width:120px; display:inline-block; }
        .desc { margin-top:10px; padding:12px; border:1px solid #eee; border-radius:10px; background:#fafafa; white-space:pre-wrap; font-size:14px; color:#444; }
        textarea { width:100%; padding:12px; border-radius:10px; border:1px solid #e5e7eb; font-family:inherit; font-size:14px; box-sizing:border-box; }
        
        @media (max-width: 900px){ 
            .sidebar { display:none; }
            .wrap { margin:0; width:100%; padding:20px; }
            .modal-body { grid-template-columns:1fr; } 
            table { min-width:760px; } 
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<div class="wrap">
    <div class="head">
        <div>
            <h1 class="title">Pengurusan Barang Hilang</h1>
            <p class="sub">
                Semak laporan <b>Menunggu Pengesahan</b>, luluskan untuk dipaparkan, atau tolak dengan alasan.
            </p>
        </div>
        <div>
            <a href="lostfound_board.php" class="btn btn-gray">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Papan Awam
            </a>
        </div>
    </div>

    <div class="panel">
        <div class="tabs">
            <button class="tab active" id="tabPending" onclick="switchTab('pending')"><i class="fa-solid fa-hourglass-half"></i> Menunggu</button>
            <button class="tab" id="tabPublished" onclick="switchTab('published')"><i class="fa-solid fa-bullhorn"></i> Dipaparkan</button>
            <button class="tab" id="tabClaims" onclick="switchTab('claims')"><i class="fa-solid fa-hand"></i> Tuntutan</button>
        </div>

        <div class="bar">
            <div class="left">
                <span class="pill"><i class="fa-solid fa-circle-info"></i> Klik baris untuk butiran.</span>
                <span class="pill" id="countPill"><i class="fa-solid fa-list"></i> <span id="countText">Memuat...</span></span>
            </div>
            <div class="right">
                <button class="btn btn-soft" onclick="refresh()"><i class="fa-solid fa-rotate"></i> Refresh</button>
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th style="width:90px;">ID</th>
                        <th>Jenis</th>
                        <th>Nama / Tajuk</th>
                        <th>Kategori</th>
                        <th>Lokasi</th>
                        <th style="width:140px;">Tarikh Kejadian</th>
                        <th style="width:140px;">Status</th>
                        <th style="width:170px;">Tarikh Laporan</th>
                    </tr>
                </thead>
                <tbody id="tbody">
                    <tr><td colspan="8" class="small" style="text-align:center; padding:30px;">Memuatkan data...</td></tr>
                </tbody>
            </table>
        </div>

        <div class="state" id="stateBox">
            <i class="fa-regular fa-face-smile" style="font-size:32px; margin-bottom:10px;"></i>
            <div id="stateText">Tiada rekod untuk dipaparkan.</div>
        </div>
    </div>
</div>

<div class="backdrop" id="backdrop" onclick="closeModal(event)">
    <div class="modal" onclick="event.stopPropagation();">
        <div class="modal-head">
            <h3 id="mTitle">Butiran Laporan</h3>
            <button class="close" onclick="hideModal()" aria-label="Tutup"><i class="fa-solid fa-xmark"></i></button>
        </div>

        <div class="modal-body">
            <div class="img" id="mImg"><div><i class="fa-regular fa-image"></i> Tiada Gambar</div></div>

            <div>
                <div class="meta" id="mBadges"></div>

                <p class="kv"><span>ID:</span> <span id="mId">-</span></p>
                <p class="kv"><span>Jenis:</span> <span id="mType">-</span></p>
                <p class="kv"><span>Kategori:</span> <span id="mCat">-</span></p>
                <p class="kv"><span>Lokasi:</span> <span id="mLoc">-</span></p>
                <p class="kv"><span>Tarikh Kejadian:</span> <span id="mInc">-</span></p>
                <p class="kv"><span>Status:</span> <span id="mStatus">-</span></p>
                <p class="kv"><span>Tarikh Laporan:</span> <span id="mCreated">-</span></p>

                <div class="desc" id="mDesc">-</div>

                <div style="margin-top:16px;">
                    <div style="font-weight:700; margin-bottom:8px; font-size:13px; color:#444;">Nota / Alasan (untuk tolak / minta info / selesai)</div>
                    <textarea id="mRemarks" rows="3" placeholder="Contoh: Sila nyatakan nombor pendaftaran / gambar kurang jelas / kes selesai pada ..."></textarea>
                    <div class="small" style="margin-top:6px; color:#888;">
                        * Nota ini akan disimpan dan dihantar kepada pelapor.
                    </div>
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:20px;">
                    <button class="btn btn-primary" id="btnApprove" onclick="approve()"><i class="fa-solid fa-check"></i> Lulus & Papar</button>
                    <button class="btn btn-danger" id="btnReject" onclick="reject()"><i class="fa-solid fa-xmark"></i> Tolak</button>
                    <button class="btn btn-gray" type="button" onclick="fillRequestTemplate()">
                       <i class="fa-solid fa-pen-to-square"></i> Template Request
                    </button>
                    <button class="btn btn-gray" id="btnRequest" onclick="requestInfo()"><i class="fa-solid fa-comment-dots"></i> Minta Maklumat</button>
                    <button class="btn btn-soft" id="btnDone" onclick="setDone()"><i class="fa-solid fa-flag-checkered"></i> Tetap Selesai</button>
                    <button class="btn btn-soft" onclick="hideModal()">Tutup</button>
                </div>

                <div class="small" id="mHint" style="margin-top:10px; font-style:italic;"></div>
            </div>
        </div>
    </div>
</div>

<script>
    const AJAX_URL = "lostfound_ajax.php";

    const TYPE_BM = { "Lost":"Hilang", "Found":"Jumpa" };
    const CAT_BM = {
        "Electronics":"Elektronik","Documents":"Dokumen","Wallet/Purse":"Dompet / Beg","Keys":"Kunci",
        "Pets":"Haiwan","Clothing":"Pakaian","Other":"Lain-lain"
    };

    let currentTab = "pending";
    let currentId = null;
    let currentStatus = null;

    const tbody = document.getElementById("tbody");
    const stateBox = document.getElementById("stateBox");
    const stateText = document.getElementById("stateText");
    const countText = document.getElementById("countText");

    function badgeType(type){
        const cls = (type === "Lost") ? "badge-lost" : "badge-found";
        const text = TYPE_BM[type] || type || "-";
        return `<span class="badge ${cls}"><i class="fa-solid fa-tag"></i> ${esc(text)}</span>`;
    }

    function badgeStatus(st){
        if(st === "Pending") return `<span class="badge badge-pending"><i class="fa-solid fa-hourglass-half"></i> Menunggu</span>`;
        if(st === "Published") return `<span class="badge badge-published"><i class="fa-solid fa-bullhorn"></i> Dipaparkan</span>`;
        if(st === "Claimed") return `<span class="badge badge-claimed"><i class="fa-solid fa-flag-checkered"></i> Selesai</span>`;
        if(st === "Rejected") return `<span class="badge badge-rejected"><i class="fa-solid fa-ban"></i> Ditolak</span>`;
        return `<span class="badge"><i class="fa-solid fa-circle"></i> ${esc(st || "-")}</span>`;
    }

    function esc(s){
        return (s ?? "").toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
    }

    function setActiveTabUI(){
        document.getElementById("tabPending").classList.toggle("active", currentTab === "pending");
        document.getElementById("tabPublished").classList.toggle("active", currentTab === "published");
        document.getElementById("tabClaims").classList.toggle("active", currentTab === "claims");
    }

    function switchTab(tab){
        currentTab = tab;
        setActiveTabUI();
        refresh();
    }
    
    function fillRequestTemplate(){
        const now = new Date();
        const pad = (n)=> String(n).padStart(2,'0');
        const ts = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
        const template = `Sila jelaskan ciri barang dengan lebih terperinci:`;
        const ta = document.getElementById("mRemarks");
        if(!ta.value.trim()){ ta.value = template; } else { ta.value = ta.value.trim() + "\n\n" + template; }
        ta.focus();
    }

    async function refresh(){
        stateBox.style.display = "none";
        countText.textContent = "Memuat...";
        tbody.innerHTML = `<tr><td colspan="8" class="small" style="text-align:center; padding:30px;"><i class="fa-solid fa-spinner fa-spin"></i> Memuatkan data...</td></tr>`;

        try{
            let url = "";
            if(currentTab === "pending"){ url = `${AJAX_URL}?action=pending_list`; } 
            else if (currentTab === "published") { url = `${AJAX_URL}?action=list`; } 
            else if (currentTab === "claims") { url = `${AJAX_URL}?action=claim_list`; }

            const res = await fetch(url, { credentials:"same-origin" });
            const data = await res.json();
            if(!data || data.ok !== true) throw new Error((data && data.error) ? data.error : "Gagal memuat data.");

            const items = data.items || [];
            countText.textContent = items.length + " rekod";

            if(items.length === 0){
                tbody.innerHTML = "";
                stateBox.style.display = "block";
                stateText.textContent = (currentTab === "pending") ? "Tiada laporan menunggu pengesahan." : (currentTab === "published") ? "Tiada laporan dipaparkan." : "Tiada tuntutan baharu.";
                return;
            }

            if (currentTab === "claims") {
                tbody.innerHTML = items.map(it => {
                    const rid = it.report_id || 0;
                    return `
                        <tr style="cursor:default;">
                            <td>${rid ? ("#" + rid) : "-"}</td>
                            <td colspan="5"><b>${esc(it.message || "-")}</b></td>
                            <td>${esc(it.created_at || "-")}</td>
                            <td>
                                ${rid ? `<button class="btn btn-soft" onclick="openDetail(${rid}); event.stopPropagation();"><i class="fa-regular fa-eye"></i> Lihat</button>` : ``}
                                <button class="btn btn-gray" onclick="markClaimRead(${it.notification_id}); event.stopPropagation();"><i class="fa-solid fa-check"></i> Buang Notis</button>
                            </td>
                        </tr>
                    `;
                }).join("");
                return;
            }

            tbody.innerHTML = items.map(it => {
                const id = it.report_id;
                const type = it.type || "";
                const cat = CAT_BM[it.category] || it.category || "-";
                const st = it.status || (currentTab === "published" ? "Published" : "Pending");
                return `
                    <tr onclick="openDetail(${id})" style="cursor:pointer;">
                        <td>#${id}</td>
                        <td>${badgeType(type)}</td>
                        <td><b>${esc(it.item_name || "-")}</b></td>
                        <td>${esc(cat)}</td>
                        <td>${esc(it.location_detail || "-")}</td>
                        <td>${esc(it.incident_date || "-")}</td>
                        <td>${badgeStatus(st)}</td>
                        <td>${esc(it.created_at || "-")}</td>
                    </tr>
                `;
            }).join("");

        } catch(err){
            console.warn(err);
            tbody.innerHTML = `<tr><td colspan="8" class="small" style="text-align:center; padding:30px; color:#d32f2f;">Ralat: ${esc(err.message || "Gagal memuat data.")}</td></tr>`;
            countText.textContent = "Ralat";
        }
    }

    const backdrop = document.getElementById("backdrop");
    const mTitle = document.getElementById("mTitle");
    const mImg = document.getElementById("mImg");
    const mBadges = document.getElementById("mBadges");
    const [mId, mType, mCat, mLoc, mInc, mStatus, mCreated, mDesc, mRemarks, mHint] = 
        ["mId", "mType", "mCat", "mLoc", "mInc", "mStatus", "mCreated", "mDesc", "mRemarks", "mHint"].map(id => document.getElementById(id));
    const [btnApprove, btnReject, btnRequest, btnDone] = ["btnApprove", "btnReject", "btnRequest", "btnDone"].map(id => document.getElementById(id));

    function showModal(){ backdrop.style.display = "flex"; document.body.style.overflow = "hidden"; }
    function hideModal(){ backdrop.style.display = "none"; document.body.style.overflow = ""; currentId = null; currentStatus = null; }
    function closeModal(e){ if(e.target === backdrop) hideModal(); }

    async function openDetail(id){
        currentId = id; showModal();
        mTitle.textContent = "Memuatkan..."; mImg.innerHTML = `<div><i class="fa-solid fa-spinner fa-spin"></i></div>`;
        mBadges.innerHTML = ""; [mId, mType, mCat, mLoc, mInc, mStatus, mCreated, mDesc, mHint].forEach(el => el.textContent = "-");
        mRemarks.value = ""; setButtonsState("loading");

        try{
            const res = await fetch(`${AJAX_URL}?action=detail&id=${id}`, { credentials:"same-origin" });
            const data = await res.json();
            if(!data || data.ok !== true) throw new Error((data && data.error) ? data.error : "Gagal memuat.");
            const it = data.item;
            currentStatus = it.status;

            mTitle.textContent = it.item_name || "Butiran Laporan";
            mId.textContent = "#" + it.report_id;
            mType.textContent = TYPE_BM[it.type] || it.type; mCat.textContent = CAT_BM[it.category] || it.category;
            mLoc.textContent = it.location_detail; mInc.textContent = it.incident_date;
            mStatus.innerHTML = badgeStatus(it.status); mCreated.textContent = it.created_at; mDesc.textContent = it.description;
            mRemarks.value = it.admin_remarks || "";
            mBadges.innerHTML = badgeType(it.type) + " " + badgeStatus(it.status);
            mImg.innerHTML = (it.image_url) ? `<img src="${esc(it.image_url)}">` : `<div><i class="fa-regular fa-image"></i> Tiada Gambar</div>`;
            setButtonsState(it.status);
        } catch(err){
            mTitle.textContent = "Ralat"; mImg.innerHTML = `<div><i class="fa-solid fa-triangle-exclamation"></i></div>`;
            mHint.textContent = err.message; setButtonsState("error");
        }
    }

    function setButtonsState(status){
        [btnApprove, btnReject, btnRequest, btnDone].forEach(b => { b.disabled = true; b.style.display = "none"; });
        if(status === "loading" || status === "error") return;

        if(status === "Pending"){
            btnApprove.style.display = "inline-flex"; btnReject.style.display = "inline-flex"; btnRequest.style.display = "inline-flex";
            btnApprove.disabled = false; btnReject.disabled = false; btnRequest.disabled = false;
            mHint.textContent = "Tindakan tersedia: Lulus/Tolak/Minta Maklumat.";
        } else if(status === "Published"){
            btnDone.style.display = "inline-flex"; btnDone.disabled = false;
            mHint.textContent = "Sudah dipaparkan. Tekan 'Tetap Selesai' jika kes selesai.";
        } else {
            mHint.textContent = "Status: " + status + " (Tiada tindakan lanjut).";
        }
    }

    function lockActions(lock=true){ [btnApprove, btnReject, btnRequest, btnDone].forEach(b => { if(b.style.display !== "none") b.disabled = lock; }); }

    async function postAction(action, payload){
        const fd = new FormData(); fd.append("action", action); Object.keys(payload||{}).forEach(k => fd.append(k, payload[k]));
        const res = await fetch(AJAX_URL, { method:"POST", body: fd, credentials:"same-origin" });
        const data = await res.json();
        if(!data || data.ok !== true) throw new Error((data && data.error) ? data.error : "Tindakan gagal.");
        return data;
    }

    async function approve(){
        if(!currentId) return; lockActions(true);
        try{ await postAction("approve", { report_id: String(currentId) }); alert("Lulus."); hideModal(); refresh(); }
        catch(e){ alert(e.message); } finally { lockActions(false); }
    }
    async function reject(){
        if(!currentId) return;
        const remarks = mRemarks.value.trim(); if(remarks.length < 5) return alert("Sila isi alasan (min 5 aksara).");
        lockActions(true);
        try{ await postAction("reject", { report_id: String(currentId), remarks }); alert("Ditolak."); hideModal(); refresh(); }
        catch(e){ alert(e.message); } finally { lockActions(false); }
    }
    async function requestInfo(){
        if(!currentId) return;
        const remarks = mRemarks.value.trim(); if(remarks.length < 5) return alert("Sila tulis maklumat yg diperlukan.");
        lockActions(true);
        try{ await postAction("request_info", { report_id: String(currentId), remarks }); alert("Permintaan dihantar."); await openDetail(currentId); }
        catch(e){ alert(e.message); } finally { lockActions(false); }
    }
    async function setDone(){
        if(!currentId) return; lockActions(true);
        try{ await postAction("set_done", { report_id: String(currentId), remarks: mRemarks.value.trim() }); alert("Selesai."); hideModal(); refresh(); }
        catch(e){ alert(e.message); } finally { lockActions(false); }
    }
    async function markClaimRead(nid){
        try{ 
            const fd = new FormData(); fd.append("action", "claim_mark_read"); fd.append("notification_id", String(nid));
            await fetch(AJAX_URL, { method:"POST", body: fd, credentials:"same-origin" }); refresh(); 
        } catch(e){ alert("Ralat."); }
    }

    refresh();
</script>
</body>
</html>