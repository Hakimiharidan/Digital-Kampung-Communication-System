<?php
session_start();
include "db_connect.php";
require_once "navbar.php";
$NAV_ACTIVE = 'terms.php';
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>i-Desa | Terma & Syarat</title>

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root{
      --primary-green:#2d6a4f;
      --bg:#f7faf7;
      --card:#fff;
      --text:#1f2937;
      --muted:#6b7280;
      --border: rgba(0,0,0,.08);
    }
    *{ box-sizing:border-box; }
    body{
      margin:0;
      font-family:'Poppins',sans-serif;
      background:var(--bg);
      color:var(--text);
      min-height:100vh;
      display:flex;
      flex-direction:column;
    }
    .wrap{ padding: 26px 8% 20px; flex:1; }
    @media (max-width: 980px){ .wrap{ padding: 20px 5% 16px; } }

    .card{
      background: var(--card);
      border:1px solid var(--border);
      border-radius: 16px;
      padding: 18px;
      box-shadow: 0 10px 24px rgba(0,0,0,.06);
    }
    h1{
      margin:0 0 6px;
      color: var(--primary-green);
      font-size: 28px;
    }
    .sub{
      margin:0 0 14px;
      color: var(--muted);
      font-size: 14px;
      line-height:1.7;
    }
    .hr{ height:1px; background:rgba(0,0,0,.07); margin: 14px 0; }

    .section h2{
      margin: 16px 0 8px;
      font-size: 18px;
      color: var(--primary-green);
    }
    .section p, .section li{
      color: var(--muted);
      line-height: 1.8;
      font-size: 14px;
    }
    ul{ margin: 8px 0 0 20px; }

    .pill{
      display:inline-flex;
      align-items:center;
      gap: 8px;
      font-weight: 900;
      padding: 8px 12px;
      border-radius: 999px;
      border:1px solid rgba(45,106,79,.20);
      background: rgba(45,106,79,.06);
      color: var(--primary-green);
      font-size: 13px;
      margin-top: 10px;
    }
  </style>
</head>

<body>
<div class="wrap">
  <div class="card">
    <h1>Terma & Syarat</h1>
    <p class="sub">
      Terma & syarat ini mentadbir penggunaan sistem i-Desa. Dengan mengakses atau menggunakan sistem,
      anda bersetuju untuk mematuhi terma ini.
      <br><strong>Kemaskini terakhir:</strong> <?php echo date("d/m/Y"); ?>
    </p>

    <span class="pill"><i class="fa-solid fa-circle-info"></i> Ringkasan: Gunakan sistem secara bertanggungjawab & ikut peranan akses.</span>

    <div class="hr"></div>

    <div class="section">
      <h2>1) Akses & Akaun</h2>
      <ul>
        <li>Pengguna mesti mendaftar/ log masuk untuk menggunakan modul tertentu.</li>
        <li>Anda bertanggungjawab menjaga kerahsiaan akaun dan kata laluan.</li>
        <li>AJK/Admin mempunyai akses tambahan untuk pengurusan komuniti.</li>
      </ul>
    </div>

    <div class="section">
      <h2>2) Penggunaan Yang Dibenarkan</h2>
      <ul>
        <li>Gunakan sistem untuk tujuan komuniti kampung (aduan, berita, fasiliti, maklum balas).</li>
        <li>Pastikan maklumat yang dihantar adalah benar dan tidak mengelirukan.</li>
        <li>Elakkan kandungan berunsur fitnah, lucah, ugutan, atau melanggar undang-undang.</li>
      </ul>
    </div>

    <div class="section">
      <h2>3) Kandungan Aduan & Lampiran</h2>
      <ul>
        <li>Pengguna bertanggungjawab terhadap kandungan aduan dan gambar yang dimuat naik.</li>
        <li>AJK/Admin boleh mengemaskini status dan maklum balas untuk tujuan tindakan.</li>
      </ul>
    </div>

    <div class="section">
      <h2>4) Had Tanggungjawab</h2>
      <p>
        i-Desa disediakan untuk membantu pengurusan komuniti. Kami tidak menjamin sistem bebas daripada gangguan
        atau ralat pada setiap masa. Pengguna digalakkan melaporkan masalah teknikal kepada Admin.
      </p>
    </div>

    <div class="section">
      <h2>5) Penggantungan Akaun</h2>
      <p>
        Pentadbir berhak menggantung akaun jika terdapat penyalahgunaan sistem, aktiviti mencurigakan,
        atau pelanggaran terma & syarat.
      </p>
    </div>

    <div class="section">
      <h2>6) Perubahan Terma</h2>
      <p>
        Terma ini boleh dikemaskini dari semasa ke semasa. Penggunaan berterusan selepas perubahan dianggap
        sebagai persetujuan terhadap terma yang dikemaskini.
      </p>
    </div>

    <div class="section">
      <h2>7) Hubungi Kami</h2>
      <p>
        Untuk pertanyaan berkaitan terma, hubungi:
        <br><strong>Email:</strong> admin@idesa.com.my
        <br><strong>Telefon:</strong> +603-8733 1234
      </p>
    </div>

  </div>
</div>

<?php include "footer.php"; ?>
</body>
</html>

