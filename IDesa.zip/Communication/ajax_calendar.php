<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

include "db_connect.php";

/* -------------------------
   JSON helpers
------------------------- */
function json_ok(array $data = [], int $code = 200): void {
    http_response_code($code);
    echo json_encode(["ok" => true, "data" => $data], JSON_UNESCAPED_UNICODE);
    exit();
}
function json_fail(string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(["ok" => false, "error" => $msg], JSON_UNESCAPED_UNICODE);
    exit();
}

/* -------------------------
   Auth helpers
------------------------- */
function is_logged_in(): bool { return isset($_SESSION['user_id']); }
function current_user_id(): int { return (int)($_SESSION['user_id'] ?? 0); }
function current_user_role(): string { return (string)($_SESSION['role'] ?? 'Resident'); }

function require_login(): void {
    if (!is_logged_in()) json_fail("Sila log masuk terlebih dahulu.", 401);
}
function require_role(array $roles): void {
    $role = current_user_role();
    if (!in_array($role, $roles, true)) json_fail("Akses tidak dibenarkan.", 403);
}

/* -------------------------
   Utils
------------------------- */
function safe_trim($s, int $maxLen = 255): string {
    $s = trim((string)$s);
    if (function_exists('mb_strlen')) {
        if (mb_strlen($s) > $maxLen) $s = mb_substr($s, 0, $maxLen);
    } else {
        if (strlen($s) > $maxLen) $s = substr($s, 0, $maxLen);
    }
    return $s;
}
function valid_datetime(string $dt): bool {
    // Basic regex for YYYY-MM-DD HH:MM(:SS) or YYYY-MM-DDTHH:MM(:SS)
    return (bool)preg_match('/^\d{4}-\d{2}-\d{2}(\s|T)\d{2}:\d{2}(:\d{2})?$/', $dt);
}
function normalize_datetime(string $dt): string {
    $dt = trim($dt);
    if (strpos($dt, 'T') !== false) {
        $dt = str_replace('T', ' ', $dt);
    }
    // If missing seconds, append :00
    if (preg_match('/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}$/', $dt)) {
        $dt .= ':00';
    }
    return $dt;
}
function activity_log($conn, string $action_details): void {
    $uid = current_user_id();
    if ($uid <= 0) return;

    $stmt = mysqli_prepare($conn, "INSERT INTO activities (user_id, action_details) VALUES (?, ?)");
    if (!$stmt) return; // Silent fail if table/column issues
    mysqli_stmt_bind_param($stmt, "is", $uid, $action_details);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}
function upload_attachment(string $field, string $folderRel): ?string {
    if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) return null;
    if ($_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) return null;
    if ($_FILES[$field]['error'] !== UPLOAD_ERR_OK) json_fail("Gagal muat naik lampiran.");

    $allowedExt = ['pdf','jpg','jpeg','png'];
    $orig = $_FILES[$field]['name'] ?? '';
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) json_fail("Lampiran hanya dibenarkan PDF/JPG/PNG.");

    $uploadDir = __DIR__ . "/" . trim($folderRel, "/");
    if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);

    $safeBase = preg_replace('/[^a-zA-Z0-9._-]/', '_', pathinfo($orig, PATHINFO_FILENAME));
    $safeName = "event_" . date("Ymd_His") . "_" . bin2hex(random_bytes(4)) . "_" . $safeBase . "." . $ext;
    $target = $uploadDir . "/" . $safeName;

    if (!move_uploaded_file($_FILES[$field]['tmp_name'], $target)) json_fail("Gagal simpan lampiran.");
    return $safeName;
}

/* -------------------------
   Routing
------------------------- */
$action = trim($_POST['action'] ?? ($_GET['action'] ?? ''));
if ($action === '') json_fail("Action tidak sah.");

/* -------------------------
   Notification helpers
------------------------- */
function notify_all_active_users(mysqli $conn, ?int $eventId, string $message, string $type = 'System'): int {
    $uRes = mysqli_query($conn, "SELECT user_id FROM users WHERE account_status='Active'");
    if (!$uRes) return 0;

    $stmt = mysqli_prepare($conn, "INSERT INTO notifications (user_id, event_id, message, type, is_read, created_at) VALUES (?, ?, ?, ?, 0, NOW())");
    if (!$stmt) return 0;

    $created = 0;
    while ($u = mysqli_fetch_assoc($uRes)) {
        $uid = (int)$u['user_id'];
        $eid = $eventId !== null ? (int)$eventId : null;
        mysqli_stmt_bind_param($stmt, "iiss", $uid, $eid, $message, $type);
        if (mysqli_stmt_execute($stmt)) $created++;
    }
    mysqli_stmt_close($stmt);
    return $created;
}

function count_active_users(mysqli $conn): int {
    $res = mysqli_query($conn, "SELECT COUNT(*) AS c FROM users WHERE account_status='Active'");
    if (!$res) return 0;
    $row = mysqli_fetch_assoc($res);
    return (int)($row['c'] ?? 0);
}

function table_exists_check(mysqli $conn, string $table): bool {
    $table = mysqli_real_escape_string($conn, $table);
    $res = mysqli_query($conn, "SHOW TABLES LIKE '{$table}'");
    if (!$res) return false;
    $row = mysqli_fetch_row($res);
    return $row ? true : false;
}

function require_cancel_table(mysqli $conn): void {
    if (!table_exists_check($conn, 'event_cancellation_requests')) {
        json_fail("Jadual 'event_cancellation_requests' tiada. Sila jalankan SQL patch untuk pembatalan acara.", 500);
    }
}

/* =========================================================
   PUBLIC: fetch_events
   GET: start, end
========================================================= */
if ($action === 'fetch_events') {
    $start = normalize_datetime($_GET['start'] ?? '');
    $end   = normalize_datetime($_GET['end'] ?? '');

    if ($start === '' || $end === '') json_fail("Julat tarikh tidak lengkap.");
    if (!valid_datetime($start) || !valid_datetime($end)) json_fail("Format tarikh/masa tidak sah.");

    // Fetch events in range, excluding Cancelled
    $sql = "
        SELECT event_id, title, description, attachment, location,
               start_datetime, end_datetime, category, status, created_by
        FROM events
        WHERE start_datetime < ?
          AND end_datetime >= ?
          AND status <> 'Cancelled'
        ORDER BY start_datetime ASC
    ";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    // Logic: event starts before end range AND ends after start range (overlap logic)
    mysqli_stmt_bind_param($stmt, "ss", $end, $start);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $events = [];
    while ($row = mysqli_fetch_assoc($res)) {
        // Optional: sanitize output if needed, but JSON encode handles it mostly
        $events[] = $row;
    }
    mysqli_stmt_close($stmt);

    json_ok(["events" => $events]);
}

/* =========================================================
   ADMIN: fetch_events_admin (AJK/Admin)
   GET: start, end
   - Includes RSVP counts
========================================================= */
if ($action === 'fetch_events_admin') {
    require_login();
    require_role(['AJK','Admin']);

    $start = normalize_datetime($_GET['start'] ?? '');
    $end   = normalize_datetime($_GET['end'] ?? '');

    if ($start === '' || $end === '') json_fail("Julat tarikh tidak lengkap.");
    if (!valid_datetime($start) || !valid_datetime($end)) json_fail("Format tarikh/masa tidak sah.");

    $sql = "
        SELECT
            e.event_id, e.title, e.description, e.attachment, e.location,
            e.start_datetime, e.end_datetime, e.category, e.status, e.created_by,
            SUM(CASE WHEN ea.rsvp_status='Going' THEN 1 ELSE 0 END) AS going_count,
            SUM(CASE WHEN ea.rsvp_status='Interested' THEN 1 ELSE 0 END) AS interested_count,
            SUM(CASE WHEN ea.rsvp_status='Not Going' THEN 1 ELSE 0 END) AS notgoing_count
        FROM events e
        LEFT JOIN event_attendance ea ON ea.event_id = e.event_id
        /* Optional: verify user is active? LEFT JOIN users u ON u.user_id = ea.user_id WHERE u.account_status='Active' */
        WHERE e.start_datetime < ?
          AND e.end_datetime >= ?
          AND e.status <> 'Cancelled'
        GROUP BY e.event_id
        ORDER BY e.start_datetime ASC
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    mysqli_stmt_bind_param($stmt, "ss", $end, $start);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $events = [];
    while ($row = mysqli_fetch_assoc($res)) {
        $row['going_count'] = (int)($row['going_count'] ?? 0);
        $row['interested_count'] = (int)($row['interested_count'] ?? 0);
        $row['notgoing_count'] = (int)($row['notgoing_count'] ?? 0);
        $events[] = $row;
    }
    mysqli_stmt_close($stmt);

    json_ok([
        "events" => $events,
        "active_users_total" => count_active_users($conn)
    ]);
}

/* =========================================================
   PUBLIC: get_event_detail
   GET: event_id
========================================================= */
if ($action === 'get_event_detail') {
    $eventId = (int)($_GET['event_id'] ?? 0);
    if ($eventId <= 0) json_fail("ID acara tidak sah.");

    $stmt = mysqli_prepare($conn, "SELECT * FROM events WHERE event_id = ? LIMIT 1");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    mysqli_stmt_bind_param($stmt, "i", $eventId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $event = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$event) json_fail("Acara tidak dijumpai.", 404);
    json_ok(["event" => $event]);
}

/* =========================================================
   Protected actions (AJK/Admin only - some exceptions below)
========================================================= */
// Actions strictly for Admin/AJK
if (in_array($action, ['create_event','update_event','cancel_event','get_settings','save_settings','fetch_cancellation_requests','review_cancellation_request'], true)) {
    require_login();
    require_role(['AJK','Admin']);
}

// request_cancellation is allowed for any logged-in user (organizer role logic or just user request)
if ($action === 'request_cancellation') {
    require_login();
}

/* =========================================================
   create_event
========================================================= */
if ($action === 'create_event') {
    $title = safe_trim($_POST['title'] ?? '', 160);
    $desc  = trim((string)($_POST['description'] ?? ''));
    $loc   = safe_trim($_POST['location'] ?? '', 180);
    $start = normalize_datetime($_POST['start_datetime'] ?? '');
    $end   = normalize_datetime($_POST['end_datetime'] ?? '');
    $cat   = safe_trim($_POST['category'] ?? 'Social', 50);

    if ($title === '' || $start === '' || $end === '') json_fail("Sila lengkapkan tajuk & tarikh/masa.");
    if (!valid_datetime($start) || !valid_datetime($end)) json_fail("Format tarikh/masa tidak sah.");
    if (strtotime($end) < strtotime($start)) json_fail("Tarikh tamat mesti selepas tarikh mula.");

    $attachment = upload_attachment('attachment', 'uploads/events');

    $createdBy = current_user_id();
    $status = 'Scheduled'; // Default

    $stmt = mysqli_prepare($conn, "
        INSERT INTO events (title, description, attachment, location, start_datetime, end_datetime, category, status, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    $descDb = ($desc === '') ? null : $desc;
    $locDb  = ($loc === '') ? null : $loc;

    mysqli_stmt_bind_param($stmt, "sssssssis",
        $title, $descDb, $attachment, $locDb, $start, $end, $cat, $status, $createdBy
    );

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        json_fail("Gagal tambah acara: " . mysqli_error($conn), 500);
    }

    $newId = (int)mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);

    activity_log($conn, "CAL_EVENT_CREATE|event_id=".$newId);
    json_ok(["message" => "Acara berjaya ditambah.", "event_id" => $newId]);
}

/* =========================================================
   update_event
========================================================= */
if ($action === 'update_event') {
    $eventId = (int)($_POST['event_id'] ?? 0);
    if ($eventId <= 0) json_fail("ID acara tidak sah.");

    $title = safe_trim($_POST['title'] ?? '', 160);
    $desc  = trim((string)($_POST['description'] ?? ''));
    $loc   = safe_trim($_POST['location'] ?? '', 180);
    $start = normalize_datetime($_POST['start_datetime'] ?? '');
    $end   = normalize_datetime($_POST['end_datetime'] ?? '');
    $cat   = safe_trim($_POST['category'] ?? 'Social', 50);
    $status= safe_trim($_POST['status'] ?? 'Scheduled', 30);

    if ($title === '' || $start === '' || $end === '') json_fail("Sila lengkapkan tajuk & tarikh/masa.");
    if (!valid_datetime($start) || !valid_datetime($end)) json_fail("Format tarikh/masa tidak sah.");
    if (strtotime($end) < strtotime($start)) json_fail("Tarikh tamat mesti selepas tarikh mula.");

    // Retrieve old attachment if not replacing
    $oldAttach = null;
    $chk = mysqli_prepare($conn, "SELECT attachment FROM events WHERE event_id=? LIMIT 1");
    if ($chk) {
        mysqli_stmt_bind_param($chk, "i", $eventId);
        mysqli_stmt_execute($chk);
        $r = mysqli_stmt_get_result($chk);
        $row = mysqli_fetch_assoc($r);
        $oldAttach = $row['attachment'] ?? null;
        mysqli_stmt_close($chk);
    }

    $newAttach = upload_attachment('attachment', 'uploads/events');
    $finalAttach = $newAttach ? $newAttach : $oldAttach;

    $descDb = ($desc === '') ? null : $desc;
    $locDb  = ($loc === '') ? null : $loc;

    $stmt = mysqli_prepare($conn, "
        UPDATE events
        SET title=?, description=?, attachment=?, location=?, start_datetime=?, end_datetime=?, category=?, status=?
        WHERE event_id=?
    ");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    mysqli_stmt_bind_param($stmt, "ssssssssi",
        $title, $descDb, $finalAttach, $locDb, $start, $end, $cat, $status, $eventId
    );

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        json_fail("Gagal kemaskini acara.", 500);
    }
    mysqli_stmt_close($stmt);

    activity_log($conn, "CAL_EVENT_UPDATE|event_id=".$eventId);
    json_ok(["message" => "Acara berjaya dikemaskini."]);
}

/* =========================================================
   request_cancellation (User / AJK / Admin)
   POST: event_id, reason
   - Creates a pending request in event_cancellation_requests table
========================================================= */
if ($action === 'request_cancellation') {
    require_cancel_table($conn);

    $eventId = (int)($_POST['event_id'] ?? 0);
    $reason  = trim((string)($_POST['reason'] ?? ''));
    if ($eventId <= 0) json_fail("ID acara tidak sah.");
    if ($reason === '') json_fail("Sila isi sebab pembatalan.");
    
    // Truncate long text
    if (strlen($reason) > 1000) $reason = substr($reason, 0, 1000);

    // Validate event
    $stmt = mysqli_prepare($conn, "SELECT event_id, title, status FROM events WHERE event_id=? LIMIT 1");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);
    mysqli_stmt_bind_param($stmt, "i", $eventId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $ev = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$ev) json_fail("Acara tidak dijumpai.", 404);
    if (($ev['status'] ?? '') === 'Cancelled') json_fail("Acara ini sudah dibatalkan.");

    $uid = current_user_id();

    // Check existing pending request
    $chk = mysqli_prepare($conn, "SELECT request_id FROM event_cancellation_requests WHERE event_id=? AND status='Pending' LIMIT 1");
    if ($chk) {
        mysqli_stmt_bind_param($chk, "i", $eventId);
        mysqli_stmt_execute($chk);
        if (mysqli_num_rows(mysqli_stmt_get_result($chk)) > 0) {
            mysqli_stmt_close($chk);
            json_fail("Permintaan pembatalan untuk acara ini masih dalam proses (Pending).");
        }
        mysqli_stmt_close($chk);
    }

    // Insert Request
    $ins = mysqli_prepare($conn, "INSERT INTO event_cancellation_requests (event_id, requested_by, reason, status, requested_at) VALUES (?, ?, ?, 'Pending', NOW())");
    if (!$ins) json_fail("Ralat DB (prepare insert).", 500);
    
    mysqli_stmt_bind_param($ins, "iis", $eventId, $uid, $reason);
    if (!mysqli_stmt_execute($ins)) {
        mysqli_stmt_close($ins);
        json_fail("Gagal hantar permintaan pembatalan.", 500);
    }
    $rid = (int)mysqli_insert_id($conn);
    mysqli_stmt_close($ins);

    activity_log($conn, "CAL_CANCEL_REQUEST|request_id={$rid}|event_id={$eventId}");
    json_ok(["message" => "Permintaan pembatalan dihantar. Sila tunggu kelulusan.", "request_id" => $rid]);
}

/* =========================================================
   fetch_cancellation_requests (AJK/Admin)
   GET: status (optional) -> Pending | Approved | Rejected | All
========================================================= */
if ($action === 'fetch_cancellation_requests') {
    require_cancel_table($conn);

    $status = safe_trim($_GET['status'] ?? 'Pending', 15);
    if (!in_array($status, ['Pending','Approved','Rejected','All'], true)) $status = 'Pending';

    $whereClause = ($status === 'All') ? "1=1" : "cr.status = ?";
    
    $sql = "
        SELECT
            cr.request_id, cr.event_id, cr.reason, cr.status,
            cr.reviewer_note, cr.requested_at, cr.reviewed_at,
            cr.requested_by, cr.reviewed_by,
            e.title,
            u1.full_name AS requester_name,
            u2.full_name AS reviewer_name
        FROM event_cancellation_requests cr
        JOIN events e ON e.event_id = cr.event_id
        JOIN users u1 ON u1.user_id = cr.requested_by
        LEFT JOIN users u2 ON u2.user_id = cr.reviewed_by
        WHERE {$whereClause}
        ORDER BY cr.requested_at DESC
        LIMIT 200
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    if ($status !== 'All') {
        mysqli_stmt_bind_param($stmt, "s", $status);
    }

    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $items = [];
    while ($r = mysqli_fetch_assoc($res)) {
        $items[] = $r;
    }
    mysqli_stmt_close($stmt);

    json_ok(["items" => $items]);
}

/* =========================================================
   review_cancellation_request (AJK/Admin)
   POST: request_id, decision (Approved|Rejected), reviewer_note (optional)
========================================================= */
if ($action === 'review_cancellation_request') {
    require_cancel_table($conn);

    $requestId = (int)($_POST['request_id'] ?? 0);
    $decision  = safe_trim($_POST['decision'] ?? '', 15);
    $note      = trim((string)($_POST['reviewer_note'] ?? ''));

    if ($requestId <= 0) json_fail("ID permintaan tidak sah.");
    if (!in_array($decision, ['Approved','Rejected'], true)) json_fail("Keputusan tidak sah.");
    if (strlen($note) > 600) $note = substr($note, 0, 600);
    $noteDb = ($note === '') ? null : $note;

    // Load request details
    $stmt = mysqli_prepare($conn, "
        SELECT cr.request_id, cr.event_id, cr.status AS req_status, cr.reason,
               e.title, e.status AS event_status
        FROM event_cancellation_requests cr
        JOIN events e ON e.event_id = cr.event_id
        WHERE cr.request_id=? LIMIT 1
    ");
    if (!$stmt) json_fail("Ralat DB.", 500);
    mysqli_stmt_bind_param($stmt, "i", $requestId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_fail("Permintaan tidak dijumpai.", 404);
    if (($row['req_status'] ?? '') !== 'Pending') json_fail("Permintaan ini bukan status Pending.");

    $reviewerId = current_user_id();

    // Update Request Status
    $upd = mysqli_prepare($conn, "
        UPDATE event_cancellation_requests
        SET status=?, reviewer_note=?, reviewed_by=?, reviewed_at=NOW()
        WHERE request_id=?
    ");
    if (!$upd) json_fail("Ralat DB.", 500);
    mysqli_stmt_bind_param($upd, "ssii", $decision, $noteDb, $reviewerId, $requestId);
    if (!mysqli_stmt_execute($upd)) {
        mysqli_stmt_close($upd);
        json_fail("Gagal kemaskini status permintaan.", 500);
    }
    mysqli_stmt_close($upd);

    $eventId = (int)$row['event_id'];
    $title   = (string)$row['title'];
    $reason  = (string)$row['reason'];
    $createdNotifs = 0;

    if ($decision === 'Approved') {
        // Cancel Event in events table
        $c = mysqli_prepare($conn, "UPDATE events SET status='Cancelled' WHERE event_id=?");
        if ($c) {
            mysqli_stmt_bind_param($c, "i", $eventId);
            mysqli_stmt_execute($c);
            mysqli_stmt_close($c);
        }

        // Notify All Users
        $msg = "[ACARA DIBATALKAN] \"{$title}\" telah dibatalkan.\nSebab: {$reason}";
        if ($note) $msg .= "\nNota Admin: {$note}";
        
        $createdNotifs = notify_all_active_users($conn, $eventId, $msg, 'System');
        activity_log($conn, "CAL_EVENT_CANCEL_APPROVED|req_id={$requestId}|event_id={$eventId}");
    } else {
        activity_log($conn, "CAL_EVENT_CANCEL_REJECTED|req_id={$requestId}|event_id={$eventId}");
    }

    json_ok([
        "message" => "Permintaan berjaya dikemaskini: {$decision}.",
        "created_notifications" => $createdNotifs
    ]);
}

/* =========================================================
   get_settings / save_settings (AJK/Admin)
   Uses calendar_settings table key/value pairs
========================================================= */
if ($action === 'get_settings') {
    $res = mysqli_query($conn, "SELECT setting_key, setting_value FROM calendar_settings");
    $settings = [];
    if ($res) {
        while ($r = mysqli_fetch_assoc($res)) {
            $settings[$r['setting_key']] = $r['setting_value'];
        }
    }
    json_ok(["settings" => $settings]);
}

if ($action === 'save_settings') {
    $reminderDays  = (int)($_POST['reminder_days'] ?? 3);
    $autoSend      = ($_POST['auto_send_reminders'] ?? '0') === '1' ? '1' : '0';
    $allowConflict = strtoupper($_POST['allow_conflicting_events'] ?? 'FALSE') === 'TRUE' ? 'TRUE' : 'FALSE';

    if ($reminderDays < 1 || $reminderDays > 60) json_fail("Hari peringatan tidak sah (1-60).");

    $uid = current_user_id();
    $pairs = [
        'reminder_days' => (string)$reminderDays,
        'auto_send_reminders' => $autoSend,
        'allow_conflicting_events' => $allowConflict
    ];

    $stmt = mysqli_prepare($conn, "
        INSERT INTO calendar_settings (setting_key, setting_value, updated_by, updated_at)
        VALUES (?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value), updated_by=VALUES(updated_by), updated_at=NOW()
    ");

    if (!$stmt) json_fail("Ralat DB.", 500);

    foreach ($pairs as $k => $v) {
        mysqli_stmt_bind_param($stmt, "ssi", $k, $v, $uid);
        mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);

    activity_log($conn, "CAL_SETTINGS_SAVE");
    json_ok(["message" => "Tetapan kalendar disimpan."]);
}

// Fallback
json_fail("Action tidak sah.", 400);
?>