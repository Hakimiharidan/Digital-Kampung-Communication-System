<?php
session_start();
include "db_connect.php";

$message = "";

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Use Prepared Statements for security (SQL Injection Protection)
    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE username = ?");
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($user = mysqli_fetch_assoc($result)) {
            // Verify the hashed password
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['role'] = $user['role']; 
                
                header("Location: homepage.php");
                exit();
            } else {
                $message = "<div class='alert error'><i class='fas fa-exclamation-circle'></i> Kata laluan tidak sah.</div>";
            }
        } else {
            $message = "<div class='alert error'><i class='fas fa-user-slash'></i> Tiada akaun ditemui.</div>";
        }
        mysqli_stmt_close($stmt);
    } else {
        $message = "<div class='alert error'>Ralat pangkalan data.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Log Masuk</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { 
            --primary: #2d6a4f; 
            --accent: #4ade80;
            --glass-bg: rgba(20, 30, 25, 0.85); /* Darker glass for better contrast */
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-white: #ffffff;
            --text-gray: #d1d5db;
        }

        body { 
            margin: 0; 
            font-family: 'Poppins', sans-serif; 
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('village.png');
            background-size: cover; 
            background-position: center;
            background-attachment: fixed;
            height: 100vh; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
        }

        .glass-card {
            background: var(--glass-bg);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 50px 40px; 
            border-radius: 20px; 
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            border: 1px solid var(--glass-border);
            text-align: center;
            color: var(--text-white);
            animation: slideUp 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        }

        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        /* --- LOGO STYLING --- */
        .login-logo {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 25px;
        }
        .logo-mark {
            width: 64px; height: 64px;
            background: linear-gradient(135deg, var(--primary), var(--accent));
            color: white; border-radius: 16px;
            display: flex; align-items: center; justify-content: center;
            font-size: 28px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            margin-bottom: 12px;
            transition: transform 0.3s;
        }
        .logo-mark:hover { transform: scale(1.05) rotate(5deg); }
        
        .logo-main { font-size: 32px; font-weight: 800; color: white; line-height: 1; letter-spacing: -1px; }
        .logo-main span { color: var(--accent); }
        .logo-sub { font-size: 11px; font-weight: 500; color: var(--text-gray); text-transform: uppercase; margin-top: 5px; letter-spacing: 1px; }

        h2 { margin: 0 0 5px 0; font-weight: 600; letter-spacing: 0.5px; }
        p { color: var(--text-gray); font-size: 0.9rem; margin-bottom: 30px; margin-top: 5px; }

        /* Form Styling */
        .form-group { margin-bottom: 20px; text-align: left; position: relative; }
        .form-group label { display: block; font-size: 0.85rem; font-weight: 500; color: var(--text-gray); margin-bottom: 8px; margin-left: 5px; }

        .input-wrapper { position: relative; }
        .input-wrapper i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: var(--text-gray); transition: 0.3s; }
        
        input { 
            width: 100%; padding: 14px 15px 14px 45px; 
            background: rgba(255, 255, 255, 0.05); 
            border: 1px solid rgba(255, 255, 255, 0.15); 
            border-radius: 12px; box-sizing: border-box; 
            transition: 0.3s; color: white; font-family: inherit; font-size: 0.95rem;
        }
        /* Placeholder Transparency Fix */
        input::placeholder { color: rgba(255, 255, 255, 0.5); opacity: 1; }
        
        input:focus { border-color: var(--accent); background: rgba(255, 255, 255, 0.1); outline: none; }
        input:focus + i { color: var(--accent); }

        .btn-login { 
            width: 100%; padding: 16px; margin-top: 10px;
            background: linear-gradient(135deg, var(--primary), #40916c); 
            color: white; border: none; border-radius: 12px; 
            font-weight: 700; cursor: pointer; font-size: 1rem; 
            letter-spacing: 0.5px; transition: 0.3s; 
            box-shadow: 0 4px 15px rgba(45, 106, 79, 0.4); 
        }
        .btn-login:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(45, 106, 79, 0.5); filter: brightness(1.1); }

        .register-link { margin-top: 25px; font-size: 0.9rem; color: var(--text-gray); }
        .register-link a { color: var(--accent); text-decoration: none; font-weight: 600; transition: 0.2s; }
        .register-link a:hover { color: white; text-decoration: underline; }

        .alert { padding: 12px; border-radius: 10px; margin-bottom: 20px; font-size: 0.9rem; display: flex; align-items: center; justify-content: center; gap: 10px; }
        .error { background: rgba(220, 38, 38, 0.25); color: #fca5a5; border: 1px solid rgba(220, 38, 38, 0.4); }
    </style>
</head>
<body>

    <div class="glass-card">
        <div class="login-logo">
            <div class="logo-mark"><i class="fa-solid fa-house-chimney-window"></i></div>
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>

        <h2>Selamat Kembali</h2>
        <p>Log masuk untuk mengakses akaun anda</p>
        
        <?php echo $message; ?>

        <form method="POST">
            <div class="form-group">
                <label>Nama Pengguna</label>
                <div class="input-wrapper">
                    <input type="text" name="username" required placeholder="Cth: AliBakar" autofocus>
                    <i class="fas fa-user"></i>
                </div>
            </div>
            <div class="form-group">
                <label>Kata Laluan</label>
                <div class="input-wrapper">
                    <input type="password" name="password" required placeholder="••••••••">
                    <i class="fas fa-lock"></i>
                </div>
            </div>
            <button type="submit" name="login" class="btn-login">Log Masuk</button>
        </form>

        <div class="register-link">
            Belum mempunyai akaun? <a href="register.php">Daftar sekarang</a>
        </div>
    </div>

</body>
</html>