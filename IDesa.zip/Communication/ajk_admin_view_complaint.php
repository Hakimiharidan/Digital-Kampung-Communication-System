<?php
session_start();
include "db_connect.php";

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}

$id = (int)($_GET['id'] ?? 0);

if (!function_exists('h')) {
  function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

$statusBM = [
    'New' => 'Baru',
    'Reviewed' => 'Disemak',
    'In Progress' => 'Dalam Tindakan',
    'Resolved' => 'Selesai',
];
$statusBadge = [
    'New' => 'badge-new',
    'Reviewed' => 'badge-review',
    'In Progress' => 'badge-progress',
    'Resolved' => 'badge-done',
];

function imageUrl($img) {
    if (!$img) return null;
    $img = trim($img);
    if ($img === "") return null;
    $path = "uploads/" . $img;
    if (file_exists(__DIR__ . "/" . $path)) return $path;
    $path2 = "uploads/" . basename($img);
    if (file_exists(__DIR__ . "/" . $path2)) return $path2;
    return "uploads/" . $img;
}

$message = "";
$messageType = "success";

// Basic guard: if id missing
if ($id <= 0) {
    header("Location: complaint.php");
    exit();
}

// Update handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = $_POST['status'] ?? 'New';
    $new_reply  = trim($_POST['reply'] ?? '');

    $allowed = ['New','Reviewed','In Progress','Resolved'];
    if (!in_array($new_status, $allowed, true)) {
        $new_status = 'New';
    }

    $stmtUp = mysqli_prepare($conn, "UPDATE complaints SET status = ?, reply = ? WHERE id = ?");
    if ($stmtUp) {
        mysqli_stmt_bind_param($stmtUp, "ssi", $new_status, $new_reply, $id);
        $ok = mysqli_stmt_execute($stmtUp);
        mysqli_stmt_close($stmtUp);

        if ($ok) {
            $message = "Kemaskini berjaya disimpan.";
            $messageType = "success";
        } else {
            $message = "Ralat: " . mysqli_error($conn);
            $messageType = "error";
        }
    } else {
        $message = "Ralat: Tidak dapat sediakan query kemaskini.";
        $messageType = "error";
    }
}

// Fetch complaint (latest data after update)
$stmt = mysqli_prepare($conn, "SELECT c.*, u.full_name, u.phone FROM complaints c LEFT JOIN users u ON u.user_id = c.user_id WHERE c.id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

if (!$data) {
    header("Location: complaint.php");
    exit();
}

$displayName  = $data['full_name'] ?: ($data['complaint_name'] ?? '-');
$displayPhone = $data['complaint_phone'] ?: ($data['phone'] ?? '-');

$st    = $data['status'] ?? 'New';
$st    = ($st === '' || $st === null) ? 'New' : $st;
$bm    = $statusBM[$st] ?? $st;
$badge = $statusBadge[$st] ?? 'badge-new';
$imgUrl = imageUrl($data['image'] ?? null);
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Semak Aduan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* Base Setup */
        * { box-sizing: border-box; }
        :root { --primary-green:#2d6a4f; --dark:#143d29; --bg:#f4f7f6; --card:#fff; --text:#333; --muted:#6b7280; }
        body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); display:flex; }

        /* --- SIDEBAR (Deep Green Theme) --- */
        .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; }
        
        .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
        .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
        .logo-text { display: flex; flex-direction: column; line-height: 1; }
        .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
        .logo-main span { color: #4ade80; }
        .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

        .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
        .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
        .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
        .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
        .nav-item i { width: 18px; text-align: center; font-size: 16px; }
        .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

        /* --- MAIN CONTENT (Fixed Layout) --- */
        .wrap { 
            margin-left: 250px; /* IMPORTANT: Pushes content right of sidebar */
            padding: 30px 8% 60px; 
            width: calc(100% - 250px);
        }

        .head { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; margin-bottom:18px; }
        .title { margin:0; font-size:24px; color:var(--dark); font-weight:700; }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; }
        
        .card { background:var(--card); border-radius:16px; padding:25px; box-shadow:0 8px 20px rgba(0,0,0,0.06); border:1px solid rgba(0,0,0,0.04); margin-bottom: 20px; }
        
        .grid-2 { display:grid; grid-template-columns: 1.6fr 1fr; gap:25px; }
        @media (max-width: 1000px){ 
            .sidebar { display:none; } 
            .wrap { margin-left: 0; width: 100%; }
            .grid-2 { grid-template-columns: 1fr; } 
        }

        /* Elements */
        .badge { display:inline-flex; align-items:center; gap:8px; padding:6px 12px; border-radius:999px; font-weight:800; font-size:12px; text-transform: uppercase; }
        .badge-new{ background:#fef2f2; color:#b91c1c; border:1px solid #fecaca; }
        .badge-review{ background:#fff7ed; color:#c2410c; border:1px solid #fed7aa; }
        .badge-progress{ background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; }
        .badge-done{ background:#ecfdf5; color:#15803d; border:1px solid #bbf7d0; }

        .alert { padding:12px 14px; border-radius:12px; font-weight:700; margin: 0 0 20px 0; border:1px solid; display:flex; gap:10px; align-items:center; font-size:14px; }
        .alert.success { background:#ecfdf5; border-color:#a7f3d0; color:#065f46; }
        .alert.error { background:#fef2f2; border-color:#fecaca; color:#7f1d1d; }

        .field { margin-bottom: 15px; }
        .field label { display:block; font-weight:700; margin-bottom:8px; font-size:13px; color:#444; }
        .field textarea, .field select { width:100%; padding:12px; border-radius:10px; border:1px solid #ddd; outline:none; font-family:inherit; font-size:14px; background:#fff; }
        .field textarea:focus, .field select:focus { border-color: var(--primary-green); box-shadow:0 0 0 3px rgba(45,106,79,0.1); }

        .btn-pill { background:var(--primary-green); color:#fff !important; padding:10px 20px; border-radius:999px; font-size:14px; display:inline-flex; align-items:center; gap:8px; text-decoration:none; border:none; cursor:pointer; font-weight:600; }
        .btn-outline { border:1px solid #ddd; color:#555 !important; padding:10px 20px; border-radius:999px; font-size:14px; background:#fff; display:inline-flex; align-items:center; gap:8px; text-decoration:none; font-weight:600; }
        .btn-outline:hover { background:#f9fafb; border-color:#ccc; }

        .hr { height:1px; background:#eee; margin:15px 0; }
        .img { width:100%; max-width:400px; border-radius:12px; border:1px solid #eee; display:block; margin-top:10px; }
        
        .muted { color:var(--muted); font-size:13px; }
        .kv-row { display:flex; justify-content:space-between; padding-bottom:10px; border-bottom:1px solid #f0f0f0; margin-bottom:10px; }
        .kv-label { color:var(--muted); font-size:13px; font-weight:500; }
        .kv-val { font-weight:700; color:#333; font-size:14px; }
    </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<div class="wrap">
    <div class="head">
        <div>
            <h1 class="title">Butiran Aduan</h1>
            <p class="sub">ID Rujukan: <strong>#AD-<?php echo (int)$data['id']; ?></strong></p>
        </div>
        <div style="display:flex; gap:10px;">
            <a href="complaint.php" class="btn-outline"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
        </div>
    </div>

    <?php if ($message): ?>
        <div class="alert <?php echo ($messageType === 'success') ? 'success' : 'error'; ?>">
            <?php echo ($messageType === 'success') ? '✅' : '❌'; ?>
            <?php echo h($message); ?>
        </div>
    <?php endif; ?>

    <div class="grid-2">
        <div class="card">
            <h2 style="margin:0 0 15px; font-size:18px; color:var(--dark); border-bottom:1px solid #eee; padding-bottom:10px;">Maklumat Aduan</h2>
            
            <div class="kv-row">
                <span class="kv-label">Status Semasa</span>
                <span class="badge <?php echo h($badge); ?>"><?php echo h($bm); ?></span>
            </div>
            <div class="kv-row">
                <span class="kv-label">Tarikh Laporan</span>
                <span class="kv-val"><?php echo date('d M Y, h:i A', strtotime($data['created_at'] ?? 'now')); ?></span>
            </div>
            <div class="kv-row">
                <span class="kv-label">Pengadu</span>
                <span class="kv-val"><?php echo h($displayName); ?></span>
            </div>
            <div class="kv-row" style="border:none;">
                <span class="kv-label">No. Telefon</span>
                <span class="kv-val"><?php echo h($displayPhone); ?></span>
            </div>

            <div class="hr"></div>

            <div style="margin-bottom:5px; font-size:13px; font-weight:700; color:var(--muted); text-transform:uppercase;">Tajuk</div>
            <div style="font-weight:700; font-size:16px; color:var(--primary-green); margin-bottom:15px;"><?php echo h($data['title'] ?? ''); ?></div>

            <div style="margin-bottom:5px; font-size:13px; font-weight:700; color:var(--muted); text-transform:uppercase;">Keterangan & Lokasi</div>
            <div style="white-space:pre-wrap; line-height:1.6; background:#f9fafb; padding:15px; border-radius:10px; border:1px solid #eee; font-size:14px;"><?php echo h($data['description'] ?? ''); ?></div>

            <?php if ($imgUrl): ?>
                <div style="margin-top:20px;">
                    <div style="margin-bottom:8px; font-size:13px; font-weight:700; color:var(--muted);">Bukti Bergambar</div>
                    <a href="<?php echo h($imgUrl); ?>" target="_blank">
                        <img class="img" src="<?php echo h($imgUrl); ?>" alt="Lampiran Aduan">
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <div class="card" style="height:fit-content;">
            <h2 style="margin:0 0 15px; font-size:18px; color:var(--dark); border-bottom:1px solid #eee; padding-bottom:10px;">Tindakan AJK / Admin</h2>

            <form method="POST">
                <div class="field">
                    <label>Kemaskini Status</label>
                    <select name="status">
                        <?php foreach (['New','Reviewed','In Progress','Resolved'] as $opt): 
                            $bmOpt = $statusBM[$opt] ?? $opt;
                        ?>
                            <option value="<?php echo h($opt); ?>" <?php echo ($st === $opt) ? 'selected' : ''; ?>>
                                <?php echo h($bmOpt); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label>Maklum Balas / Catatan Penyelesaian</label>
                    <textarea name="reply" rows="8" placeholder="Tulis maklum balas kepada pengadu..."><?php echo h($data['reply'] ?? ''); ?></textarea>
                </div>

                <button type="submit" class="btn-pill" style="width:100%; justify-content:center;">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan & Kemaskini
                </button>
                
                <p style="font-size:12px; color:var(--muted); text-align:center; margin-top:15px; line-height:1.4;">
                    Maklum balas ini akan dilihat oleh pengadu pada halaman status aduan mereka.
                </p>
            </form>
        </div>
    </div>
</div>

</body>
</html>