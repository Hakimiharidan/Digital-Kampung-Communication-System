<?php
session_start();
include "db_connect.php";

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!in_array($role, ['Resident','AJK','Admin'], true)) {
    header("Location: homepage.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];

// Helper Functions
if (!function_exists('h')) {
  function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

// Fetch user info
$u_name = $_SESSION['full_name'] ?? '';
$u_phone = '';
$stmtU = mysqli_prepare($conn, "SELECT full_name, phone FROM users WHERE user_id = ? LIMIT 1");
if ($stmtU) {
    mysqli_stmt_bind_param($stmtU, "i", $user_id);
    mysqli_stmt_execute($stmtU);
    $resU = mysqli_stmt_get_result($stmtU);
    if ($rowU = mysqli_fetch_assoc($resU)) {
        $u_name = $rowU['full_name'] ?? $u_name;
        $u_phone = $rowU['phone'] ?? '';
    }
    mysqli_stmt_close($stmtU);
}

$message = "";
$messageType = "success";

function saveComplaintImage($file) {
    if (!isset($file) || !isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return null;
    $maxSize = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $maxSize) return ["error" => "Saiz gambar terlalu besar. Maksimum 5MB."];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ["jpg","jpeg","png","webp"];
    if (!in_array($ext, $allowed, true)) return ["error" => "Format gambar tidak disokong."];
    
    $baseDir = __DIR__ . "/uploads/complaints";
    if (!is_dir($baseDir)) @mkdir($baseDir, 0777, true);
    
    $safe = "complaint_" . date("Ymd_His") . "_" . bin2hex(random_bytes(4)) . "." . $ext;
    $targetPath = $baseDir . "/" . $safe;
    
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) return ["error" => "Gagal memuat naik gambar."];
    return ["path" => "complaints/" . $safe];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $phone_input = trim($_POST['complaint_phone'] ?? '');

    if ($title === "" || $description === "") {
        $message = "Sila lengkapkan tajuk dan keterangan aduan.";
        $messageType = "error";
    } else {
        $complaint_name = $u_name ?: "Penduduk";
        $complaint_phone = $u_phone ?: $phone_input;
        if ($complaint_phone === "") $complaint_phone = "-";

        $imagePath = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $img = saveComplaintImage($_FILES['image']);
            if (isset($img['error'])) {
                $message = $img['error'];
                $messageType = "error";
            } else {
                $imagePath = $img['path'];
            }
        }

        if ($messageType !== "error") {
            $status = "New";
            $stmt = mysqli_prepare($conn, "INSERT INTO complaints (user_id, complaint_name, complaint_phone, title, description, image, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "issssss", $user_id, $complaint_name, $complaint_phone, $title, $description, $imagePath, $status);
                $ok = mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);

                if ($ok) {
                    $message = "Aduan berjaya dihantar! Anda akan dialihkan...";
                    $messageType = "success";
                    echo "<script>setTimeout(function(){ window.location.href='resident_report_list.php'; }, 1200);</script>";
                } else {
                    $message = "Ralat Pangkalan Data.";
                    $messageType = "error";
                }
            } else {
                $message = "Ralat Sistem.";
                $messageType = "error";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Buat Aduan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --primary-green:#2d6a4f; --accent-brown:#6d4c41; --text-dark:#333; --bg:#f7faf7; --card:#fff; --muted:#6b7280; }
        * { box-sizing: border-box; }
        
        body { 
            margin: 0; 
            font-family: 'Poppins', sans-serif; 
            background: var(--bg); 
            color: var(--text-dark);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .wrap { 
            flex: 1; 
            width: 100%; 
            padding: 26px 8% 60px; 
            max-width: 1000px;
            margin: 0 auto;
        }

        .head { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; margin-bottom:18px; }
        .title { margin:0; font-size:28px; color:var(--primary-green); font-weight: 700; }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; }
        
        .card { background:var(--card); border-radius:16px; padding:25px; box-shadow:0 8px 20px rgba(0,0,0,0.06); border:1px solid rgba(0,0,0,0.04); }
        
        .alert { padding:12px 14px; border-radius:12px; font-weight:600; margin-bottom: 20px; border:1px solid; display:flex; align-items:center; gap:10px; font-size: 14px; }
        .alert.success { background:#ecfdf5; border-color:#a7f3d0; color:#065f46; }
        .alert.error { background:#fef2f2; border-color:#fecaca; color:#7f1d1d; }

        .field { margin-bottom: 16px; }
        .field label { display:block; font-weight:600; margin-bottom:8px; font-size: 14px; color: #444; }
        .field input, .field textarea { width:100%; padding:12px; border-radius:10px; border:1px solid #ddd; outline:none; font-family:inherit; font-size: 14px; transition: 0.2s; }
        .field input:focus, .field textarea:focus { border-color: var(--primary-green); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }
        
        .btn-pill { background:var(--primary-green); color:#fff !important; padding:12px 24px; border-radius:50px; font-size:14px; font-weight:600; display:inline-flex; align-items:center; gap:8px; border:none; cursor:pointer; text-decoration:none; transition:0.2s; }
        .btn-pill:hover { opacity: 0.9; transform: translateY(-1px); }
        
        .btn-outline { border:1px solid #ddd; color:#555 !important; padding:12px 24px; border-radius:50px; font-size:14px; font-weight:600; background:#fff; display:inline-flex; align-items:center; gap:8px; text-decoration:none; transition:0.2s; }
        .btn-outline:hover { border-color: var(--primary-green); color: var(--primary-green) !important; background: #f0fdf4; }

        .btn-admin { border:1px solid #1f2937; color:#1f2937 !important; background:#fff; padding:10px 18px; border-radius:50px; font-size:14px; display:inline-flex; align-items:center; gap:8px; text-decoration:none; font-weight: 600; }
        .btn-admin:hover { background: #f3f4f6; }

        .muted { color: #888; font-size: 13px; }
        .user-info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; background: #f9fafb; padding: 15px; border-radius: 12px; margin-bottom: 20px; border: 1px solid #eee; }
        
        @media (max-width: 600px) { .user-info-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

<?php include "navbar.php"; ?>

<div class="wrap">
    <div class="head">
        <div>
            <h1 class="title">Buat Aduan Baru</h1>
            <p class="sub">Lengkapkan borang di bawah untuk menghantar aduan kepada AJK.</p>
        </div>
        <div style="display:flex; gap:10px; align-items:center;">
            <?php if ($role === 'Admin' || $role === 'AJK'): ?>
                <a class="btn-admin" href="complaint.php">
                    <i class="fa-solid fa-user-shield"></i> Panel Staff
                </a>
            <?php endif; ?>
            
            <a class="btn-outline" href="resident_report_list.php"><i class="fa-solid fa-list"></i> Senarai Aduan</a>
        </div>
    </div>

    <div class="card">
        <?php if ($message): ?>
            <div class="alert <?php echo ($messageType === 'success') ? 'success' : 'error'; ?>">
                <?php echo ($messageType === 'success') ? '<i class="fa-solid fa-check-circle"></i>' : '<i class="fa-solid fa-circle-exclamation"></i>'; ?>
                <?php echo h($message); ?>
            </div>
        <?php endif; ?>

        <div class="user-info-grid">
            <div>
                <div class="muted">Nama Pengadu</div>
                <div style="font-weight:700; font-size:15px; color:#333;"><?php echo h($u_name ?: 'Penduduk'); ?></div>
            </div>
            <div>
                <div class="muted">No. Telefon (Profil)</div>
                <div style="font-weight:700; font-size:15px; color:#333;"><?php echo h($u_phone ?: '-'); ?></div>
            </div>
        </div>

        <form method="POST" enctype="multipart/form-data">
            
            <?php if (!$u_phone): ?>
                <div class="field">
                    <label>No. Telefon (Wajib diisi jika tiada dalam profil)</label>
                    <input type="text" name="complaint_phone" placeholder="Contoh: 0123456789" value="<?php echo h($_POST['complaint_phone'] ?? ''); ?>">
                </div>
            <?php endif; ?>

            <div class="field">
                <label>Tajuk Aduan</label>
                <input type="text" name="title" placeholder="Contoh: Lampu Jalan Rosak di Lorong 5" value="<?php echo h($_POST['title'] ?? ''); ?>" required>
            </div>

            <div class="field">
                <label>Keterangan & Lokasi</label>
                <textarea name="description" rows="5" placeholder="Sila nyatakan butiran kerosakan dan lokasi yang tepat..." required><?php echo h($_POST['description'] ?? ''); ?></textarea>
            </div>

            <div class="field">
                <label>Muat Naik Gambar (Pilihan)</label>
                <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
                <div class="muted" style="margin-top:5px;">Format: JPG/PNG/WEBP • Maksimum 5MB</div>
            </div>

            <div style="margin-top: 25px; display:flex; gap:10px;">
                <button type="submit" class="btn-pill">
                    <i class="fa-solid fa-paper-plane"></i> Hantar Aduan
                </button>
                <a href="resident_report_list.php" class="btn-outline">Batal</a>
            </div>
        </form>
    </div>
</div>

<?php include "footer.php"; ?>

</body>
</html>