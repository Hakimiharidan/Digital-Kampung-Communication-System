<?php
session_start();
include "db_connect.php";

// Security Checks
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}
$role = $_SESSION['role'] ?? 'Resident';
if (!in_array($role, ['Resident','AJK','Admin'], true)) {
    header("Location: homepage.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'Pengguna';

// Helper Functions
if (!function_exists('h')) {
    function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('bind_stmt_params')) {
    function bind_stmt_params($stmt, string $types, array &$params): bool {
        if (!$stmt) return false;
        $bind = [$stmt, $types];
        foreach ($params as $k => $v) $bind[] = &$params[$k];
        return call_user_func_array('mysqli_stmt_bind_param', $bind);
    }
}

// Data Handling (Filter & Search)
$statusBM = [ 'New' => 'Baru', 'Reviewed' => 'Disemak', 'In Progress' => 'Dalam Tindakan', 'Resolved' => 'Selesai' ];
$statusBadge = [ 'New' => 'b-new', 'Reviewed' => 'b-reviewed', 'In Progress' => 'b-progress', 'Resolved' => 'b-resolved' ];

$filter = trim($_GET['status'] ?? 'all');
$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;

$where = " WHERE user_id = ? ";
$types = "i";
$params = [$user_id];

if ($filter === 'new') { $where .= " AND (status = 'New' OR status = '' OR status IS NULL) "; }
elseif ($filter === 'progress') { $where .= " AND status IN ('Reviewed','In Progress') "; }
elseif ($filter === 'resolved') { $where .= " AND status = 'Resolved' "; }
elseif (in_array($filter, ['New','Reviewed','In Progress','Resolved'], true)) {
    $where .= " AND status = ? "; $types .= "s"; $params[] = $filter;
}

if ($q !== '') {
    $like = '%' . $q . '%';
    $where .= " AND (title LIKE ? OR description LIKE ?) ";
    $types .= "ss"; $params[] = $like; $params[] = $like;
}

// Count Query
$totalRows = 0;
$stmtC = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM complaints" . $where);
if ($stmtC) {
    $pC = $params;
    if (bind_stmt_params($stmtC, $types, $pC)) {
        mysqli_stmt_execute($stmtC);
        $resC = mysqli_stmt_get_result($stmtC);
        $totalRows = (int)(mysqli_fetch_assoc($resC)['total'] ?? 0);
    }
    mysqli_stmt_close($stmtC);
}

// Data Query
$rows = [];
$sql = "SELECT id, title, status, created_at FROM complaints" . $where . " ORDER BY created_at DESC LIMIT ? OFFSET ?";
$stmt = mysqli_prepare($conn, $sql);
if ($stmt) {
    $types2 = $types . "ii";
    $params2 = $params;
    $params2[] = $perPage;
    $params2[] = $offset;
    if (bind_stmt_params($stmt, $types2, $params2)) {
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($r = mysqli_fetch_assoc($res)) $rows[] = $r;
    }
    mysqli_stmt_close($stmt);
}

$totalPages = max(1, (int)ceil($totalRows / $perPage));
if ($page > $totalPages) $page = $totalPages;
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Senarai Aduan Saya</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* 1. Global Reset & Box Sizing */
        :root { --primary-green:#2d6a4f; --accent-brown:#6d4c41; --text-dark:#333; --bg:#f7faf7; --card:#fff; --muted:#6b7280; }
        * { box-sizing: border-box; }

        /* 2. Flex Layout for Sticky Footer */
        body { 
            margin: 0; 
            font-family: 'Poppins', sans-serif; 
            background: var(--bg); 
            color: var(--text-dark);
            display: flex; 
            flex-direction: column; 
            min-height: 100vh; /* Ensures body takes full height */
        }

        /* 3. Navbar & Footer Styling handled by includes, 
           but we ensure content pushes footer down */
        .wrap { 
            flex: 1; /* Pushes footer down */
            width: 100%; 
            padding: 26px 8% 60px; /* Padding creates the visual spacing */
            max-width: 1200px; /* Optional: Limits max width for large screens */
            margin: 0 auto; /* Centers the content */
        }

        /* --- Page Specific Styles --- */
        .head { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; margin-bottom:18px; }
        .title { margin:0; font-size:28px; color:var(--primary-green); }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; }
        
        .card { background:var(--card); border-radius:16px; padding:18px; box-shadow:0 8px 20px rgba(0,0,0,0.06); border:1px solid rgba(0,0,0,0.04); }
        .table { width:100%; border-collapse:collapse; }
        .table th, .table td { padding:12px 12px; border-bottom:1px solid rgba(0,0,0,0.06); text-align:left; font-size:14px; }
        .table th { font-size:12px; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); }
        
        .row-actions a { font-weight:800; color:var(--primary-green); text-decoration:none; }
        .row-actions a:hover { text-decoration:underline; }
        
        .badge { display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:999px; font-weight:800; font-size:12px; }
        .b-new { background:#f1f5f9; color:#334155; }
        .b-reviewed { background:#fff7ed; color:#9a3412; }
        .b-progress { background:#eff6ff; color:#1d4ed8; }
        .b-resolved { background:#dcfce7; color:#166534; }
        
        .filters { display:flex; gap:10px; flex-wrap:wrap; }
        .filters input, .filters select { padding:10px 12px; border-radius:12px; border:1px solid rgba(0,0,0,0.12); font-family:inherit; }
        .pager { display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-top:14px; }
        
        .panel { display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
        .panel .btn-pill { background:var(--primary-green); color:#fff !important; padding:10px 18px; border-radius:999px; font-size:14px; display:inline-flex; align-items:center; gap:8px; text-decoration:none; border:none; }
        .panel .btn-outline { border:1px solid var(--primary-green); color:var(--primary-green) !important; padding:10px 18px; border-radius:999px; font-size:14px; background:#fff; display:inline-flex; align-items:center; gap:8px; text-decoration:none; }
        .panel .btn-admin { border:1px solid #1f2937; color:#1f2937 !important; background:#fff; padding:10px 18px; border-radius:999px; font-size:14px; display:inline-flex; align-items:center; gap:8px; text-decoration:none; }
        .panel .btn-admin:hover { background: #f3f4f6; }

        @media (max-width: 980px){ .wrap{padding:20px 5% 50px;} }
    </style>
</head>
<body>

    <?php include "navbar.php"; ?>

    <div class="wrap">
        <div class="head">
            <div>
                <h1 class="title">Senarai Aduan Saya</h1>
                <p class="sub">Hai <strong><?php echo h($full_name); ?></strong>. Ini adalah rekod aduan yang anda telah hantar.</p>
            </div>
            <div class="panel">
                <?php if ($role === 'Admin' || $role === 'AJK'): ?>
                    <a class="btn-admin" href="complaint.php">
                        <i class="fa-solid fa-user-shield"></i> Panel Staff
                    </a>
                <?php endif; ?>
                
                <a class="btn-pill" href="resident_add_report.php"><i class="fa-solid fa-pen-to-square"></i> Aduan Baru</a>
            </div>
        </div>

        <div class="card">
            <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; align-items:flex-end;">
                <div>
                    <h2 style="margin:0; font-size:18px; color:var(--primary-green);">Rekod Aduan</h2>
                    <p class="sub" style="margin-top:4px;">Klik <strong>Lihat</strong> untuk butiran & maklum balas AJK.</p>
                </div>
                <form method="GET" class="filters">
                    <select name="status">
                        <option value="all" <?php echo ($filter==='all')?'selected':''; ?>>Semua Status</option>
                        <option value="new" <?php echo ($filter==='new')?'selected':''; ?>>Baru</option>
                        <option value="progress" <?php echo ($filter==='progress')?'selected':''; ?>>Dalam Proses</option>
                        <option value="resolved" <?php echo ($filter==='resolved')?'selected':''; ?>>Selesai</option>
                    </select>
                    <input type="text" name="q" placeholder="Cari tajuk / butiran..." value="<?php echo h($q); ?>">
                    <button class="btn-pill" type="submit" style="border:none; cursor:pointer;"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
                </form>
            </div>

            <div style="overflow:auto; margin-top:12px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tajuk</th>
                            <th>Tarikh</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($rows)): ?>
                        <tr><td colspan="5" class="sub" style="text-align:center; padding:20px;">Tiada rekod yang sepadan.</td></tr>
                    <?php else: foreach ($rows as $r): 
                        $st = $r['status'] ?: 'New';
                        $bm = $statusBM[$st] ?? $st;
                        $badge = $statusBadge[$st] ?? 'b-new';
                        $dateTxt = ($r['created_at']) ? date('d/m/Y', strtotime($r['created_at'])) : '-';
                    ?>
                        <tr>
                            <td>#AD-<?php echo (int)$r['id']; ?></td>
                            <td><?php echo h($r['title']); ?></td>
                            <td><?php echo h($dateTxt); ?></td>
                            <td><span class="badge <?php echo h($badge); ?>"><?php echo h($bm); ?></span></td>
                            <td class="row-actions"><a href="resident_detail_report.php?id=<?php echo (int)$r['id']; ?>">Lihat</a></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="pager">
                <div class="sub">Jumlah rekod: <strong><?php echo (int)$totalRows; ?></strong></div>
                <div class="panel">
                    <?php $base = "resident_report_list.php?status=" . urlencode($filter) . "&q=" . urlencode($q); ?>
                    <a class="btn-outline" href="<?php echo h($base . "&page=" . max(1, $page-1)); ?>" <?php echo ($page<=1)?'style="pointer-events:none; opacity:.5;"':''; ?>><i class="fa-solid fa-arrow-left"></i></a>
                    <a class="btn-outline" href="<?php echo h($base . "&page=" . min($totalPages, $page+1)); ?>" <?php echo ($page>=$totalPages)?'style="pointer-events:none; opacity:.5;"':''; ?>><i class="fa-solid fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>

    <?php include "footer.php"; ?>

</body>
</html>