<?php
session_start();
include "db_connect.php";

$isLoggedIn = isset($_SESSION['user_id']);
$role = $_SESSION['role'] ?? 'Resident';
$dashboardLink = ($role === 'AJK' || $role === 'Admin') ? "ajk_dashboard.php" : "profile_management.php";

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function isEmergencyTitle(string $title): bool {
  $t = mb_strtolower($title);
  return (strpos($t, 'emergency') !== false) || (strpos($title, '🚨') !== false);
}

// Handle feedback submission
$flash = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_feedback'])) {
    $post_id = (int)($_POST['post_id'] ?? 0);
    $feedback_text = trim((string)($_POST['feedback_text'] ?? ''));

    if ($post_id > 0 && $feedback_text !== '') {
        $stmt = mysqli_prepare($conn, "INSERT INTO bulletin_feedback (post_id, feedback_text) VALUES (?, ?)");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "is", $post_id, $feedback_text);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            $flash = "Maklum balas berjaya dihantar.";
        } else {
            $flash = "Ralat: tidak dapat simpan maklum balas.";
        }
    } else {
        $flash = "Sila isi maklum balas dengan lengkap.";
    }
}

// Filters (UI)
$category = $_GET['category'] ?? 'All';
$allowedCat = ['All','Announcement','Event','Emergency'];
if (!in_array($category, $allowedCat, true)) $category = 'All';

$q = trim((string)($_GET['q'] ?? ''));

// Highlight: latest posts within 7 days (max 3) across ALL categories
$hotPosts = [];
if ($conn) {
  $sqlHot = "SELECT * FROM bulletin_posts\n            WHERE created_at >= (NOW() - INTERVAL 7 DAY)\n            ORDER BY\n              (CASE WHEN (title LIKE '%EMERGENCY%' OR title LIKE '%🚨%') THEN 2 ELSE 0 END) DESC,\n              is_pinned DESC,\n              created_at DESC\n            LIMIT 3";
  $resHot = mysqli_query($conn, $sqlHot);
  if ($resHot) while ($r = mysqli_fetch_assoc($resHot)) $hotPosts[] = $r;
}

// Build query for main list (safe)
$conds = [];
$types = '';
$params = [];

if ($category === 'Event') {
  $conds[] = "category = 'Event'";
} elseif ($category === 'Announcement') {
  $conds[] = "category = 'News' AND (title NOT LIKE '%EMERGENCY%' AND title NOT LIKE '%🚨%')";
} elseif ($category === 'Emergency') {
  $conds[] = "category = 'News' AND (title LIKE '%EMERGENCY%' OR title LIKE '%🚨%')";
}

if ($q !== '') {
  $conds[] = "(title LIKE ? OR content LIKE ?)";
  $like = '%' . $q . '%';
  $types .= 'ss';
  $params[] = $like;
  $params[] = $like;
}

$sql = "SELECT * FROM bulletin_posts";
if (!empty($conds)) $sql .= " WHERE " . implode(" AND ", $conds);
$sql .= " ORDER BY is_pinned DESC, created_at DESC";

$posts = [];
if ($conn) {
  if ($types === '') {
    $res = mysqli_query($conn, $sql);
    if ($res) while ($row = mysqli_fetch_assoc($res)) $posts[] = $row;
  } else {
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
      // bind_param needs references
      $bind = [$types];
      foreach ($params as $k => $v) { $bind[] = &$params[$k]; }
      call_user_func_array('mysqli_stmt_bind_param', array_merge([$stmt], $bind));
      mysqli_stmt_execute($stmt);
      $res = mysqli_stmt_get_result($stmt);
      while ($res && ($row = mysqli_fetch_assoc($res))) $posts[] = $row;
      mysqli_stmt_close($stmt);
    }
  }
}

// preload feedbacks (safe int interpolation)
$feedbackByPost = [];
if (!empty($posts)) {
  $ids = array_map(fn($p) => (int)$p['post_id'], $posts);
  $in = implode(',', $ids);
  $sql2 = "SELECT post_id, feedback_text, created_at FROM bulletin_feedback WHERE post_id IN ($in) ORDER BY created_at DESC";
  $res2 = mysqli_query($conn, $sql2);
  if ($res2) {
    while ($f = mysqli_fetch_assoc($res2)) {
      $pid = (int)$f['post_id'];
      if (!isset($feedbackByPost[$pid])) $feedbackByPost[$pid] = [];
      $feedbackByPost[$pid][] = $f;
    }
  }
}

// navigation items
$NAV_ITEMS = [
  ['label' => 'Laman Utama', 'href' => 'homepage.php', 'active' => ['homepage.php']],
  ['label' => 'Kalendar', 'href' => 'calendar.php', 'active' => ['calendar.php']],
  ['label' => 'Buletin', 'href' => 'bulletin.php', 'active' => ['bulletin.php']],
  ['label' => 'Sewa Fasiliti', 'href' => 'facility_rental.php', 'active' => ['facility_rental.php']],
  ['label' => 'Kenalan Kecemasan', 'href' => 'emergency_contacts.php', 'active' => ['emergency_contacts.php']],
];
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Buletin Komuniti | i-Desa</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root{
      --primary:#2d6a4f;
      --brown:#6d4c41;
      --text:#333;
      --muted:#6b7280;
      --bg:#f7faf7;
      --card:#fff;
      --border:#eaeaea;
    }
    *{ box-sizing:border-box; }
    body{ margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); }
    .container{ width:min(1100px, 92vw); margin: 24px auto 70px; }
    .page-title{ display:flex; align-items:flex-end; justify-content:space-between; gap:16px; flex-wrap:wrap; }
    .page-title h1{ margin:0; font-size: 28px; }
    .sub{ margin:6px 0 0; color:var(--muted); font-size: 14px; }
    .toolbar{ background:var(--card); border:1px solid var(--border); border-radius:16px; padding:14px; margin-top:16px; display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
    .toolbar input, .toolbar select{ padding:10px 12px; border:1px solid var(--border); border-radius:12px; font-family:inherit; }
    .toolbar button{ padding:10px 14px; border:0; border-radius:12px; background:var(--primary); color:#fff; font-weight:600; cursor:pointer; }
    .flash{ margin-top:16px; background:#e9f7ef; border:1px solid #cfeedd; color:#1f5136; padding:12px 14px; border-radius:14px; }
    .grid{ display:grid; grid-template-columns: 1fr; gap: 16px; margin-top: 18px; }
    .card{ background:var(--card); border:1px solid var(--border); border-radius:18px; padding:16px; box-shadow:0 8px 22px rgba(0,0,0,0.05); }
    .card-head{ display:flex; justify-content:space-between; gap:12px; align-items:flex-start; }
    .meta{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; color:var(--muted); font-size: 13px; }
    .badge{ display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; font-size: 12px; font-weight:700; }
    .badge.news{ background:#e9f7ef; color:#1f5136; border:1px solid #cfeedd; }
    .badge.event{ background:#fff3e6; color:#7a3e00; border:1px solid #ffe0bf; }
    .badge.pin{ background:#eef2ff; color:#243b99; border:1px solid #dbe3ff; }
    .badge.emergency{ background:#fef2f2; color:#991b1b; border:1px solid #fecaca; }

    .hot-wrap{ margin: 18px 0 6px; }
    .hot-head{ display:flex; justify-content:space-between; align-items:flex-end; gap:12px; flex-wrap:wrap; }
    .hot-title{ margin:0; font-size:18px; }
    .hot-sub{ color:var(--muted); font-size:13px; }
    .hot-grid{ display:grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; margin-top: 12px; }
    .hot-card{ background: linear-gradient(180deg, rgba(45,106,79,0.08), rgba(45,106,79,0.02)); border:1px solid rgba(45,106,79,0.18); border-radius: 18px; padding: 14px; box-shadow: 0 10px 26px rgba(0,0,0,0.06); }
    .hot-card .t{ margin:8px 0 8px; font-weight:800; line-height:1.35; }
    .hot-card .m{ color:var(--muted); font-size:13px; }
    .hot-card a{ text-decoration:none; color:inherit; display:block; }
    @media (max-width: 900px){ .hot-grid{ grid-template-columns: 1fr; } }
    .title{ margin:10px 0 6px; font-size: 20px; }
    .content{ margin:0; line-height:1.6; }
    .attachments{ margin-top: 12px; display:flex; gap:12px; flex-wrap:wrap; }
    .attach-link{ display:inline-flex; align-items:center; gap:10px; padding:10px 12px; border-radius:12px; border:1px solid var(--border); text-decoration:none; color:var(--text); background:#fff; }
    .attach-img{ width:min(420px, 100%); border-radius:14px; border:1px solid var(--border); display:block; }
    .row{ display:flex; gap:12px; flex-wrap:wrap; margin-top: 10px; }
    .link{ color: var(--primary); text-decoration:none; font-weight:600; }
    .feedback{ margin-top: 14px; padding-top: 14px; border-top: 1px dashed var(--border); }
    .feedback h3{ margin:0 0 10px; font-size: 15px; color: var(--brown); }
    .feedback-list{ display:grid; gap:8px; margin-bottom: 10px; }
    .feedback-item{ background:#fbfbfb; border:1px solid var(--border); border-radius:14px; padding:10px 12px; }
    .feedback-item .t{ color:var(--muted); font-size: 12px; margin-top: 6px; }
    textarea{ width:100%; min-height: 80px; padding:10px 12px; border-radius:14px; border:1px solid var(--border); font-family:inherit; resize:vertical; }
    .feedback-actions{ display:flex; justify-content:flex-end; margin-top:10px; }
    .btn{ padding:10px 14px; border-radius:14px; border:0; background:var(--brown); color:#fff; font-weight:700; cursor:pointer; }
    .admin-link{ text-decoration:none; background: #1b4332; color:#fff; padding:10px 14px; border-radius:12px; font-weight:700; }
  </style>
</head>
<body>
  <?php require_once "navbar.php"; ?>

  <div class="container">
    <div class="page-title">
      <div>
        <h1>Buletin Komuniti</h1>
        <p class="sub">Pengumuman, berita dan acara kampung.</p>
      </div>
      <?php if ($role === 'AJK' || $role === 'Admin'): ?>
        <a class="admin-link" href="admin_bulletin.php">Panel Admin Buletin</a>
      <?php endif; ?>
    </div>

    <?php if ($flash): ?>
      <div class="flash"><?php echo h($flash); ?></div>
    <?php endif; ?>

    <form class="toolbar" method="get" action="bulletin.php">
      <select name="category" aria-label="Kategori">
        <option value="All" <?php echo $category==='All'?'selected':''; ?>>Semua Kategori</option>
        <option value="Announcement" <?php echo $category==='Announcement'?'selected':''; ?>>Pengumuman</option>
        <option value="Event" <?php echo $category==='Event'?'selected':''; ?>>Acara</option>
        <option value="Emergency" <?php echo $category==='Emergency'?'selected':''; ?>>Kecemasan</option>
      </select>
      <input type="text" name="q" value="<?php echo h($q); ?>" placeholder="Cari tajuk / kandungan...">
      <button type="submit">Tapis</button>
    </form>

    <?php if (!empty($hotPosts)): ?>
      <div class="hot-wrap">
        <div class="hot-head">
          <h2 class="hot-title">Berita Terkini Minggu Ini</h2>
          <div class="hot-sub">Dipaparkan maksimum 3 berita paling baharu (7 hari terakhir).</div>
        </div>
        <div class="hot-grid">
          <?php foreach ($hotPosts as $hp):
            $hpTitle = (string)($hp['title'] ?? '');
            $hpCat = (string)($hp['category'] ?? 'News');
            $hpIsPinned = ((int)($hp['is_pinned'] ?? 0) === 1);
            $hpIsEmergency = ($hpCat === 'News' && isEmergencyTitle($hpTitle));
            $hpBadge = $hpIsEmergency ? 'emergency' : (($hpCat === 'Event') ? 'event' : 'news');
            $hpLabel = $hpIsEmergency ? 'Kecemasan' : (($hpCat === 'Event') ? 'Acara' : 'Pengumuman');
          ?>
            <a class="hot-card" href="#post-<?php echo (int)$hp['post_id']; ?>">
              <div class="hot-meta">
                <span class="badge <?php echo h($hpBadge); ?>"><?php echo h($hpLabel); ?></span>
                <?php if ($hpIsPinned): ?><span class="badge pin">Disorot</span><?php endif; ?>
                <span class="hot-date"><?php echo h(date('d/m/Y', strtotime($hp['created_at'] ?? 'now'))); ?></span>
              </div>
              <div class="hot-h"><?php echo h($hpTitle); ?></div>
              <div class="hot-sn"><?php echo h(mb_strimwidth(strip_tags((string)($hp['content'] ?? '')), 0, 140, '…')); ?></div>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

    <div class="grid">
      <?php if (empty($posts)): ?>
        <div class="card">
          Tiada posting buletin buat masa ini.
        </div>
      <?php else: ?>
        <?php foreach ($posts as $p): 
          $pid = (int)$p['post_id'];
          $titleTxt = (string)($p['title'] ?? '');
          $cat = (string)($p['category'] ?? 'News');
          $isPinned = ((int)($p['is_pinned'] ?? 0) === 1);
          $isEmergency = ($cat === 'News' && isEmergencyTitle($titleTxt));
          $badgeCls = $isEmergency ? 'emergency' : (($cat === 'Event') ? 'event' : 'news');
          $badgeLabel = $isEmergency ? 'Kecemasan' : (($cat === 'Event') ? 'Acara' : 'Pengumuman');
          $attachment = trim((string)($p['attachment'] ?? ''));
          $attHref = $attachment;
          if ($attachment !== '' && !preg_match('/^https?:\/\//i', $attachment)) {
              $attHref = $attachment;
          }
          $ext = strtolower(pathinfo($attachment, PATHINFO_EXTENSION));
          $isImg = in_array($ext, ['png','jpg','jpeg','gif','webp'], true);
        ?>
          <div class="card" id="post-<?php echo (int)$pid; ?>">
            <div class="card-head">
              <div>
                <div class="meta">
                  <span class="badge <?php echo h($badgeCls); ?>"><?php echo h($badgeLabel); ?></span>
                  <?php if ($isPinned): ?><span class="badge pin">Disorot</span><?php endif; ?>
                  <span><?php echo h(date("d/m/Y, H:i", strtotime($p['created_at']))); ?></span>
                  <?php if (!empty($p['event_date'])): ?><span>Tarikh Acara: <b><?php echo h(date("d/m/Y", strtotime($p['event_date']))); ?></b></span><?php endif; ?>
                  <?php if (!empty($p['program_date'])): ?><span>Tarikh Program: <b><?php echo h(date("d/m/Y", strtotime($p['program_date']))); ?></b></span><?php endif; ?>
                </div>
                <div class="title"><?php echo h($titleTxt); ?></div>
              </div>
            </div>

            <p class="content"><?php echo nl2br(h($p['content'])); ?></p>

            <div class="row">
              <?php if (!empty($p['location_link'])): ?>
                <a class="link" target="_blank" rel="noopener" href="<?php echo h($p['location_link']); ?>">Lihat lokasi</a>
              <?php endif; ?>
            </div>

            <?php if ($attachment !== ''): ?>
              <div class="attachments">
                <?php if ($isImg): ?>
                  <a href="<?php echo h($attHref); ?>" target="_blank" rel="noopener">
                    <img class="attach-img" src="<?php echo h($attHref); ?>" alt="Lampiran">
                  </a>
                <?php else: ?>
                  <a class="attach-link" href="<?php echo h($attHref); ?>" target="_blank" rel="noopener">
                    <span>📎</span> <span>Muat turun lampiran</span>
                  </a>
                <?php endif; ?>
              </div>
            <?php endif; ?>

            <div class="feedback">
              <h3>Maklum Balas</h3>
              <div class="feedback-list">
                <?php 
                  $fb = $feedbackByPost[$pid] ?? [];
                  if (empty($fb)):
                ?>
                  <div class="feedback-item">Tiada maklum balas lagi.</div>
                <?php else: foreach ($fb as $f): ?>
                  <div class="feedback-item">
                    <div><?php echo nl2br(h($f['feedback_text'])); ?></div>
                    <div class="t"><?php echo h(date("d/m/Y, H:i", strtotime($f['created_at']))); ?></div>
                  </div>
                <?php endforeach; endif; ?>
              </div>

              <form method="post" action="bulletin.php?category=<?php echo urlencode($category); ?>&q=<?php echo urlencode($q); ?>">
                <input type="hidden" name="post_id" value="<?php echo (int)$pid; ?>">
                <textarea name="feedback_text" placeholder="Tulis maklum balas anda..." required></textarea>
                <div class="feedback-actions">
                  <button class="btn" type="submit" name="submit_feedback">Hantar</button>
                </div>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
