<?php
session_start();
$NAV_ACTIVE = 'help_centre.php';
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>i-Desa | Pusat Bantuan (FAQ)</title>

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root{
      --primary-green:#2d6a4f;
      --accent-brown:#6d4c41;
      --text-dark:#1f2937;
      --bg:#f7faf7;
      --card:#ffffff;
      --muted:#6b7280;
      --border: rgba(0,0,0,.08);
    }
    *{ box-sizing:border-box; }
    body{
      margin:0;
      font-family:'Poppins',sans-serif;
      background:var(--bg);
      color:var(--text-dark);
      min-height:100vh;
      display:flex;
      flex-direction:column;
    }

    .wrap{ padding: 26px 8% 20px; flex:1; }
    @media (max-width: 980px){ .wrap{ padding: 20px 5% 16px; } }

    .hero{
      background: linear-gradient(180deg, rgba(45,106,79,.10), rgba(45,106,79,.02));
      border:1px solid rgba(45,106,79,.14);
      border-radius: 18px;
      padding: 18px;
      box-shadow: 0 10px 25px rgba(0,0,0,.06);
      display:flex;
      gap: 14px;
      align-items:flex-start;
      justify-content:space-between;
      flex-wrap:wrap;
    }
    .hero h1{
      margin:0;
      font-size: 28px;
      color: var(--primary-green);
      letter-spacing: .2px;
    }
    .hero p{
      margin:6px 0 0;
      color: var(--muted);
      font-size: 14px;
      line-height:1.6;
      max-width: 720px;
    }

    .grid{
      display:grid;
      grid-template-columns: 1.15fr .85fr;
      gap: 14px;
      margin-top: 14px;
    }
    @media (max-width: 980px){ .grid{ grid-template-columns: 1fr; } }

    .card{
      background: var(--card);
      border:1px solid var(--border);
      border-radius: 16px;
      padding: 16px;
      box-shadow: 0 10px 24px rgba(0,0,0,.06);
    }

    .section-title{
      margin:0 0 10px;
      font-size: 18px;
      color: var(--primary-green);
      letter-spacing:.2px;
    }

    /* Search (visual only; no backend required) */
    .search{
      display:flex;
      gap: 10px;
      flex-wrap:wrap;
      margin-top: 10px;
    }
    .search input{
      flex: 1;
      min-width: 220px;
      padding: 12px 12px;
      border-radius: 12px;
      border:1px solid rgba(0,0,0,.12);
      font-family:inherit;
      outline:none;
    }
    .search input:focus{
      border-color: rgba(45,106,79,.55);
      box-shadow: 0 0 0 4px rgba(45,106,79,.12);
    }
    .btn-pill{
      background: var(--primary-green);
      color: #fff;
      border:none;
      padding: 12px 14px;
      border-radius: 999px;
      font-weight: 900;
      cursor:pointer;
      display:inline-flex;
      align-items:center;
      gap: 8px;
    }

    /* FAQ accordion using <details> */
    .faq{
      display:flex;
      flex-direction:column;
      gap: 10px;
    }
    details{
      border:1px solid rgba(0,0,0,.08);
      border-radius: 14px;
      background:#fff;
      overflow:hidden;
    }
    summary{
      cursor:pointer;
      list-style:none;
      padding: 12px 14px;
      font-weight: 900;
      color:#374151;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap: 10px;
    }
    summary::-webkit-details-marker{ display:none; }
    summary .q{
      display:flex;
      align-items:center;
      gap: 10px;
    }
    summary i{
      color: var(--primary-green);
    }
    .ans{
      padding: 0 14px 14px;
      color: var(--muted);
      line-height: 1.7;
      font-size: 14px;
    }
    .ans code{
      background: rgba(0,0,0,.04);
      padding: 2px 6px;
      border-radius: 8px;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      font-size: 13px;
    }

    .quick{
      display:flex;
      flex-direction:column;
      gap: 10px;
    }
    .quick a{
      text-decoration:none;
      font-weight:900;
      color:#374151;
      padding: 12px 12px;
      border-radius: 14px;
      border: 1px solid rgba(0,0,0,.08);
      background:#fff;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap: 10px;
      transition:.15s;
    }
    .quick a:hover{
      border-color: rgba(45,106,79,.35);
      background: rgba(45,106,79,.06);
      color: var(--primary-green);
    }

    .muted{ color: var(--muted); font-size: 13px; }
    .contact{
      display:flex;
      flex-direction:column;
      gap: 10px;
      margin-top: 12px;
    }
    .contact .row{
      display:flex;
      align-items:flex-start;
      gap: 12px;
      color:#374151;
      font-weight:800;
    }
    .contact i{
      color: var(--primary-green);
      margin-top: 3px;
    }
    .contact span{
      font-weight:700;
      color: var(--muted);
      line-height:1.6;
      font-size: 14px;
    }
  </style>
</head>

<body>
<?php include "navbar.php"; ?>

<div class="wrap">

  <div class="hero">
    <div>
      <h1>Pusat Bantuan (FAQ)</h1>
      <p>
        Dapatkan jawapan pantas untuk isu biasa seperti log masuk, aduan, notifikasi,
        tempahan fasiliti, dan penggunaan modul sistem i-Desa.
      </p>

      <div class="search" aria-label="Carian FAQ (visual)">
        <input type="text" placeholder="Cari soalan... (contoh: buat aduan, status, notifikasi)" disabled>
        <button class="btn-pill" type="button" disabled>
          <i class="fa-solid fa-magnifying-glass"></i> Cari
        </button>
      </div>
      <div class="muted" style="margin-top:8px;">
        * Carian ini pilihan sahaja. Anda boleh rujuk soalan lazim di bawah.
      </div>
    </div>
  </div>

  <div class="grid">
    <div class="card">
      <h2 class="section-title">Soalan Lazim</h2>

      <div class="faq">

        <details open>
          <summary>
            <span class="q"><i class="fa-solid fa-circle-question"></i> Bagaimana cara buat aduan?</span>
            <i class="fa-solid fa-chevron-down"></i>
          </summary>
          <div class="ans">
            Jika anda <strong>Resident</strong>:
            <ol>
              <li>Pergi ke menu <strong>Aduan</strong> pada navbar.</li>
              <li>Pilih <strong>Buat Aduan</strong>.</li>
              <li>Isi tajuk, butiran, dan muat naik gambar jika ada.</li>
            </ol>
            Anda boleh semak status pada <code>resident_report_list.php</code>.
          </div>
        </details>

        <details>
          <summary>
            <span class="q"><i class="fa-solid fa-circle-question"></i> Kenapa saya tak boleh akses complaint.php?</span>
            <i class="fa-solid fa-chevron-down"></i>
          </summary>
          <div class="ans">
            Halaman <strong>complaint.php</strong> adalah untuk <strong>AJK/Admin</strong>.
            Resident akan diarahkan ke halaman senarai aduan sendiri untuk melihat status aduan.
          </div>
        </details>

        <details>
          <summary>
            <span class="q"><i class="fa-solid fa-circle-question"></i> Maksud status aduan: Baru / Disemak / Dalam Tindakan / Selesai?</span>
            <i class="fa-solid fa-chevron-down"></i>
          </summary>
          <div class="ans">
            <ul>
              <li><strong>Baru</strong>: Aduan baru dihantar dan belum disemak.</li>
              <li><strong>Disemak</strong>: AJK/Admin sudah melihat aduan.</li>
              <li><strong>Dalam Tindakan</strong>: Tindakan sedang dibuat / dalam proses.</li>
              <li><strong>Selesai</strong>: Kes telah diselesaikan.</li>
            </ul>
          </div>
        </details>

        <details>
          <summary>
            <span class="q"><i class="fa-solid fa-circle-question"></i> Bagaimana saya lihat notifikasi?</span>
            <i class="fa-solid fa-chevron-down"></i>
          </summary>
          <div class="ans">
            Klik ikon loceng pada navbar. Anda juga boleh buka halaman
            <code>my_notifications_calendar.php</code> untuk paparan notifikasi & kalendar.
          </div>
        </details>

        <details>
          <summary>
            <span class="q"><i class="fa-solid fa-circle-question"></i> Saya terlupa kata laluan / akaun bermasalah</span>
            <i class="fa-solid fa-chevron-down"></i>
          </summary>
          <div class="ans">
            Sila hubungi pentadbir kampung (Admin) untuk semakan akaun.
            Jika modul reset kata laluan belum tersedia, Admin akan membantu kemaskini.
          </div>
        </details>

      </div>
    </div>

    <div class="card">
      <h2 class="section-title">Pautan Cepat</h2>

      <div class="quick">
        <a href="homepage.php">
          <span><i class="fa-solid fa-house" style="margin-right:10px;"></i> Halaman Utama</span>
          <i class="fa-solid fa-arrow-right"></i>
        </a>
        <a href="bulletin.php">
          <span><i class="fa-solid fa-bullhorn" style="margin-right:10px;"></i> Buletin Komuniti</span>
          <i class="fa-solid fa-arrow-right"></i>
        </a>
        <a href="calendar.php">
          <span><i class="fa-solid fa-calendar-days" style="margin-right:10px;"></i> Kalendar Kampung</span>
          <i class="fa-solid fa-arrow-right"></i>
        </a>
        <a href="resident_add_report.php">
          <span><i class="fa-solid fa-pen-to-square" style="margin-right:10px;"></i> Buat Aduan</span>
          <i class="fa-solid fa-arrow-right"></i>
        </a>
      </div>

      <div class="contact">
        <div class="muted" style="margin-top:10px;">Masih perlukan bantuan?</div>

        <div class="row">
          <i class="fa-solid fa-phone"></i>
          <div>
            <div>Telefon</div>
            <span>+603-8733 1234 (Isnin–Jumaat, 9am–5pm)</span>
          </div>
        </div>

        <div class="row">
          <i class="fa-solid fa-envelope"></i>
          <div>
            <div>Email</div>
            <span>admin@idesa.com.my</span>
          </div>
        </div>
      </div>

    </div>
  </div>

</div>

<?php include "footer.php"; ?>
</body>
</html>
