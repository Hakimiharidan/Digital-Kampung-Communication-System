<?php
session_start();
include "db_connect.php";

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}


// ✅ FIX: Define $role here so the Sidebar can use it without error
$role = $_SESSION['role'];

// HTML Helper
if (!function_exists('h')) {
    function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

// Emergency Title Check
function isEmergencyTitle(string $title): bool {
    $t = mb_strtolower($title);
    return (strpos($t, 'emergency') !== false) || (strpos($title, '🚨') !== false);
}

// WhatsApp Config Integration
if (file_exists(__DIR__ . '/whatsapp_config.php')) {
    require_once __DIR__ . '/whatsapp_config.php';
}

function sendWhatsApp(string $to, string $message, &$errOut = ''): bool {
    if (!defined('WHATSAPP_API_URL') || !defined('WHATSAPP_API_TOKEN')) {
        $errOut = 'WhatsApp API belum dikonfigurasi (whatsapp_config.php).';
        return false;
    }

    $payload = json_encode(["to" => $to, "message" => $message], JSON_UNESCAPED_UNICODE);
    $ch = curl_init(WHATSAPP_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . WHATSAPP_API_TOKEN,
        ],
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_TIMEOUT => 20,
    ]);
    $resp = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($resp === false) {
        $errOut = $curlErr ?: 'Gagal hubungi WhatsApp API.';
        return false;
    }

    if ($http < 200 || $http >= 300) {
        $errOut = 'WhatsApp API pulangkan HTTP ' . $http;
        return false;
    }

    return true;
}

function insertNotification(mysqli $conn, int $userId, string $message, string $type = 'News'): bool {
    $stmt = mysqli_prepare($conn, "INSERT INTO notifications (user_id, event_id, message, type, is_read) VALUES (?, NULL, ?, ?, 0)");
    if (!$stmt) return false;
    mysqli_stmt_bind_param($stmt, "iss", $userId, $message, $type);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return (bool)$ok;
}

// Flash Messages
$flash = '';
$flashType = 'success';

// Handle Post Creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_post'])) {
    $type = $_POST['post_type'] ?? 'Announcement';
    $title = trim((string)($_POST['title'] ?? ''));
    $content = trim((string)($_POST['content'] ?? ''));
    $event_date = $_POST['event_date'] ?? '';
    $location_link = trim((string)($_POST['location_link'] ?? ''));
    $pin = isset($_POST['is_pinned']) ? 1 : 0;

    if ($title === '' || $content === '') {
        $flash = 'Sila isi tajuk dan kandungan.';
        $flashType = 'error';
    } else {
        $category = 'News';
        $eventDateVal = null;
        $locationVal = null;

        if ($type === 'Event') {
            $category = 'Event';
            $eventDateVal = ($event_date !== '') ? $event_date : null;
            $locationVal = ($location_link !== '') ? $location_link : null;
        } elseif ($type === 'Emergency') {
            $category = 'News';
            if (!isEmergencyTitle($title)) {
                $title = '🚨 [EMERGENCY] ' . $title;
            }
            $pin = 1;
        }

        $attachmentRel = null;
        if (!empty($_FILES['attachment']['name']) && is_uploaded_file($_FILES['attachment']['tmp_name'])) {
            $uploadDirAbs = __DIR__ . '/uploads/bulletin';
            if (!is_dir($uploadDirAbs)) @mkdir($uploadDirAbs, 0775, true);

            $orig = basename($_FILES['attachment']['name']);
            $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
            $safeBase = preg_replace('/[^a-zA-Z0-9\-_.]+/', '_', pathinfo($orig, PATHINFO_FILENAME));
            $rand = bin2hex(random_bytes(4));
            $fileName = date('Ymd_His') . '_' . $safeBase . '_' . $rand . ($ext ? '.' . $ext : '');
            $destAbs = $uploadDirAbs . '/' . $fileName;
            $destRel = 'uploads/bulletin/' . $fileName;
            
            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $destAbs)) {
                $attachmentRel = $destRel;
            } else {
                $flash = 'Ralat: gagal muat naik lampiran.';
                $flashType = 'error';
            }
        }

        if ($flashType !== 'error') {
            $program_date = null;
            $stmt = mysqli_prepare($conn, "INSERT INTO bulletin_posts (title, category, content, event_date, location_link, attachment, program_date, is_pinned) VALUES (?,?,?,?,?,?,?,?)");
            if (!$stmt) {
                $flash = 'Ralat DB: tidak dapat tambah posting.';
                $flashType = 'error';
            } else {
                mysqli_stmt_bind_param($stmt, "sssssssi", $title, $category, $content, $eventDateVal, $locationVal, $attachmentRel, $program_date, $pin);
                $ok = mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);

                if ($ok) {
                    $flash = 'Posting berjaya diterbitkan.';
                    $flashType = 'success';
                } else {
                    $flash = 'Ralat: gagal terbitkan posting.';
                    $flashType = 'error';
                }
            }
        }
    }
}

// Handle Sending Messages
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_send'])) {
    $postId = (int)($_POST['post_id'] ?? 0);
    $sendMode = $_POST['send_mode'] ?? '';
    $extraMsg = trim((string)($_POST['extra_message'] ?? ''));

    $post = null;
    if ($postId > 0) {
        $stmt = mysqli_prepare($conn, "SELECT post_id, title, category, content, created_at FROM bulletin_posts WHERE post_id=? LIMIT 1");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $postId);
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $post = $res ? mysqli_fetch_assoc($res) : null;
            mysqli_stmt_close($stmt);
        }
    }

    if (!$post) {
        $flash = 'Ralat: posting tidak ditemui.';
        $flashType = 'error';
    } else {
        $title = (string)$post['title'];
        $content = (string)$post['content'];
        $isEmergency = isEmergencyTitle($title);

        $users = [];
        $uRes = mysqli_query($conn, "SELECT user_id, full_name, email, phone FROM users WHERE account_status='Active'");
        if ($uRes) while ($u = mysqli_fetch_assoc($uRes)) $users[] = $u;

        if (empty($users)) {
            $flash = 'Tiada pengguna aktif dijumpai.';
            $flashType = 'error';
        } else {
            $subject = 'i-Desa: ' . $title;
            $body = "Berita daripada i-Desa\n\n" . "Tajuk: {$title}\n" . "Kategori: " . (($post['category'] ?? '') ?: '-') . "\n" . "Tarikh: " . ($post['created_at'] ?? '') . "\n\n" . $content . "\n";
            
            if ($extraMsg !== '') {
                $body .= "\n---\nMesej tambahan:\n" . $extraMsg . "\n";
            }
            $body .= "\n\nLog masuk i-Desa untuk maklumat lanjut.\n";

            $sent = 0;
            $failed = 0;

            if ($sendMode === 'email') {
                // Ensure sendmail/SMTP is configured on server
                $headers = "From: i-Desa <no-reply@idesa.local>\r\n";
                foreach ($users as $u) {
                    $to = trim((string)($u['email'] ?? ''));
                    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) { $failed++; continue; }
                    $ok = @mail($to, $subject, $body, $headers);
                    if ($ok) $sent++; else $failed++;
                }
                $flash = "Email dihantar: {$sent}. Gagal: {$failed}.";
                $flashType = 'success';
            } elseif ($sendMode === 'push') {
                mysqli_begin_transaction($conn);
                try {
                    foreach ($users as $u) {
                        $uid = (int)$u['user_id'];
                        $msg = ($isEmergency ? "🚨 " : "") . "Berita i-Desa: {$title}";
                        if ($extraMsg !== '') $msg .= "\n" . $extraMsg;
                        $ok = insertNotification($conn, $uid, $msg, $isEmergency ? 'Emergency' : 'News');
                        if ($ok) $sent++; else $failed++;
                    }
                    mysqli_commit($conn);
                } catch (Throwable $e) {
                    mysqli_rollback($conn);
                    $flash = 'Ralat: gagal cipta notifikasi.';
                    $flashType = 'error';
                }
                if ($flashType !== 'error') {
                    $flash = "Notifikasi dicipta: {$sent}. Gagal: {$failed}.";
                    $flashType = 'success';
                }
            } elseif ($sendMode === 'whatsapp') {
                if (!$isEmergency) {
                    $flash = 'WhatsApp hanya untuk Emergency Alert sahaja.';
                    $flashType = 'error';
                } else {
                    $waMsg = "🚨 AMARAN KECEMASAN i-Desa\n\n" . $title . "\n\n" . $content;
                    if ($extraMsg !== '') $waMsg .= "\n\nMesej tambahan:\n" . $extraMsg;
                    foreach ($users as $u) {
                        $to = trim((string)($u['phone'] ?? ''));
                        if ($to === '') { $failed++; continue; }
                        $err = '';
                        $ok = sendWhatsApp($to, $waMsg, $err);
                        if ($ok) $sent++; else $failed++;
                    }
                    $flash = "WhatsApp dihantar: {$sent}. Gagal: {$failed}.";
                    $flashType = ($sent > 0) ? 'success' : 'error';
                }
            } else {
                $flash = 'Sila pilih tindakan.';
                $flashType = 'error';
            }
        }
    }
}

// Fetch Posts
$posts = [];
$res = mysqli_query($conn, "SELECT post_id, title, category, created_at, is_pinned FROM bulletin_posts ORDER BY is_pinned DESC, created_at DESC LIMIT 30");
if ($res) while ($r = mysqli_fetch_assoc($res)) $posts[] = $r;
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pusat Berita | i-Desa Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        /* Base Setup */
        * { box-sizing: border-box; }
        :root { 
            --primary: #2d6a4f; 
            --dark: #143d29; /* Deep Green */
            --bg: #f4f7f6; 
            --card: #fff; 
            --text: #333; 
            --muted: #6b7280; 
        }
        
        body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); display:flex; min-height:100vh; }

        /* Sidebar */
        .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; box-shadow: 4px 0 15px rgba(0,0,0,0.05); }
        .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
        .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
        .logo-text { display: flex; flex-direction: column; line-height: 1; }
        .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
        .logo-main span { color: #4ade80; }
        .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }
        .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
        .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
        .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
        .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
        .nav-item i { width: 18px; text-align: center; font-size: 16px; }
        .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

        /* Main Content */
        .content { margin-left: 250px; padding: 30px; width: calc(100% - 250px); }
        .head { display:flex; justify-content:space-between; align-items:center; margin-bottom:25px; }
        .title { margin:0; font-size:24px; color:var(--dark); font-weight: 700; }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; }

        /* Grid */
        .grid-2 { display:grid; grid-template-columns: 1fr 1fr; gap:25px; }
        @media (max-width: 1000px){ .sidebar{ display:none; } .content{ margin:0; width:100%; } .grid-2{ grid-template-columns:1fr; } }

        /* Cards */
        .card { background:var(--card); border-radius:16px; padding:25px; box-shadow:0 4px 6px rgba(0,0,0,0.02); margin-bottom: 25px; border: 1px solid #eee; }
        h3 { margin: 0 0 15px; font-size: 18px; color: var(--primary); font-weight: 700; border-bottom: 1px solid #f0f0f0; padding-bottom: 10px; }

        /* Forms */
        label { display:block; font-size:13px; font-weight:600; margin-bottom:6px; color:#444; }
        input, select, textarea { width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:8px; font-size:14px; outline:none; transition:0.2s; background:#fff; }
        input:focus, select:focus, textarea:focus { border-color:var(--primary); box-shadow:0 0 0 3px rgba(45,106,79,0.1); }
        .hint { font-size:12px; color:#888; margin-top:5px; }

        /* Buttons */
        .btn { padding: 10px 20px; border-radius: 50px; border: 1px solid #ddd; background: #fff; color: #555; cursor: pointer; font-weight: 600; font-size: 14px; transition: 0.2s; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; }
        .btn:hover { background: #f9fafb; transform: translateY(-1px); }
        .btn.primary { background: var(--primary); border-color: var(--primary); color: #fff; }
        .btn.primary:hover { opacity: 0.9; }
        
        /* Table */
        table { width:100%; border-collapse:collapse; margin-top:10px; }
        th { text-align:left; padding:12px 15px; background:#f9fafb; color:#666; font-size:12px; font-weight:600; border-bottom:1px solid #eee; text-transform:uppercase; }
        td { padding:14px 15px; border-bottom:1px solid #f3f4f6; font-size:14px; color:#333; }
        tr:hover td { background:#fafafa; }

        /* Badges */
        .pill { display:inline-flex; padding:4px 10px; border-radius:20px; font-size:11px; font-weight:700; text-transform:uppercase; }
        .pill.news{ background:#ecfdf5; color:#065f46; border:1px solid #a7f3d0; }
        .pill.event{ background:#fff7ed; color:#9a3412; border:1px solid #fed7aa; }
        .pill.emg{ background:#fef2f2; color:#991b1b; border:1px solid #fecaca; }
        .pill.pin{ background:#eff6ff; color:#1e40af; border:1px solid #bfdbfe; margin-left: 5px; }

        /* Alerts */
        .alert { padding:12px 15px; border-radius:10px; font-weight:600; margin-bottom: 20px; border:1px solid; display:flex; gap:10px; align-items:center; font-size: 14px; }
        .alert.success { background:#ecfdf5; border-color:#a7f3d0; color:#065f46; }
        .alert.error { background:#fef2f2; border-color:#fecaca; color:#7f1d1d; }
    </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_residents.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<main class="content">
    <div class="head">
        <div>
            <h1 class="title">Pusat Berita & Pengumuman</h1>
            <p class="sub">Terbitkan berita terkini dan hantar notifikasi kepada penduduk.</p>
        </div>
        <div style="display:flex; gap:10px;">
            <a class="btn" href="bulletin.php" target="_blank"><i class="fas fa-external-link-alt"></i> Paparan Awam</a>
            <a class="btn primary" href="admin_bulletin.php"><i class="fas fa-pen-to-square"></i> Editor Penuh</a>
        </div>
    </div>

    <?php if ($flash): ?>
        <div class="alert <?php echo ($flashType === 'success') ? 'success' : 'error'; ?>">
            <?php echo ($flashType === 'success') ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-circle-exclamation"></i>'; ?>
            <?php echo h($flash); ?>
        </div>
    <?php endif; ?>

    <div class="grid-2">
        <section class="card">
            <h3><i class="fas fa-plus-circle"></i> Terbitkan Berita Pantas</h3>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="create_post" value="1">
                
                <div style="display: grid; grid-template-columns: 1fr auto; gap: 15px; margin-bottom: 15px;">
                    <div>
                        <label>Jenis Berita</label>
                        <select name="post_type">
                            <option value="Announcement">Pengumuman (Announcement)</option>
                            <option value="Event">Acara (Event)</option>
                            <option value="Emergency">Kecemasan (Emergency)</option>
                        </select>
                    </div>
                    <div style="display:flex; align-items:flex-end;">
                        <label style="cursor:pointer; display:flex; align-items:center; gap:8px;">
                            <input type="checkbox" name="is_pinned" value="1" style="width:auto;"> Pin di Atas
                        </label>
                    </div>
                </div>

                <div class="field">
                    <label>Tajuk Utama</label>
                    <input type="text" name="title" placeholder="Contoh: Gangguan Bekalan Air" required>
                </div>

                <div class="field">
                    <label>Kandungan</label>
                    <textarea name="content" rows="4" placeholder="Tulis butiran berita di sini..." required></textarea>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                    <div>
                        <label>Tarikh (Jika Event)</label>
                        <input type="date" name="event_date">
                    </div>
                    <div>
                        <label>Pautan Lokasi</label>
                        <input type="url" name="location_link" placeholder="https://maps.google.com...">
                    </div>
                </div>

                <div class="field">
                    <label>Lampiran (Gambar/PDF)</label>
                    <input type="file" name="attachment" accept="image/*,.pdf,.doc,.docx">
                </div>

                <button class="btn primary" type="submit" style="width:100%; justify-content:center;">
                    <i class="fas fa-paper-plane"></i> Terbitkan Sekarang
                </button>
            </form>
        </section>

        <section class="card">
            <h3><i class="fas fa-bullhorn"></i> Hantar Notifikasi</h3>
            <form method="post">
                <input type="hidden" name="action_send" value="1">
                
                <div class="field">
                    <label>Pilih Berita untuk Dihantar</label>
                    <select name="post_id" required>
                        <option value="">-- Sila Pilih --</option>
                        <?php foreach ($posts as $p): 
                            $t = (string)($p['title'] ?? '');
                            $isEmg = isEmergencyTitle($t);
                            $tag = $isEmg ? 'Emergency' : (($p['category'] ?? '') ?: 'News');
                        ?>
                            <option value="<?php echo (int)$p['post_id']; ?>">
                                <?php echo h('#' . (int)$p['post_id'] . ' • ' . $tag . ' • ' . substr($t, 0, 40)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label>Saluran Penghantaran</label>
                    <select name="send_mode" required>
                        <option value="">-- Pilih Saluran --</option>
                        <option value="email">📧 E-mel (Semua Pengguna Aktif)</option>
                        <option value="push">🔔 Push Notification (Sistem)</option>
                        <option value="whatsapp">💬 WhatsApp API (Kecemasan Sahaja)</option>
                    </select>
                    <div class="hint">* WhatsApp hanya dibenarkan untuk berita bertaraf "Emergency".</div>
                </div>

                <div class="field">
                    <label>Mesej Tambahan (Opsyenal)</label>
                    <textarea name="extra_message" rows="3" placeholder="Contoh: Sila ambil tindakan segera..."></textarea>
                </div>

                <button class="btn primary" type="submit" style="width:100%; justify-content:center; background:#1e3a8a; border-color:#1e3a8a;">
                    <i class="fas fa-share-square"></i> Hantar Notifikasi
                </button>
            </form>
        </section>
    </div>

    <section class="card">
        <h3><i class="fas fa-list"></i> Senarai Berita Terkini</h3>
        <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th width="50">ID</th>
                        <th>Tajuk</th>
                        <th width="150">Kategori</th>
                        <th width="150">Tarikh</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($posts)): ?>
                        <tr><td colspan="4" style="text-align:center; padding:30px; color:#888;">Tiada rekod.</td></tr>
                    <?php else: foreach ($posts as $p): 
                        $t = (string)($p['title'] ?? '');
                        $isEmg = isEmergencyTitle($t);
                        $cat = (string)($p['category'] ?? 'News');
                    ?>
                        <tr>
                            <td>#<?php echo (int)$p['post_id']; ?></td>
                            <td>
                                <strong><?php echo h($t); ?></strong>
                                <?php if ((int)($p['is_pinned'] ?? 0) === 1): ?>
                                    <span class="pill pin"><i class="fas fa-thumbtack"></i> Pinned</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($isEmg): ?>
                                    <span class="pill emg">Emergency</span>
                                <?php elseif ($cat === 'Event'): ?>
                                    <span class="pill event">Event</span>
                                <?php else: ?>
                                    <span class="pill news">News</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo h(date('d M Y', strtotime((string)($p['created_at'] ?? 'now')))); ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</main>

</body>
</html>