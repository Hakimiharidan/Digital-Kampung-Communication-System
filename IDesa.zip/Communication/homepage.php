<?php
session_start();
include "db_connect.php";

// --- 1. LOGIC: Determine Links based on Role ---
$isLoggedIn = isset($_SESSION['user_id']);
$role = $_SESSION['role'] ?? 'Resident';

// Link Logic
$aduanLink = $isLoggedIn ? (($role === 'AJK' || $role === 'Admin') ? "complaint.php" : "resident_add_report.php") : "login_page.php";
$rentalLink = $isLoggedIn ? "facility_rental.php" : "login_page.php";
$calendarLink = "calendar.php"; // Public access allowed

// --- 2. LOGIC: Fetch Emergency Alert (Last 24 Hours) ---
$emergencyAlert = null;
if (isset($conn)) {
    $emgSql = "SELECT message, created_at FROM notifications 
               WHERE type='Emergency' 
               AND created_at >= NOW() - INTERVAL 1 DAY 
               ORDER BY created_at DESC LIMIT 1";
    $emgRes = mysqli_query($conn, $emgSql);
    if ($emgRes && mysqli_num_rows($emgRes) > 0) {
        $emergencyAlert = mysqli_fetch_assoc($emgRes);
    }
}

// --- 3. LOGIC: Fetch Data for Engagement Section ---
$newsList = [];
$eventList = [];

if (isset($conn)) {
    // News
    $chk = mysqli_query($conn, "SHOW TABLES LIKE 'bulletin_posts'");
    if (mysqli_num_rows($chk) > 0) {
        $newsSql = "SELECT title, category, created_at FROM bulletin_posts ORDER BY created_at DESC LIMIT 3";
        $newsRes = mysqli_query($conn, $newsSql);
        while ($row = mysqli_fetch_assoc($newsRes)) $newsList[] = $row;
    }

    // Events
    $chk2 = mysqli_query($conn, "SHOW TABLES LIKE 'events'");
    if (mysqli_num_rows($chk2) > 0) {
        $evtSql = "SELECT title, start_datetime, location FROM events WHERE start_datetime >= NOW() ORDER BY start_datetime ASC LIMIT 3";
        $evtRes = mysqli_query($conn, $evtSql);
        while ($row = mysqli_fetch_assoc($evtRes)) $eventList[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Komuniti Pintar</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #2d6a4f;
            --primary-dark: #1b4332;
            --accent: #d8f3dc;
            --text: #1f2937;
            --muted: #6b7280;
            --bg: #f8fafc;
            --white: #ffffff;
            --alert-red: #dc2626;
            --shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.15);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Poppins', sans-serif; background-color: var(--bg); color: var(--text); overflow-x: hidden; }

        /* --- 1. EMERGENCY TICKER --- */
        .emergency-bar {
            background-color: var(--alert-red);
            color: white;
            padding: 12px 5%;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            box-shadow: 0 4px 10px rgba(220, 38, 38, 0.3);
            position: relative;
            z-index: 2000;
            font-size: 0.95rem;
        }
        .emergency-bar i { animation: pulse 1.5s infinite; }
        .emergency-msg { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 900px; }

        /* --- 2. HERO SLIDESHOW SECTION --- */
        .hero {
            position: relative;
            height: 750px; /* Enlarged Height */
            /* SCENERY BACKGROUND */
            background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.5)), url('village.png'); 
            background-size: cover;
            background-position: center;
            background-attachment: fixed; /* Parallax effect */
            display: flex;
            align-items: center;
            justify-content: center; /* Center content */
            padding: 0 10%;
            color: white;
            overflow: hidden;
            text-align: center; /* Center text */
        }

        /* Slider Logic */
        .slide-container { position: relative; width: 100%; max-width: 900px; z-index: 2; }
        .slide { display: none; animation: fadeIn 1s ease-out; }
        .slide.active { display: block; }

        /* Enlarged Fonts */
        .hero h1 { font-size: 4.5rem; font-weight: 800; line-height: 1.1; margin-bottom: 25px; text-shadow: 0 4px 15px rgba(0,0,0,0.4); }
        .hero p { font-size: 1.4rem; margin-bottom: 40px; opacity: 0.95; line-height: 1.6; font-weight: 400; max-width: 800px; margin-left: auto; margin-right: auto; text-shadow: 0 2px 5px rgba(0,0,0,0.5); }
        
        .cta-btn {
            background: var(--primary); color: var(--white); padding: 18px 45px; border-radius: 50px;
            text-decoration: none; font-weight: 700; transition: 0.3s; display: inline-flex; align-items: center; gap: 10px;
            box-shadow: 0 4px 20px rgba(45, 106, 79, 0.4); border: 2px solid transparent; font-size: 1.1rem;
        }
        .cta-btn:hover { transform: translateY(-5px); background: transparent; border-color: var(--white); color: var(--white); }

        /* Arrows */
        .arrow {
            position: absolute; top: 50%; transform: translateY(-50%);
            background: rgba(255,255,255,0.1); color: white; border: 1px solid rgba(255,255,255,0.3);
            width: 60px; height: 60px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: 0.3s; z-index: 10; font-size: 1.5rem; backdrop-filter: blur(5px);
        }
        .arrow:hover { background: var(--primary); border-color: var(--primary); }
        .prev { left: 4%; }
        .next { right: 4%; }

        /* --- 3. ENGAGEMENT SECTION --- */
        .section { padding: 80px 8%; }
        
        .engagement-wrapper { background: #fff; display: grid; grid-template-columns: 1fr 1fr; gap: 60px; }
        .engage-col h3 { font-size: 1.6rem; margin-bottom: 30px; display: flex; align-items: center; gap: 12px; color: var(--primary-dark); border-left: 5px solid var(--primary); padding-left: 15px; }
        
        .list-item {
            display: flex; gap: 20px; margin-bottom: 25px; align-items: flex-start;
            padding: 20px; border-radius: 16px; background: var(--bg); transition: 0.3s; border: 1px solid transparent;
        }
        .list-item:hover { transform: translateY(-5px); border-color: var(--primary); background: white; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        
        .list-date {
            background: white; padding: 12px; border-radius: 12px; text-align: center; min-width: 75px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05); border: 1px solid #e2e8f0;
        }
        .date-day { display: block; font-size: 1.5rem; font-weight: 800; color: var(--primary); line-height: 1; }
        .date-month { font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: var(--muted); }
        
        .list-content h4 { font-size: 1.15rem; margin-bottom: 8px; font-weight: 700; color: var(--text); }
        .list-content p { font-size: 0.95rem; color: var(--muted); margin: 0; }
        .tag { font-size: 0.75rem; background: var(--accent); color: var(--primary); padding: 4px 10px; border-radius: 6px; font-weight: 700; letter-spacing: 0.5px; text-transform: uppercase; }

        /* --- 4. SERVICES GRID --- */
        .services-section { background: var(--bg); position: relative; border-top: 1px solid #e5e7eb; }
        .section-title { text-align: center; margin-bottom: 60px; }
        .section-title h2 { font-size: 2.5rem; color: var(--primary-dark); font-weight: 800; letter-spacing: -1px; }
        .section-title p { color: var(--muted); margin-top: 10px; font-size: 1.1rem; }

        .services-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 35px; }
        .service-card {
            background: white; padding: 45px 30px; border-radius: 24px; text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.02); border: 1px solid #eee;
            text-decoration: none; color: var(--text); transition: 0.4s; position: relative; overflow: hidden;
        }
        .service-card:hover { transform: translateY(-12px); box-shadow: 0 20px 40px rgba(0,0,0,0.08); border-color: var(--primary); }
        
        /* Interactive Card Underline */
        .service-card::after {
            content: ''; position: absolute; bottom: 0; left: 0; width: 100%; height: 4px; background: var(--primary);
            transform: scaleX(0); transition: 0.4s; transform-origin: center;
        }
        .service-card:hover::after { transform: scaleX(1); }

        .icon-box {
            width: 80px; height: 80px; margin: 0 auto 25px; background: var(--accent);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 32px; color: var(--primary); transition: 0.4s;
        }
        .service-card:hover .icon-box { background: var(--primary); color: white; transform: scale(1.1) rotate(5deg); }
        .service-card h3 { font-size: 1.35rem; margin-bottom: 12px; font-weight: 700; }
        .service-card p { font-size: 0.95rem; color: var(--muted); line-height: 1.6; }

        /* Animations */
        @keyframes slideDown { from { transform: translateY(-100%); } to { transform: translateY(0); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.6; } 100% { opacity: 1; } }

        /* Mobile */
        @media (max-width: 900px) {
            .hero { height: 600px; padding: 0 5%; }
            .hero h1 { font-size: 2.5rem; }
            .hero p { font-size: 1.1rem; }
            .arrow { width: 45px; height: 45px; font-size: 1.2rem; }
            .engagement-wrapper { grid-template-columns: 1fr; gap: 50px; }
        }
    </style>
</head>
<body>

<?php if ($emergencyAlert): ?>
<div class="emergency-bar">
    <i class="fas fa-exclamation-triangle"></i>
    <div class="emergency-msg">
        <strong>PERHATIAN:</strong> <?php echo htmlspecialchars($emergencyAlert['message']); ?> 
        <span style="font-size:0.8em; opacity:0.8; margin-left:10px;">[<?php echo date("d M H:i", strtotime($emergencyAlert['created_at'])); ?>]</span>
    </div>
</div>
<?php endif; ?>

<?php include 'navbar.php'; ?>

<header class="hero">
    <div class="arrow prev" onclick="changeSlide(-1)"><i class="fas fa-chevron-left"></i></div>
    <div class="arrow next" onclick="changeSlide(1)"><i class="fas fa-chevron-right"></i></div>

    <div class="slide-container">
        
        <div class="slide active">
            <h1>Komuniti Pintar,<br>Kehidupan Sejahtera.</h1>
            <p>Platform digital rasmi i-Desa menghubungkan anda dengan kemudahan kampung, berita terkini, dan pengurusan komuniti yang efisien.</p>
            <a href="#services" class="cta-btn">Teroka Perkhidmatan <i class="fas fa-arrow-down"></i></a>
        </div>

        <div class="slide">
            <h1>Suara Anda,<br>Tanggungjawab Kami.</h1>
            <p>Laporkan isu infrastruktur, keselamatan, atau cadangan penambahbaikan terus kepada AJK untuk tindakan pantas.</p>
            <a href="<?php echo $aduanLink; ?>" class="cta-btn">Buat Laporan <i class="fas fa-file-contract"></i></a>
        </div>

        <div class="slide">
            <h1>Fasiliti Kampung<br>Sedia Digunakan.</h1>
            <p>Tempah Dewan Serbaguna, Gelanggang Sukan, dan peralatan majlis dengan mudah secara dalam talian.</p>
            <a href="<?php echo $rentalLink; ?>" class="cta-btn">Tempah Sekarang <i class="fas fa-building"></i></a>
        </div>

        <div class="slide">
            <h1>Kekal Aktif,<br>Kekal Berhubung.</h1>
            <p>Jangan ketinggalan program gotong-royong, sukaneka, dan majlis ilmu yang dianjurkan untuk anda.</p>
            <a href="<?php echo $calendarLink; ?>" class="cta-btn">Lihat Kalendar <i class="fas fa-calendar-alt"></i></a>
        </div>

    </div>
</header>

<section class="section engagement-wrapper">
    <div class="engage-col">
        <h3><i class="fas fa-calendar-check"></i> Acara Akan Datang</h3>
        <?php if (empty($eventList)): ?>
            <div class="list-item" style="display:block; text-align:center; color:#999; padding:30px;">Tiada acara dijadualkan.</div>
        <?php else: foreach($eventList as $evt): ?>
            <div class="list-item">
                <div class="list-date">
                    <span class="date-day"><?php echo date('d', strtotime($evt['start_datetime'])); ?></span>
                    <span class="date-month"><?php echo date('M', strtotime($evt['start_datetime'])); ?></span>
                </div>
                <div class="list-content">
                    <h4><?php echo htmlspecialchars($evt['title']); ?></h4>
                    <p><i class="fas fa-map-marker-alt" style="color:var(--primary); margin-right:5px;"></i> <?php echo htmlspecialchars($evt['location']); ?></p>
                </div>
            </div>
        <?php endforeach; endif; ?>
        <a href="calendar.php" style="color:var(--primary); font-weight:700; text-decoration:none; margin-left:5px; font-size:0.95rem;">Lihat Kalendar Penuh &rarr;</a>
    </div>

    <div class="engage-col">
        <h3><i class="fas fa-newspaper"></i> Berita Terkini</h3>
        <?php if (empty($newsList)): ?>
            <div class="list-item" style="display:block; text-align:center; color:#999; padding:30px;">Tiada berita terkini.</div>
        <?php else: foreach($newsList as $news): ?>
            <div class="list-item">
                <div class="list-date" style="background:#fff7ed; border-color:#ffedd5;">
                    <span class="date-day" style="color:#c2410c;"><?php echo date('d', strtotime($news['created_at'])); ?></span>
                    <span class="date-month"><?php echo date('M', strtotime($news['created_at'])); ?></span>
                </div>
                <div class="list-content">
                    <span class="tag"><?php echo htmlspecialchars($news['category'] ?: 'Umum'); ?></span>
                    <h4 style="margin-top:8px;"><?php echo htmlspecialchars($news['title']); ?></h4>
                </div>
            </div>
        <?php endforeach; endif; ?>
        <a href="bulletin.php" style="color:var(--primary); font-weight:700; text-decoration:none; margin-left:5px; font-size:0.95rem;">Baca Semua Berita &rarr;</a>
    </div>
</section>

<section class="section services-section" id="services">
    <div class="section-title">
        <h2>Perkhidmatan Kami</h2>
        <p>Akses semua keperluan kampung dengan mudah dan pantas di satu tempat.</p>
    </div>
    
    <div class="services-grid">
        <a href="bulletin.php" class="service-card">
            <div class="icon-box"><i class="fas fa-bullhorn"></i></div>
            <h3>Papan Kenyataan</h3>
            <p>Berita terkini dan pengumuman rasmi daripada pihak pengurusan kampung.</p>
        </a>

        <a href="<?php echo $aduanLink; ?>" class="service-card">
            <div class="icon-box"><i class="fas fa-file-contract"></i></div>
            <h3>E-Aduan</h3>
            <p>Saluran rasmi untuk melaporkan kerosakan, isu keselamatan, atau cadangan.</p>
        </a>

        <a href="calendar.php" class="service-card">
            <div class="icon-box"><i class="fas fa-calendar-alt"></i></div>
            <h3>Kalendar Aktiviti</h3>
            <p>Jadual lengkap aktiviti gotong-royong, sukan, dan program komuniti.</p>
        </a>

        <a href="facility_rental.php" class="service-card">
            <div class="icon-box"><i class="fas fa-building"></i></div>
            <h3>Sewa Fasiliti</h3>
            <p>Tempahan dewan, gelanggang sukan, dan peralatan untuk kegunaan peribadi.</p>
        </a>

        <a href="lostfound_board.php" class="service-card">
            <div class="icon-box"><i class="fas fa-search"></i></div>
            <h3>Hilang & Jumpa</h3>
            <p>Platform komuniti untuk menghebahkan dan mencari barang yang tercicir.</p>
        </a>

        <a href="emergency_contacts.php" class="service-card">
            <div class="icon-box"><i class="fas fa-phone-volume"></i></div>
            <h3>Bantuan Cemas</h3>
            <p>Senarai nombor telefon penting polis, bomba, hospital, dan AJK.</p>
        </a>
    </div>
</section>

<?php include 'footer.php'; ?>

<script>
    let slideIndex = 0;
    const slides = document.querySelectorAll('.slide');
    const totalSlides = slides.length;
    let autoSlideInterval;

    function showSlide(index) {
        // Reset all
        slides.forEach(slide => slide.classList.remove('active'));
        
        // Loop logic
        if (index >= totalSlides) slideIndex = 0;
        else if (index < 0) slideIndex = totalSlides - 1;
        else slideIndex = index;

        // Activate new slide
        slides[slideIndex].classList.add('active');
    }

    function changeSlide(n) {
        showSlide(slideIndex + n);
        resetTimer();
    }

    function resetTimer() {
        clearInterval(autoSlideInterval);
        autoSlideInterval = setInterval(() => changeSlide(1), 6000); // Change every 6 seconds
    }

    // Start
    resetTimer();
</script>

</body>
</html>