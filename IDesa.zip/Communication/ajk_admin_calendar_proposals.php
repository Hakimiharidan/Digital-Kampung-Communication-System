<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}

$viewerName = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'AJK/Admin';
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Semakan Cadangan</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    /* 1. Global Reset & Theme Variables */
    * { box-sizing: border-box; }
    :root { 
        --primary: #2d6a4f; 
        --dark: #143d29; /* Deep Green Theme */
        --bg: #f4f7f6; 
        --card: #fff; 
        --text: #333; 
        --muted: #6b7280; 
        --border: #e5e7eb;
        --danger: #dc2626;
        --success: #16a34a;
        --warning: #ca8a04;
    }
    
    body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); display:flex; }

    /* --- SIDEBAR --- */
    .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; box-shadow: 4px 0 15px rgba(0,0,0,0.05); }
    
    .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
    .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
    .logo-text { display: flex; flex-direction: column; line-height: 1; }
    .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .logo-main span { color: #4ade80; }
    .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

    .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
    .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
    .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
    .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
    .nav-item i { width: 18px; text-align: center; font-size: 16px; }
    .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

    /* --- CONTENT AREA --- */
    .wrap { 
        margin-left: 250px; 
        padding: 30px 40px 60px; 
        width: calc(100% - 250px);
    }

    /* Buttons */
    .btn { padding: 10px 20px; border-radius: 50px; border: 1px solid #ddd; background: #fff; color: #555; cursor: pointer; font-weight: 600; font-size: 13px; transition: 0.2s; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; }
    .btn:hover { background: #f9fafb; transform: translateY(-1px); }
    .btn.primary { background: var(--primary); border-color: var(--primary); color: #fff; }
    .btn.primary:hover { opacity: 0.9; }
    .btn.danger { background: #fee2e2; border-color: #fecaca; color: var(--danger); }
    .btn.danger:hover { background: #fecaca; }
    .btn.small { padding: 6px 12px; font-size: 12px; }

    /* Cards & Layout */
    .card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); margin-bottom: 20px; }
    .row { display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }
    .between { justify-content: space-between; }

    h2 { margin: 0 0 5px; color: var(--dark); font-size: 24px; font-weight: 700; }
    .notice { color: var(--muted); font-size: 13px; line-height: 1.5; }
    
    /* Tabs & Filters */
    .tab-container { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 15px; border-bottom: 1px solid #eee; padding-bottom: 15px; margin-bottom: 20px; }
    .tabBtn { border-radius: 10px; padding: 8px 16px; font-size: 14px; text-decoration: none; color: var(--muted); font-weight: 600; transition: 0.2s; }
    .tabBtn:hover { background: #f3f4f6; color: var(--dark); }
    .tabActive { background: #ecfdf5; color: var(--primary); }

    select { padding: 10px 15px; border-radius: 10px; border: 1px solid #ddd; outline: none; font-size: 14px; color: #444; cursor: pointer; }
    select:focus { border-color: var(--primary); }

    /* Tables */
    .tableWrap { overflow-x: auto; border: 1px solid #eee; border-radius: 12px; }
    table { width: 100%; border-collapse: collapse; min-width: 800px; }
    th { text-align: left; padding: 14px 20px; background: #f9fafb; color: #6b7280; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; border-bottom: 1px solid #e5e7eb; }
    td { padding: 16px 20px; border-bottom: 1px solid #f3f4f6; font-size: 14px; color: #374151; vertical-align: middle; }
    tr:hover td { background: #fafafa; }

    /* Badges */
    .badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; border: 1px solid transparent; }
    .badge.pending { background: #fffbeb; border-color: #fde68a; color: #92400e; }
    .badge.approved { background: #f0fdf4; border-color: #bbf7d0; color: #166534; }
    .badge.rejected { background: #fef2f2; border-color: #fecaca; color: #7f1d1d; }
    .badge.transferred { background: #eff6ff; border-color: #bfdbfe; color: #1e3a8a; }

    .link { color: var(--primary); text-decoration: none; font-weight: 600; }
    .link:hover { text-decoration: underline; }

    /* Dialog/Modal */
    dialog { border: none; border-radius: 16px; width: 90%; max-width: 700px; padding: 30px; box-shadow: 0 20px 50px rgba(0,0,0,0.2); }
    dialog::backdrop { background: rgba(0,0,0,0.4); backdrop-filter: blur(2px); }
    .modalHead { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
    .modalHead h3 { font-size: 18px; color: var(--dark); font-weight: 700; margin: 0; }

    textarea { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 10px; font-size: 14px; outline: none; font-family: inherit; resize: vertical; }
    textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }

    .kv-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; }
    .kv-label { color: var(--muted); font-weight: 500; }
    .kv-val { font-weight: 600; color: var(--dark); text-align: right; }

    @media (max-width: 1000px) {
        .sidebar { display: none; }
        .wrap { margin-left: 0; width: 100%; padding: 20px; }
    }
</style>
</head>

<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<div class="wrap">
  
  <div class="card">
    <div class="row between">
      <div>
        <h2>Semakan Cadangan</h2>
        <div class="notice">Luluskan atau tolak cadangan acara daripada penduduk.</div>
      </div>
      <a href="ajk_admin_calendar.php" class="btn"><i class="fas fa-arrow-left"></i> Kembali ke Kalendar</a>
    </div>

    <div class="tab-container">
        <a href="ajk_admin_calendar.php" class="tabBtn">Jadual</a>
        <a href="ajk_admin_calendar_proposals.php" class="tabBtn tabActive">Cadangan</a>
        <a href="ajk_admin_calendar_reminders.php" class="tabBtn">Peringatan</a>
        <a href="ajk_admin_calendar_settings.php" class="tabBtn">Tetapan</a>
    </div>

    <div class="row between" style="margin-top: 20px;">
        <div class="row">
            <select id="filterStatus">
              <option value="">Semua Status</option>
              <option value="PENDING">Menunggu (Pending)</option>
              <option value="APPROVED">Lulus (Approved)</option>
              <option value="REJECTED">Ditolak (Rejected)</option>
              <option value="TRANSFERRED">Dipindah ke Jadual</option>
            </select>
            <button class="btn small" id="btnRefresh" type="button"><i class="fas fa-sync"></i> Refresh</button>
        </div>
        <div class="notice" id="countText" style="font-weight: 600;">Memuatkan...</div>
    </div>

    <div class="tableWrap" style="margin-top: 15px;">
      <table>
        <thead>
          <tr>
            <th>Tarikh Hantar</th>
            <th>Pengguna</th>
            <th>Tajuk Cadangan</th>
            <th>Tarikh Acara</th>
            <th>Status</th>
            <th>Tindakan</th>
          </tr>
        </thead>
        <tbody id="tbody">
          <tr><td colspan="6" class="notice" style="text-align:center; padding:30px;">Memuatkan data...</td></tr>
        </tbody>
      </table>
    </div>
  </div>

</div>

<dialog id="dlg">
  <div class="modalHead">
    <h3>Butiran Cadangan</h3>
    <button class="btn small" type="button" onclick="dlg.close()"><i class="fas fa-times"></i></button>
  </div>

  <div id="details"></div>

  <div style="margin-top:20px; border-top:1px solid #eee; padding-top:15px;">
    <div class="row between" style="margin-bottom:10px;">
        <label style="font-size:13px; font-weight:600;">Catatan AJK / Alasan Penolakan</label>
        <button class="btn small" type="button" id="btnAutoNote">Auto-format (Request Info)</button>
    </div>
    
    <textarea id="ajk_note" rows="3" placeholder="Tulis catatan di sini..."></textarea>

    <div class="row" style="justify-content:flex-end; margin-top:20px;">
      <button class="btn danger" id="btnReject" type="button"><i class="fas fa-times"></i> Tolak</button>
      <button class="btn primary" id="btnApprove" type="button"><i class="fas fa-check"></i> Lulus</button>
      <button class="btn primary" id="btnTransfer" type="button" style="display:none; background:#1e3a8a; border-color:#1e3a8a;"><i class="fas fa-calendar-plus"></i> Pindah ke Jadual</button>
    </div>

    <div class="notice" id="msg" style="margin-top:10px; text-align:right;"></div>
  </div>
</dialog>

<script>
const tbody = document.getElementById('tbody');
const dlg = document.getElementById('dlg');
const details = document.getElementById('details');
const msg = document.getElementById('msg');
const ajkNote = document.getElementById('ajk_note');
const btnTransfer = document.getElementById('btnTransfer');
const countText = document.getElementById('countText');
const filterStatus = document.getElementById('filterStatus');

const viewerName = <?php echo json_encode($viewerName, JSON_UNESCAPED_UNICODE); ?>;
let currentItem = null;

function esc(s){ return (s ?? '').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function nl2br(s){ return esc(s).replace(/\n/g,'<br>'); }

function badgeHTML(status){
  const s = (status || '').toUpperCase();
  let cls = '';
  if (s === 'PENDING') cls = 'pending';
  else if (s === 'APPROVED') cls = 'approved';
  else if (s === 'REJECTED') cls = 'rejected';
  else if (s === 'TRANSFERRED') cls = 'transferred';
  return `<span class="badge ${cls}">${esc(s)}</span>`;
}

function formatRequestNote(raw){
  const now = new Date();
  const pad = (n)=>String(n).padStart(2,'0');
  const ts = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
  const body = (raw || '').trim();
  return `[REQUEST ${ts}]\n${body}\nDisemak oleh: AJK i-Desa (${viewerName})`;
}

async function load(){
  try{
    countText.textContent = "Memuatkan...";
    tbody.innerHTML = '<tr><td colspan="6" class="notice" style="text-align:center; padding:30px;">Memuatkan...</td></tr>';

    const res = await fetch('ajax_calendar_proposal.php?action=all_proposals', {credentials:'same-origin'});
    const json = await res.json();

    if(!json.ok){
      tbody.innerHTML = '<tr><td colspan="6" class="notice" style="text-align:center; color:red;">Gagal memuat data.</td></tr>';
      return;
    }

    let items = (json.data && json.data.items) ? json.data.items : [];
    const f = (filterStatus.value || '').toUpperCase().trim();
    if(f) items = items.filter(x => (x.status || '').toUpperCase() === f);

    countText.textContent = `${items.length} rekod dijumpai`;
    tbody.innerHTML = '';

    if(items.length===0){
      tbody.innerHTML = '<tr><td colspan="6" class="notice" style="text-align:center; padding:30px;">Tiada cadangan untuk paparan ini.</td></tr>';
      return;
    }

    items.forEach(it=>{
      const p = it.proposal || {};
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${esc(it.created_at)}</td>
        <td>
            <div style="font-weight:600; color:#333;">${esc(it.full_name || '-') }</div>
            <div style="font-size:12px; color:#888;">${esc(it.email || '')}</div>
        </td>
        <td><a class="link" href="javascript:void(0)">${esc(p.title || '-')}</a></td>
        <td>${esc(p.start_datetime || '')}</td>
        <td>${badgeHTML(it.status)}</td>
        <td><button class="btn small" type="button">Lihat</button></td>
      `;
      tr.querySelector('button').addEventListener('click', ()=>open(it));
      tr.querySelector('a').addEventListener('click', ()=>open(it));
      tbody.appendChild(tr);
    });

  }catch(e){
    console.warn(e);
    tbody.innerHTML = '<tr><td colspan="6" class="notice" style="text-align:center;">Ralat rangkaian.</td></tr>';
  }
}

function open(it){
  currentItem = it;
  const p = it.proposal || {};
  ajkNote.value = (p.ajk_note || '');
  msg.textContent = '';

  const st = (it.status || '').toUpperCase();
  btnTransfer.style.display = (st === 'APPROVED') ? 'inline-flex' : 'none';
  
  // Toggle Approve/Reject buttons visibility based on status
  const isPending = st === 'PENDING';
  document.getElementById('btnApprove').style.display = isPending ? 'inline-flex' : 'none';
  document.getElementById('btnReject').style.display = isPending ? 'inline-flex' : 'none';

  details.innerHTML = `
    <div style="background:#f9fafb; padding:15px; border-radius:12px; margin-bottom:15px; border:1px solid #eee;">
      <div class="row between" style="margin-bottom:10px;">
        <span class="badge" style="background:#e5e7eb; color:#444;">ID #${esc(it.activity_id)}</span>
        ${badgeHTML(st)}
      </div>
      <div class="kv-row"><span class="kv-label">Pengguna</span><span class="kv-val">${esc(it.full_name)}</span></div>
      <div class="kv-row"><span class="kv-label">Email</span><span class="kv-val">${esc(it.email)}</span></div>
    </div>

    <div style="margin-bottom:5px; font-size:12px; font-weight:700; color:#888; text-transform:uppercase;">Tajuk Acara</div>
    <div style="font-size:16px; font-weight:700; color:var(--primary); margin-bottom:15px;">${esc(p.title)}</div>

    <div class="grid-2" style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:15px;">
        <div>
            <div style="font-size:12px; font-weight:700; color:#888;">Mula</div>
            <div>${esc(p.start_datetime)}</div>
        </div>
        <div>
            <div style="font-size:12px; font-weight:700; color:#888;">Tamat</div>
            <div>${esc(p.end_datetime)}</div>
        </div>
    </div>

    <div style="margin-bottom:5px; font-size:12px; font-weight:700; color:#888;">Lokasi</div>
    <div style="margin-bottom:15px;">${esc(p.location || '-')}</div>

    <div style="margin-bottom:5px; font-size:12px; font-weight:700; color:#888;">Kategori</div>
    <div style="margin-bottom:15px;">${esc(p.category || '-')}</div>

    <div style="margin-bottom:5px; font-size:12px; font-weight:700; color:#888;">Penerangan</div>
    <div style="background:#fff; border:1px solid #eee; padding:10px; border-radius:8px; font-size:14px; line-height:1.5;">${nl2br(p.description || '-')}</div>

    ${ p.attachment ? `<div style="margin-top:15px;"><a class="btn small" href="uploads/proposals/${encodeURIComponent(p.attachment)}" target="_blank"><i class="fas fa-paperclip"></i> Lihat Lampiran</a></div>` : '' }
  `;

  dlg.showModal();
}

async function review(decision){
  if(!currentItem) return;
  if(!confirm(`Adakah anda pasti mahu ${decision} cadangan ini?`)) return;

  msg.textContent = 'Menyimpan...';
  const fd = new FormData();
  fd.append('action','review_proposal');
  fd.append('activity_id', currentItem.activity_id);
  fd.append('decision', decision);
  fd.append('ajk_note', ajkNote.value);

  try{
    const res = await fetch('ajax_calendar_proposal.php', {method:'POST', body:fd, credentials:'same-origin'});
    const json = await res.json();
    if(!json.ok) throw new Error(json.error);
    msg.textContent = 'Berjaya!';
    dlg.close();
    await load();
  }catch(e){ msg.textContent = 'Ralat: ' + e.message; }
}

document.getElementById('btnApprove').addEventListener('click', ()=>review('APPROVED'));
document.getElementById('btnReject').addEventListener('click', ()=>review('REJECTED'));

btnTransfer.addEventListener('click', async ()=>{
  if(!currentItem) return;
  if(!confirm("Pindahkan acara ini ke Kalendar Rasmi?")) return;

  msg.textContent = 'Memproses...';
  const fd = new FormData();
  fd.append('action','transfer_to_schedule');
  fd.append('activity_id', currentItem.activity_id);

  try{
    const res = await fetch('ajax_calendar_proposal.php', {method:'POST', body:fd, credentials:'same-origin'});
    const json = await res.json();
    if(!json.ok) throw new Error(json.error);
    alert('Berjaya dipindahkan ke Jadual Rasmi.');
    dlg.close();
    await load();
  }catch(e){ msg.textContent = 'Ralat: ' + e.message; }
});

document.getElementById('btnRefresh').addEventListener('click', load);
filterStatus.addEventListener('change', load);

document.getElementById('btnAutoNote').addEventListener('click', ()=>{
  const raw = ajkNote.value.trim() || "Sila berikan maklumat tambahan (contoh: lokasi tepat, tujuan acara).";
  ajkNote.value = formatRequestNote(raw);
});

load();
</script>
</body>
</html>