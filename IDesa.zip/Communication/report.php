<?php
session_start();
include "db_connect.php";

// 1. Security Check
if (!isset($_SESSION['user_id']) || (($_SESSION['role'] ?? '') !== 'AJK' && ($_SESSION['role'] ?? '') !== 'Admin')) {
    header("Location: homepage.php");
    exit();
}

$role = $_SESSION['role'];

// HTML Helper
if (!function_exists('h')) {
  function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

// Helper: Check Table Exists
function tableExists(mysqli $conn, string $table): bool {
    $sql = "SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return false;
    mysqli_stmt_bind_param($stmt, "s", $table);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    return (bool)($res && mysqli_fetch_row($res));
}

// Helper: Safe Count
function safeCount(mysqli $conn, string $sql, int $fallback = 0): int {
    try {
        $res = mysqli_query($conn, $sql);
        if (!$res) return $fallback;
        $row = mysqli_fetch_assoc($res);
        return (int)($row['total'] ?? $fallback);
    } catch (Throwable $e) { return $fallback; }
}

// UI Mapping
$statusBM = [ 'New' => 'Baru', 'Reviewed' => 'Disemak', 'In Progress' => 'Dalam Tindakan', 'Resolved' => 'Selesai' ];

// 2. Statistics
$resident_count  = safeCount($conn, "SELECT COUNT(*) as total FROM users WHERE role='Resident'");
$complaint_count = safeCount($conn, "SELECT COUNT(*) as total FROM complaints");
$post_count = tableExists($conn, 'bulletin_posts') ? safeCount($conn, "SELECT COUNT(*) as total FROM bulletin_posts") : 0;
$bulletin_feedback_count = tableExists($conn, 'bulletin_feedback') ? safeCount($conn, "SELECT COUNT(*) as total FROM bulletin_feedback") : 0;
$new_regs = safeCount($conn, "SELECT COUNT(*) as total FROM users WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())");

// 3. Fetch Data Tables
$complaints = [];
try {
    $sql_complaints = "SELECT c.id, COALESCE(u.full_name, c.complaint_name) AS full_name, c.created_at, c.status FROM complaints c LEFT JOIN users u ON c.user_id = u.user_id ORDER BY c.created_at DESC LIMIT 5";
    $res = mysqli_query($conn, $sql_complaints);
    while ($res && ($row = mysqli_fetch_assoc($res))) $complaints[] = $row;
} catch (Throwable $e) { $complaints = []; }

$posts = [];
if (tableExists($conn, 'bulletin_posts')) {
    $res = mysqli_query($conn, "SELECT post_id, title, category, created_at FROM bulletin_posts ORDER BY created_at DESC LIMIT 5");
    while ($res && ($row = mysqli_fetch_assoc($res))) $posts[] = $row;
}

$bf = [];
if (tableExists($conn, 'bulletin_feedback')) {
    $sql_bf = "SELECT bf.feedback_id, bf.feedback_text, bf.created_at, bp.title AS post_title FROM bulletin_feedback bf LEFT JOIN bulletin_posts bp ON bp.post_id = bf.post_id ORDER BY bf.created_at DESC LIMIT 5";
    $res = mysqli_query($conn, $sql_bf);
    while ($res && ($row = mysqli_fetch_assoc($res))) $bf[] = $row;
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Laporan Sistem | i-Desa</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; }
        :root { 
            --primary: #2d6a4f; 
            --dark: #143d29; 
            --bg: #f4f7f6; 
            --card: #fff; 
            --text: #333; 
            --muted: #6b7280; 
        }
        
        body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); display:flex; min-height:100vh; }

        /* Sidebar */
        .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; box-shadow: 4px 0 15px rgba(0,0,0,0.05); }
        .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
        .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
        .logo-text { display: flex; flex-direction: column; line-height: 1; }
        .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
        .logo-main span { color: #4ade80; }
        .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }
        .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
        .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: 0.2s; }
        .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
        .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
        .nav-item i { width: 18px; text-align: center; font-size: 16px; }
        .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

        /* Main Content */
        .content { margin-left: 250px; padding: 30px; width: calc(100% - 250px); }
        
        .head { display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; }
        .title { margin:0; font-size:24px; color:var(--dark); font-weight: 700; }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; }

        /* Stats Grid */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: var(--card); border-radius: 16px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); display: flex; align-items: center; gap: 15px; border: 1px solid #eee; }
        .stat-icon { width: 50px; height: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; }
        .stat-info h3 { margin: 0; font-size: 28px; color: var(--dark); font-weight: 700; }
        .stat-info p { margin: 0; font-size: 13px; color: var(--muted); font-weight: 600; text-transform: uppercase; }

        /* Colors for Icons */
        .blue { background: #e0f2fe; color: #0284c7; }
        .purple { background: #f3e8ff; color: #7e22ce; }
        .orange { background: #ffedd5; color: #c2410c; }
        .green { background: #dcfce7; color: #15803d; }

        /* Report Sections */
        .report-section { background: var(--card); border-radius: 16px; padding: 25px; margin-bottom: 30px; border: 1px solid #eee; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .section-header { font-size: 16px; font-weight: 700; color: var(--primary); margin-bottom: 15px; border-bottom: 2px solid #f0fdf4; padding-bottom: 10px; display: inline-block; }

        /* Tables */
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 12px 15px; background: #f9fafb; color: #64748b; font-size: 12px; font-weight: 600; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
        td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; color: #334155; }
        tr:hover td { background: #fcfcfc; }

        /* Badges */
        .status-pill { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
        .st-done { background: #dcfce7; color: #166534; }
        .st-pend { background: #fee2e2; color: #991b1b; }
        .st-prog { background: #e0f2fe; color: #075985; }

        /* Print Button */
        .btn-print { background: var(--dark); color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; display: inline-flex; align-items: center; gap: 8px; transition: 0.2s; }
        .btn-print:hover { background: #0f2e1f; }

        /* Print Styles */
        @media print {
            .sidebar, .btn-print, .divider { display: none !important; }
            .content { margin: 0; width: 100%; padding: 0; }
            body { background: white; -webkit-print-color-adjust: exact; }
            .stat-card, .report-section { box-shadow: none; border: 1px solid #ccc; break-inside: avoid; }
        }

        @media (max-width: 900px) {
            .sidebar { display: none; }
            .content { margin: 0; width: 100%; padding: 20px; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item"><i class="fas fa-chart-pie"></i> <span>Dashboard</span></a>
        
        <?php if($role === 'Admin'): ?>
            <a href="manage_residents.php" class="nav-item"><i class="fas fa-users-cog"></i> <span>Urus Pengguna</span></a>
        <?php endif; ?>

        <a href="manage_news.php" class="nav-item"><i class="fas fa-newspaper"></i> <span>Urus Buletin</span></a>
        <a href="admin_rental.php" class="nav-item"><i class="fas fa-building"></i> <span>Sewa Fasiliti</span></a>
        <a href="admin_emergency.php" class="nav-item"><i class="fas fa-phone-alt"></i> <span>Kecemasan</span></a>
        <a href="ajk_lostfound.php" class="nav-item"><i class="fas fa-search"></i> <span>Hilang/Jumpa</span></a>
        <a href="ajk_admin_calendar.php" class="nav-item"><i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span></a>
        <a href="complaint.php" class="nav-item"><i class="fas fa-clipboard"></i> <span>Urus Aduan</span></a>
        
        <a href="report.php" class="nav-item active"><i class="fas fa-file-invoice"></i> <span>Laporan</span></a>
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span></a>
</aside>

<main class="content">
    <div class="head">
        <div>
            <h1 class="title">Laporan & Analisis Sistem</h1>
            <p class="sub">Ringkasan prestasi bulanan dan rekod aktiviti i-Desa.</p>
        </div>
        <button onclick="window.print()" class="btn-print"><i class="fas fa-print"></i> Cetak Laporan</button>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon blue"><i class="fas fa-users"></i></div>
            <div class="stat-info">
                <p>Penduduk</p>
                <h3><?php echo number_format($resident_count); ?></h3>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon orange"><i class="fas fa-clipboard-list"></i></div>
            <div class="stat-info">
                <p>Jumlah Aduan</p>
                <h3><?php echo number_format($complaint_count); ?></h3>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon purple"><i class="fas fa-bullhorn"></i></div>
            <div class="stat-info">
                <p>Pengumuman</p>
                <h3><?php echo number_format($post_count); ?></h3>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green"><i class="fas fa-user-plus"></i></div>
            <div class="stat-info">
                <p>Daftar Baru (Bulan Ini)</p>
                <h3><?php echo number_format($new_regs); ?></h3>
            </div>
        </div>
    </div>

    <div class="report-section">
        <div class="section-header">Log Aduan Terkini</div>
        <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th>ID Rujukan</th>
                        <th>Pengadu</th>
                        <th>Tarikh</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($complaints)): ?>
                        <tr><td colspan="4" style="text-align:center; padding:20px;">Tiada rekod.</td></tr>
                    <?php else: foreach($complaints as $row): 
                        $st = $row['status'] ?: 'New';
                        $cls = ($st === 'Resolved') ? 'st-done' : (($st === 'In Progress') ? 'st-prog' : 'st-pend');
                    ?>
                        <tr>
                            <td><strong>#AD-<?php echo (int)$row['id']; ?></strong></td>
                            <td><?php echo h($row['full_name']); ?></td>
                            <td><?php echo h(date('d/m/Y', strtotime($row['created_at']))); ?></td>
                            <td><span class="status-pill <?php echo $cls; ?>"><?php echo h($statusBM[$st] ?? $st); ?></span></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="report-section">
        <div class="section-header">Pengumuman Terkini</div>
        <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tajuk Berita</th>
                        <th>Kategori</th>
                        <th>Tarikh Terbit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($posts)): ?>
                        <tr><td colspan="4" style="text-align:center; padding:20px;">Tiada pengumuman.</td></tr>
                    <?php else: foreach($posts as $p): ?>
                        <tr>
                            <td>#BP-<?php echo (int)$p['post_id']; ?></td>
                            <td><?php echo h($p['title']); ?></td>
                            <td><span style="font-weight:600; color:var(--primary);"><?php echo h($p['category']); ?></span></td>
                            <td><?php echo h(date('d M Y', strtotime($p['created_at']))); ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="report-section">
        <div class="section-header">Maklum Balas Penduduk</div>
        <div style="overflow-x:auto;">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Berita Berkaitan</th>
                        <th>Maklum Balas</th>
                        <th>Tarikh</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($bf)): ?>
                        <tr><td colspan="4" style="text-align:center; padding:20px;">Tiada maklum balas.</td></tr>
                    <?php else: foreach($bf as $f): ?>
                        <tr>
                            <td>#FB-<?php echo (int)$f['feedback_id']; ?></td>
                            <td><?php echo h($f['post_title'] ?? '(Hapus)'); ?></td>
                            <td><?php echo h($f['feedback_text']); ?></td>
                            <td><?php echo h(date('d/m/Y', strtotime($f['created_at']))); ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div style="text-align:center; color:#888; font-size:12px; margin-top:30px;">
        Laporan dijana pada <?php echo date('d M Y, H:i'); ?> oleh <?php echo h($_SESSION['full_name'] ?? 'Admin'); ?>
    </div>

</main>

</body>
</html>