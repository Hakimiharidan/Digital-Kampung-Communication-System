<?php
session_start();
include "db_connect.php";
include "navbar.php";

// Security: Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$role = $_SESSION['role'] ?? 'Resident';

// Server-side fallback (if AJAX is not ready)
$fallback_sql = "
    SELECT report_id, type, item_name, category, location_detail, incident_date, image_path, created_at, status
    FROM lost_found_reports
    WHERE status = 'Published'
    ORDER BY created_at DESC
    LIMIT 12
";
$fallback_result = mysqli_query($conn, $fallback_sql);
$fallback_items = [];
if ($fallback_result) {
    while ($row = mysqli_fetch_assoc($fallback_result)) {
        $fallback_items[] = $row;
    }
}

// Mapping label BM
$categoryBM = [
    "Electronics" => "Elektronik",
    "Documents" => "Dokumen",
    "Wallet/Purse" => "Dompet / Beg",
    "Keys" => "Kunci",
    "Pets" => "Haiwan",
    "Clothing" => "Pakaian",
    "Other" => "Lain-lain",
];
$typeBM = [
    "Lost" => "Hilang",
    "Found" => "Jumpa",
];
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Barang Hilang & Jumpa</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        :root { --primary-green:#2d6a4f; --accent-brown:#6d4c41; --text-dark:#333; --bg:#f7faf7; --card:#fff; --muted:#6b7280; }
        body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text-dark); }
        nav { display:flex; justify-content:space-between; align-items:center; padding:20px 8%; background:#fff; box-shadow:0 2px 10px rgba(0,0,0,0.05); position:sticky; top:0; z-index:1000; }
        .logo { font-size:28px; font-weight:bold; color:var(--primary-green); text-decoration:none; }
        .logo span { color:var(--accent-brown); }
        .nav-links { display:flex; gap:22px; align-items:center; flex-wrap:wrap; }
        .nav-links a { text-decoration:none; color:#555; font-weight:500; transition:.2s; }
        .nav-links a:hover { color:var(--primary-green); }
        
        /* Buttons */
        .btn-pill { background:var(--primary-green); color:white !important; padding:10px 18px; border-radius:999px; font-size:14px; text-decoration:none; display:inline-flex; align-items:center; gap:6px; transition:0.2s; }
        .btn-pill:hover { opacity: 0.9; }
        
        .btn-outline { border:1px solid var(--primary-green); color:var(--primary-green) !important; padding:10px 18px; border-radius:999px; font-size:14px; background:#fff; text-decoration:none; display:inline-flex; align-items:center; gap:6px; transition:0.2s;}
        .btn-outline:hover { background: #eefdf3; }

        .wrap { padding:26px 8% 60px; }
        .head { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; }
        .title { margin:0; font-size:28px; color:var(--primary-green); }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; }
        .actions { display:flex; gap:10px; flex-wrap:wrap; }

        .panel { margin-top:18px; background:var(--card); border:1px solid #eaeaea; border-radius:16px; padding:16px; box-shadow:0 8px 24px rgba(0,0,0,0.04); }
        
        /* Filters */
        .filters { display:grid; grid-template-columns: 1fr 0.7fr 0.9fr 0.6fr auto; gap:12px; align-items:center; }
        .filters input, .filters select { width:100%; padding:10px 12px; border-radius:12px; border:1px solid #e5e7eb; outline:none; font-family:inherit; box-sizing: border-box; }
        .filters button { padding:10px 14px; border-radius:12px; border:0; cursor:pointer; font-weight:600; white-space: nowrap; }
        
        .search-wrapper { position: relative; width: 100%; }
        .search-wrapper i { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #9ca3af; font-size: 14px; pointer-events: none; }
        .search-wrapper input { padding-left: 38px; }

        .btn-primary { background:var(--primary-green); color:#fff; }
        .btn-soft { background:#ecf5ef; color:var(--primary-green); }

        .meta-row { display:flex; gap:10px; flex-wrap:wrap; margin-top:10px; color:var(--muted); font-size:13px; }
        .pill { display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; border:1px solid #e5e7eb; background:#fff; }
        .badge { display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; font-weight:600; font-size:12px; }
        .badge-lost { background:#fff1f2; color:#9f1239; border:1px solid #fecdd3; }
        .badge-found { background:#ecfeff; color:#155e75; border:1px solid #a5f3fc; }

        .grid { margin-top:18px; display:grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap:14px; }
        .card { background:var(--card); border:1px solid #eaeaea; border-radius:16px; overflow:hidden; box-shadow:0 10px 26px rgba(0,0,0,0.04); cursor:pointer; transition:.15s; }
        .card:hover { transform: translateY(-2px); border-color:#d7eadf; }
        .thumb { height:150px; background:#f3f4f6; display:flex; align-items:center; justify-content:center; color:#9ca3af; }
        .thumb img { width:100%; height:100%; object-fit:cover; display:block; }
        .card-body { padding:14px; }
        .item-title { margin:0; font-size:16px; font-weight:700; color:#111827; line-height:1.25; }
        .item-sub { margin:8px 0 0; color:var(--muted); font-size:13px; }
        .card-foot { margin-top:10px; display:flex; justify-content:space-between; align-items:center; gap:10px; color:var(--muted); font-size:12px; }

        .state { margin-top:18px; text-align:center; color:var(--muted); padding:22px; border:1px dashed #d1d5db; border-radius:16px; background:#fff; }
        .state i { font-size:24px; margin-bottom:8px; color:#9ca3af; }

        /* Modal */
        .modal-backdrop { position:fixed; inset:0; background:rgba(0,0,0,.45); display:none; align-items:center; justify-content:center; padding:16px; z-index:2000; }
        .modal { width:min(920px, 100%); background:#fff; border-radius:18px; overflow:hidden; box-shadow:0 30px 70px rgba(0,0,0,.25); }
        .modal-head { padding:14px 16px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #eee; }
        .modal-head h3 { margin:0; font-size:16px; color:var(--primary-green); }
        .modal-close { background:transparent; border:0; cursor:pointer; font-size:18px; color:#6b7280; }
        .modal-body { padding:16px; display:grid; grid-template-columns: 1.05fr 0.95fr; gap:16px; }
        .modal-img { background:#f3f4f6; border-radius:14px; overflow:hidden; min-height:260px; display:flex; align-items:center; justify-content:center; color:#9ca3af; }
        .modal-img img { width:100%; height:100%; object-fit:cover; }
        .modal-meta { display:flex; flex-wrap:wrap; gap:8px; margin:8px 0 10px; }
        .kv { margin:0; color:#111827; font-size:14px; }
        .kv span { color:var(--muted); font-weight:500; }
        .desc { margin-top:10px; padding:12px; border:1px solid #eee; border-radius:14px; background:#fafafa; color:#111827; font-size:14px; white-space:pre-wrap; }
        .modal-actions { margin-top:12px; display:flex; gap:10px; flex-wrap:wrap; }
        .small { font-size:12px; color:var(--muted); margin-top:6px; }

        @media (max-width: 860px) {
            .filters { grid-template-columns: 1fr 1fr; }
            .modal-body { grid-template-columns: 1fr; }
        }
    </style>
</head>

<body>

<div class="wrap">
    <div class="head">
        <div>
            <h1 class="title">Barang Hilang & Jumpa</h1>
            <p class="sub">Laporan akan dipaparkan selepas disahkan oleh AJK. Sila gunakan maklumat yang jelas.</p>
        </div>

        <div class="actions">
            <?php if ($role === 'AJK' || $role === 'Admin'): ?>
                <a class="btn-pill" href="ajk_lostfound.php" style="background:var(--accent-brown); border-color:var(--accent-brown);">
                    <i class="fa-solid fa-user-shield"></i> Urus Laporan
                </a>
            <?php endif; ?>
            <a class="btn-pill" href="lostfound_report.php"><i class="fa-solid fa-plus"></i> Buat Laporan</a>
            <a class="btn-outline" href="lostfound_myreports.php"><i class="fa-regular fa-folder-open"></i> Laporan Saya</a>
        </div>
    </div>

    <div class="panel">
        <div class="filters">
            <div class="search-wrapper">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input id="q" type="text" placeholder="Cari barang...">
            </div>

            <select id="type">
                <option value="">Semua Jenis</option>
                <option value="Lost">Hilang</option>
                <option value="Found">Jumpa</option>
            </select>
            <select id="category">
                <option value="">Semua Kategori</option>
                <option value="Electronics">Elektronik</option>
                <option value="Documents">Dokumen</option>
                <option value="Wallet/Purse">Dompet / Beg</option>
                <option value="Keys">Kunci</option>
                <option value="Pets">Haiwan</option>
                <option value="Clothing">Pakaian</option>
                <option value="Other">Lain-lain</option>
            </select>
            <select id="sort">
                <option value="newest">Terbaharu</option>
                <option value="oldest">Terlama</option>
                <option value="incident_newest">Tarikh Kejadian (Baharu)</option>
                <option value="incident_oldest">Tarikh Kejadian (Lama)</option>
            </select>

            <button class="btn-primary" id="btnSearch">Cari</button>
        </div>

        <div class="meta-row">
            <span class="pill" id="countPill"><i class="fa-solid fa-list"></i> <span id="countText">Memuat...</span></span>
        </div>
    </div>

    <div id="grid" class="grid">
        <?php if (count($fallback_items) === 0): ?>
            <div class="state" style="grid-column:1/-1;">
                <i class="fa-regular fa-face-smile"></i>
                <div>Tiada laporan yang dipaparkan buat masa ini.</div>
            </div>
        <?php else: ?>
            <?php foreach ($fallback_items as $it): ?>
                <?php
                    $rid = (int)$it['report_id'];
                    $t = $it['type'];
                    $badgeClass = ($t === 'Lost') ? 'badge-lost' : 'badge-found';
                    $badgeText = $typeBM[$t] ?? $t;
                    $cat = $it['category'];
                    $catText = $categoryBM[$cat] ?? $cat;
                    $title = htmlspecialchars($it['item_name'] ?? '', ENT_QUOTES, 'UTF-8');
                    $loc = htmlspecialchars($it['location_detail'] ?? '', ENT_QUOTES, 'UTF-8');
                    $inc = htmlspecialchars($it['incident_date'] ?? '', ENT_QUOTES, 'UTF-8');
                    $img = $it['image_path'] ?? '';
                ?>
                <div class="card" data-id="<?php echo $rid; ?>" onclick="openDetail(<?php echo $rid; ?>)">
                    <div class="thumb">
                        <?php if (!empty($img) && file_exists($img)): ?>
                            <img src="<?php echo htmlspecialchars($img, ENT_QUOTES, 'UTF-8'); ?>" alt="Gambar">
                        <?php else: ?>
                            <div><i class="fa-regular fa-image"></i> Tiada Gambar</div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="badge <?php echo $badgeClass; ?>"><i class="fa-solid fa-tag"></i> <?php echo $badgeText; ?></div>
                        <h3 class="item-title" style="margin-top:10px;"><?php echo $title; ?></h3>
                        <p class="item-sub"><i class="fa-solid fa-layer-group"></i> <?php echo htmlspecialchars($catText, ENT_QUOTES, 'UTF-8'); ?></p>
                        <p class="item-sub"><i class="fa-solid fa-location-dot"></i> <?php echo $loc; ?></p>
                        <div class="card-foot">
                            <span><i class="fa-regular fa-calendar"></i> <?php echo $inc; ?></span>
                            <span><i class="fa-regular fa-eye"></i> Lihat</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div id="state" class="state" style="display:none;">
        <i class="fa-solid fa-spinner fa-spin"></i>
        <div id="stateText">Memuatkan senarai...</div>
    </div>
</div>

<div class="modal-backdrop" id="modalBackdrop" onclick="closeModal(event)">
    <div class="modal" onclick="event.stopPropagation();">
        <div class="modal-head">
            <h3 id="modalTitle">Butiran Laporan</h3>
            <button class="modal-close" onclick="hideModal()" aria-label="Tutup"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body">
            <div class="modal-img" id="modalImg">
                <div><i class="fa-regular fa-image"></i> Tiada Gambar</div>
            </div>

            <div>
                <div class="modal-meta" id="modalBadges"></div>

                <p class="kv"><span>Jenis:</span> <span id="mType">-</span></p>
                <p class="kv"><span>Kategori:</span> <span id="mCategory">-</span></p>
                <p class="kv"><span>Lokasi:</span> <span id="mLocation">-</span></p>
                <p class="kv"><span>Tarikh Kejadian:</span> <span id="mIncident">-</span></p>
                <p class="kv"><span>Tarikh Laporan:</span> <span id="mCreated">-</span></p>

                <div class="desc" id="mDesc">-</div>

                <div class="modal-actions">
                    <button class="btn-primary" type="button" onclick="showClaimForm()">
                        <i class="fa-solid fa-hand"></i> Saya Pemilik / Saya Ingin Tuntut
                    </button>
                    <button class="btn-soft" type="button" onclick="hideModal()">
                        Tutup
                    </button>
                </div>

                <div id="claimBox" style="display:none; margin-top:12px;">
                    <div style="margin-bottom:8px; font-weight:600;">Maklumat Tuntutan</div>
                    <textarea id="claimMsg" rows="4" style="width:100%; padding:10px 12px; border-radius:12px; border:1px solid #e5e7eb; font-family:inherit;"
                        placeholder="Contoh: ciri unik / nombor rangka / tanda khas, atau penerangan untuk AJK semak."></textarea>
                    <div style="display:flex; gap:10px; margin-top:10px; flex-wrap:wrap;">
                        <button class="btn-primary" type="button" onclick="submitClaim()"><i class="fa-solid fa-paper-plane"></i> Hantar Tuntutan</button>
                        <button class="btn-soft" type="button" onclick="hideClaimForm()">Batal</button>
                    </div>
                    <div class="small" id="claimHint">* Tuntutan akan dihantar kepada AJK untuk pengesahan.</div>
                </div>

                <div class="small" id="modalNote"></div>
            </div>
        </div>
    </div>
</div>

<script>
    // ====== Config ======
    const AJAX_URL = "lostfound_ajax.php";
    const CAT_BM = { "Electronics":"Elektronik","Documents":"Dokumen","Wallet/Purse":"Dompet / Beg","Keys":"Kunci","Pets":"Haiwan","Clothing":"Pakaian","Other":"Lain-lain" };
    const TYPE_BM = { "Lost":"Hilang", "Found":"Jumpa" };
    let currentDetailId = null;

    // ====== DOM ======
    const grid = document.getElementById("grid");
    const stateBox = document.getElementById("state");
    const stateText = document.getElementById("stateText");
    const countText = document.getElementById("countText");
    const qEl = document.getElementById("q");
    const typeEl = document.getElementById("type");
    const catEl = document.getElementById("category");
    const sortEl = document.getElementById("sort");

    document.getElementById("btnSearch").addEventListener("click", () => fetchList(true));
    [qEl, typeEl, catEl, sortEl].forEach(el => el.addEventListener("change", () => fetchList(true)));
    qEl.addEventListener("keydown", (e) => { if(e.key === "Enter") fetchList(true); });

    function esc(s){ return (s ?? "").toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

    function showLoading(msg){ stateBox.style.display = "block"; stateText.textContent = msg || "Memuatkan senarai..."; }
    function hideLoading(){ stateBox.style.display = "none"; }

    function renderCards(items){
        if(!Array.isArray(items) || items.length === 0){
            grid.innerHTML = `<div class="state" style="grid-column:1/-1;"><i class="fa-regular fa-face-smile"></i><div>Tiada laporan yang sepadan.</div></div>`;
            countText.textContent = "0 rekod";
            return;
        }
        countText.textContent = items.length + " rekod";
        grid.innerHTML = items.map(it => {
            const rid = it.report_id;
            const badgeClass = (it.type === "Lost") ? "badge-lost" : "badge-found";
            const badgeText = TYPE_BM[it.type] || it.type;
            const imgHtml = (it.image_url) ? `<img src="${esc(it.image_url)}" alt="Gambar">` : `<div><i class="fa-regular fa-image"></i> Tiada Gambar</div>`;
            const catText = CAT_BM[it.category] || it.category || "-";
            return `
                <div class="card" data-id="${rid}" onclick="openDetail(${rid})">
                    <div class="thumb">${imgHtml}</div>
                    <div class="card-body">
                        <div class="badge ${badgeClass}"><i class="fa-solid fa-tag"></i> ${esc(badgeText)}</div>
                        <h3 class="item-title" style="margin-top:10px;">${esc(it.item_name || "-")}</h3>
                        <p class="item-sub"><i class="fa-solid fa-layer-group"></i> ${esc(catText)}</p>
                        <p class="item-sub"><i class="fa-solid fa-location-dot"></i> ${esc(it.location_detail || "-")}</p>
                        <div class="card-foot"><span><i class="fa-regular fa-calendar"></i> ${esc(it.incident_date || "-")}</span><span><i class="fa-regular fa-eye"></i> Lihat</span></div>
                    </div>
                </div>
            `;
        }).join("");
    }

    async function fetchList(forceAjax){
        showLoading("Memuatkan senarai (AJAX)...");
        try {
            const params = new URLSearchParams({ action: "list", q: qEl.value.trim(), type: typeEl.value, category: catEl.value, sort: sortEl.value });
            const res = await fetch(`${AJAX_URL}?${params.toString()}`, { credentials: "same-origin" });
            const data = await res.json();
            if(!data || data.ok !== true) throw new Error(data.error || "Gagal memuatkan data.");
            renderCards(data.items || []);
            hideLoading();
        } catch (err) {
            console.warn("AJAX list failed:", err);
            hideLoading();
            countText.textContent = "Paparan asas (fallback)";
        }
    }

    // ====== Modal Functions ======
    const modalBackdrop = document.getElementById("modalBackdrop");
    const modalTitle = document.getElementById("modalTitle");
    const modalImg = document.getElementById("modalImg");
    const modalBadges = document.getElementById("modalBadges");
    const [mType, mCategory, mLocation, mIncident, mCreated, mDesc, modalNote] = 
        ["mType", "mCategory", "mLocation", "mIncident", "mCreated", "mDesc", "modalNote"].map(id => document.getElementById(id));

    function openDetail(id){ currentDetailId = id; showModal(); loadDetail(id); }
    function showModal(){ hideClaimForm(); modalNote.textContent = ""; modalBackdrop.style.display = "flex"; document.body.style.overflow = "hidden"; }
    function hideModal(){ modalBackdrop.style.display = "none"; document.body.style.overflow = ""; currentDetailId = null; }
    function closeModal(e){ if(e.target === modalBackdrop) hideModal(); }

    async function loadDetail(id){
        modalTitle.textContent = "Memuatkan..."; modalImg.innerHTML = `<div><i class="fa-solid fa-spinner fa-spin"></i></div>`;
        modalBadges.innerHTML = ""; [mType, mCategory, mLocation, mIncident, mCreated, mDesc].forEach(el => el.textContent = "-");
        try {
            const res = await fetch(`${AJAX_URL}?action=detail&id=${id}`, { credentials: "same-origin" });
            const data = await res.json();
            if(!data || !data.ok || !data.item) throw new Error("Gagal.");
            const it = data.item;
            modalTitle.textContent = it.item_name || "Butiran";
            modalImg.innerHTML = (it.image_url) ? `<img src="${esc(it.image_url)}">` : `<div><i class="fa-regular fa-image"></i> Tiada Gambar</div>`;
            const badgeClass = (it.type === "Lost") ? "badge-lost" : "badge-found";
            modalBadges.innerHTML = `<span class="badge ${badgeClass}"><i class="fa-solid fa-tag"></i> ${esc(TYPE_BM[it.type]||it.type)}</span>`;
            mType.textContent = TYPE_BM[it.type]||it.type; mCategory.textContent = CAT_BM[it.category]||it.category;
            mLocation.textContent = it.location_detail; mIncident.textContent = it.incident_date; mCreated.textContent = it.created_at; mDesc.textContent = it.description;
            modalNote.textContent = (it.contact_share_consent && it.reporter_phone) ? "Hubungan: " + it.reporter_phone : "Hubungi AJK untuk urusan lanjut.";
        } catch (err) { modalTitle.textContent = "Ralat"; modalImg.innerHTML = "Gagal."; }
    }

    const claimBox = document.getElementById("claimBox");
    const claimMsg = document.getElementById("claimMsg");
    function showClaimForm(){ claimBox.style.display = "block"; claimMsg.focus(); }
    function hideClaimForm(){ claimBox.style.display = "none"; claimMsg.value = ""; }
    async function submitClaim(){
        if(!currentDetailId) return;
        const msg = claimMsg.value.trim();
        if(msg.length < 10) return alert("Sila isi maklumat (min 10 aksara).");
        try {
            const form = new FormData(); form.append("action", "claim_submit"); form.append("report_id", currentDetailId); form.append("message", msg);
            const res = await fetch(AJAX_URL, { method:"POST", body: form, credentials:"same-origin" });
            const data = await res.json();
            if(data.ok){ alert("Tuntutan dihantar."); hideClaimForm(); } else throw new Error(data.error);
        } catch (e) { alert("Gagal hantar tuntutan."); }
    }

    fetchList(true);
</script>

</body>
</html>
<?php include "footer.php"; ?>