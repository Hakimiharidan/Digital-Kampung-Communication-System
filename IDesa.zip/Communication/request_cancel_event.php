<?php
session_start();
include "db_connect.php";

// HTML escaping helper
if (!function_exists('h')) {
  function h($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
}

if (!isset($_SESSION['user_id'])) {
  header("Location: login_page.php");
  exit;
}

$userId = (int)($_SESSION['user_id'] ?? 0);
$role = $_SESSION['role'] ?? 'Resident';
$isAdminOrAjk = ($role === 'AJK' || $role === 'Admin');
$preselectId = (int)($_GET['event_id'] ?? 0);

// Applicant info
$applicantName = 'Pengguna';
$stmtU = mysqli_prepare($conn, "SELECT full_name FROM users WHERE user_id=? LIMIT 1");
if ($stmtU) {
  mysqli_stmt_bind_param($stmtU, "i", $userId);
  mysqli_stmt_execute($stmtU);
  $resU = mysqli_stmt_get_result($stmtU);
  if ($rowU = mysqli_fetch_assoc($resU)) {
    $applicantName = $rowU['full_name'] ?: $applicantName;
  }
  mysqli_stmt_close($stmtU);
}

// Fetch events
$events = [];
$sql = "SELECT event_id, title, start_datetime, end_datetime, status 
        FROM events 
        WHERE status <> 'Cancelled' 
          AND end_datetime >= NOW() 
        ORDER BY start_datetime ASC";
$res = mysqli_query($conn, $sql);
if ($res) {
  while ($row = mysqli_fetch_assoc($res)) { $events[] = $row; }
}
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Mohon Pembatalan</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
    * { box-sizing: border-box; }
    :root { 
        --primary: #2d6a4f; 
        --dark: #143d29; 
        --bg: #f4f7f6; 
        --card: #fff; 
        --text: #333; 
        --muted: #6b7280; 
        --border: #e5e7eb;
    }
    
    body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); display:flex; flex-direction:column; min-height:100vh; }

    /* --- SIDEBAR (For Admin/AJK) --- */
    .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; top:0; left:0; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; box-shadow: 4px 0 15px rgba(0,0,0,0.05); }
    .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
    .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
    .logo-text { display: flex; flex-direction: column; line-height: 1; }
    .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .logo-main span { color: #4ade80; }
    .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }
    .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
    .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: 0.2s; }
    .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
    .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
    .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

    /* --- CONTENT AREA --- */
    .wrap { 
        flex: 1;
        <?php if($isAdminOrAjk): ?>
            margin-left: 250px; 
            width: calc(100% - 250px);
            padding: 30px 40px 60px;
        <?php else: ?>
            margin: 0 auto;
            width: 100%;
            max-width: 1000px;
            padding: 30px 20px 60px;
        <?php endif; ?>
    }

    /* Cards & Forms */
    .card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); }
    
    h2 { margin: 0 0 5px; color: var(--dark); font-size: 24px; font-weight: 700; }
    .notice { color: var(--muted); font-size: 13px; margin-top: 5px; }
    
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
    @media (max-width: 800px) { .grid { grid-template-columns: 1fr; } }

    label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; color: #374151; }
    select, textarea { width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 10px; font-size: 14px; outline: none; transition: 0.2s; font-family: inherit; }
    select:focus, textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }

    /* Event Info Box */
    .info-box { background: #f9fafb; border: 1px solid #eee; border-radius: 12px; padding: 15px; }
    .kv-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 13px; border-bottom: 1px solid #f0f0f0; padding-bottom: 8px; }
    .kv-row:last-child { border: none; margin: 0; padding: 0; }
    .kv-label { color: var(--muted); }
    .kv-val { font-weight: 600; color: var(--text); text-align: right; }

    /* Buttons */
    .btn { padding: 10px 24px; border-radius: 50px; border: 1px solid #ddd; background: #fff; color: #555; cursor: pointer; font-weight: 600; font-size: 14px; transition: 0.2s; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; }
    .btn:hover { background: #f9fafb; transform: translateY(-1px); }
    .btn.primary { background: var(--primary); border-color: var(--primary); color: #fff; }
    .btn.primary:hover { opacity: 0.9; }
    .btn.primary:disabled { background: #ccc; border-color: #ccc; cursor: not-allowed; }

    /* Messages */
    .msg-box { margin-top: 15px; padding: 12px; border-radius: 8px; font-size: 13px; font-weight: 600; display: none; }
    .msg-box.success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; display: block; }
    .msg-box.error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; display: block; }

    @media (max-width: 1000px) {
        .sidebar { display: none; }
        .wrap { margin-left: 0; width: 100%; padding: 20px; }
    }
</style>
</head>

<body>

<?php if($isAdminOrAjk): ?>
    <aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_residents.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <?php if($role === 'Admin'): ?>
        <a href="manage_news.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>
        <?php endif; ?>

        <?php if($role === 'Admin'): ?>
        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Sewa Fasiliti</span>
        </a>
        <?php endif; ?>
        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
        <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
                <a href="ajk_admin_calendar.php" class="nav-item active">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>            
        </a>
        <?php endif; ?>
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>
<?php else: ?>
    <?php include "navbar.php"; ?>
<?php endif; ?>

<div class="wrap">
  
  <div class="card">
    <div style="border-bottom:1px solid #eee; padding-bottom:15px; margin-bottom:20px;">
        <h2>Mohon Pembatalan Acara</h2>
        <div class="notice">
            Hantar permohonan untuk membatalkan acara. Permohonan akan disemak oleh AJK/Admin sebelum diluluskan.
        </div>
    </div>

    <div class="grid">
      <div>
        <label>Pilih Acara</label>
        <select id="eventSelect">
          <option value="">-- Sila Pilih --</option>
          <?php foreach($events as $ev): ?>
            <option value="<?php echo (int)$ev['event_id']; ?>" <?php echo ($preselectId === (int)$ev['event_id']) ? 'selected' : ''; ?>>
              <?php echo h(date('d/m/Y', strtotime($ev['start_datetime']))); ?> — <?php echo h($ev['title']); ?>
            </option>
          <?php endforeach; ?>
        </select>

        <?php if(empty($events)): ?>
          <div class="notice" style="color:var(--muted); margin-top:10px;">
            Tiada acara aktif yang boleh dibatalkan.
          </div>
        <?php endif; ?>

        <div style="margin-top:20px;">
            <label>Butiran Acara</label>
            <div class="info-box" id="eventInfo">
                <div class="kv-row"><span class="kv-label">Tajuk</span><span class="kv-val">-</span></div>
                <div class="kv-row"><span class="kv-label">Tarikh</span><span class="kv-val">-</span></div>
                <div class="kv-row"><span class="kv-label">Lokasi</span><span class="kv-val">-</span></div>
                <div class="kv-row"><span class="kv-label">Kategori</span><span class="kv-val">-</span></div>
                <div class="kv-row"><span class="kv-label">Status</span><span class="kv-val">-</span></div>
            </div>
        </div>
      </div>

      <div>
        <form id="cancelForm">
          <label>Maklumat Pemohon</label>
          <div class="info-box" style="margin-bottom:15px;">
            <div class="kv-row"><span class="kv-label">Nama</span><span class="kv-val"><?php echo h($applicantName); ?></span></div>
            <div class="kv-row"><span class="kv-label">Peranan</span><span class="kv-val"><?php echo h($role); ?></span></div>
            <div class="kv-row"><span class="kv-label">Tarikh Mohon</span><span class="kv-val" id="tsNow">-</span></div>
          </div>

          <label>Sebab Pembatalan <span style="color:red">*</span></label>
          <textarea id="reason" rows="5" required placeholder="Sila nyatakan sebab (Contoh: Masalah cuaca, lokasi tidak tersedia, kecemasan...)"></textarea>
          <div class="notice">Sebab ini akan dipaparkan kepada pengguna jika diluluskan.</div>

          <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;">
            <?php if($isAdminOrAjk): ?>
                <a class="btn" href="ajk_admin_calendar.php">Batal</a>
            <?php else: ?>
                <a class="btn" href="calendar.php">Batal</a>
            <?php endif; ?>
            
            <button class="btn primary" type="submit" <?php echo empty($events) ? 'disabled' : ''; ?>>
                <i class="fas fa-paper-plane"></i> Hantar Permintaan
            </button>
          </div>

          <div id="msgBox" class="msg-box"></div>
        </form>
      </div>
    </div>
  </div>

</div>

<?php if(!$isAdminOrAjk) { include "footer.php"; } ?>

<script>
const AJAX_URL = "ajax_calendar.php";

function esc(s){ return (s ?? "").toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

async function fetchJSON(url, opts={}){
  try{
    const res = await fetch(url, opts);
    const ct = res.headers.get('content-type') || '';
    if(ct.includes('application/json')) return await res.json();
    return { ok:false, message: 'Respon bukan JSON.' };
  }catch(e){ return { ok:false, message: 'Ralat Rangkaian.' }; }
}

function setInfo(ev){
  const wrap = document.getElementById('eventInfo');
  if(!ev){
    wrap.innerHTML = `<div class="notice" style="text-align:center">Sila pilih acara</div>`;
    return;
  }
  wrap.innerHTML = `
    <div class="kv-row"><span class="kv-label">Tajuk</span><span class="kv-val">${esc(ev.title)}</span></div>
    <div class="kv-row"><span class="kv-label">Mula</span><span class="kv-val">${esc(ev.start_datetime)}</span></div>
    <div class="kv-row"><span class="kv-label">Tamat</span><span class="kv-val">${esc(ev.end_datetime)}</span></div>
    <div class="kv-row"><span class="kv-label">Lokasi</span><span class="kv-val">${esc(ev.location)}</span></div>
    <div class="kv-row"><span class="kv-label">Kategori</span><span class="kv-val">${esc(ev.category)}</span></div>
    <div class="kv-row"><span class="kv-label">Status</span><span class="kv-val">${esc(ev.status)}</span></div>
  `;
}

async function loadEventDetail(eventId){
  if(!eventId){ setInfo(null); return; }
  const json = await fetchJSON(`${AJAX_URL}?action=get_event_detail&event_id=${encodeURIComponent(eventId)}`, { credentials:'same-origin' });
  if(!json.ok){
    alert(json.message || 'Gagal ambil data acara.');
    return;
  }
  const ev = json?.data?.event || json?.event || null;
  setInfo(ev);
}

function nowTS(){
  const d = new Date();
  const pad = n => String(n).padStart(2,'0');
  return `${d.getDate()}/${pad(d.getMonth()+1)}/${d.getFullYear()}`;
}
document.getElementById('tsNow').textContent = nowTS();

const sel = document.getElementById('eventSelect');
sel.addEventListener('change', () => loadEventDetail(sel.value));
if(sel.value) loadEventDetail(sel.value);

document.getElementById('cancelForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const eventId = sel.value;
  const reason = document.getElementById('reason').value.trim();
  const box = document.getElementById('msgBox');
  const btn = e.target.querySelector('button[type="submit"]');

  if(!eventId) return alert("Sila pilih acara.");
  if(!reason) return alert("Sila isi sebab pembatalan.");

  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menghantar...';
  
  const fd = new FormData();
  fd.append('action', 'request_cancellation');
  fd.append('event_id', eventId);
  fd.append('reason', reason);

  const json = await fetchJSON(AJAX_URL, { method:'POST', body: fd, credentials:'same-origin' });
  
  box.className = 'msg-box ' + (json.ok ? 'success' : 'error');
  box.textContent = (json.data && json.data.message) ? json.data.message : (json.message || "Permintaan dihantar.");
  
  if(json.ok){
      document.getElementById('reason').value = '';
      setTimeout(() => {
          window.location.href = "<?php echo $isAdminOrAjk ? 'ajk_admin_calendar.php' : 'calendar.php'; ?>";
      }, 1500);
  } else {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-paper-plane"></i> Hantar Permintaan';
  }
});
</script>

</body>
</html>