<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}

$viewerName = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'AJK/Admin';
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Tetapan Kalendar</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    /* 1. Global Reset & Box Sizing */
    * { box-sizing: border-box; }
    
    :root { 
        --primary: #2d6a4f; 
        --dark: #143d29; /* Deep Green Theme */
        --brown: #6d4c41; 
        --text: #333; 
        --muted: #6b7280; 
        --bg: #f4f7f6; 
        --card: #fff; 
    }

    body { font-family: 'Poppins', sans-serif; margin: 0; background: var(--bg); color: var(--text); display: flex; }

    /* --- SIDEBAR (Deep Green) --- */
    .sidebar { 
        width: 250px; 
        height: 100vh; 
        background: var(--dark); 
        padding: 25px 18px; 
        position: fixed; 
        display: flex; 
        flex-direction: column; 
        color: #fff; 
        z-index: 100; 
        overflow-y: auto;
        box-shadow: 4px 0 15px rgba(0,0,0,0.05);
    }

    .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
    .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
    .logo-text { display: flex; flex-direction: column; line-height: 1; }
    .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .logo-main span { color: #4ade80; }
    .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

    .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
    .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
    .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
    .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
    .nav-item i { width: 18px; text-align: center; font-size: 16px; }
    .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

    /* --- CONTENT AREA --- */
    .wrap { 
        margin-left: 250px; 
        padding: 30px 8% 60px; 
        width: calc(100% - 250px);
    }

    .card { border:1px solid #e9e9e9; border-radius:16px; padding:25px; background:#fff; box-shadow:0 8px 20px rgba(0,0,0,0.03); max-width:900px; margin-top: 20px; }
    
    h2 { font-weight: 700; color: var(--dark); font-size: 22px; margin-bottom: 5px; }
    .notice { color:var(--muted); font-size:13px; margin-bottom: 20px; }
    
    .grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
    @media (max-width:820px){ 
        .sidebar { display: none; }
        .wrap { margin-left: 0; width: 100%; }
        .grid { grid-template-columns:1fr; } 
    }

    label { font-size:13px; font-weight:700; display: block; margin-bottom: 8px; color: #444; }
    input, select { width:100%; padding:12px; border-radius:10px; border:1px solid #ddd; outline: none; font-family: inherit; font-size: 14px; transition: 0.2s; }
    input:focus, select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }
    input:disabled { background: #f9fafb; color: #999; }

    .small { font-size:12px; color:var(--muted); margin-top: 5px; }
    hr { border:none; border-top:1px solid #eee; margin:20px 0; }

    .row { display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
    
    .btn { padding:10px 24px; border-radius:50px; border:0; cursor:pointer; font-weight:600; font-size: 14px; transition: 0.2s; }
    .btn.primary { background:var(--primary); color:#fff; }
    .btn.primary:hover { opacity: 0.9; transform: translateY(-1px); }
    .btn.gray { background:#f3f4f6; color: #555; border: 1px solid #ddd; }
    .btn.gray:hover { background: #e5e7eb; }

    .toast { display:none; margin-top:15px; padding:12px 15px; border-radius:12px; border:1px solid; font-size:13px; font-weight:600; }
    .toast.show { display:block; }
    .toast.ok { border-color:#b7dcc8; background:#ecf5ef; color:var(--primary); }
    .toast.err { border-color:#f0b4b4; background:#fff5f5; color:#b42318; }
</style>
</head>

<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<div class="wrap">
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <h2 style="margin:0;">Tetapan Kalendar</h2>
        <a href="ajk_admin_calendar.php" class="btn gray" style="text-decoration:none; font-size:12px;">Kembali ke Kalendar</a>
    </div>
    
    <div class="notice">
      Konfigurasi cara kalendar berfungsi untuk komuniti (AJK/Admin sahaja).
    </div>

    <hr>

    <form id="form">
      <div class="grid">
        <div>
          <label>Hari Peringatan (Reminder Days)</label>
          <input type="number" id="reminder_days" name="reminder_days" min="1" max="60" value="3" required>
          <div class="small">Contoh: 3 = hantar notifikasi 3 hari sebelum acara bermula.</div>
        </div>

        <div>
          <label>Auto Send Reminders</label>
          <select id="auto_send_reminders" name="auto_send_reminders">
            <option value="0">0 - Manual</option>
            <option value="1">1 - Auto (perlukan cron)</option>
          </select>
          <div class="small">Jika Auto=1, sistem akan cuba hantar peringatan secara automatik.</div>
        </div>

        <div>
          <label>Benarkan Acara Bertindih</label>
          <select id="allow_conflicting_events" name="allow_conflicting_events">
            <option value="FALSE">TIDAK (Block Double Booking)</option>
            <option value="TRUE">YA (Benarkan Overlap)</option>
          </select>
          <div class="small">Tetapan ini mengawal jika dua acara boleh berlaku pada masa yang sama.</div>
        </div>

        <div>
          <label>Pengguna Semasa</label>
          <input type="text" value="<?php echo htmlspecialchars($viewerName); ?>" disabled>
          <div class="small">Log perubahan akan direkodkan di bawah nama anda.</div>
        </div>
      </div>

      <div class="row" style="justify-content:flex-end; margin-top:25px;">
        <button class="btn gray" type="button" id="btnReload"><i class="fas fa-rotate"></i> Muat Semula</button>
        <button class="btn primary" type="submit" id="btnSave"><i class="fas fa-save"></i> Simpan Tetapan</button>
      </div>

      <div id="toast" class="toast"></div>
    </form>
  </div>
</div>

<script>
const toast = document.getElementById('toast');
const btnSave = document.getElementById('btnSave');
const btnReload = document.getElementById('btnReload');

const elReminder = document.getElementById('reminder_days');
const elAuto = document.getElementById('auto_send_reminders');
const elConflict = document.getElementById('allow_conflicting_events');

function showToast(type, msg){
  toast.className = 'toast show ' + (type === 'ok' ? 'ok' : 'err');
  toast.innerHTML = (type === 'ok' ? '<i class="fas fa-check-circle"></i> ' : '<i class="fas fa-exclamation-circle"></i> ') + msg;
  window.clearTimeout(showToast._t);
  showToast._t = window.setTimeout(()=>{ toast.className='toast'; toast.textContent=''; }, 2600);
}

async function fetchJSON(url, opts){
  const res = await fetch(url, opts);
  const text = await res.text();
  try { return JSON.parse(text); }
  catch(e){ return { ok:false, error:'Response bukan JSON. Semak ajax_calendar.php.' }; }
}

function applySettings(settings){
  elReminder.value = settings.reminder_days ? String(settings.reminder_days) : "3";
  elAuto.value = (String(settings.auto_send_reminders ?? "0") === "1") ? "1" : "0";
  elConflict.value = (String(settings.allow_conflicting_events ?? "FALSE").toUpperCase() === "TRUE") ? "TRUE" : "FALSE";
}

async function loadSettings(){
  btnReload.disabled = true;
  btnReload.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memuat...';
  try{
    const json = await fetchJSON('ajax_calendar.php?action=get_settings', {credentials:'same-origin'});
    if(!json.ok){
      showToast('err', json.error || 'Gagal memuat tetapan.');
      return;
    }
    applySettings((json.data && json.data.settings) ? json.data.settings : {});
    showToast('ok', 'Tetapan berjaya dimuat.');
  } catch(e){
    showToast('err', 'Ralat rangkaian / server.');
  } finally {
    btnReload.disabled = false;
    btnReload.innerHTML = '<i class="fas fa-rotate"></i> Muat Semula';
  }
}

btnReload.addEventListener('click', loadSettings);

document.getElementById('form').addEventListener('submit', async (e)=>{
  e.preventDefault();

  const reminder = Number(elReminder.value);
  if(!Number.isFinite(reminder) || reminder < 1 || reminder > 60){
    showToast('err', 'Hari Peringatan mesti antara 1 hingga 60.');
    return;
  }

  btnSave.disabled = true;
  btnSave.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';

  try{
    const fd = new FormData();
    fd.append('action','save_settings');
    fd.append('reminder_days', String(reminder));
    fd.append('auto_send_reminders', elAuto.value);
    fd.append('allow_conflicting_events', elConflict.value);

    const json = await fetchJSON('ajax_calendar.php', {method:'POST', body:fd, credentials:'same-origin'});
    if(!json.ok){
      showToast('err', json.error || 'Gagal simpan tetapan.');
      return;
    }
    showToast('ok', (json.data && json.data.message) ? json.data.message : 'Tetapan berjaya disimpan.');
  } catch(e){
    showToast('err', 'Ralat rangkaian / server.');
  } finally {
    btnSave.disabled = false;
    btnSave.innerHTML = '<i class="fas fa-save"></i> Simpan Tetapan';
  }
});

// Load settings on page load
loadSettings();
</script>
</body>
</html>