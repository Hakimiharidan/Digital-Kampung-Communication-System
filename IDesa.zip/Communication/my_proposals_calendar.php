<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
$dashboardLink = ($role === 'AJK' || $role === 'Admin') ? "ajk_dashboard.php" : "profile_management.php";
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Cadangan Acara Saya</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
:root{
  --primary:#2d6a4f;
  --brown:#6d4c41;
  --text:#333;
  --muted:#6b7280;
  --bg:#f7faf7;
  --card:#fff;
  --border:#eaeaea;
  --danger:#b42318;
}
body{ margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); }
nav{ display:flex; justify-content:space-between; align-items:center; padding:20px 8%; background:#fff;
     box-shadow:0 2px 10px rgba(0,0,0,0.05); position:sticky; top:0; z-index:1000; }
.logo{ font-size:28px; font-weight:bold; color:var(--primary); text-decoration:none; }
.logo span{ color:var(--brown); }
.nav-links{ display:flex; gap:18px; align-items:center; flex-wrap:wrap; }
.nav-links a{ text-decoration:none; color:#555; font-weight:500; transition:.2s; }
.nav-links a:hover{ color:var(--primary); }
.btn-pill{ background:var(--primary); color:white !important; padding:10px 18px; border-radius:999px; font-size:14px; }
.btn-outline{ border:1px solid var(--primary); color:var(--primary) !important; padding:10px 18px; border-radius:999px; font-size:14px; background:#fff; }

.wrap{ padding:26px 8% 70px; }
.head{ display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; }
.title{ margin:0; font-size:28px; color:var(--primary); }
.sub{ margin:6px 0 0; color:var(--muted); font-size:14px; }

.panel{ margin-top:18px; background:var(--card); border:1px solid var(--border); border-radius:16px; padding:16px;
        box-shadow:0 8px 24px rgba(0,0,0,0.04); }

table{ width:100%; border-collapse:collapse; }
th,td{ border-bottom:1px solid #eee; padding:10px; text-align:left; font-size:13px; vertical-align:top; }
th{ background:#fafafa; position:sticky; top:0; z-index:1; }

.badge{ display:inline-flex; align-items:center; gap:6px; font-size:12px; padding:4px 10px; border:1px solid #e5e7eb; border-radius:999px; background:#fff; font-weight:700; }
.badge.pending{ border-color:#f3d18b; background:#fff8e8; }
.badge.approved{ border-color:#b7dcc8; background:#ecf5ef; color:var(--primary); }
.badge.rejected{ border-color:#f0b4b4; background:#fff5f5; color:var(--danger); }
.badge.transferred{ border-color:#c7d2fe; background:#eef2ff; color:#3730a3; }

a.link{ color:var(--primary); text-decoration:none; font-weight:700; }
a.link:hover{ text-decoration:underline; }

dialog{ border:none; border-radius:18px; max-width:820px; width:min(920px,96%); box-shadow:0 30px 70px rgba(0,0,0,.25); }
dialog::backdrop{ background:rgba(0,0,0,.35); }
.modalWrap{ padding:14px; }
.modalHead{ display:flex; justify-content:space-between; align-items:center; gap:12px; border-bottom:1px solid #eee; padding-bottom:10px; }
.card{ background:#fff; border:1px solid #eee; border-radius:16px; padding:12px; }
.btn{ padding:10px 14px; border-radius:12px; border:1px solid #d1d5db; background:#fff; cursor:pointer; font-weight:800; }
.btn.primary{ background:var(--primary); color:#fff; border-color:var(--primary); }
.notice{ color:var(--muted); font-size:13px; }
</style>
</head>

<body>
<nav>
  <a href="homepage.php" class="logo">i-<span>Desa</span></a>
  <div class="nav-links">
    <a href="homepage.php">Laman Utama</a>
    <a href="calendar.php">Kalendar</a>
    <a href="<?php echo htmlspecialchars($dashboardLink); ?>" class="btn-pill">Papan Pemuka Saya</a>
    <a href="logout.php" title="Log Keluar"><i class="fas fa-sign-out-alt"></i></a>
  </div>
</nav>

<div class="wrap">
  <div class="head">
    <div>
      <h1 class="title">Cadangan Acara Saya</h1>
      <p class="sub">Senarai cadangan acara yang anda hantar. Klik tajuk untuk lihat butiran penuh.</p>
    </div>
    <div style="display:flex; gap:10px; flex-wrap:wrap;">
      <button class="btn" id="btnRefresh"><i class="fa-solid fa-rotate"></i> Muat Semula</button>
      <a class="btn primary" href="calendar.php"><i class="fa-solid fa-calendar-days"></i> Kembali Kalendar</a>
    </div>
  </div>

  <div class="panel">
    <table>
      <thead>
        <tr>
          <th style="width:18%">Tarikh Hantar</th>
          <th style="width:34%">Tajuk</th>
          <th style="width:16%">Kategori</th>
          <th style="width:18%">Mula</th>
          <th style="width:14%">Status</th>
        </tr>
      </thead>
      <tbody id="tbody"></tbody>
    </table>
    <div class="notice" style="margin-top:10px;">
      Nota: Status “TRANSFERRED” bermaksud cadangan telah ditukar menjadi acara dalam kalendar oleh AJK/Admin.
    </div>
  </div>
</div>

<dialog id="dlg">
  <div class="modalWrap">
    <div class="modalHead">
      <h3 style="margin:0">Butiran Cadangan</h3>
      <button class="btn" id="btnClose" type="button">Tutup</button>
    </div>
    <div id="dlgBody" style="margin-top:12px;"></div>
  </div>
</dialog>

<script>
const tbody = document.getElementById('tbody');
const dlg = document.getElementById('dlg');
const dlgBody = document.getElementById('dlgBody');
document.getElementById('btnClose').addEventListener('click', ()=>dlg.close());
document.getElementById('btnRefresh').addEventListener('click', load);

function fmtDT(s){
  if(!s) return '-';
  const iso = s.replace(' ', 'T');
  const d = new Date(iso);
  if (isNaN(d.getTime())) return s;
  return d.toLocaleString('ms-MY', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' });
}

function normStatus(raw){
  const s = (raw || '').toString().trim().toUpperCase();
  if (s === 'PENDING') return {label:'PENDING', cls:'pending'};
  if (s === 'APPROVED') return {label:'APPROVED', cls:'approved'};
  if (s === 'REJECTED') return {label:'REJECTED', cls:'rejected'};
  if (s === 'TRANSFERRED') return {label:'TRANSFERRED', cls:'transferred'};
  return {label: raw || '-', cls:''};
}

function badgeNode(statusRaw){
  const st = normStatus(statusRaw);
  const span = document.createElement('span');
  span.className = 'badge ' + st.cls;
  span.textContent = st.label;
  return span;
}

function safeText(v, fallback='-'){
  const s = (v ?? '').toString().trim();
  return s ? s : fallback;
}

function renderMultiline(text){
  const wrap = document.createElement('div');
  const s = (text ?? '').toString().trim();
  if (!s) { wrap.textContent = '-'; return wrap; }
  s.split(/\r?\n/).forEach((line, idx)=>{
    if (idx>0) wrap.appendChild(document.createElement('br'));
    wrap.appendChild(document.createTextNode(line));
  });
  return wrap;
}

function openDetails(it){
  const p = it.proposal || {};
  dlgBody.innerHTML = '';

  const card = document.createElement('div');
  card.className = 'card';

  function row(label, valueNodeOrText){
    const div = document.createElement('div');
    div.style.marginBottom = '8px';
    const b = document.createElement('b');
    b.textContent = label + ': ';
    div.appendChild(b);

    if (valueNodeOrText instanceof Node) div.appendChild(valueNodeOrText);
    else div.appendChild(document.createTextNode(safeText(valueNodeOrText)));
    return div;
  }

  card.appendChild(row('Status', normStatus(it.status).label));
  card.appendChild(row('Tajuk', safeText(p.title, '(Tanpa tajuk)')));
  card.appendChild(row('Tarikh/Masa', `${fmtDT(p.start_datetime)} → ${fmtDT(p.end_datetime)}`));
  card.appendChild(row('Lokasi', safeText(p.location)));
  card.appendChild(row('Kategori', safeText(p.category)));

  const desc = document.createElement('div');
  desc.style.marginTop = '10px';
  const bdesc = document.createElement('b');
  bdesc.textContent = 'Penerangan:';
  desc.appendChild(bdesc);
  desc.appendChild(document.createElement('br'));
  desc.appendChild(renderMultiline(p.description));
  card.appendChild(desc);

  if (p.attachment) {
    const att = document.createElement('div');
    att.style.marginTop = '10px';
    const batt = document.createElement('b');
    batt.textContent = 'Lampiran: ';
    att.appendChild(batt);

    const link = document.createElement('a');
    link.className = 'link';
    link.target = '_blank';
    link.rel = 'noopener';
    link.href = `uploads/proposals/${encodeURIComponent((p.attachment || '').toString())}`;
    link.textContent = 'Muat turun';
    att.appendChild(link);

    card.appendChild(att);
  }

  if (p.ajk_note) {
    const note = document.createElement('div');
    note.style.marginTop = '10px';
    const bnote = document.createElement('b');
    bnote.textContent = 'Catatan AJK: ';
    note.appendChild(bnote);
    note.appendChild(renderMultiline(p.ajk_note));
    card.appendChild(note);
  }

  dlgBody.appendChild(card);
  dlg.showModal();
}

function makeRow(it){
  const p = it.proposal || {};
  const tr = document.createElement('tr');

  const tdCreated = document.createElement('td');
  tdCreated.textContent = fmtDT(it.created_at);

  const tdTitle = document.createElement('td');
  const a = document.createElement('a');
  a.href = 'javascript:void(0)';
  a.className = 'link';
  a.textContent = safeText(p.title, '(Tanpa tajuk)');
  a.addEventListener('click', ()=>openDetails(it));
  tdTitle.appendChild(a);

  const tdCat = document.createElement('td');
  tdCat.textContent = safeText(p.category);

  const tdStart = document.createElement('td');
  tdStart.textContent = fmtDT(p.start_datetime);

  const tdStatus = document.createElement('td');
  tdStatus.appendChild(badgeNode(it.status));

  tr.appendChild(tdCreated);
  tr.appendChild(tdTitle);
  tr.appendChild(tdCat);
  tr.appendChild(tdStart);
  tr.appendChild(tdStatus);

  return tr;
}

async function load(){
  tbody.innerHTML = `<tr><td colspan="5"><small>Memuat...</small></td></tr>`;

  try{
    const res = await fetch('ajax_calendar_proposal.php?action=my_proposals', {credentials:'same-origin'});
    const json = await res.json();

    if(!json.ok){
      tbody.innerHTML = `<tr><td colspan="5" class="notice">${(json.error || json.message || 'Gagal memuat data.')}</td></tr>`;
      return;
    }

    const items = (json.data && json.data.items) ? json.data.items : [];
    tbody.innerHTML = '';

    if(items.length === 0){
      tbody.innerHTML = `<tr><td colspan="5" class="notice">Tiada cadangan.</td></tr>`;
      return;
    }

    items.forEach(it => tbody.appendChild(makeRow(it)));
  } catch(e){
    tbody.innerHTML = `<tr><td colspan="5" class="notice">Ralat rangkaian / server.</td></tr>`;
  }
}

load();
</script>
</body>
</html>
