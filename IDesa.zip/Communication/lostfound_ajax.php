<?php
// lostfound_ajax.php
session_start();
header('Content-Type: application/json; charset=utf-8');

include "db_connect.php";

/* -------------------------
   Helpers
------------------------- */
function json_out($arr, $code = 200) {
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit();
}

function require_login() {
    if (!isset($_SESSION['user_id'])) {
        json_out(["ok" => false, "error" => "Sila log masuk terlebih dahulu."], 401);
    }
}

function is_ajk_or_admin(): bool {
    $role = $_SESSION['role'] ?? 'Resident';
    return ($role === 'AJK' || $role === 'Admin');
}

function post_bool($key): int {
    if (!isset($_POST[$key])) return 0;
    $v = $_POST[$key];
    return ($v === '1' || $v === 1 || $v === 'true' || $v === 'on') ? 1 : 0;
}

function safe_trim($s, $maxLen = 255) {
    $s = trim((string)$s);
    if (function_exists('mb_strlen')) {
        if (mb_strlen($s) > $maxLen) $s = mb_substr($s, 0, $maxLen);
    } else {
        if (strlen($s) > $maxLen) $s = substr($s, 0, $maxLen);
    }
    return $s;
}

/**
 * Append log lines into admin_remarks WITHOUT overwriting existing logs.
 * Adds a blank line between entries.
 */
function append_admin_remarks($conn, int $report_id, string $line): void {
    $stmt = mysqli_prepare($conn, "
        UPDATE lost_found_reports
        SET admin_remarks = CONCAT(
            COALESCE(admin_remarks,''),
            IF(COALESCE(admin_remarks,'')='', '', '\n\n'),
            ?
        )
        WHERE report_id = ?
    ");
    if (!$stmt) return;
    mysqli_stmt_bind_param($stmt, "si", $line, $report_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function notify_roles($conn, array $roles, string $message, string $type = 'System') {
    if (count($roles) === 0) return;

    $in = implode(",", array_fill(0, count($roles), "?"));
    $sql = "SELECT user_id FROM users WHERE role IN ($in) AND account_status = 'Active'";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return;

    $types = str_repeat("s", count($roles));
    mysqli_stmt_bind_param($stmt, $types, ...$roles);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $ins = mysqli_prepare($conn, "INSERT INTO notifications (user_id, event_id, message, type, is_read) VALUES (?, NULL, ?, ?, 0)");
    if (!$ins) {
        mysqli_stmt_close($stmt);
        return;
    }

    while ($row = mysqli_fetch_assoc($res)) {
        $uid = (int)$row['user_id'];
        mysqli_stmt_bind_param($ins, "iss", $uid, $message, $type);
        mysqli_stmt_execute($ins);
    }
    mysqli_stmt_close($ins);
    mysqli_stmt_close($stmt);
}

function notify_user($conn, int $user_id, string $message, string $type = 'System') {
    $stmt = mysqli_prepare($conn, "INSERT INTO notifications (user_id, event_id, message, type, is_read) VALUES (?, NULL, ?, ?, 0)");
    if (!$stmt) return;
    mysqli_stmt_bind_param($stmt, "iss", $user_id, $message, $type);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/* -------------------------
   Note Builders (BM)
------------------------- */
function reviewer_name_from_session(): string {
    $n = $_SESSION['full_name'] ?? ($_SESSION['username'] ?? '');
    $n = trim((string)$n);
    if ($n === '') $n = "AJK/Admin";
    return $n;
}

function build_request_note(string $remarks, string $reviewerName): string {
    $ts = date("Y-m-d H:i:s");
    $remarks = trim($remarks);
    return "[REQUEST {$ts}]\n"
        . $remarks
        . "\nDisemak oleh: AJK i-Desa ({$reviewerName})";
}

function build_reject_note(string $remarks, string $reviewerName): string {
    $ts = date("Y-m-d H:i:s");
    $remarks = trim($remarks);
    return "[REJECT {$ts}]\n"
        . $remarks
        . "\nDisemak oleh: AJK i-Desa ({$reviewerName})";
}

function build_done_note(string $remarks, string $reviewerName): string {
    $ts = date("Y-m-d H:i:s");
    $remarks = trim($remarks);
    return "[DONE {$ts}]\n"
        . $remarks
        . "\nDisemak oleh: AJK i-Desa ({$reviewerName})";
}

/* -------------------------
   Routing
------------------------- */
$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$action = trim($action);

if ($action === '') {
    json_out(["ok" => false, "error" => "Action tidak diberikan."], 400);
}

require_login();
$current_user_id = (int)($_SESSION['user_id'] ?? 0);

/* -------------------------
   ACTION: list (Published board)
------------------------- */
if ($action === 'list') {
    $q = safe_trim($_GET['q'] ?? '', 80);
    $type = safe_trim($_GET['type'] ?? '', 10);
    $category = safe_trim($_GET['category'] ?? '', 30);
    $sort = safe_trim($_GET['sort'] ?? 'newest', 30);

    $where = " WHERE status = 'Published' ";
    $params = [];
    $types = "";

    if ($type === 'Lost' || $type === 'Found') {
        $where .= " AND type = ? ";
        $params[] = $type;
        $types .= "s";
    }

    if ($category !== '') {
        $where .= " AND category = ? ";
        $params[] = $category;
        $types .= "s";
    }

    if ($q !== '') {
        $where .= " AND (item_name LIKE ? OR description LIKE ? OR location_detail LIKE ?) ";
        $like = "%".$q."%";
        $params[] = $like; $params[] = $like; $params[] = $like;
        $types .= "sss";
    }

    $orderBy = " ORDER BY created_at DESC ";
    if ($sort === 'oldest') $orderBy = " ORDER BY created_at ASC ";
    if ($sort === 'incident_newest') $orderBy = " ORDER BY incident_date DESC, created_at DESC ";
    if ($sort === 'incident_oldest') $orderBy = " ORDER BY incident_date ASC, created_at DESC ";

    $sql = "
        SELECT report_id, type, item_name, category, location_detail, incident_date, image_path, created_at
        FROM lost_found_reports
        $where
        $orderBy
        LIMIT 200
    ";

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB (prepare)."], 500);

    if ($types !== '') mysqli_stmt_bind_param($stmt, $types, ...$params);

    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $items = [];
    while ($row = mysqli_fetch_assoc($res)) {
        $items[] = [
            "report_id" => (int)$row["report_id"],
            "type" => $row["type"],
            "item_name" => $row["item_name"],
            "category" => $row["category"],
            "location_detail" => $row["location_detail"],
            "incident_date" => $row["incident_date"],
            "created_at" => $row["created_at"],
            "image_url" => (!empty($row["image_path"])) ? $row["image_path"] : null
        ];
    }
    mysqli_stmt_close($stmt);

    json_out(["ok" => true, "items" => $items]);
}

/* -------------------------
   ACTION: detail
------------------------- */
if ($action === 'detail') {
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) json_out(["ok" => false, "error" => "ID tidak sah."], 400);

    $sql = "
        SELECT r.*,
               u.phone AS reporter_phone,
               u.full_name AS reporter_name
        FROM lost_found_reports r
        JOIN users u ON u.user_id = r.user_id
        WHERE r.report_id = ?
        LIMIT 1
    ";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB (prepare)."], 500);

    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_out(["ok" => false, "error" => "Rekod tidak dijumpai."], 404);

    $owner_id = (int)$row['user_id'];
    $status = $row['status'];

    $allowed = false;
    if (is_ajk_or_admin()) $allowed = true;
    else if ($status === 'Published') $allowed = true;
    else if ($owner_id === $current_user_id) $allowed = true;

    if (!$allowed) json_out(["ok" => false, "error" => "Anda tidak dibenarkan melihat butiran ini."], 403);

    $consent = (int)$row['contact_share_consent'];
    $phone_out = null;
    if (is_ajk_or_admin() || $consent === 1) $phone_out = $row['reporter_phone'] ?? null;

    $item = [
        "report_id" => (int)$row["report_id"],
        "user_id" => (int)$row["user_id"],
        "type" => $row["type"],
        "item_name" => $row["item_name"],
        "description" => $row["description"],
        "category" => $row["category"],
        "location_detail" => $row["location_detail"],
        "incident_date" => $row["incident_date"],
        "image_url" => (!empty($row["image_path"])) ? $row["image_path"] : null,
        "status" => $row["status"],
        "contact_share_consent" => (int)$row["contact_share_consent"],
        "admin_remarks" => $row["admin_remarks"],
        "resolved_at" => $row["resolved_at"],
        "created_at" => $row["created_at"],
        "updated_at" => $row["updated_at"],
        "reporter_phone" => $phone_out,
        "reporter_name" => $row["reporter_name"] ?? null
    ];

    json_out(["ok" => true, "item" => $item]);
}

/* -------------------------
   ACTION: myreports
------------------------- */
if ($action === 'myreports') {
    $status = safe_trim($_GET['status'] ?? '', 20);

    $where = " WHERE user_id = ? ";
    $params = [$current_user_id];
    $types = "i";

    if ($status !== '') {
        $where .= " AND status = ? ";
        $params[] = $status;
        $types .= "s";
    }

    $sql = "
        SELECT report_id, type, item_name, category, location_detail, incident_date, image_path, status, created_at
        FROM lost_found_reports
        $where
        ORDER BY created_at DESC
        LIMIT 300
    ";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB (prepare)."], 500);

    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $items = [];
    while ($row = mysqli_fetch_assoc($res)) {
        $items[] = [
            "report_id" => (int)$row["report_id"],
            "type" => $row["type"],
            "item_name" => $row["item_name"],
            "category" => $row["category"],
            "location_detail" => $row["location_detail"],
            "incident_date" => $row["incident_date"],
            "status" => $row["status"],
            "created_at" => $row["created_at"],
            "image_url" => (!empty($row["image_path"])) ? $row["image_path"] : null
        ];
    }
    mysqli_stmt_close($stmt);

    json_out(["ok" => true, "items" => $items]);
}

/* -------------------------
   ACTION: submit_report
------------------------- */
if ($action === 'submit_report') {
    $type = safe_trim($_POST['type'] ?? '', 10);
    $item_name = safe_trim($_POST['item_name'] ?? '', 100);
    $description = trim((string)($_POST['description'] ?? ''));
    $category = safe_trim($_POST['category'] ?? 'Other', 30);
    $location_detail = safe_trim($_POST['location_detail'] ?? '', 255);
    $incident_date = safe_trim($_POST['incident_date'] ?? '', 20);
    $consent = post_bool('contact_share_consent');

    if (!in_array($type, ['Lost', 'Found'], true)) json_out(["ok" => false, "error" => "Jenis tidak sah."], 400);
    if ($item_name === '' || (function_exists('mb_strlen') ? mb_strlen($item_name) : strlen($item_name)) < 3) json_out(["ok" => false, "error" => "Nama barang mesti diisi."], 400);
    if ($description === '' || (function_exists('mb_strlen') ? mb_strlen($description) : strlen($description)) < 10) json_out(["ok" => false, "error" => "Penerangan mesti lebih jelas (min 10 aksara)."], 400);
    if ($location_detail === '') json_out(["ok" => false, "error" => "Lokasi mesti diisi."], 400);
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $incident_date)) json_out(["ok" => false, "error" => "Tarikh kejadian tidak sah (YYYY-MM-DD)."], 400);

    $image_path = null;
    if (isset($_FILES['image']) && is_array($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) json_out(["ok" => false, "error" => "Gagal muat naik gambar."], 400);

        $allowed = ['jpg','jpeg','png'];
        $orig = $_FILES['image']['name'] ?? '';
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed, true)) json_out(["ok" => false, "error" => "Format gambar hanya dibenarkan: JPG, JPEG, PNG."], 400);

        $baseDir = __DIR__ . "/uploads/lostfound";
        if (!is_dir($baseDir)) @mkdir($baseDir, 0775, true);

        $newName = "lf_" . date("Ymd_His") . "_" . bin2hex(random_bytes(4)) . "." . $ext;
        $dest = $baseDir . "/" . $newName;

        if (!move_uploaded_file($_FILES['image']['tmp_name'], $dest)) json_out(["ok" => false, "error" => "Gagal simpan gambar ke server."], 500);

        $image_path = "uploads/lostfound/" . $newName;
    }

    $sql = "INSERT INTO lost_found_reports
            (user_id, type, item_name, description, category, location_detail, incident_date, image_path, status, contact_share_consent)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB (prepare)."], 500);

    mysqli_stmt_bind_param($stmt, "isssssssi",
        $current_user_id, $type, $item_name, $description, $category,
        $location_detail, $incident_date, $image_path, $consent
    );

    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        json_out(["ok" => false, "error" => "Gagal simpan laporan."], 500);
    }

    $new_id = (int)mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);

    notify_roles($conn, ['AJK','Admin'], "Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #{$new_id})", "System");
    json_out(["ok" => true, "report_id" => $new_id]);
}

/* -------------------------
   ACTION: pending_list (AJK/Admin)
------------------------- */
if ($action === 'pending_list') {
    if (!is_ajk_or_admin()) json_out(["ok" => false, "error" => "Akses AJK/Admin sahaja."], 403);

    $sql = "
        SELECT report_id, user_id, type, item_name, category, location_detail, incident_date, image_path, status, created_at
        FROM lost_found_reports
        WHERE status = 'Pending'
        ORDER BY created_at DESC
        LIMIT 500
    ";
    $res = mysqli_query($conn, $sql);
    if (!$res) json_out(["ok" => false, "error" => "Ralat DB (query)."], 500);

    $items = [];
    while ($row = mysqli_fetch_assoc($res)) {
        $items[] = [
            "report_id" => (int)$row["report_id"],
            "user_id" => (int)$row["user_id"],
            "type" => $row["type"],
            "item_name" => $row["item_name"],
            "category" => $row["category"],
            "location_detail" => $row["location_detail"],
            "incident_date" => $row["incident_date"],
            "status" => $row["status"],
            "created_at" => $row["created_at"],
            "image_url" => (!empty($row["image_path"])) ? $row["image_path"] : null
        ];
    }

    json_out(["ok" => true, "items" => $items]);
}

/* -------------------------
   ACTION: approve (AJK/Admin)
------------------------- */
if ($action === 'approve') {
    if (!is_ajk_or_admin()) json_out(["ok" => false, "error" => "Akses AJK/Admin sahaja."], 403);

    $report_id = (int)($_POST['report_id'] ?? 0);
    if ($report_id <= 0) json_out(["ok" => false, "error" => "ID tidak sah."], 400);

    $stmt = mysqli_prepare($conn, "SELECT user_id FROM lost_found_reports WHERE report_id = ? LIMIT 1");
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB."], 500);
    mysqli_stmt_bind_param($stmt, "i", $report_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_out(["ok" => false, "error" => "Rekod tidak dijumpai."], 404);
    $owner_id = (int)$row['user_id'];

    $stmt2 = mysqli_prepare($conn, "UPDATE lost_found_reports SET status='Published' WHERE report_id=?");
    if (!$stmt2) json_out(["ok" => false, "error" => "Ralat DB."], 500);
    mysqli_stmt_bind_param($stmt2, "i", $report_id);
    mysqli_stmt_execute($stmt2);
    mysqli_stmt_close($stmt2);

    notify_user($conn, $owner_id, "Laporan anda telah diluluskan dan dipaparkan di papan Barang Hilang & Jumpa. (ID: #{$report_id})", "System");
    json_out(["ok" => true]);
}

/* -------------------------
   ACTION: reject (AJK/Admin) - formatted note
------------------------- */
if ($action === 'reject') {
    if (!is_ajk_or_admin()) json_out(["ok" => false, "error" => "Akses AJK/Admin sahaja."], 403);

    $report_id = (int)($_POST['report_id'] ?? 0);
    $remarks = trim((string)($_POST['remarks'] ?? ''));

    if ($report_id <= 0) json_out(["ok" => false, "error" => "ID tidak sah."], 400);
    if ($remarks === '' || (function_exists('mb_strlen') ? mb_strlen($remarks) : strlen($remarks)) < 5) {
        json_out(["ok" => false, "error" => "Sila isi alasan penolakan (min 5 aksara)."], 400);
    }

    $stmt = mysqli_prepare($conn, "SELECT user_id FROM lost_found_reports WHERE report_id = ? LIMIT 1");
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB."], 500);
    mysqli_stmt_bind_param($stmt, "i", $report_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_out(["ok" => false, "error" => "Rekod tidak dijumpai."], 404);
    $owner_id = (int)$row['user_id'];

    $stmt2 = mysqli_prepare($conn, "UPDATE lost_found_reports SET status='Rejected' WHERE report_id=?");
    if (!$stmt2) json_out(["ok" => false, "error" => "Ralat DB."], 500);
    mysqli_stmt_bind_param($stmt2, "i", $report_id);
    mysqli_stmt_execute($stmt2);
    mysqli_stmt_close($stmt2);

    $reviewer = reviewer_name_from_session();
    $note = build_reject_note($remarks, $reviewer);
    append_admin_remarks($conn, $report_id, $note);

    notify_user($conn, $owner_id, "Laporan anda telah ditolak.\n{$note}\n(ID: #{$report_id})", "System");
    json_out(["ok" => true]);
}

/* -------------------------
   ACTION: request_info (AJK/Admin) - formatted note
------------------------- */
if ($action === 'request_info') {
    if (!is_ajk_or_admin()) json_out(["ok" => false, "error" => "Akses AJK/Admin sahaja."], 403);

    $report_id = (int)($_POST['report_id'] ?? 0);
    $remarks = trim((string)($_POST['remarks'] ?? ''));

    if ($report_id <= 0) json_out(["ok" => false, "error" => "ID tidak sah."], 400);
    if ($remarks === '' || (function_exists('mb_strlen') ? mb_strlen($remarks) : strlen($remarks)) < 5) {
        json_out(["ok" => false, "error" => "Sila isi maklumat diminta (min 5 aksara)."], 400);
    }

    $stmt = mysqli_prepare($conn, "SELECT user_id FROM lost_found_reports WHERE report_id = ? LIMIT 1");
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB."], 500);
    mysqli_stmt_bind_param($stmt, "i", $report_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_out(["ok" => false, "error" => "Rekod tidak dijumpai."], 404);
    $owner_id = (int)$row['user_id'];

    $reviewer = reviewer_name_from_session();
    $note = build_request_note($remarks, $reviewer);
    append_admin_remarks($conn, $report_id, $note);

    notify_user($conn, $owner_id, "AJK memerlukan maklumat tambahan untuk laporan anda:\n{$note}\n(ID: #{$report_id})", "System");
    json_out(["ok" => true]);
}

/* -------------------------
   ACTION: set_done (AJK/Admin) - formatted note
------------------------- */
if ($action === 'set_done') {
    if (!is_ajk_or_admin()) json_out(["ok" => false, "error" => "Akses AJK/Admin sahaja."], 403);

    $report_id = (int)($_POST['report_id'] ?? 0);
    $remarks = trim((string)($_POST['remarks'] ?? ''));

    if ($report_id <= 0) json_out(["ok" => false, "error" => "ID tidak sah."], 400);

    $stmt = mysqli_prepare($conn, "SELECT user_id FROM lost_found_reports WHERE report_id = ? LIMIT 1");
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB."], 500);
    mysqli_stmt_bind_param($stmt, "i", $report_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_out(["ok" => false, "error" => "Rekod tidak dijumpai."], 404);
    $owner_id = (int)$row['user_id'];

    if ($remarks === '') $remarks = "Kes telah diselesaikan oleh AJK.";

    $stmt2 = mysqli_prepare($conn, "UPDATE lost_found_reports SET status='Claimed', resolved_at=NOW() WHERE report_id=?");
    if (!$stmt2) json_out(["ok" => false, "error" => "Ralat DB."], 500);
    mysqli_stmt_bind_param($stmt2, "i", $report_id);
    mysqli_stmt_execute($stmt2);
    mysqli_stmt_close($stmt2);

    $reviewer = reviewer_name_from_session();
    $note = build_done_note($remarks, $reviewer);
    append_admin_remarks($conn, $report_id, $note);

    notify_user($conn, $owner_id, "Status laporan anda telah ditetapkan sebagai SELESAI.\n{$note}\n(ID: #{$report_id})", "System");
    json_out(["ok" => true]);
}

/* -------------------------
   ACTION: claim_submit (Resident)
------------------------- */
if ($action === 'claim_submit') {
    $report_id = (int)($_POST['report_id'] ?? 0);
    $message = trim((string)($_POST['message'] ?? ''));

    if ($report_id <= 0) json_out(["ok" => false, "error" => "ID laporan tidak sah."], 400);
    if ($message === '' || (function_exists('mb_strlen') ? mb_strlen($message) : strlen($message)) < 5) {
        json_out(["ok" => false, "error" => "Mesej tuntutan terlalu ringkas (min 5 aksara)."], 400);
    }

    $stmt = mysqli_prepare($conn, "SELECT status, item_name FROM lost_found_reports WHERE report_id = ? LIMIT 1");
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB."], 500);
    mysqli_stmt_bind_param($stmt, "i", $report_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_out(["ok" => false, "error" => "Laporan tidak dijumpai."], 404);
    if (($row['status'] ?? '') !== 'Published') json_out(["ok" => false, "error" => "Tuntutan hanya boleh dibuat untuk laporan yang dipaparkan."], 400);

    $claimant_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? ("User#".$current_user_id);
    $item_name = $row['item_name'] ?? '';
    $now = date("Y-m-d H:i:s");

    $msg = "CLAIM_LF:#{$report_id} | Item: {$item_name} | Oleh: {$claimant_name} (UID:{$current_user_id}) | {$message}";
    notify_roles($conn, ['AJK','Admin'], $msg, 'System');

    $line = "[CLAIM {$now}] {$claimant_name} (UID:{$current_user_id}): {$message}";
    append_admin_remarks($conn, $report_id, $line);

    json_out(["ok" => true]);
}

/* -------------------------
   ACTION: claim_list (AJK/Admin)
------------------------- */
if ($action === 'claim_list') {
    if (!is_ajk_or_admin()) json_out(["ok" => false, "error" => "Akses AJK/Admin sahaja."], 403);

    $stmt = mysqli_prepare($conn, "
        SELECT notification_id, message, created_at
        FROM notifications
        WHERE user_id = ?
          AND is_read = 0
          AND type = 'System'
          AND message LIKE 'CLAIM_LF:#%'
        ORDER BY created_at DESC
        LIMIT 300
    ");
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB."], 500);

    mysqli_stmt_bind_param($stmt, "i", $current_user_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $items = [];
    while ($r = mysqli_fetch_assoc($res)) {
        $rid = null;
        if (preg_match('/CLAIM_LF:#(\d+)/', $r['message'], $m)) $rid = (int)$m[1];

        $items[] = [
            "notification_id" => (int)$r["notification_id"],
            "report_id" => $rid,
            "message" => $r["message"],
            "created_at" => $r["created_at"]
        ];
    }
    mysqli_stmt_close($stmt);

    json_out(["ok" => true, "items" => $items]);
}

/* -------------------------
   ACTION: claim_mark_read (AJK/Admin)
------------------------- */
if ($action === 'claim_mark_read') {
    if (!is_ajk_or_admin()) json_out(["ok" => false, "error" => "Akses AJK/Admin sahaja."], 403);

    $nid = (int)($_POST['notification_id'] ?? 0);
    if ($nid <= 0) json_out(["ok" => false, "error" => "ID notifikasi tidak sah."], 400);

    $stmt = mysqli_prepare($conn, "UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?");
    if (!$stmt) json_out(["ok" => false, "error" => "Ralat DB."], 500);

    mysqli_stmt_bind_param($stmt, "ii", $nid, $current_user_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    json_out(["ok" => true]);
}

/* -------------------------
   Unknown action
------------------------- */
json_out(["ok" => false, "error" => "Action tidak dikenali: {$action}"], 400);
