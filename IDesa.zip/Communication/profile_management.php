<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$uid = (int) $_SESSION['user_id'];
$message = "";

/* ========= HELPER: fetch user ========= */
function fetchUser($conn, $uid) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE user_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);
    return $user;
}

/* ========= HELPER: safely delete old picture ========= */
function deleteOldPicture($filename) {
    if (empty($filename) || $filename === 'default_avatar.png') return;
    $safeName = basename($filename);
    $path = __DIR__ . "/uploads/" . $safeName;
    if (file_exists($path)) { @unlink($path); }
}

$user = fetchUser($conn, $uid);
$oldPic = $user['profile_picture'] ?? 'default_avatar.png';

/* ========= 1) HANDLE IMAGE UPLOAD ========= */
if (isset($_FILES['new_profile_pic']) && !empty($_FILES['new_profile_pic']['name'])) {
    $file = $_FILES['new_profile_pic'];
    if ($file['error'] === 0) {
        $fileName = $file['name'];
        $fileTmp  = $file['tmp_name'];
        $fileExt  = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed  = array('jpg', 'jpeg', 'png');

        if (in_array($fileExt, $allowed)) {
            if ($file['size'] > 10 * 1024 * 1024) {
                $message = "<script>alert('Fail terlalu besar! Maksimum 10MB.');</script>";
            } else {
                $newFileName = "profile_" . $uid . "_" . time() . "." . $fileExt;
                $uploadDir   = __DIR__ . "/uploads";
                $uploadDest  = $uploadDir . "/" . $newFileName;

                if (!is_dir($uploadDir)) { mkdir($uploadDir, 0777, true); }

                if (move_uploaded_file($fileTmp, $uploadDest)) {
                    $stmt = mysqli_prepare($conn, "UPDATE users SET profile_picture = ? WHERE user_id = ?");
                    mysqli_stmt_bind_param($stmt, "si", $newFileName, $uid);
                    $ok = mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);

                    if ($ok) {
                        deleteOldPicture($oldPic);
                        header("Location: " . $_SERVER['PHP_SELF']);
                        exit();
                    } else {
                        @unlink($uploadDest);
                        $message = "<script>alert('Gagal kemaskini rekod dalam database!');</script>";
                    }
                } else {
                    $message = "<script>alert('Gagal memuat naik fail!');</script>";
                }
            }
        } else {
            $message = "<script>alert('Format fail tidak sah! Sila guna JPG atau PNG.');</script>";
        }
    }
}

/* ========= 2) HANDLE REMOVE PHOTO ========= */
if (isset($_POST['remove_photo'])) {
    deleteOldPicture($oldPic);
    $default = 'default_avatar.png';
    $stmt = mysqli_prepare($conn, "UPDATE users SET profile_picture = ? WHERE user_id = ?");
    mysqli_stmt_bind_param($stmt, "si", $default, $uid);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

/* ========= 3) HANDLE INFO UPDATE (NEW FEATURE) ========= */
if (isset($_POST['update_profile'])) {
    // Sanitize inputs
    $fullName = trim($_POST['full_name']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $address  = trim($_POST['address']);

    // Basic Validation
    if (empty($fullName) || empty($email)) {
        $message = "<script>alert('Nama dan Emel tidak boleh kosong!');</script>";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE users SET full_name = ?, email = ?, phone = ?, address = ? WHERE user_id = ?");
        mysqli_stmt_bind_param($stmt, "ssssi", $fullName, $email, $phone, $address, $uid);
        
        if (mysqli_stmt_execute($stmt)) {
            $message = "<script>alert('Profil berjaya dikemaskini!'); window.location.href='profile_management.php';</script>";
        } else {
            $message = "<script>alert('Gagal mengemaskini profil. Sila cuba lagi.');</script>";
        }
        mysqli_stmt_close($stmt);
    }
}

$user = fetchUser($conn, $uid); // Refresh data
$hasPhoto = (!empty($user['profile_picture']) && $user['profile_picture'] !== 'default_avatar.png' && file_exists(__DIR__ . "/uploads/" . basename($user['profile_picture'])));
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>i-Desa | Profil Saya</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --primary: #2d6a4f; --dark: #1b4332; --bg: #f3f4f6; --text: #374151; }
        body { margin: 0; font-family: 'Poppins', sans-serif; background: var(--bg); display: flex; min-height: 100vh; color: var(--text); }

        /* Sidebar */
        .sidebar { width: 280px; background: var(--dark); color: white; padding: 40px 25px; display: flex; flex-direction: column; box-shadow: 4px 0 15px rgba(0,0,0,0.1); }
        .sidebar h2 { font-size: 1.8rem; margin-bottom: 50px; font-weight: 700; display: flex; align-items: center; gap: 10px; }
        .sidebar h2 i { color: #4ade80; }
        .menu-link { padding: 14px 20px; color: #d1d5db; text-decoration: none; margin-bottom: 8px; border-radius: 12px; transition: 0.3s; font-weight: 500; display: flex; align-items: center; gap: 12px; }
        .menu-link:hover { background: rgba(255,255,255,0.1); color: white; transform: translateX(5px); }
        .menu-link.active { background: var(--primary); color: white; box-shadow: 0 4px 12px rgba(0,0,0,0.2); }
        .logout-link { margin-top: auto; background: rgba(239, 68, 68, 0.2); color: #fca5a5; }
        .logout-link:hover { background: #ef4444; color: white; }

        /* Content */
        .main { flex: 1; padding: 50px; overflow-y: auto; }
        
        /* Header Card */
        .profile-card { background: white; padding: 40px; border-radius: 24px; box-shadow: 0 10px 30px -5px rgba(0,0,0,0.05); display: flex; align-items: center; gap: 35px; border: 1px solid #e5e7eb; position: relative; overflow: hidden; }
        .profile-card::before { content: ''; position: absolute; top: 0; left: 0; width: 8px; height: 100%; background: var(--primary); }

        /* Avatar */
        .avatar-box {
            width: 130px; height: 130px; border-radius: 50%; overflow: hidden; position: relative;
            border: 4px solid white; box-shadow: 0 8px 20px rgba(0,0,0,0.15); cursor: pointer; background: #e5e7eb; flex-shrink: 0;
        }
        .avatar-img { width: 100%; height: 100%; object-fit: cover; }
        .avatar-initial { width: 100%; height: 100%; display: flex; justify-content: center; align-items: center; background: var(--primary); color: white; font-size: 3.5rem; font-weight: 700; }
        
        .avatar-overlay {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6);
            display: flex; flex-direction: column; justify-content: center; align-items: center; color: white;
            opacity: 0; transition: 0.3s; font-size: 0.9rem;
        }
        .avatar-box:hover .avatar-overlay { opacity: 1; }

        .user-info { flex: 1; }
        .user-info h1 { margin: 0; font-size: 2rem; font-weight: 700; color: var(--dark); display: flex; align-items: center; gap: 10px; }
        .user-info p { margin: 5px 0 0; color: #6b7280; font-size: 1rem; }
        .role-badge { display: inline-block; background: #dcfce7; color: var(--primary); padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; margin-top: 10px; }

        /* Edit Toggle Buttons */
        .edit-toggle-btn { margin-left: auto; background: white; border: 2px solid #e5e7eb; padding: 10px 20px; border-radius: 12px; cursor: pointer; font-weight: 600; color: #6b7280; transition: 0.3s; display: flex; align-items: center; gap: 8px; }
        .edit-toggle-btn:hover { border-color: var(--primary); color: var(--primary); }
        .action-buttons { display: none; gap: 10px; margin-left: auto; }
        .btn-save { background: var(--primary); color: white; border: none; padding: 10px 25px; border-radius: 12px; cursor: pointer; font-weight: 600; }
        .btn-save:hover { background: var(--dark); }
        .btn-cancel { background: #f3f4f6; color: #6b7280; border: none; padding: 10px 20px; border-radius: 12px; cursor: pointer; font-weight: 600; }
        .btn-cancel:hover { background: #e5e7eb; }

        /* Info Grid */
        .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 25px; margin-top: 30px; }
        .info-item { background: white; padding: 25px; border-radius: 16px; border: 1px solid #e5e7eb; transition: 0.3s; position: relative; }
        .info-item:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0,0,0,0.03); border-color: var(--primary); }
        .label { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; color: #9ca3af; font-weight: 600; margin-bottom: 8px; display: block; }
        .value { font-size: 1.1rem; font-weight: 500; color: var(--text); display: flex; align-items: center; gap: 10px; min-height: 28px; }
        .value i { color: var(--primary); font-size: 1.2rem; opacity: 0.8; }

        /* Form Inputs (Hidden by default) */
        .edit-input { 
            display: none; 
            width: 100%; 
            padding: 8px 12px; 
            border: 2px solid #e5e7eb; 
            border-radius: 8px; 
            font-family: inherit; 
            font-size: 1rem; 
            color: var(--dark);
            outline: none;
            transition: 0.3s;
        }
        .edit-input:focus { border-color: var(--primary); }
        textarea.edit-input { resize: vertical; min-height: 80px; }

        /* Modal */
        .modal-bg { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 999; justify-content: center; align-items: center; backdrop-filter: blur(5px); }
        .modal { background: white; padding: 30px; border-radius: 20px; width: 400px; text-align: center; position: relative; box-shadow: 0 20px 50px rgba(0,0,0,0.2); animation: popIn 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .close-modal { position: absolute; top: 15px; right: 20px; font-size: 1.5rem; cursor: pointer; color: #9ca3af; transition: 0.2s; }
        .close-modal:hover { color: var(--text); }
        .modal h3 { margin-top: 0; color: var(--dark); }
        
        .modal-actions { display: flex; gap: 15px; justify-content: center; margin-top: 25px; }
        .btn-action { flex: 1; padding: 15px; border-radius: 12px; border: 2px solid #e5e7eb; background: transparent; cursor: pointer; transition: 0.2s; display: flex; flex-direction: column; align-items: center; gap: 8px; color: var(--text); font-weight: 500; }
        .btn-action:hover { border-color: var(--primary); background: #f0fdf4; color: var(--primary); transform: translateY(-2px); }
        .btn-action.delete:hover { border-color: #ef4444; background: #fef2f2; color: #ef4444; }
        .btn-action i { font-size: 1.5rem; }

        @keyframes popIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
    </style>
</head>
<body>

<?php echo $message; ?>

<div class="sidebar">
    <h2><i class="fas fa-house-user"></i> i-Desa</h2>
    <a href="homepage.php" class="menu-link"><i class="fas fa-home"></i> Laman Utama</a>
    <a href="profile_management.php" class="menu-link active"><i class="fas fa-user-circle"></i> Profil Saya</a>
    <a href="change_password.php" class="menu-link"><i class="fas fa-key"></i> Tukar Kata Laluan</a>
    <a href="my_notifications_calendar.php" class="menu-link"><i class="fas fa-history"></i> Log Aktiviti</a>
    <a href="logout.php" class="menu-link logout-link"><i class="fas fa-sign-out-alt"></i> Log Keluar</a>
</div>

<div class="main">
    
    <form method="POST" id="profileForm">
    
        <div class="profile-card">
            <div class="avatar-box" id="avatarTrigger" data-has-photo="<?php echo $hasPhoto ? '1' : '0'; ?>">
                <?php if ($hasPhoto): ?>
                    <img src="uploads/<?php echo htmlspecialchars(basename($user['profile_picture'])); ?>" class="avatar-img" alt="Profile">
                <?php else: ?>
                    <div class="avatar-initial"><?php echo strtoupper($user['full_name'][0]); ?></div>
                <?php endif; ?>
                
                <div class="avatar-overlay">
                    <i class="fas fa-camera fa-lg"></i>
                    <span style="margin-top:5px; font-weight:600;">Ubah</span>
                </div>
            </div>

            <div class="user-info">
                <h1 class="view-data"><?php echo htmlspecialchars($user['full_name']); ?></h1>
                <input type="text" name="full_name" class="edit-input" value="<?php echo htmlspecialchars($user['full_name']); ?>" style="font-size:1.5rem; font-weight:700; margin-bottom:10px;">
                
                <p>Ahli Komuniti Berdaftar</p>
                <span class="role-badge"><?php echo htmlspecialchars($user['username']); ?></span>
            </div>

            <div class="edit-toggle-btn" id="btnEdit" onclick="toggleEditMode()">
                <i class="fas fa-pen"></i> Sunting
            </div>

            <div class="action-buttons" id="actionButtons">
                <button type="button" class="btn-cancel" onclick="cancelEdit()">Batal</button>
                <button type="submit" name="update_profile" class="btn-save">Simpan</button>
            </div>
        </div>

        <div class="info-grid">
            <div class="info-item">
                <span class="label">Alamat Emel</span>
                <div class="value">
                    <i class="far fa-envelope"></i> 
                    <span class="view-data"><?php echo htmlspecialchars($user['email']); ?></span>
                    <input type="email" name="email" class="edit-input" value="<?php echo htmlspecialchars($user['email']); ?>">
                </div>
            </div>
            <div class="info-item">
                <span class="label">Nombor Telefon</span>
                <div class="value">
                    <i class="fas fa-phone-alt"></i> 
                    <span class="view-data"><?php echo htmlspecialchars($user['phone'] ?? 'Tiada rekod'); ?></span>
                    <input type="text" name="phone" class="edit-input" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="Contoh: 012-3456789">
                </div>
            </div>
            <div class="info-item" style="grid-column: 1 / -1;">
                <span class="label">Alamat Rumah</span>
                <div class="value">
                    <i class="fas fa-map-marker-alt"></i> 
                    <span class="view-data"><?php echo htmlspecialchars($user['address'] ?? 'Belum dikemaskini'); ?></span>
                    <textarea name="address" class="edit-input" rows="2" placeholder="Masukkan alamat lengkap..."><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                </div>
            </div>
        </div>

    </form> </div>

<div class="modal-bg" id="photoModal">
    <div class="modal">
        <span class="close-modal" onclick="closeModal()">&times;</span>
        <h3>Kemaskini Gambar</h3>
        <p style="color:#6b7280; font-size:0.9rem;">Pilih tindakan untuk gambar profil anda.</p>
        
        <div class="modal-actions">
            <button class="btn-action" onclick="triggerUpload()">
                <i class="fas fa-cloud-upload-alt" style="color:var(--primary);"></i>
                <span>Muat Naik</span>
            </button>
            
            <?php if ($hasPhoto): ?>
            <form method="POST" style="flex:1; display:flex;">
                <button type="submit" name="remove_photo" class="btn-action delete" style="width:100%;">
                    <i class="fas fa-trash-alt" style="color:#ef4444;"></i>
                    <span>Padam</span>
                </button>
            </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<form id="uploadForm" method="POST" enctype="multipart/form-data" style="display:none;">
    <input type="file" name="new_profile_pic" id="fileInput" accept="image/png,image/jpeg" onchange="this.form.submit()">
</form>

<script>
    /* --- Photo Modal Logic --- */
    const modal = document.getElementById('photoModal');
    const trigger = document.getElementById('avatarTrigger');

    trigger.addEventListener('click', () => {
        // Prevent opening photo modal if in edit mode (optional, mostly user preference)
        const hasPhoto = trigger.getAttribute('data-has-photo') === '1';
        if (hasPhoto) {
            modal.style.display = 'flex';
        } else {
            triggerUpload();
        }
    });

    function closeModal() { modal.style.display = 'none'; }
    function triggerUpload() { document.getElementById('fileInput').click(); }

    window.onclick = function(e) { if (e.target === modal) closeModal(); }

    /* --- Edit Profile Toggle Logic --- */
    function toggleEditMode() {
        const viewData = document.querySelectorAll('.view-data');
        const editInputs = document.querySelectorAll('.edit-input');
        const btnEdit = document.getElementById('btnEdit');
        const actionButtons = document.getElementById('actionButtons');

        // Hide view text, Show inputs
        viewData.forEach(el => el.style.display = 'none');
        editInputs.forEach(el => el.style.display = 'block');

        // Toggle buttons
        btnEdit.style.display = 'none';
        actionButtons.style.display = 'flex';
    }

    function cancelEdit() {
        // Reload page to reset data or simply toggle back (reloading is safer to clear unsaved changes)
        location.reload(); 
    }
</script>

</body>
</html>