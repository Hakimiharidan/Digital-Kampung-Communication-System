<?php 
session_start(); 
include "db_connect.php"; 

if(!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$uid = $_SESSION['user_id'];

// Fetch activities for this specific user
$query = "SELECT * FROM activities WHERE user_id = '$uid' ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>i-Desa | Aktiviti Saya</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --p-green: #2d6a4f; --dark: #1b4332; }
        body { margin: 0; font-family: 'Poppins', sans-serif; background: #f4f7f4; padding: 40px; }
        
        .container { max-width: 800px; margin: auto; background: white; padding: 40px; border-radius: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.05); }
        h2 { color: var(--dark); display: flex; align-items: center; gap: 15px; }
        
        .timeline { border-left: 3px solid #eef2ef; padding-left: 20px; margin-left: 20px; margin-top: 30px; }
        .activity-item { position: relative; margin-bottom: 30px; }
        .activity-item::before { content: ''; position: absolute; left: -28px; top: 5px; width: 12px; height: 12px; background: var(--p-green); border-radius: 50%; border: 3px solid white; box-shadow: 0 0 5px rgba(0,0,0,0.1); }
        
        .activity-content { background: #f9fbf9; padding: 15px 20px; border-radius: 12px; border: 1px solid #edf2ee; }
        .activity-date { font-size: 0.75rem; color: #888; font-weight: 600; text-transform: uppercase; }
        .activity-text { margin: 5px 0 0; color: #444; }

        .empty-state { text-align: center; padding: 40px; color: #888; }
        .back-btn { display: inline-block; margin-top: 20px; color: var(--p-green); text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>

<div class="container">
    <h2><i class="fas fa-history"></i> Garis masa aktiviti saya</h2>
    <p style="color: #666;">Log tindakan terbaru anda dalam sistem i-Desa.</p>

    <div class="timeline">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <div class="activity-item">
                    <div class="activity-content">
                        <div class="activity-date"><?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></div>
                        <p class="activity-text"><?php echo htmlspecialchars($row['action_details']); ?></p>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-folder-open fa-3x" style="margin-bottom: 15px; opacity: 0.3;"></i>
                <p>Tiada aktiviti direkodkan lagi.</p>
            </div>
        <?php endif; ?>
    </div>

    <a href="profile_management.php" class="back-btn">← Kembali ke Papan Pemuka</a>
</div>

</body>
</html>