<?php
session_start();
include_once "db_connect.php";
include_once "navbar.php";

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Pusat Notifikasi</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    /* 1. Global Reset & Variables */
    :root {
        --primary: #2d6a4f;
        --primary-dark: #1b4332;
        --bg: #f8fafc;
        --card: #ffffff;
        --text: #333;
        --muted: #6b7280;
        --border: #e5e7eb;
        
        /* Distinct Notification Colors */
        --bg-admin-msg: #f0f9ff; /* Light Blue for Admin Messages */
        --border-admin: #0ea5e9;
        
        --border-report: #f59e0b; /* Orange */
        --border-calendar: #22c55e; /* Green */
        --border-lostfound: #8b5cf6; /* Purple */
        --border-emergency: #ef4444; /* Red */
    }

    body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); min-height:100vh; }
    .wrap { max-width: 1100px; margin: 0 auto; padding: 30px 20px 80px; }

    /* Header */
    header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 25px; flex-wrap: wrap; gap: 15px; }
    h1 { margin: 0; font-size: 28px; color: var(--primary-dark); font-weight: 700; }
    .subtitle { margin: 5px 0 0; color: var(--muted); font-size: 14px; }

    /* Tabs Navigation */
    .tabs { display: flex; gap: 20px; border-bottom: 2px solid var(--border); padding-bottom: 0; margin-bottom: 20px; }
    .tab-btn {
        padding: 10px 15px; background: transparent; border: none;
        border-bottom: 3px solid transparent; font-weight: 600;
        color: var(--muted); cursor: pointer; font-size: 15px;
        transition: all 0.2s;
    }
    .tab-btn:hover { color: var(--primary); }
    .tab-btn.active { color: var(--primary); border-bottom-color: var(--primary); }
    .tab-btn i { margin-right: 8px; }

    /* --- GMAIL STYLE TOOLBAR --- */
    .gmail-toolbar {
        display: flex; gap: 10px; align-items: center; padding: 12px 15px;
        background: #fff; border: 1px solid var(--border); border-radius: 12px 12px 0 0;
        border-bottom: 1px solid var(--border); flex-wrap: wrap;
    }

    .search-wrapper { position: relative; flex: 1; min-width: 250px; }
    .search-wrapper input {
        width: 100%; padding: 10px 10px 10px 40px; border-radius: 8px; border: 1px solid var(--border);
        background: #f1f5f9; font-size: 14px; outline: none; transition: 0.2s;
    }
    .search-wrapper input:focus { background: #fff; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }
    .search-icon { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--muted); }

    .filter-btn {
        padding: 6px 14px; border: 1px solid transparent; background: transparent; 
        font-size: 13px; font-weight: 600; color: var(--muted); cursor: pointer; border-radius: 20px;
    }
    .filter-btn:hover { background: #f1f5f9; }
    .filter-btn.active { background: #e0f2fe; color: #0284c7; border-color: #bae6fd; }

    /* --- NOTIFICATION LIST --- */
    .notif-list-container {
        background: #fff; border: 1px solid var(--border); border-top: none;
        border-radius: 0 0 12px 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); overflow: hidden;
    }
    
    .notif-row {
        display: grid; grid-template-columns: 50px 1fr 120px 100px;
        padding: 16px; border-bottom: 1px solid var(--border);
        align-items: start; cursor: pointer; transition: 0.1s; gap: 15px;
        position: relative; border-left: 4px solid transparent; /* Status Indicator Strip */
    }
    .notif-row:last-child { border-bottom: none; }
    .notif-row:hover { background-color: #fafafa; }
    
    /* Highlight Unread */
    .notif-row.unread { font-weight: 600; background-color: #fff; }
    .notif-row.unread .n-msg { color: #111; }

    /* --- DIFFERENTIATED STYLES (The Request) --- */
    
    /* 1. Admin/AJK Manual Messages (Highlighted) */
    .notif-row.source-admin {
        background-color: var(--bg-admin-msg); /* Light Blue Background */
    }
    .notif-row.source-admin:hover { background-color: #e0f2fe; }
    .notif-row.source-admin .type-icon { background-color: #0284c7; color: white; }

    /* 2. Color Coded Strips */
    .notif-row.cat-Admin { border-left-color: var(--border-admin); }
    .notif-row.cat-Report { border-left-color: var(--border-report); }
    .notif-row.cat-Calendar { border-left-color: var(--border-calendar); }
    .notif-row.cat-LostFound { border-left-color: var(--border-lostfound); }
    .notif-row.cat-Emergency { border-left-color: var(--border-emergency); background-color: #fef2f2; }

    /* Icons */
    .type-icon {
        width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center;
        font-size: 16px; background: #f1f5f9; color: var(--muted);
    }
    /* Specific Icons Colors */
    .notif-row.cat-Report .type-icon { color: var(--border-report); background: #fff7ed; }
    .notif-row.cat-Calendar .type-icon { color: var(--border-calendar); background: #ecfdf5; }
    .notif-row.cat-LostFound .type-icon { color: var(--border-lostfound); background: #f5f3ff; }
    .notif-row.cat-Emergency .type-icon { color: #fff; background: var(--border-emergency); }

    /* Text */
    .n-header { font-size: 12px; color: var(--muted); margin-bottom: 4px; display: flex; gap: 8px; align-items: center; }
    .n-msg { font-size: 14px; color: #4b5563; line-height: 1.5; }
    .n-date { font-size: 12px; color: var(--muted); text-align: right; white-space: nowrap; }

    /* Actions */
    .row-actions {
        display: flex; gap: 5px; justify-content: flex-end; opacity: 0.6; transition: 0.2s;
    }
    .notif-row:hover .row-actions { opacity: 1; }
    
    .action-btn {
        width: 30px; height: 30px; border-radius: 6px; border: 1px solid var(--border);
        background: #fff; color: var(--muted); cursor: pointer; display: flex; align-items: center; justify-content: center;
    }
    .action-btn:hover { background: var(--primary); color: white; border-color: var(--primary); }
    .btn-del:hover { background: #ef4444; border-color: #ef4444; }

    /* Tabs & Content */
    .tab-content { display: none; animation: fadeIn 0.3s ease; }
    .tab-content.active { display: block; }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

    /* Empty State */
    .empty-box { padding: 50px; text-align: center; color: var(--muted); }
    
    /* --- TABLE (for Booking Tab) --- */
    .table-container { background: #fff; border: 1px solid var(--border); border-radius: 12px; overflow: hidden; padding:0; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f8fafc; text-align: left; padding: 15px; font-size: 13px; font-weight: 600; color: var(--muted); border-bottom: 1px solid var(--border); }
    td { padding: 15px; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
    
    .badge { padding: 4px 10px; border-radius: 99px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
    .b-confirmed { background: #dcfce7; color: #166534; }
    .b-pending { background: #fef9c3; color: #854d0e; }
    .b-rejected { background: #fee2e2; color: #991b1b; }

    /* Modal Preferences */
    dialog { border: none; border-radius: 12px; padding: 20px; width: 90%; max-width: 400px; box-shadow: 0 20px 50px rgba(0,0,0,0.2); }
    dialog::backdrop { background: rgba(0,0,0,0.5); }
    .pref-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f1f5f9; align-items: center; }
    .toggle { position: relative; display: inline-block; width: 36px; height: 20px; }
    .toggle input { opacity: 0; width: 0; height: 0; }
    .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }
    .slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 2px; bottom: 2px; background-color: white; transition: .4s; border-radius: 50%; }
    input:checked + .slider { background-color: var(--primary); }
    input:checked + .slider:before { transform: translateX(16px); }

    /* Responsive */
    @media (max-width: 600px) {
        .notif-row { grid-template-columns: 40px 1fr; gap: 10px; }
        .n-date, .row-actions { display: none; } /* Simplified mobile view */
    }
</style>
</head>

<body>

<div class="wrap">
    
    <header>
        <div>
            <h1>Pusat Notifikasi</h1>
            <p class="subtitle">Semua kemaskini penting dan status permohonan anda.</p>
        </div>
        <div style="display:flex; gap:10px;">
            <button onclick="document.getElementById('dlgPrefs').showModal()" class="action-btn" style="width:auto; padding:0 15px; border-radius:8px;">
                <i class="fas fa-sliders-h" style="margin-right:8px;"></i> Tetapan
            </button>
            <a href="homepage.php" class="action-btn" style="width:auto; padding:0 15px; border-radius:8px; text-decoration:none;">
                <i class="fa-solid fa-arrow-left" style="margin-right:8px;"></i> Kembali
            </a>
        </div>
    </header>

    <div class="tabs">
        <button class="tab-btn active" onclick="switchTab('notif')" id="tab-btn-notif">
            <i class="fas fa-bell"></i> Notifikasi Terkini
        </button>
        <button class="tab-btn" onclick="switchTab('booking')" id="tab-btn-booking">
            <i class="fas fa-calendar-check"></i> Status Tempahan Fasiliti
        </button>
    </div>

    <div id="view-notif" class="tab-content active">
        
        <div class="gmail-toolbar">
            <div style="display:flex; gap:5px; flex-wrap:wrap;">
                <button class="filter-btn active" onclick="filterType('all')" id="fil-all">Semua</button>
                <button class="filter-btn" onclick="filterType('Admin')" id="fil-Admin">Admin/AJK</button>
                <button class="filter-btn" onclick="filterType('Report')" id="fil-Report">Aduan</button>
                <button class="filter-btn" onclick="filterType('Calendar')" id="fil-Calendar">Kalendar</button>
                <button class="filter-btn" onclick="filterType('LostFound')" id="fil-LostFound">Lost & Found</button>
            </div>

            <div class="search-wrapper">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="searchInput" placeholder="Cari notifikasi..." onkeyup="handleSearch(event)">
            </div>

            <div style="display:flex; gap:5px; margin-left:auto;">
                <button class="action-btn" title="Refresh" onclick="loadNotifications()"><i class="fas fa-sync-alt"></i></button>
                <button class="action-btn" title="Tanda Semua Dibaca" onclick="markAllRead()"><i class="fas fa-check-double"></i></button>
                <button class="action-btn btn-del" title="Padam Yang Telah Dibaca" onclick="clearOld()"><i class="fas fa-trash-alt"></i></button>
            </div>
        </div>

        <div class="notif-list-container" id="notifContainer">
            <div class="empty-box"><i class="fas fa-spinner fa-spin"></i> Memuatkan...</div>
        </div>
    </div>

    <div id="view-booking" class="tab-content">
        <div class="table-container">
            <div style="padding:15px; border-bottom:1px solid #eee; display:flex; justify-content:space-between;">
                <h3 style="margin:0; font-size:16px; color:var(--primary-dark);">Rekod Tempahan Fasiliti</h3>
                <button onclick="loadBookings()" style="background:none; border:none; cursor:pointer;"><i class="fas fa-sync"></i></button>
            </div>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Tarikh Mohon</th>
                            <th>Fasiliti</th>
                            <th>Tarikh Guna</th>
                            <th>Status</th>
                            <th>Harga</th>
                        </tr>
                    </thead>
                    <tbody id="tbodyBooking"></tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<dialog id="dlgPrefs">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
        <h3 style="margin:0;">Tetapan Notifikasi</h3>
        <button onclick="document.getElementById('dlgPrefs').close()" style="background:none; border:none; font-size:20px; cursor:pointer;">&times;</button>
    </div>
    <p style="font-size:13px; color:var(--muted);">Pilih jenis notifikasi yang ingin dipaparkan dalam senarai.</p>
    
    <div class="pref-row">
        <span>Notifikasi Admin/AJK (Penting)</span>
        <label class="toggle"><input type="checkbox" id="pref_Admin" checked onchange="savePrefs()"><span class="slider"></span></label>
    </div>
    <div class="pref-row">
        <span>Status Aduan</span>
        <label class="toggle"><input type="checkbox" id="pref_Report" checked onchange="savePrefs()"><span class="slider"></span></label>
    </div>
    <div class="pref-row">
        <span>Kalendar & Acara</span>
        <label class="toggle"><input type="checkbox" id="pref_Calendar" checked onchange="savePrefs()"><span class="slider"></span></label>
    </div>
    <div class="pref-row">
        <span>Barang Hilang & Jumpa</span>
        <label class="toggle"><input type="checkbox" id="pref_LostFound" checked onchange="savePrefs()"><span class="slider"></span></label>
    </div>
</dialog>

<dialog id="dlgDetail" style="max-width:500px;">
    <div style="padding:20px;">
        <h3 id="dtlTitle" style="margin-top:0;">Butiran</h3>
        <div id="dtlBody" style="line-height:1.6; font-size:14px; margin-bottom:20px;"></div>
        <div style="text-align:right;">
            <button onclick="document.getElementById('dlgDetail').close()" class="action-btn" style="width:auto; padding:0 20px;">Tutup</button>
        </div>
    </div>
</dialog>

<script>
// --- STATE ---
let allNotifs = [];
let currentFilter = 'all';
let searchQuery = '';

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    loadPrefs();
    loadNotifications();
});

// --- TABS ---
function switchTab(id) {
    document.querySelectorAll('.tab-content').forEach(e => e.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(e => e.classList.remove('active'));
    document.getElementById('view-'+id).classList.add('active');
    document.getElementById('tab-btn-'+id).classList.add('active');
    
    if(id === 'notif') loadNotifications();
    if(id === 'booking') loadBookings();
}

// --- NOTIFICATIONS ---
async function loadNotifications() {
    const container = document.getElementById('notifContainer');
    // Don't wipe if we are just filtering, but for refresh yes
    if(allNotifs.length === 0) container.innerHTML = '<div class="empty-box"><i class="fas fa-spinner fa-spin"></i> Memuatkan...</div>';

    try {
        const fd = new FormData();
        fd.append('action', 'fetch_notifications');
        const res = await fetch('ajax_calendar_notification.php', { method:'POST', body:fd });
        const json = await res.json();
        
        if(!json.ok) throw new Error(json.error);
        
        allNotifs = json.data.notifications;
        renderList();

    } catch(e) {
        container.innerHTML = `<div class="empty-box" style="color:red;">Ralat: ${e.message}</div>`;
    }
}

function renderList() {
    const container = document.getElementById('notifContainer');
    container.innerHTML = '';

    // Filter Logic
    const prefs = JSON.parse(localStorage.getItem('notif_prefs') || '{}');
    
    const filtered = allNotifs.filter(n => {
        // Preference Filter
        if(prefs[n.type] === false) return false;
        
        // Search Filter
        if(searchQuery && !n.message.toLowerCase().includes(searchQuery)) return false;

        // Button Filter
        if(currentFilter !== 'all' && n.type !== currentFilter) return false;

        return true;
    });

    if(filtered.length === 0) {
        container.innerHTML = `<div class="empty-box"><i class="far fa-bell-slash"></i><br>Tiada notifikasi.</div>`;
        return;
    }

    // Render Rows
    let html = '';
    filtered.forEach(n => {
        const isRead = n.is_read == 1;
        const clsUnread = isRead ? '' : 'unread';
        const clsSource = (n.source === 'Admin') ? 'source-admin' : '';
        const clsCat = 'cat-' + n.type;
        
        // Icons based on Type
        let icon = '<i class="fas fa-info"></i>';
        if(n.type === 'Admin') icon = '<i class="fas fa-bullhorn"></i>';
        if(n.type === 'Report') icon = '<i class="fas fa-file-alt"></i>';
        if(n.type === 'Calendar') icon = '<i class="far fa-calendar-alt"></i>';
        if(n.type === 'LostFound') icon = '<i class="fas fa-search"></i>';
        if(n.type === 'Emergency') icon = '<i class="fas fa-exclamation-triangle"></i>';

        html += `
        <div class="notif-row ${clsUnread} ${clsSource} ${clsCat}" onclick="openDetail(${n.notification_id}, '${escapeHtml(n.message)}', ${n.event_id || 'null'})">
            <div class="type-icon">${icon}</div>
            
            <div style="overflow:hidden;">
                <div class="n-header">
                    <span style="font-weight:700; color:var(--primary);">${n.type}</span>
                    ${n.source === 'Admin' ? '<span style="background:#0ea5e9; color:white; padding:1px 6px; border-radius:4px; font-size:10px;">ADMIN</span>' : ''}
                </div>
                <div class="n-msg">${escapeHtml(n.message)}</div>
            </div>

            <div class="n-date">${formatDate(n.created_at)}</div>

            <div class="row-actions">
                ${!isRead ? `<button class="action-btn" title="Tanda Baca" onclick="markRead(${n.notification_id}, event)"><i class="fas fa-check"></i></button>` : ''}
                <button class="action-btn btn-del" title="Padam" onclick="deleteNotif(${n.notification_id}, event)"><i class="far fa-trash-alt"></i></button>
            </div>
        </div>
        `;
    });
    container.innerHTML = html;
}

// --- ACTIONS ---
function filterType(type) {
    currentFilter = type;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('fil-'+type).classList.add('active');
    renderList();
}

function handleSearch(e) {
    searchQuery = e.target.value.toLowerCase();
    renderList();
}

async function markRead(id, e) {
    if(e) e.stopPropagation();
    const fd = new FormData(); fd.append('action', 'mark_read'); fd.append('notification_id', id);
    await fetch('ajax_calendar_notification.php', { method:'POST', body:fd });
    
    // Update local state for instant feel
    const item = allNotifs.find(n => n.notification_id == id);
    if(item) item.is_read = 1;
    renderList();
}

async function markAllRead() {
    if(!confirm("Tandakan semua sebagai dibaca?")) return;
    const fd = new FormData(); fd.append('action', 'mark_all_read');
    await fetch('ajax_calendar_notification.php', { method:'POST', body:fd });
    allNotifs.forEach(n => n.is_read = 1);
    renderList();
}

async function deleteNotif(id, e) {
    if(e) e.stopPropagation();
    if(!confirm("Padam notifikasi ini?")) return;
    
    const fd = new FormData(); fd.append('action', 'delete_notification'); fd.append('notification_id', id);
    await fetch('ajax_calendar_notification.php', { method:'POST', body:fd });
    
    allNotifs = allNotifs.filter(n => n.notification_id != id);
    renderList();
}

async function clearOld() {
    if(!confirm("Padam semua notifikasi lama (Read)?")) return;
    const fd = new FormData(); fd.append('action', 'clear_old_notifications');
    await fetch('ajax_calendar_notification.php', { method:'POST', body:fd });
    loadNotifications();
}

// --- PREFERENCES ---
function loadPrefs() {
    const prefs = JSON.parse(localStorage.getItem('notif_prefs') || '{"Admin":true,"Report":true,"Calendar":true,"LostFound":true}');
    for(let k in prefs) {
        const el = document.getElementById('pref_'+k);
        if(el) el.checked = prefs[k];
    }
}

function savePrefs() {
    const prefs = {
        Admin: document.getElementById('pref_Admin').checked,
        Report: document.getElementById('pref_Report').checked,
        Calendar: document.getElementById('pref_Calendar').checked,
        LostFound: document.getElementById('pref_LostFound').checked
    };
    localStorage.setItem('notif_prefs', JSON.stringify(prefs));
    renderList();
}

// --- BOOKINGS ---
async function loadBookings() {
    const tbody = document.getElementById('tbodyBooking');
    try {
        const fd = new FormData(); fd.append('action', 'fetch_my_bookings');
        const res = await fetch('ajax_calendar_notification.php', { method:'POST', body:fd });
        const json = await res.json();
        
        if(!json.ok) throw new Error(json.error);
        
        if(json.data.bookings.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-box">Tiada rekod tempahan.</td></tr>';
            return;
        }

        tbody.innerHTML = json.data.bookings.map(b => {
            let cls = 'b-pending';
            if(b.status === 'Confirmed') cls = 'b-confirmed';
            if(b.status === 'Rejected') cls = 'b-rejected';
            
            return `
                <tr>
                    <td>${formatDate(b.created_at)}</td>
                    <td><b>${escapeHtml(b.facility_name)}</b></td>
                    <td>${escapeHtml(b.booking_date)} (${b.start_time})</td>
                    <td><span class="badge ${cls}">${b.status}</span></td>
                    <td>RM ${b.total_amount}</td>
                </tr>
            `;
        }).join('');
    } catch(e) { tbody.innerHTML = `<tr><td colspan="5" class="empty-box" style="color:red;">${e.message}</td></tr>`; }
}

// --- HELPERS ---
function openDetail(id, msg, eid) {
    markRead(id); // Auto mark read
    document.getElementById('dtlBody').innerText = msg;
    document.getElementById('dlgDetail').showModal();
}

function escapeHtml(text) {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function formatDate(dateString) {
    if(!dateString) return '-';
    const d = new Date(dateString.replace(' ','T'));
    return d.toLocaleDateString('ms-MY', { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' });
}
</script>

<?php include "footer.php"; ?>
</body>
</html>