<?php
session_start();
include "db_connect.php";

// 1. Session & Auth
$role = $_SESSION['role'] ?? 'Resident';
$isLoggedIn = isset($_SESSION['user_id']);
$isAdminOrAjk = ($role === 'AJK' || $role === 'Admin');

// Helper
if (!function_exists('h')) {
    function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

$flash = "";
$flashType = ""; // success or error

// 2. Prefill Data (if logged in)
$prefill = ['full_name'=>'', 'email'=>'', 'phone'=>''];
if ($isLoggedIn) {
    $uid = (int)$_SESSION['user_id'];
    $stmt = mysqli_prepare($conn, "SELECT full_name, email, phone FROM users WHERE user_id=?");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $uid);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        if ($res && ($u = mysqli_fetch_assoc($res))) $prefill = $u;
        mysqli_stmt_close($stmt);
    }
}

// 3. Process Booking Submission
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['submit_booking'])) {
    $contact_name  = trim((string)($_POST['contact_name'] ?? ''));
    $contact_phone = trim((string)($_POST['contact_phone'] ?? ''));
    $contact_email = trim((string)($_POST['contact_email'] ?? ''));
    $user_origin   = $_POST['user_origin'] ?? 'Resident';
    $facility_id   = (int)($_POST['facility_id'] ?? 0);
    $date          = $_POST['date'] ?? '';
    $purpose       = trim((string)($_POST['purpose'] ?? ''));
    $duration      = (int)($_POST['duration'] ?? 0);
    $start_time_in = $_POST['start_time'] ?? '08:00';

    if ($contact_name==='' || $contact_phone==='' || $facility_id<=0 || $date==='' || $purpose==='' || $duration<=0) {
        $flash = "Sila lengkapkan semua maklumat wajib.";
        $flashType = "error";
    } else {
        if (!in_array($user_origin, ['Resident','Outsider'], true)) $user_origin = 'Resident';

        // Get facility details
        $stmt_f = mysqli_prepare($conn, "SELECT rate_per_hour, price_unit, status, name FROM facilities WHERE facility_id=?");
        mysqli_stmt_bind_param($stmt_f, "i", $facility_id);
        mysqli_stmt_execute($stmt_f);
        $res_f = mysqli_stmt_get_result($stmt_f);
        $fac = $res_f ? mysqli_fetch_assoc($res_f) : null;
        mysqli_stmt_close($stmt_f);

        if (!$fac) {
            $flash = "Ralat: Fasiliti tidak dijumpai.";
            $flashType = "error";
        } elseif (($fac['status'] ?? '') !== 'Available') {
            $flash = "Maaf, fasiliti ini sedang diselenggara (Maintenance).";
            $flashType = "error";
        } else {
            $rate = (float)$fac['rate_per_hour'];
            $unit = $fac['price_unit'] ?? 'Hour';

            // Calculate Times & Cost
            if ($unit === 'Day') {
                $start_time = "00:00:00";
                $duration_hours = $duration * 24;
                $total_amount = $rate * $duration; 
            } else {
                // Validate Operating Hours (08:00 - 23:00)
                $start_time = $start_time_in . ":00";
                $start_ts = strtotime("$date $start_time");
                $end_ts = $start_ts + ($duration * 3600);
                $start_h = (int)date("H", $start_ts);
                $end_h = (int)date("H", $end_ts);
                
                // Simple logic: if end hour is smaller than start hour, it crossed midnight (not allowed usually)
                if ($start_h < 8 || ($end_h > 23 && $end_h < 24) || ($end_h < 8 && $end_h > 0)) {
                    $flash = "Waktu operasi fasiliti adalah 8:00 Pagi - 11:00 Malam sahaja.";
                    $flashType = "error";
                } else {
                    $duration_hours = $duration;
                    $total_amount = $rate * $duration;
                }
            }

            if ($flashType !== "error") {
                // Check Conflicts (Buffer 30 mins)
                $start_ts = strtotime("$date $start_time");
                $end_ts = $start_ts + ($duration_hours * 3600);
                $sql_start = date("H:i:s", $start_ts);
                $sql_end = date("H:i:s", $end_ts);

                $check_sql = "SELECT booking_id FROM bookings 
                              WHERE facility_id = ? 
                              AND booking_date = ? 
                              AND status != 'Rejected' 
                              AND (
                                ? < ADDTIME(ADDTIME(start_time, SEC_TO_TIME(duration_hours*3600)), '00:30:00')
                                AND 
                                ? > SUBTIME(start_time, '00:30:00')
                              )";
                $stmt_check = mysqli_prepare($conn, $check_sql);
                if ($stmt_check) {
                    mysqli_stmt_bind_param($stmt_check, "isss", $facility_id, $date, $sql_start, $sql_end);
                    mysqli_stmt_execute($stmt_check);
                    $res_c = mysqli_stmt_get_result($stmt_check);
                    $hasConflict = ($res_c && mysqli_num_rows($res_c) > 0);
                    mysqli_stmt_close($stmt_check);

                    if ($hasConflict) {
                        $flash = "Slot masa tersebut telah ditempah. Sila pilih masa lain.";
                        $flashType = "error";
                    } else {
                        // Insert Booking
                        $insert_sql = "INSERT INTO bookings (contact_name, contact_phone, contact_email, user_origin, facility_id, booking_date, start_time, duration_hours, total_amount, purpose, status)
                                       VALUES (?,?,?,?,?,?,?,?,?,?, 'Pending')";
                        $stmt_i = mysqli_prepare($conn, $insert_sql);
                        if ($stmt_i) {
                            mysqli_stmt_bind_param($stmt_i, "ssssissids", $contact_name, $contact_phone, $contact_email, $user_origin, $facility_id, $date, $start_time, $duration_hours, $total_amount, $purpose);
                            mysqli_stmt_execute($stmt_i);
                            mysqli_stmt_close($stmt_i);
                            $flash = "Tempahan berjaya dihantar! Sila tunggu pengesahan AJK.";
                            $flashType = "success";
                            // Clear post to prevent resubmission
                            $_POST = [];
                        } else {
                            $flash = "Ralat pangkalan data.";
                            $flashType = "error";
                        }
                    }
                }
            }
        }
    }
}

// 4. Fetch Facilities
$facilities = [];
$res = mysqli_query($conn, "SELECT * FROM facilities ORDER BY status ASC, name ASC");
if ($res) while ($r = mysqli_fetch_assoc($res)) $facilities[] = $r;

// 5. Fetch User's Recent Bookings
$myBookings = [];
if ($isLoggedIn && ($prefill['email'] || $prefill['phone'])) {
    $email = $prefill['email'];
    $phone = $prefill['phone'];
    $sqlb = "SELECT b.*, f.name AS facility_name, f.price_unit 
             FROM bookings b JOIN facilities f ON b.facility_id=f.facility_id
             WHERE (b.contact_email = ? OR b.contact_phone = ?)
             ORDER BY b.created_at DESC LIMIT 5";
    $stmt = mysqli_prepare($conn, $sqlb);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $email, $phone);
        mysqli_stmt_execute($stmt);
        $resb = mysqli_stmt_get_result($stmt);
        if ($resb) while ($x = mysqli_fetch_assoc($resb)) $myBookings[] = $x;
        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Sewa Fasiliti</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
    /* Global Styles */
    :root { --primary:#2d6a4f; --dark:#1b4332; --accent:#d8f3dc; --bg:#f8fafc; --text:#1f2937; --muted:#64748b; --card:#ffffff; --border:#e2e8f0; }
    * { box-sizing:border-box; }
    body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); display:flex; flex-direction:column; min-height:100vh; }
    
    /* Layout Wrapper */
    .wrap { flex:1; width:100%; max-width:1200px; margin:0 auto; padding:30px 20px; }

    /* Header */
    .page-header { display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:30px; flex-wrap:wrap; gap:15px; }
    .title h1 { margin:0; font-size:28px; color:var(--dark); font-weight:700; }
    .title p { margin:5px 0 0; color:var(--muted); font-size:14px; max-width:600px; }
    
    /* Admin Button */
    .btn-admin { background:var(--dark); color:white; padding:10px 18px; border-radius:10px; font-weight:600; text-decoration:none; display:inline-flex; align-items:center; gap:8px; box-shadow:0 4px 6px rgba(0,0,0,0.1); transition:0.2s; }
    .btn-admin:hover { background:#0f291e; transform:translateY(-2px); }

    /* Flash Message */
    .alert { padding:15px; border-radius:12px; margin-bottom:25px; font-weight:500; display:flex; align-items:center; gap:10px; font-size:14px; }
    .alert.success { background:#dcfce7; color:#166534; border:1px solid #bbf7d0; }
    .alert.error { background:#fee2e2; color:#991b1b; border:1px solid #fecaca; }

    /* Main Grid */
    .main-grid { display:grid; grid-template-columns: 1fr 1.3fr; gap:30px; }
    @media (max-width: 900px) { .main-grid { grid-template-columns: 1fr; } .facility-cards { order: 2; } .booking-form { order: 1; } }

    /* Card Styling */
    .card { background:var(--card); border:1px solid var(--border); border-radius:16px; padding:25px; box-shadow:0 2px 4px rgba(0,0,0,0.02); }
    .card-title { margin:0 0 20px; font-size:18px; color:var(--primary); font-weight:700; border-bottom:1px solid var(--border); padding-bottom:10px; }

    /* Form Styles */
    .form-group { margin-bottom:15px; }
    .form-group label { display:block; font-size:13px; font-weight:600; margin-bottom:6px; color:var(--text); }
    .form-control { width:100%; padding:12px; border:1px solid var(--border); border-radius:10px; font-family:inherit; font-size:14px; transition:0.2s; outline:none; }
    .form-control:focus { border-color:var(--primary); box-shadow:0 0 0 3px var(--accent); }
    textarea.form-control { resize:vertical; min-height:100px; }
    
    .row-2 { display:grid; grid-template-columns: 1fr 1fr; gap:15px; }
    
    .btn-submit { background:var(--primary); color:white; border:none; padding:12px 24px; border-radius:50px; font-weight:600; cursor:pointer; width:100%; font-size:15px; transition:0.2s; display:flex; justify-content:center; align-items:center; gap:8px; }
    .btn-submit:hover { background:var(--dark); transform:translateY(-1px); }

    /* Facility Cards (Interactive) */
    .facility-list { display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:20px; }
    
    .f-card { 
        background:white; border:1px solid var(--border); border-radius:16px; overflow:hidden; 
        transition:0.3s; cursor:pointer; position:relative; display:flex; flex-direction:column;
    }
    .f-card:hover { transform:translateY(-5px); box-shadow:0 10px 20px rgba(0,0,0,0.08); border-color:var(--primary); }
    .f-card.selected { border:2px solid var(--primary); background:#f0fdf4; }
    
    .f-img { width:100%; height:160px; object-fit:cover; background:#eee; }
    .f-content { padding:15px; flex:1; display:flex; flex-direction:column; }
    .f-name { font-weight:700; font-size:16px; color:var(--dark); margin-bottom:5px; }
    .f-desc { font-size:13px; color:var(--muted); line-height:1.5; margin-bottom:12px; flex:1; }
    
    .f-meta { display:flex; justify-content:space-between; align-items:center; margin-top:auto; pt:10px; border-top:1px solid #f1f5f9; }
    .f-price { font-weight:700; color:var(--primary); font-size:15px; }
    .f-badge { font-size:11px; font-weight:700; padding:4px 10px; border-radius:20px; text-transform:uppercase; }
    .st-avail { background:#dcfce7; color:#15803d; }
    .st-maint { background:#fee2e2; color:#991b1b; }

    /* Booking History Table */
    .history-table { width:100%; border-collapse:collapse; margin-top:15px; font-size:13px; }
    .history-table th { text-align:left; padding:10px; background:#f8fafc; border-bottom:1px solid var(--border); color:var(--muted); }
    .history-table td { padding:10px; border-bottom:1px solid var(--border); }
    .pill { display:inline-block; padding:3px 8px; border-radius:6px; font-size:11px; font-weight:600; }
    .p-pending { background:#fff7ed; color:#c2410c; }
    .p-confirmed { background:#dcfce7; color:#15803d; }
    .p-rejected { background:#fef2f2; color:#991b1b; }
    .p-await { background:#eff6ff; color:#1e40af; }

</style>
</head>
<body>

<?php include "navbar.php"; ?>

<div class="wrap">
    
    <div class="page-header">
        <div class="title">
            <h1>Sewa Fasiliti</h1>
            <p>Pilih fasiliti pilihan anda, semak kadar sewaan, dan buat tempahan segera secara dalam talian.</p>
        </div>
        
        
        <?php if($role === 'Admin'): ?>
        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-tools"></i> <span>Panel Tetapan Sewa</span>
        </a>
        <?php endif; ?>
        
    </div>

    <?php if ($flash): ?>
        <div class="alert <?php echo $flashType; ?>">
            <i class="fas <?php echo ($flashType=='success')?'fa-check-circle':'fa-circle-exclamation'; ?>"></i> 
            <?php echo h($flash); ?>
        </div>
    <?php endif; ?>

    <div class="main-grid">
        
        <div class="booking-form">
            <section class="card" id="formSection">
                <div class="card-title"><i class="fas fa-file-signature"></i> Borang Tempahan</div>
                
                <form method="post" id="rentalForm">
                    <div class="form-group">
                        <label>Fasiliti Pilihan</label>
                        <select name="facility_id" id="facility_id" class="form-control" required onchange="updateFormLogic()">
                            <option value="">-- Sila Pilih Fasiliti di Sebelah --</option>
                            <?php foreach ($facilities as $f): ?>
                                <option value="<?php echo (int)$f['facility_id']; ?>" 
                                        data-unit="<?php echo h($f['price_unit']); ?>"
                                        data-price="<?php echo h($f['rate_per_hour']); ?>"
                                        data-status="<?php echo h($f['status']); ?>">
                                    <?php echo h($f['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div style="font-size:12px; color:var(--muted); margin-top:5px;" id="pricingHint">
                            Klik pada kad fasiliti untuk memilih.
                        </div>
                    </div>

                    <div class="row-2">
                        <div class="form-group">
                            <label>Nama Pemohon</label>
                            <input type="text" name="contact_name" class="form-control" required value="<?php echo h($_POST['contact_name'] ?? $prefill['full_name']); ?>">
                        </div>
                        <div class="form-group">
                            <label>No. Telefon</label>
                            <input type="text" name="contact_phone" class="form-control" required value="<?php echo h($_POST['contact_phone'] ?? $prefill['phone']); ?>">
                        </div>
                    </div>

                    <div class="row-2">
                        <div class="form-group">
                            <label>E-mel (Opsyenal)</label>
                            <input type="email" name="contact_email" class="form-control" value="<?php echo h($_POST['contact_email'] ?? $prefill['email']); ?>">
                        </div>
                        <div class="form-group">
                            <label>Kategori Pengguna</label>
                            <select name="user_origin" class="form-control">
                                <option value="Resident">Penduduk (Resident)</option>
                                <option value="Outsider">Luar (Outsider)</option>
                            </select>
                        </div>
                    </div>

                    <div class="row-2">
                        <div class="form-group">
                            <label>Tarikh Tempahan</label>
                            <input type="date" name="date" class="form-control" required value="<?php echo h($_POST['date'] ?? ''); ?>" min="<?php echo date('Y-m-d'); ?>">
                        </div>
                        
                        <div class="form-group" id="timeGroup">
                            <label>Waktu Mula</label>
                            <input type="time" name="start_time" class="form-control" value="<?php echo h($_POST['start_time'] ?? '08:00'); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label id="durationLabel">Tempoh Sewaan (Jam)</label>
                        <div style="display:flex; align-items:center; gap:10px;">
                            <input type="number" name="duration" class="form-control" min="1" required value="<?php echo h($_POST['duration'] ?? ''); ?>" placeholder="Contoh: 2">
                            <span id="unitLabel" style="font-size:13px; font-weight:600; color:var(--muted);">Jam</span>
                        </div>
                        <div style="font-size:12px; color:var(--primary); margin-top:5px; font-weight:600;" id="totalCostPreview"></div>
                    </div>

                    <div class="form-group">
                        <label>Tujuan Sewaan</label>
                        <textarea name="purpose" class="form-control" required placeholder="Contoh: Majlis Kesyukuran, Mesyuarat AJK..."><?php echo h($_POST['purpose'] ?? ''); ?></textarea>
                    </div>

                    <button type="submit" name="submit_booking" class="btn-submit">
                        <i class="fas fa-paper-plane"></i> Hantar Tempahan
                    </button>
                </form>
            </section>

            <?php if (!empty($myBookings)): ?>
            <div class="card" style="margin-top:20px;">
                <div class="card-title">Tempahan Saya</div>
                <table class="history-table">
                    <thead><tr><th>Fasiliti</th><th>Tarikh</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach($myBookings as $b): 
                            $st = $b['status'];
                            $cls = match($st) { 'Confirmed'=>'p-confirmed', 'Rejected'=>'p-rejected', 'Awaiting Payment'=>'p-await', default=>'p-pending' };
                        ?>
                        <tr>
                            <td><?php echo h($b['facility_name']); ?></td>
                            <td><?php echo h(date('d/m/y', strtotime($b['booking_date']))); ?></td>
                            <td><span class="pill <?php echo $cls; ?>"><?php echo h($st); ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

        <div class="facility-cards">
            <section class="card" style="background:transparent; border:none; box-shadow:none; padding:0;">
                <h3 style="margin:0 0 15px; color:var(--dark);">Pilihan Fasiliti</h3>
                
                <div class="facility-list">
                    <?php if (empty($facilities)): ?>
                        <div style="padding:20px; text-align:center; background:white; border-radius:12px;">Tiada fasiliti tersedia.</div>
                    <?php else: foreach ($facilities as $f): 
                        $statusClass = ($f['status'] === 'Available') ? 'st-avail' : 'st-maint';
                        $img = $f['image_path'] ?: 'https://placehold.co/400x300?text=No+Image';
                    ?>
                        <div class="f-card" onclick="selectFacility(<?php echo $f['facility_id']; ?>, this)">
                            <img src="<?php echo h($img); ?>" alt="<?php echo h($f['name']); ?>" class="f-img">
                            <div class="f-content">
                                <div class="f-name"><?php echo h($f['name']); ?></div>
                                <div class="f-desc"><?php echo h(substr($f['description'] ?? '', 0, 80)) . '...'; ?></div>
                                <div class="f-meta">
                                    <div class="f-price">
                                        RM <?php echo h(number_format((float)$f['rate_per_hour'], 2)); ?> 
                                        <span style="font-size:11px; font-weight:400; color:var(--muted);">/ <?php echo ($f['price_unit']=='Day')?'Hari':'Jam'; ?></span>
                                    </div>
                                    <span class="f-badge <?php echo $statusClass; ?>"><?php echo h($f['status']); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </section>
        </div>

    </div>
</div>

<?php include "footer.php"; ?>

<script>
    function selectFacility(id, cardEl) {
        // Highlight logic
        document.querySelectorAll('.f-card').forEach(c => c.classList.remove('selected'));
        if(cardEl) cardEl.classList.add('selected');

        // Update select box
        const select = document.getElementById('facility_id');
        select.value = id;
        
        // Trigger update
        updateFormLogic();

        // Smooth scroll to form (mobile UX)
        if(window.innerWidth < 900) {
            document.getElementById('formSection').scrollIntoView({ behavior: 'smooth' });
        }
    }

    function updateFormLogic() {
        const select = document.getElementById('facility_id');
        const opt = select.options[select.selectedIndex];
        
        const unitHint = document.getElementById('pricingHint');
        const timeGroup = document.getElementById('timeGroup');
        const durationLabel = document.getElementById('durationLabel');
        const unitLabel = document.getElementById('unitLabel');
        const costPreview = document.getElementById('totalCostPreview');
        const durationInput = document.querySelector('input[name="duration"]');

        if (!opt.value) {
            unitHint.innerText = "Sila klik fasiliti di sebelah kanan.";
            costPreview.innerText = "";
            return;
        }

        const unit = opt.getAttribute('data-unit');
        const price = parseFloat(opt.getAttribute('data-price'));
        const status = opt.getAttribute('data-status');

        unitHint.innerHTML = `<span style="color:${status==='Available'?'green':'red'}"><i class="fas fa-info-circle"></i> Status: ${status}</span>`;

        if (unit === 'Day') {
            timeGroup.style.display = 'none';
            durationLabel.innerText = "Bilangan Hari";
            unitLabel.innerText = "Hari";
        } else {
            timeGroup.style.display = 'block';
            durationLabel.innerText = "Tempoh Sewaan (Jam)";
            unitLabel.innerText = "Jam";
        }

        // Live Cost Calculation
        calculateTotal(price);
        durationInput.oninput = () => calculateTotal(price);
    }

    function calculateTotal(price) {
        const duration = document.querySelector('input[name="duration"]').value;
        const preview = document.getElementById('totalCostPreview');
        if(duration > 0) {
            const total = (price * duration).toFixed(2);
            preview.innerText = `Anggaran Harga: RM ${total}`;
        } else {
            preview.innerText = "";
        }
    }

    // Init
    updateFormLogic();
</script>

</body>
</html>