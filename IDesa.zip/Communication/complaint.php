<?php
session_start();
include "db_connect.php";

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';

// Rule: Only AJK/Admin can access this page
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: resident_report_list.php");
    exit();
}

$full_name = $_SESSION['full_name'] ?? 'Pengguna';

// HTML escape helper
if (!function_exists('h')) {
  function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

// Stats Functions
function countComplaintsGlobal($conn, $type) {
    if (!$conn) return 0;
    if ($type === 'new') {
        $sql = "SELECT COUNT(*) AS total FROM complaints WHERE (status = 'New' OR status = '' OR status IS NULL)";
    } elseif ($type === 'progress') {
        $sql = "SELECT COUNT(*) AS total FROM complaints WHERE status IN ('Reviewed','In Progress')";
    } elseif ($type === 'resolved') {
        $sql = "SELECT COUNT(*) AS total FROM complaints WHERE status = 'Resolved'";
    } else {
        $sql = "SELECT COUNT(*) AS total FROM complaints";
    }
    $res = mysqli_query($conn, $sql);
    $row = $res ? mysqli_fetch_assoc($res) : null;
    return (int)($row['total'] ?? 0);
}

$a_total    = countComplaintsGlobal($conn, 'all');
$a_new      = countComplaintsGlobal($conn, 'new');
$a_progress = countComplaintsGlobal($conn, 'progress');
$a_resolved = countComplaintsGlobal($conn, 'resolved');

// Fetch Recent Complaints
$recent = [];
if ($conn) {
    $sql = "SELECT c.id, c.title, c.status, c.created_at,
            COALESCE(u.full_name, c.complaint_name) AS complainant
            FROM complaints c
            LEFT JOIN users u ON u.user_id = c.user_id
            ORDER BY c.created_at DESC
            LIMIT 10";
    $res = mysqli_query($conn, $sql);
    while ($res && ($row = mysqli_fetch_assoc($res))) { $recent[] = $row; }
}

// Status Mappings
$statusBM = [ 'New' => 'Baru', 'Reviewed' => 'Disemak', 'In Progress' => 'Dalam Tindakan', 'Resolved' => 'Selesai' ];
$statusBadge = [ 'New' => 'badge-new', 'Reviewed' => 'badge-review', 'In Progress' => 'badge-progress', 'Resolved' => 'badge-done' ];
?>

<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Urus Aduan | i-Desa</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Base Setup */
        * { box-sizing: border-box; }
        :root { --primary:#2d6a4f; --dark:#143d29; --bg:#f4f7f6; --card:#fff; --text:#333; --muted:#6b7280; }
        body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); display:flex; }

        /* --- SIDEBAR --- */
        .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; }
        
        .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
        .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
        .logo-text { display: flex; flex-direction: column; line-height: 1; }
        .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
        .logo-main span { color: #4ade80; }
        .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

        .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
        .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
        .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
        .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
        .nav-item i { width: 18px; text-align: center; font-size: 16px; }
        .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

        /* --- CONTENT --- */
        .content { margin-left: 250px; padding: 30px; width: calc(100% - 250px); }
        
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        .page-title h1 { margin: 0; font-size: 24px; color: var(--dark); font-weight: 700; }
        .page-title p { margin: 5px 0 0; color: var(--muted); font-size: 14px; }

        /* Stats Grid */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: var(--card); padding: 20px; border-radius: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); display: flex; align-items: center; gap: 15px; transition: transform 0.2s; border: 1px solid #eee; }
        .stat-card:hover { transform: translateY(-3px); }
        
        .stat-icon { width: 50px; height: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 20px; }
        .icon-blue { background: #e0f2fe; color: #0284c7; }
        .icon-orange { background: #ffedd5; color: #c2410c; }
        .icon-purple { background: #f3e8ff; color: #7e22ce; }
        .icon-green { background: #dcfce7; color: #15803d; }

        .stat-info div { font-size: 13px; color: var(--muted); font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-info h3 { margin: 5px 0 0; font-size: 28px; color: var(--text); line-height: 1; }

        /* Table Section */
        .table-container { background: var(--card); border-radius: 16px; padding: 25px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); border: 1px solid #eaeaea; }
        .table-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #f0f0f0; padding-bottom: 15px; }
        .table-header h2 { margin: 0; font-size: 18px; color: var(--dark); font-weight: 600; }
        
        .btn-link { color: var(--primary); text-decoration: none; font-weight: 600; font-size: 14px; display: flex; align-items: center; gap: 5px; }
        .btn-link:hover { text-decoration: underline; }

        table { width: 100%; border-collapse: collapse; min-width: 600px; }
        th { text-align: left; padding: 12px 15px; color: var(--muted); font-size: 12px; text-transform: uppercase; font-weight: 600; background: #f9fafb; border-bottom: 1px solid #eee; }
        td { padding: 15px; border-bottom: 1px solid #f0f0f0; font-size: 14px; color: #444; vertical-align: middle; }
        tr:hover td { background: #fcfcfc; }

        /* Badges */
        .badge { padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; display: inline-block; }
        .badge-new { background: #fee2e2; color: #b91c1c; }
        .badge-review { background: #ffedd5; color: #c2410c; }
        .badge-progress { background: #e0f2fe; color: #0369a1; }
        .badge-done { background: #dcfce7; color: #15803d; }

        .btn-action { padding: 6px 14px; background: #fff; border: 1px solid #ddd; border-radius: 8px; color: #555; text-decoration: none; font-size: 12px; font-weight: 600; transition: 0.2s; }
        .btn-action:hover { border-color: var(--primary); color: var(--primary); background: #f0fdf4; }

        @media(max-width: 900px) {
            .sidebar { display: none; }
            .content { margin: 0; width: 100%; padding: 20px; }
        }
    </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

    <div class="content">
        
        <div class="page-header">
            <div class="page-title">
                <h1>Pusat Aduan</h1>
                <p>Urus dan semak aduan penduduk daripada satu papan pemuka.</p>
            </div>
            <div>
                <a href="resident_report_list.php" class="btn-action" style="padding: 10px 20px; font-size: 14px;">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon icon-blue"><i class="fas fa-folder-open"></i></div>
                <div class="stat-info">
                    <div>Jumlah Aduan</div>
                    <h3><?php echo $a_total; ?></h3>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-orange"><i class="fas fa-exclamation-circle"></i></div>
                <div class="stat-info">
                    <div>Aduan Baru</div>
                    <h3><?php echo $a_new; ?></h3>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-purple"><i class="fas fa-spinner"></i></div>
                <div class="stat-info">
                    <div>Dalam Proses</div>
                    <h3><?php echo $a_progress; ?></h3>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
                <div class="stat-info">
                    <div>Selesai</div>
                    <h3><?php echo $a_resolved; ?></h3>
                </div>
            </div>
        </div>

        <div class="table-container">
            <div class="table-header">
                <h2>Aduan Terkini</h2>
                <a href="ajk_admin_view_complaint.php" class="btn-link">Lihat Semua <i class="fas fa-arrow-right"></i></a>
            </div>

            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th width="10%">ID</th>
                            <th width="25%">Pengadu</th>
                            <th width="30%">Tajuk Aduan</th>
                            <th width="15%">Tarikh</th>
                            <th width="10%">Status</th>
                            <th width="10%">Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($recent)): ?>
                            <tr><td colspan="6" style="text-align:center; padding:30px; color:#888;">Tiada aduan direkodkan.</td></tr>
                        <?php else: ?>
                            <?php foreach ($recent as $r): 
                                $st = $r['status'] ?? 'New';
                                $badgeClass = $statusBadge[$st] ?? 'badge-new';
                                $statusLabel = $statusBM[$st] ?? $st;
                            ?>
                            <tr>
                                <td><strong>#AD-<?php echo (int)$r['id']; ?></strong></td>
                                <td><?php echo h($r['complainant'] ?? 'Tidak Diketahui'); ?></td>
                                <td><?php echo h($r['title'] ?? '-'); ?></td>
                                <td><?php echo date('d M Y', strtotime($r['created_at'])); ?></td>
                                <td><span class="badge <?php echo $badgeClass; ?>"><?php echo $statusLabel; ?></span></td>
                                <td>
                                    <a href="ajk_admin_view_complaint.php?id=<?php echo (int)$r['id']; ?>" class="btn-action">
                                        Semak
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</body>
</html>