<?php 
session_start(); 
include "db_connect.php"; 

if(!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$uid = $_SESSION['user_id'];
$message = "";

if (isset($_POST['change_pw'])) {
    $current_pw = $_POST['current_pw'];
    $new_pw = $_POST['new_pw'];
    $confirm_pw = $_POST['confirm_pw'];

    // 1. Fetch user's current hashed password from DB
    $res = mysqli_query($conn, "SELECT password FROM users WHERE user_id='$uid'");
    $user = mysqli_fetch_assoc($res);

    // 2. Validation Checks
    if (!password_verify($current_pw, $user['password'])) {
        $message = "<div class='alert error'><i class='fas fa-times-circle'></i> Kata laluan semasa tidak betul!</div>";
    } elseif ($new_pw !== $confirm_pw) {
        $message = "<div class='alert error'><i class='fas fa-times-circle'></i> Kata laluan baharu tidak sepadan!</div>";
    } elseif (strlen($new_pw) < 6) {
        $message = "<div class='alert error'><i class='fas fa-exclamation-triangle'></i> Kata laluan mestilah sekurang-kurangnya 6 aksara.</div>";
    } else {
        // 3. Hash the new password and Update
        $hashed_pw = password_hash($new_pw, PASSWORD_DEFAULT);
        $update = mysqli_query($conn, "UPDATE users SET password='$hashed_pw' WHERE user_id='$uid'");
        
        if ($update) {
            // Activity logging has been removed from here to keep your timeline clean for feedback/complaints!
            
            $message = "<div class='alert success'><i class='fas fa-check-circle'></i> Kata laluan berjaya dikemas kini!</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>i-Desa | Tukar Kata Laluan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --p-green: #2d6a4f; --dark: #1b4332; }
        body { margin: 0; font-family: 'Poppins', sans-serif; background: #f4f7f4; display: flex; justify-content: center; align-items: center; height: 100vh; }
        
        .container { display: flex; width: 850px; height: 550px; background: white; border-radius: 30px; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.1); }
        
        .side-panel { flex: 1; background: linear-gradient(rgba(109, 76, 65, 0.8), rgba(62, 39, 35, 0.8)), url('village.png'); background-size: cover; background-position: center; padding: 40px; color: white; display: flex; flex-direction: column; justify-content: center; }
        
        .form-panel { flex: 1.2; padding: 50px; }
        .form-panel h2 { color: var(--dark); margin-bottom: 30px; }

        .form-group { margin-bottom: 20px; position: relative; }
        .form-group i { position: absolute; left: 15px; top: 40px; color: var(--p-green); }

        label { display: block; font-size: 0.85rem; font-weight: 600; color: #666; margin-bottom: 8px; }
        input { width: 100%; padding: 12px 15px 12px 45px; border: 2px solid #eee; border-radius: 12px; box-sizing: border-box; font-family: inherit; transition: 0.3s; }
        input:focus { border-color: var(--p-green); outline: none; }

        .btn-update { width: 100%; padding: 15px; background: var(--p-green); color: white; border: none; border-radius: 12px; font-weight: bold; cursor: pointer; font-size: 1rem; transition: 0.3s; margin-top: 10px; }
        .btn-update:hover { background: var(--dark); transform: translateY(-2px); }

        .back-link { display: block; text-align: center; margin-top: 20px; color: #888; text-decoration: none; font-size: 0.9rem; }

        .alert { padding: 15px; border-radius: 12px; margin-bottom: 20px; font-size: 0.85rem; display: flex; align-items: center; gap: 10px; }
        .success { background: #e7f5ee; color: #2d6a4f; border: 1px solid #c2e7d6; }
        .error { background: #fff0f0; color: #d63031; border: 1px solid #ffdbdb; }
    </style>
</head>
<body>

<div class="container">
    <div class="side-panel">
        <h1>Keselamatan</h1>
        <p>Kata laluan yang kukuh membantu memastikan akaun i-Desa dan maklumat peribadi anda selamat daripada akses yang tidak dibenarkan.</p>
    </div>

    <div class="form-panel">
        <h2>Tukar Kata Laluan</h2>
        <?php echo $message; ?>

        <form method="POST">
            <div class="form-group">
                <label>Kata Laluan Semasa</label>
                <i class="fas fa-lock"></i>
                <input type="password" name="current_pw" required placeholder="••••••••">
            </div>

            <div class="form-group">
                <label>Kata Laluan Baru</label>
                <i class="fas fa-key"></i>
                <input type="password" name="new_pw" required placeholder="Min 6 aksara">
            </div>

            <div class="form-group">
                <label>Sahkan Kata Laluan Baharu</label>
                <i class="fas fa-shield-alt"></i>
                <input type="password" name="confirm_pw" required placeholder="Taip semula kata laluan baharu">
            </div>

            <button type="submit" name="change_pw" class="btn-update">Kemas kini Kata Laluan</button>
            <a href="profile_management.php" class="back-link">Kembali ke Papan Pemuka</a>
        </form>
    </div>
</div>

</body>
</html>