<?php
// navbar.php
// Improvement: Bigger fonts, wider gaps, office icon, user greeting

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- Helpers ---
if (!function_exists('h')) {
    function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

if (!function_exists('nav_item_is_active')) {
    function nav_item_is_active($currentPage, $activeList) {
        if (!is_array($activeList) || empty($activeList)) return false;
        return in_array($currentPage, $activeList, true);
    }
}

if (!function_exists('nav_can_show')) {
    function nav_can_show($item, $isLoggedIn, $role) {
        if (isset($item['role']) && is_array($item['role']) && !in_array($role, $item['role'], true)) return false;
        return true;
    }
}

if (!function_exists('render_top_nav')) {
    function render_top_nav($items, $currentPage, $isLoggedIn, $role) {
        foreach ($items as $it) {
            $type = $it['type'] ?? 'link';
            if ($type === 'link') {
                $isActive = nav_item_is_active($currentPage, $it['active'] ?? [$it['href']]);
                echo '<a class="idesa-link '.($isActive?'active':'').'" href="'.h($it['href']).'">'.h($it['label']).'</a>';
            } elseif ($type === 'dropdown') {
                $isActive = nav_item_is_active($currentPage, $it['active'] ?? []);
                echo '<div class="idesa-dd"><a href="#" class="idesa-link '.($isActive?'active':'').'" onclick="return false;">'.h($it['label']).' <i class="fa-solid fa-chevron-down" style="font-size:12px; margin-left:4px; opacity:0.6;"></i></a>';
                echo '<div class="idesa-dd-menu">';
                foreach ($it['children'] as $ch) {
                    if (($ch['type']??'')==='divider') { echo '<div class="idesa-dd-divider"></div>'; continue; }
                    if (!nav_can_show($ch, $isLoggedIn, $role)) continue;
                    echo '<a class="idesa-dd-item" href="'.h($ch['href']).'">'.h($ch['label']).'</a>';
                }
                echo '</div></div>';
            }
        }
    }
}

$isLoggedIn = isset($_SESSION['user_id']);
$role = $_SESSION['role'] ?? 'Guest';
$userId = (int)($_SESSION['user_id'] ?? 0);
$userName = $_SESSION['full_name'] ?? 'Pengguna'; // Ensure full_name is set in login

// --- Logic: Is User Admin/AJK? ---
$isAdminOrAJK = ($isLoggedIn && ($role === 'AJK' || $role === 'Admin'));

$currentPage = basename($_SERVER['PHP_SELF']);
if (isset($NAV_ACTIVE) && is_string($NAV_ACTIVE) && $NAV_ACTIVE !== '') {
    $currentPage = $NAV_ACTIVE;
}

// Notification Logic
$unreadNotif = 0;
if ($isLoggedIn) {
    if (!isset($conn) || !($conn instanceof mysqli)) {
        $dbPath = __DIR__ . "/db_connect.php";
        if (file_exists($dbPath)) include_once $dbPath;
    }
    if (isset($conn) && ($conn instanceof mysqli)) {
        $stmt = mysqli_prepare($conn, "SELECT full_name FROM users WHERE user_id=?");
        if($stmt){
             mysqli_stmt_bind_param($stmt, "i", $userId);
             mysqli_stmt_execute($stmt);
             $res = mysqli_stmt_get_result($stmt);
             if($res && $row = mysqli_fetch_assoc($res)) $userName = $row['full_name']; // Fetch latest name
             mysqli_stmt_close($stmt);
        }

        $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS c FROM notifications WHERE user_id=? AND is_read=0");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $userId);
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            if ($res && ($row = mysqli_fetch_assoc($res))) $unreadNotif = (int)$row['c'];
            mysqli_stmt_close($stmt);
        }
    }
}
$notifBadgeText = ($unreadNotif > 99) ? "99+" : (string)$unreadNotif;

// --- Menu Data ---
$aduanChildren = [];
if ($role === 'Resident') {
    $aduanChildren = [
        ['type'=>'link','label'=>'Buat Aduan','href'=>'resident_add_report.php','active'=>['resident_add_report.php']],
        ['type'=>'link','label'=>'Rekod Aduan Saya','href'=>'resident_report_list.php','active'=>['resident_report_list.php','resident_detail_report.php']],
    ];
} elseif ($isAdminOrAJK) {
    $aduanChildren = [
        ['type'=>'link','label'=>'Pusat Aduan (Admin)','href'=>'complaint.php','active'=>['complaint.php']],
        ['type'=>'link','label'=>'Semak Aduan','href'=>'ajk_admin_view_complaint.php','active'=>['ajk_admin_view_complaint.php','admin_view_complaint.php']],
        ['type'=>'divider'],
        ['type'=>'link','label'=>'Rekod Aduan Saya','href'=>'resident_report_list.php','active'=>['resident_report_list.php']],
    ];
} else {
    $aduanChildren = [['type'=>'link','label'=>'Log Masuk Diperlukan','href'=>'login_page.php']];
}

$NAV_ITEMS = [
    ['type'=>'link', 'label'=>'Utama', 'href'=>'homepage.php', 'active'=>['homepage.php']],
    [
        'type'=>'dropdown', 'label'=>'Komuniti', 'href'=>'bulletin.php', 'active'=>['bulletin.php'],
        'children'=>[ ['type'=>'link','label'=>'Buletin & Berita','href'=>'bulletin.php'] ]
    ],
    [
        'type'=>'dropdown', 'label'=>'Kalendar', 'href'=>'calendar.php', 'active'=>['calendar.php','ajk_admin_calendar.php'],
        'children'=>[
            ['type'=>'link','label'=>'Kalendar Kampung','href'=>'calendar.php'],
            ['type'=>'link','label'=>'Urus Kalendar','href'=>'ajk_admin_calendar.php', 'role'=>['AJK','Admin']],
        ]
    ],
    [
        'type'=>'dropdown', 'label'=>'Aduan', 'href'=> ($isAdminOrAJK) ? 'complaint.php' : 'resident_report_list.php',
        'active'=>['complaint.php','resident_add_report.php','resident_report_list.php'],
        'children'=>$aduanChildren
    ],
    [
        'type'=>'dropdown', 'label'=>'Fasiliti', 'href'=>'#',
        'active'=>['emergency_contacts.php','lostfound_board.php','facility_rental.php'],
        'children'=>[
            ['type'=>'link','label'=>'Kecemasan','href'=>'emergency_contacts.php'],
            ['type'=>'link','label'=>'Hilang & Dijumpai','href'=>'lostfound_board.php'],
            ['type'=>'link','label'=>'Sewa Kemudahan','href'=>'facility_rental.php'],
        ]
    ],
];

// Theme Config
$NAV_THEME = [
    'primary' => '#166534',
    'gradient_start' => '#166534',
    'gradient_end'   => '#15803d',
    'accent'  => '#dcfce7',
    'text'    => '#374151',
    'bg'      => '#f9fafb', // Soft Off-White
];

if (!defined('IDESA_NAVBAR_CSS')) {
    define('IDESA_NAVBAR_CSS', true);
    ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --nav-primary: <?php echo h($NAV_THEME['primary']); ?>;
            --nav-grad-1: <?php echo h($NAV_THEME['gradient_start']); ?>;
            --nav-grad-2: <?php echo h($NAV_THEME['gradient_end']); ?>;
            --nav-accent: <?php echo h($NAV_THEME['accent']); ?>;
            --nav-text: <?php echo h($NAV_THEME['text']); ?>;
            --nav-bg: <?php echo h($NAV_THEME['bg']); ?>;
            --nav-font: 'Inter', system-ui, -apple-system, sans-serif;
        }

        .idesa-nav {
            position: sticky; top: 0; z-index: 1000;
            background: rgba(249, 250, 251, 0.98); /* Soft Off-White */
            backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px);
            border-bottom: 1px solid rgba(0,0,0,0.08);
            box-shadow: 0 4px 20px rgba(0,0,0,0.03);
            font-family: var(--nav-font);
            width: 100%;
        }

        .idesa-nav .inner-container {
            width: 100%;
            padding: 0 4%; /* More padding */
            height: 95px; /* Taller Navbar */
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-sizing: border-box;
        }

        /* Logo Area */
        .idesa-logo {
            text-decoration: none; display: flex; align-items: center; gap: 15px;
            flex-shrink: 0; 
        }
        .logo-mark {
            width: 48px; height: 48px; /* Bigger Logo */
            background: linear-gradient(135deg, var(--nav-grad-1), var(--nav-grad-2));
            color: white; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 24px;
            box-shadow: 0 4px 10px rgba(22, 101, 52, 0.25);
        }
        .logo-text { display: flex; flex-direction: column; line-height: 1; }
        .logo-main { font-size: 24px; font-weight: 800; color: #111827; letter-spacing: -0.5px; }
        .logo-main span { color: var(--nav-primary); }
        .logo-sub { font-size: 12px; font-weight: 600; color: #6b7280; text-transform: uppercase; margin-top: 4px; }

        /* Links Area - Bigger Font & Gaps */
        .idesa-links {
            display: flex; align-items: center; gap: 10px; /* Wider Gap */
            justify-content: center;
            flex: 1;
            margin: 0 30px;
        }

        .idesa-link {
            text-decoration: none; color: var(--nav-text);
            font-size: 16px; /* Bigger Font */
            font-weight: 600; /* Bolder */
            padding: 12px 18px; border-radius: 12px;
            transition: all 0.2s ease; display: inline-flex; align-items: center; gap: 8px;
            white-space: nowrap; 
        }
        .idesa-link:hover { color: var(--nav-primary); background: #e5e7eb; }
        .idesa-link.active { color: var(--nav-primary); font-weight: 800; background: var(--nav-accent); }

        /* Dropdowns */
        .idesa-dd { position: relative; }
        .idesa-dd-menu {
            position: absolute; top: 100%; left: 50%;
            transform: translateX(-50%) translateY(15px);
            min-width: 240px; background: white;
            border: 1px solid rgba(0,0,0,0.06); border-radius: 16px; padding: 8px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.15);
            opacity: 0; visibility: hidden; transition: all 0.2s; pointer-events: none;
        }
        .idesa-dd:hover .idesa-dd-menu, .idesa-dd:focus-within .idesa-dd-menu {
            opacity: 1; visibility: visible; transform: translateX(-50%) translateY(20px); pointer-events: auto;
        }
        .idesa-dd-item {
            display: block; padding: 12px 16px; border-radius: 10px;
            color: #4b5563; text-decoration: none; font-size: 15px; font-weight: 500;
        }
        .idesa-dd-item:hover { background: #f3f4f6; color: var(--nav-primary); }
        .idesa-dd-divider { height: 1px; background: #e2e8f0; margin: 8px; }

        /* Actions Area */
        .idesa-actions {
            display: flex; align-items: center; gap: 15px;
            flex-shrink: 0; 
        }

        /* Greeting Text */
        .user-greet {
            text-align: right; margin-right: 10px; line-height: 1.2;
            display: flex; flex-direction: column;
        }
        .greet-name { font-size: 14px; font-weight: 700; color: #1f2937; }
        .greet-role { font-size: 11px; font-weight: 600; color: var(--nav-primary); text-transform: uppercase; }

        .btn-icon-only {
            color: #64748b; width: 46px; height: 46px; border-radius: 14px;
            display: inline-flex; justify-content: center; align-items: center;
            text-decoration: none; border: 1px solid transparent; transition: 0.2s; position: relative;
        }
        .btn-icon-only:hover { background: #e5e7eb; color: var(--nav-primary); }

        /* Admin Button - OFFICE ICON */
        .btn-admin-office {
            color: #374151; width: 50px; height: 50px; border-radius: 14px;
            display: inline-flex; justify-content: center; align-items: center;
            text-decoration: none; transition: 0.2s;
            background: #f3f4f6; border: 1px solid #e5e7eb;
            font-size: 22px; /* Bigger Icon */
        }
        .btn-admin-office:hover {
            background: #e5e7eb; color: var(--nav-primary); transform: scale(1.05); box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        /* Dashboard Button */
        .btn-dashboard {
            background: linear-gradient(135deg, var(--nav-grad-1), var(--nav-grad-2));
            color: white !important; padding: 12px 24px; border-radius: 14px;
            font-size: 15px; font-weight: 700; text-decoration: none;
            box-shadow: 0 4px 14px rgba(22, 101, 52, 0.25);
            transition: transform 0.2s, box-shadow 0.2s;
            display: inline-flex; align-items: center; gap: 10px; white-space: nowrap;
        }
        .btn-dashboard:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(22, 101, 52, 0.35); }

        .notif-badge {
            position: absolute; top: 8px; right: 8px;
            background: #ef4444; color: white; font-size: 11px; font-weight: 800;
            min-width: 18px; height: 18px; border-radius: 9px;
            display: flex; align-items: center; justify-content: center; border: 2px solid white;
        }

        .nav-toggle { display: none; background: transparent; border: 1px solid #e2e8f0; border-radius: 10px; width: 44px; height: 44px; font-size: 20px; color: #374151; cursor: pointer; flex-shrink: 0; }
        .idesa-mobile { max-height: 0; overflow: hidden; background: white; transition: max-height 0.4s ease; border-bottom: 1px solid #f1f5f9; }
        .idesa-mobile.open { max-height: 800px; box-shadow: 0 20px 40px rgba(0,0,0,0.05); }

        @media (max-width: 1200px) {
            .idesa-links { display: none; } 
            .nav-toggle { display: inline-flex; align-items: center; justify-content: center; }
            .idesa-nav .inner-container { height: 80px; padding: 0 5%; }
            .user-greet { display: none; } /* Hide greeting on smaller screens */
            .btn-dashboard span { display: none; } 
            .btn-dashboard { padding: 0; width: 44px; height: 44px; justify-content: center; }
            .btn-dashboard i { margin: 0; }
        }
        
        @media (max-width: 480px) {
            .logo-text { display: none; }
        }
    </style>
    <?php
}
?>

<nav class="idesa-nav">
    <div class="inner-container">
        <a href="homepage.php" class="idesa-logo">
            <div class="logo-mark"><i class="fa-solid fa-house-chimney-window"></i></div>
            <div class="logo-text">
                <div class="logo-main">i-<span>Desa</span></div>
                <div class="logo-sub">Gerbang Komuniti Pintar</div>
            </div>
        </a>

        <div class="idesa-links">
            <?php render_top_nav($NAV_ITEMS, $currentPage, $isLoggedIn, $role); ?>
        </div>

        <div class="idesa-actions">
            <?php if ($isLoggedIn): ?>
                
                <div class="user-greet">
                    <span class="greet-name">Hi, <?php echo h(explode(' ', trim($userName))[0]); ?></span>
                    <span class="greet-role"><?php echo h($role); ?></span>
                </div>

                <?php if ($isAdminOrAJK): ?>
                    <a href="ajk_dashboard.php" class="btn-admin-office" title="Panel Pentadbiran">
                        <i class="fa-solid fa-landmark"></i>
                    </a>
                <?php endif; ?>

                <a href="my_notifications_calendar.php" class="btn-icon-only" aria-label="Notifikasi">
                    <i class="fa-regular fa-bell" style="font-size: 22px;"></i>
                    <?php if ($unreadNotif > 0): ?><span class="notif-badge"><?php echo h($notifBadgeText); ?></span><?php endif; ?>
                </a>

                <a class="btn-dashboard" href="profile_management.php">
                    <i class="fa-solid fa-user-circle" style="font-size: 18px;"></i>
                    <span>Profil</span>
                </a>

                <a class="btn-icon-only" href="logout.php" title="Log Keluar" style="color:#ef4444;">
                    <i class="fa-solid fa-power-off" style="font-size: 20px;"></i>
                </a>

            <?php else: ?>
                <a class="btn-dashboard" href="login_page.php">
                    <span>Log Masuk</span> <i class="fa-solid fa-arrow-right"></i>
                </a>
            <?php endif; ?>

            <button class="nav-toggle" onclick="toggleMobileNav()"><i class="fa-solid fa-bars"></i></button>
        </div>
    </div>

    <div class="idesa-mobile" id="mobileDrawer">
        <div style="padding: 25px; display:flex; flex-direction:column; gap:12px;">
            <?php if ($isLoggedIn): ?>
                <div style="padding-bottom:15px; border-bottom:1px solid #eee; margin-bottom:10px;">
                    <div style="font-weight:800; font-size:18px; color:#1f2937;">Hi, <?php echo h($userName); ?></div>
                    <div style="font-size:13px; color:var(--nav-primary); font-weight:600; text-transform:uppercase;"><?php echo h($role); ?></div>
                </div>
            <?php endif; ?>

            <?php if($isAdminOrAJK): ?>
                <a href="ajk_dashboard.php" style="background:#f0fdf4; color:#166534; padding:14px; border-radius:12px; font-weight:700; text-decoration:none; border:1px solid #bbf7d0; display:flex; align-items:center; gap:12px; font-size:16px;">
                    <i class="fa-solid fa-landmark"></i> Panel Pentadbiran
                </a>
            <?php endif; ?>
            
            <?php foreach ($NAV_ITEMS as $it): 
                $type = $it['type'] ?? 'link';
                if ($type === 'link'): ?>
                    <a href="<?php echo h($it['href']); ?>" style="padding:14px; font-weight:600; color:#333; text-decoration:none; display:block; border:1px solid #eee; border-radius:12px; font-size:16px;">
                        <?php echo h($it['label']); ?>
                    </a>
                <?php elseif ($type === 'dropdown'): ?>
                    <details style="border:1px solid #eee; border-radius:12px;">
                        <summary style="padding:14px; font-weight:700; cursor:pointer; list-style:none; display:flex; justify-content:space-between; font-size:16px;">
                            <?php echo h($it['label']); ?> <i class="fa-solid fa-chevron-down"></i>
                        </summary>
                        <div style="padding: 5px 15px 15px; display:flex; flex-direction:column; gap:10px;">
                            <?php foreach ($it['children'] as $ch): 
                                if (($ch['type']??'')==='divider' || !nav_can_show($ch, $isLoggedIn, $role)) continue; ?>
                                <a href="<?php echo h($ch['href']); ?>" style="text-decoration:none; color:#555; padding:10px; font-size:15px; font-weight:500;"><?php echo h($ch['label']); ?></a>
                            <?php endforeach; ?>
                        </div>
                    </details>
                <?php endif; 
            endforeach; ?>
        </div>
    </div>
</nav>

<script>
function toggleMobileNav() {
    document.getElementById('mobileDrawer').classList.toggle('open');
}
document.addEventListener('click', function(e) {
    if (!e.target.closest('.idesa-nav')) {
        document.getElementById('mobileDrawer').classList.remove('open');
    }
});
</script>