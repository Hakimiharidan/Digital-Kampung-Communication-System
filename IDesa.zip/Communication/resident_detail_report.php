<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!in_array($role, ['Resident','AJK','Admin'], true)) {
    header("Location: homepage.php");
    exit();
}
$user_id = (int)$_SESSION['user_id'];
$id = (int)($_GET['id'] ?? 0);

if (!function_exists('h')) {
  function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

$statusBM = [
    'New' => 'Baru',
    'Reviewed' => 'Disemak',
    'In Progress' => 'Dalam Tindakan',
    'Resolved' => 'Selesai',
];
$statusBadge = [
    'New' => 'b-new',
    'Reviewed' => 'b-reviewed',
    'In Progress' => 'b-progress',
    'Resolved' => 'b-resolved',
];

function imageUrl($img) {
    if (!$img) return null;
    $img = trim($img);
    if ($img === "") return null;
    // Prefer stored relative path (e.g. complaints/xxx.jpg)
    $path = "uploads/" . $img;
    if (file_exists(__DIR__ . "/" . $path)) return $path;

    // Backward compatibility: file name stored without folder
    $path2 = "uploads/" . basename($img);
    if (file_exists(__DIR__ . "/" . $path2)) return $path2;

    return "uploads/" . $img;
}

$stmt = mysqli_prepare($conn, "SELECT id, complaint_name, complaint_phone, title, description, image, status, reply, created_at, updated_at FROM complaints WHERE id = ? AND user_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, "ii", $id, $user_id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

if (!$data) {
    header("Location: resident_report_list.php");
    exit();
}

$st = $data['status'] ?? 'New';
$bm = $statusBM[$st] ?? $st;
$badge = $statusBadge[$st] ?? 'b-new';
$imgUrl = imageUrl($data['image'] ?? null);
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Butiran Aduan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root { --primary-green:#2d6a4f; --accent-brown:#6d4c41; --text-dark:#333; --bg:#f7faf7; --card:#fff; --muted:#6b7280; }
        *{ box-sizing:border-box; }
        body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text-dark); }
        nav { display:flex; justify-content:space-between; align-items:center; padding:16px 8%; background:var(--card); box-shadow:0 4px 10px rgba(0,0,0,0.05); position:sticky; top:0; z-index:1000; }
        .logo { font-size:28px; font-weight:800; color:var(--primary-green); text-decoration:none; }
        .logo span { color:var(--accent-brown); }
        .nav-links { display:flex; gap:18px; align-items:center; flex-wrap:wrap; }
        .nav-links a { text-decoration:none; color:#555; font-weight:600; transition:.2s; }
        .nav-links a:hover { color:var(--primary-green); }
        .btn-pill { background:var(--primary-green); color:#fff !important; padding:10px 18px; border-radius:999px; font-size:14px; display:inline-flex; align-items:center; gap:8px; }
        .btn-outline { border:1px solid var(--primary-green); color:var(--primary-green) !important; padding:10px 18px; border-radius:999px; font-size:14px; background:#fff; display:inline-flex; align-items:center; gap:8px; }
        .wrap { padding:26px 8% 60px; }
        .head { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; margin-bottom:18px; }
        .title { margin:0; font-size:28px; color:var(--primary-green); }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; }
        .card { background:var(--card); border-radius:16px; padding:18px; box-shadow:0 8px 20px rgba(0,0,0,0.06); border:1px solid rgba(0,0,0,0.04); }
        .grid { display:grid; gap:14px; }
        .grid-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .grid-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        @media (max-width: 980px){ .grid-3{ grid-template-columns:1fr; } .grid-2{ grid-template-columns:1fr; } nav{padding:14px 5%;} .wrap{padding:20px 5% 50px;} }
        .stat { display:flex; justify-content:space-between; align-items:flex-end; gap:12px; padding:18px; border-radius:16px; background:linear-gradient(180deg, rgba(45,106,79,0.08), rgba(45,106,79,0.02)); border:1px solid rgba(45,106,79,0.12); }
        .stat .k { font-size:12px; letter-spacing:.08em; text-transform:uppercase; color:var(--muted); font-weight:800; }
        .stat .v { font-size:40px; font-weight:900; line-height:1; color:#1f2937; margin-top:6px; }
        .stat .ico { font-size:22px; color:var(--primary-green); opacity:.9; }
        .table { width:100%; border-collapse:collapse; }
        .table th, .table td { padding:12px 12px; border-bottom:1px solid rgba(0,0,0,0.06); text-align:left; font-size:14px; }
        .table th { font-size:12px; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); }
        .row-actions a{ font-weight:800; color:var(--primary-green); text-decoration:none; }
        .row-actions a:hover{ text-decoration:underline; }
        .badge { display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:999px; font-weight:800; font-size:12px; }
        .b-new{ background:#f1f5f9; color:#334155; }
        .b-reviewed{ background:#fff7ed; color:#9a3412; }
        .b-progress{ background:#eff6ff; color:#1d4ed8; }
        .b-resolved{ background:#dcfce7; color:#166534; }
        .alert { padding:12px 14px; border-radius:12px; font-weight:700; margin: 0 0 14px 0; border:1px solid; }
        .alert.success { background:#ecfdf5; border-color:#a7f3d0; color:#065f46; }
        .alert.error { background:#fef2f2; border-color:#fecaca; color:#7f1d1d; }
        .field label{ display:block; font-weight:800; margin-bottom:8px; }
        .field input, .field textarea, .field select{ width:100%; padding:12px 12px; border-radius:12px; border:1px solid rgba(0,0,0,0.12); outline:none; font-family:inherit; }
        .field input:focus, .field textarea:focus, .field select:focus { border-color: rgba(45,106,79,0.55); box-shadow:0 0 0 4px rgba(45,106,79,0.12); }
        .muted{ color:var(--muted); font-size:13px; }
        .hr{ height:1px; background:rgba(0,0,0,0.06); margin:16px 0; }
        .img { width:100%; max-width:520px; border-radius:14px; border:1px solid rgba(0,0,0,0.08); display:block; }
        .footer { text-align:center; margin-top:26px; color:var(--muted); font-size:13px; }
    </style>

</head>
<body>

<nav>
    <a href="homepage.php" class="logo">i-<span>Desa</span></a>
    <div class="nav-links">
        <a href="homepage.php">Laman Utama</a><a href="complaint.php" class="btn-outline"><i class="fa-solid fa-bullhorn"></i> Pusat Aduan</a><a href="profile_management.php" class="btn-pill"><i class="fa-solid fa-user"></i> Profil</a><a href="logout.php" title="Log Keluar"><i class="fas fa-sign-out-alt"></i></a>
    </div>
</nav>


<div class="wrap">
    <div class="head">
        <div>
            <h1 class="title">Butiran Aduan</h1>
            <p class="sub">Rujukan: <strong>#AD-<?php echo (int)$data['id']; ?></strong></p>
        </div>
        <div class="actions">
            <a class="btn-outline" href="resident_report_list.php"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
            <a class="btn-pill" href="resident_add_report.php"><i class="fa-solid fa-pen-to-square"></i> Aduan Baru</a>
        </div>
    </div>

    <div class="grid grid-2">
        <div class="card">
            <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;">
                <div>
                    <div class="muted">Status</div>
                    <div style="margin-top:6px;"><span class="badge <?php echo h($badge); ?>"><?php echo h($bm); ?></span></div>
                </div>
                <div style="text-align:right;">
                    <div class="muted">Tarikh Hantar</div>
                    <div style="font-weight:900;"><?php echo date('d/m/Y', strtotime($data['created_at'] ?? 'now')); ?></div>
                </div>
            </div>

            <div class="hr"></div>

            <h2 style="margin:0 0 8px; font-size:18px; color:var(--primary-green);"><?php echo h($data['title'] ?? ''); ?></h2>
            <div class="muted" style="margin-bottom:10px;">Nama: <strong><?php echo h($data['complaint_name'] ?? '-'); ?></strong> • Telefon: <strong><?php echo h($data['complaint_phone'] ?? '-'); ?></strong></div>
            <div style="white-space:pre-wrap; line-height:1.6;"><?php echo h($data['description'] ?? ''); ?></div>

            <?php if ($imgUrl): ?>
                <div class="hr"></div>
                <div class="muted" style="margin-bottom:10px;">Gambar Lampiran</div>
                <img class="img" src="<?php echo h($imgUrl); ?>" alt="Lampiran Aduan">
            <?php endif; ?>
        </div>

        <div class="card">
            <h2 style="margin:0 0 10px; font-size:18px; color:var(--primary-green);">Maklum Balas AJK</h2>
            <?php if (!empty($data['reply'])): ?>
                <div style="white-space:pre-wrap; line-height:1.6;"><?php echo h($data['reply']); ?></div>
                <div class="muted" style="margin-top:12px;">Dikemas kini: <?php echo date('d/m/Y', strtotime($data['updated_at'] ?? 'now')); ?></div>
            <?php else: ?>
                <p class="muted" style="margin:0;">Belum ada maklum balas daripada AJK.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="footer">Sistem Komunikasi Kampung &copy; <?php echo date('Y'); ?></div>
</div>

</body>
</html>
