<?php
session_start();
include "db_connect.php";

// 1. Security: Admin Only
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'AJK') {
        header("Location: ajk_dashboard.php");
    } else {
        header("Location: homepage.php");
    }
    exit();
}

// ✅ FIX: Define $role variable here so it can be used in the Sidebar HTML later
$role = $_SESSION['role'];

$message = "";
$msg_type = "";

// 2. Logic: Register User
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register_user'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $form_role = mysqli_real_escape_string($conn, $_POST['role']); // Renamed to avoid conflict
    $status = mysqli_real_escape_string($conn, $_POST['account_status']);
    
    $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = mysqli_query($conn, "SELECT user_id FROM users WHERE username='$username' OR email='$email'");
    if (mysqli_num_rows($check) > 0) {
        $message = "Gagal: Username atau Emel sudah wujud.";
        $msg_type = "error";
    } else {
        $sql = "INSERT INTO users (full_name, username, email, phone, address, password, role, account_status, created_at) 
                VALUES ('$full_name', '$username', '$email', '$phone', '$address', '$hashed_password', '$form_role', '$status', NOW())";
        if (mysqli_query($conn, $sql)) {
            $message = "Berjaya: Pengguna baru didaftarkan.";
            $msg_type = "success";
        } else {
            $message = "Ralat Database: " . mysqli_error($conn);
            $msg_type = "error";
        }
    }
}

// 3. Logic: Actions (Delete/Suspend/Activate)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $act = $_GET['action'];
    if ($act == 'delete') mysqli_query($conn, "DELETE FROM users WHERE user_id=$id AND role!='Admin'");
    elseif ($act == 'activate') mysqli_query($conn, "UPDATE users SET account_status='Active' WHERE user_id=$id");
    elseif ($act == 'suspend') mysqli_query($conn, "UPDATE users SET account_status='Suspended' WHERE user_id=$id");
    
    header("Location: manage_residents.php");
    exit();
}

// 4. Logic: Filtering & Pagination
$whereClause = "WHERE 1=1";

// Search Filter
$search = $_GET['q'] ?? '';
if($search) {
    $s = mysqli_real_escape_string($conn, $search);
    $whereClause .= " AND (full_name LIKE '%$s%' OR username LIKE '%$s%' OR email LIKE '%$s%')";
}

// Role Filter
$role_filter = $_GET['role'] ?? '';
if($role_filter) {
    $r = mysqli_real_escape_string($conn, $role_filter);
    $whereClause .= " AND role = '$r'";
}

// Status Filter
$status_filter = $_GET['status'] ?? '';
if($status_filter) {
    $st = mysqli_real_escape_string($conn, $status_filter);
    $whereClause .= " AND account_status = '$st'";
}

// Pagination Logic
$limit = 10; // Items per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Count Total
$count_sql = "SELECT COUNT(*) as total FROM users $whereClause";
$total_result = mysqli_fetch_assoc(mysqli_query($conn, $count_sql));
$total_records = $total_result['total'];
$total_pages = ceil($total_records / $limit);

// Fetch Data
$sql = "SELECT * FROM users $whereClause ORDER BY created_at DESC LIMIT $start, $limit";
$users = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Urus Penduduk | i-Desa Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Global Reset & Box Sizing */
    * { box-sizing: border-box; }
    
    :root { --p-green:#2d6a4f; --dark:#143d29; --bg:#f4f7f6; --card:#fff; --border:#eaeaea; --muted:#6b7280; --primary-btn:#40916c; }
    
    body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); display:flex; color:#333; }

    /* Sidebar (Deep Green Theme) */
    .sidebar { width:250px; height:100vh; background:var(--dark); color:white; padding:25px 18px; position:fixed; overflow-y:auto; z-index:100; box-shadow: 4px 0 15px rgba(0,0,0,0.05); display: flex; flex-direction: column; }
    
    .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
    .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
    .logo-text { display: flex; flex-direction: column; line-height: 1; }
    .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .logo-main span { color: #4ade80; }
    .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

    .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
    .nav-item { display:flex; align-items:center; gap:14px; padding:12px 18px; color:#b4cfc0; text-decoration:none; border-radius:12px; font-size:14px; font-weight: 500; transition:.2s; }
    .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
    .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
    .nav-item i { width: 18px; text-align: center; font-size: 16px; }
    .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

    /* Content */
    .content { margin-left:250px; padding:30px; width:calc(100% - 250px); }
    .page-title { font-size:24px; font-weight:700; color:var(--dark); margin-bottom:5px; }
    .page-sub { font-size:14px; color:var(--muted); margin-bottom:25px; }

    /* General Card */
    .card { background:var(--card); border-radius:16px; box-shadow:0 4px 6px rgba(0,0,0,0.02); margin-bottom:30px; overflow:hidden; border:1px solid var(--border); }
    .card-header { padding:20px 25px; border-bottom:1px solid #f0f0f0; background:#fafafa; font-weight:600; color:var(--dark); display:flex; align-items:center; gap:10px; }
    .card-body { padding:25px; }

    /* Form Design */
    .form-section-title { font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; color:var(--p-green); margin-bottom:15px; border-bottom:2px solid #e8f5e9; padding-bottom:5px; display:inline-block; }
    .form-grid { display:grid; grid-template-columns: repeat(2, 1fr); gap:20px; }
    .form-group { margin-bottom:15px; }
    .form-group label { display:block; font-size:13px; font-weight:500; color:#555; margin-bottom:6px; }
    .form-group input, .form-group select, .form-group textarea { width:100%; padding:10px 12px; border:1px solid #ddd; border-radius:8px; font-family:inherit; font-size:14px; transition:0.2s; outline:none; }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color:var(--p-green); box-shadow:0 0 0 3px rgba(45,106,79,0.1); }
    .btn-submit { background:var(--primary-btn); color:white; border:none; padding:12px 30px; border-radius:8px; font-weight:600; cursor:pointer; width:100%; margin-top:10px; transition:.2s; }
    .btn-submit:hover { background:var(--dark); }

    /* Filter Bar */
    .filter-bar { display:flex; gap:15px; flex-wrap:wrap; padding:20px 25px; background:#fff; border-bottom:1px solid #eee; align-items:center; }
    .search-box { flex:1; position:relative; min-width:200px; }
    .search-box i { position:absolute; left:12px; top:50%; transform:translateY(-50%); color:#999; font-size:14px; }
    .search-box input { width:100%; padding:10px 10px 10px 35px; border:1px solid #ddd; border-radius:8px; font-size:14px; outline:none; }
    .filter-select { padding:10px; border:1px solid #ddd; border-radius:8px; font-size:14px; min-width:140px; cursor:pointer; outline:none; }
    .btn-filter { padding:10px 20px; background:var(--dark); color:white; border:none; border-radius:8px; cursor:pointer; font-size:14px; }

    /* Table */
    table { width:100%; border-collapse:collapse; font-size:14px; }
    th { text-align:left; padding:15px 20px; background:#f9fafb; color:#666; font-weight:600; border-bottom:1px solid #eee; }
    td { padding:15px 20px; border-bottom:1px solid #eee; color:#444; }
    tr:last-child td { border-bottom:none; }
    
    .user-info strong { display:block; color:var(--dark); }
    .user-info span { font-size:12px; color:#888; }
    
    .badge { padding:4px 10px; border-radius:20px; font-size:11px; font-weight:600; text-transform:uppercase; }
    .role-admin { background:#e3f2fd; color:#1565c0; }
    .role-ajk { background:#e8f5e9; color:#2e7d32; }
    .role-resident { background:#f3f4f6; color:#4b5563; }
    
    .status-active { color:#2e7d32; font-weight:600; }
    .status-pending { color:#f57c00; font-weight:600; }
    .status-suspended { color:#c62828; font-weight:600; }

    .action-link { margin-right:8px; color:#666; transition:.2s; }
    .action-link:hover { color:var(--p-green); }

    /* Pagination */
    .pagination { display:flex; justify-content:flex-end; padding:20px 25px; gap:5px; align-items:center; border-top:1px solid #eee; }
    .page-link { padding:6px 12px; border:1px solid #ddd; border-radius:6px; color:#555; text-decoration:none; font-size:13px; transition:.2s; }
    .page-link:hover, .page-link.active { background:var(--p-green); color:white; border-color:var(--p-green); }
    .page-info { font-size:13px; color:#777; margin-right:auto; }

    /* Alert */
    .alert { padding:12px 15px; border-radius:8px; margin-bottom:20px; font-size:14px; display:flex; align-items:center; gap:10px; }
    .alert.success { background:#e8f5e9; color:#2e7d32; border:1px solid #c8e6c9; }
    .alert.error { background:#ffebee; color:#c62828; border:1px solid #ffcdd2; }

    @media(max-width:900px){ .sidebar{display:none;} .content{margin:0; width:100%; padding:20px;} .form-grid{grid-template-columns:1fr;} }
  </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

  <main class="content">
    <div class="page-title">Pengurusan Pengguna</div>
    <div class="page-sub">Daftar pengguna baru dan urus akaun sedia ada.</div>
    
    <?php if($message): ?>
      <div class="alert <?php echo $msg_type; ?>">
        <i class="fas <?php echo ($msg_type=='success')?'fa-check-circle':'fa-exclamation-circle'; ?>"></i>
        <?php echo $message; ?>
      </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header"><i class="fas fa-user-plus"></i> Pendaftaran Manual</div>
      <div class="card-body">
        <form method="POST" action="">
          
          <div class="form-grid">
            <div>
              <div class="form-section-title">1. Maklumat Peribadi</div>
              <div class="form-group">
                <label>Nama Penuh</label>
                <input type="text" name="full_name" required placeholder="Cth: Ali Bin Abu">
              </div>
              <div class="form-group">
                <label>Nombor Telefon</label>
                <input type="text" name="phone" required placeholder="Cth: 0123456789">
              </div>
              <div class="form-group">
                <label>Alamat Rumah</label>
                <textarea name="address" rows="3" required placeholder="No rumah, jalan..."></textarea>
              </div>
            </div>

            <div>
              <div class="form-section-title">2. Tetapan Akaun</div>
              <div class="form-group">
                <label>Username (ID Log Masuk)</label>
                <input type="text" name="username" required placeholder="Unik (tiada jarak)">
              </div>
              <div class="form-group">
                <label>Alamat Emel</label>
                <input type="email" name="email" required placeholder="email@contoh.com">
              </div>
              <div class="form-group">
                <label>Kata Laluan</label>
                <input type="password" name="password" required placeholder="Minimum 6 aksara">
              </div>
              <div class="form-grid" style="grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:0;">
                <div class="form-group">
                  <label>Peranan</label>
                  <select name="role">
                    <option value="Resident">Penduduk</option>
                    <option value="AJK">AJK</option>
                    <option value="Admin">Admin</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Status</label>
                  <select name="account_status">
                    <option value="Active">Aktif</option>
                    <option value="Pending">Pending</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          
          <button type="submit" name="register_user" class="btn-submit"><i class="fas fa-save"></i> Simpan Pendaftaran</button>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><i class="fas fa-users"></i> Senarai Pengguna</div>
      
      <form method="GET" class="filter-bar">
        <div class="search-box">
          <i class="fas fa-search"></i>
          <input type="text" name="q" placeholder="Cari nama, username atau emel..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <select name="role" class="filter-select">
          <option value="">Semua Peranan</option>
          <option value="Resident" <?php if($role_filter=='Resident') echo 'selected'; ?>>Penduduk</option>
          <option value="AJK" <?php if($role_filter=='AJK') echo 'selected'; ?>>AJK</option>
          <option value="Admin" <?php if($role_filter=='Admin') echo 'selected'; ?>>Admin</option>
        </select>
        <select name="status" class="filter-select">
          <option value="">Semua Status</option>
          <option value="Active" <?php if($status_filter=='Active') echo 'selected'; ?>>Aktif</option>
          <option value="Pending" <?php if($status_filter=='Pending') echo 'selected'; ?>>Pending</option>
          <option value="Suspended" <?php if($status_filter=='Suspended') echo 'selected'; ?>>Digantung</option>
        </select>
        <button type="submit" class="btn-filter">Tapis</button>
        <?php if($search || $role_filter || $status_filter): ?>
            <a href="manage_residents.php" style="color:red; font-size:13px; text-decoration:none; margin-left:10px;">Reset</a>
        <?php endif; ?>
      </form>

      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr>
              <th width="5%">ID</th>
              <th width="30%">Maklumat Pengguna</th>
              <th width="25%">Hubungan</th>
              <th width="15%">Peranan</th>
              <th width="10%">Status</th>
              <th width="15%" style="text-align:right;">Tindakan</th>
            </tr>
          </thead>
          <tbody>
            <?php if(mysqli_num_rows($users) > 0): ?>
              <?php while($row = mysqli_fetch_assoc($users)): 
                  $roleBadge = ($row['role']=='Admin')?'role-admin':(($row['role']=='AJK')?'role-ajk':'role-resident');
                  $statusClass = 'status-pending';
                  if($row['account_status']=='Active') $statusClass='status-active';
                  if($row['account_status']=='Suspended') $statusClass='status-suspended';
              ?>
              <tr>
                <td>#<?php echo $row['user_id']; ?></td>
                <td>
                  <div class="user-info">
                    <strong><?php echo htmlspecialchars($row['full_name']); ?></strong>
                    <span>@<?php echo htmlspecialchars($row['username']); ?></span>
                  </div>
                </td>
                <td>
                  <div class="user-info">
                    <span style="display:block; margin-bottom:2px;"><i class="far fa-envelope"></i> <?php echo htmlspecialchars($row['email']); ?></span>
                    <span><i class="fas fa-phone-alt"></i> <?php echo htmlspecialchars($row['phone']); ?></span>
                  </div>
                </td>
                <td><span class="badge <?php echo $roleBadge; ?>"><?php echo $row['role']; ?></span></td>
                <td class="<?php echo $statusClass; ?>"><?php echo $row['account_status']; ?></td>
                <td style="text-align:right;">
                  <?php if($row['role'] !== 'Admin' || $_SESSION['user_id'] == $row['user_id']): ?>
                    <?php if($row['account_status'] != 'Active'): ?>
                      <a href="?action=activate&id=<?php echo $row['user_id']; ?>" class="action-link" title="Aktifkan"><i class="fas fa-check-circle" style="color:green;"></i></a>
                    <?php else: ?>
                      <a href="?action=suspend&id=<?php echo $row['user_id']; ?>" class="action-link" title="Gantung"><i class="fas fa-ban" style="color:orange;"></i></a>
                    <?php endif; ?>
                    
                    <?php if($row['role'] !== 'Admin'): ?>
                      <a href="?action=delete&id=<?php echo $row['user_id']; ?>" class="action-link" title="Padam" onclick="return confirm('Padam pengguna ini?');"><i class="fas fa-trash-alt" style="color:red;"></i></a>
                    <?php endif; ?>
                  <?php else: ?>
                    <span style="color:#ccc; font-size:11px;">Protected</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="6" style="text-align:center; padding:30px; color:#999;">Tiada rekod ditemui.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <?php if($total_pages > 1): ?>
      <div class="pagination">
        <span class="page-info">Menunjukkan <?php echo $start+1; ?> - <?php echo min($start+$limit, $total_records); ?> daripada <?php echo $total_records; ?> rekod</span>
        
        <?php if($page > 1): ?>
          <a href="?page=<?php echo $page-1; ?>&q=<?php echo $search; ?>&role=<?php echo $role_filter; ?>&status=<?php echo $status_filter; ?>" class="page-link">&laquo;</a>
        <?php endif; ?>

        <?php for($i=1; $i<=$total_pages; $i++): ?>
          <a href="?page=<?php echo $i; ?>&q=<?php echo $search; ?>&role=<?php echo $role_filter; ?>&status=<?php echo $status_filter; ?>" class="page-link <?php if($i==$page) echo 'active'; ?>">
            <?php echo $i; ?>
          </a>
        <?php endfor; ?>

        <?php if($page < $total_pages): ?>
          <a href="?page=<?php echo $page+1; ?>&q=<?php echo $search; ?>&role=<?php echo $role_filter; ?>&status=<?php echo $status_filter; ?>" class="page-link">&raquo;</a>
        <?php endif; ?>
      </div>
      <?php endif; ?>

    </div>
  </main>
</body>
</html>