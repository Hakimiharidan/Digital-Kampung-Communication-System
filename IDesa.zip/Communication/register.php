<?php
include "db_connect.php";

$message = "";

if (isset($_POST['register'])) {
    $fn = trim($_POST['full_name']);
    $un = trim($_POST['username']);
    $em = trim($_POST['email']);
    $pw = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $ph = trim($_POST['phone']);
    $ad = trim($_POST['address']);
    
    // SECURITY UPGRADE: Use Prepared Statements to prevent SQL Injection
    
    // 1. Check for duplicate Username or Email
    $check = mysqli_prepare($conn, "SELECT user_id FROM users WHERE username = ? OR email = ?");
    mysqli_stmt_bind_param($check, "ss", $un, $em);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);
    
    if (mysqli_stmt_num_rows($check) > 0) {
        $message = "<div class='alert error'><i class='fas fa-exclamation-circle'></i> Nama pengguna atau Emel sudah wujud.</div>";
    } else {
        // 2. Insert New User
        $insert = mysqli_prepare($conn, "INSERT INTO users (full_name, username, email, password, phone, address, role) VALUES (?, ?, ?, ?, ?, ?, 'Resident')");
        
        if ($insert) {
            mysqli_stmt_bind_param($insert, "ssssss", $fn, $un, $em, $pw, $ph, $ad);
            if (mysqli_stmt_execute($insert)) {
                echo "<script>alert('Pendaftaran Berjaya! Sila log masuk.'); window.location='login_page.php';</script>";
                exit();
            } else {
                $message = "<div class='alert error'>Ralat sistem. Sila cuba lagi.</div>";
            }
            mysqli_stmt_close($insert);
        }
    }
    mysqli_stmt_close($check);
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Daftar Akaun</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { 
            --primary: #2d6a4f; 
            --accent: #4ade80;
            --glass-bg: rgba(20, 30, 25, 0.85); /* Matched to Login */
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-white: #ffffff;
            --text-gray: #d1d5db;
        }

        body { 
            margin: 0; 
            font-family: 'Poppins', sans-serif; 
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('village.png');
            background-size: cover; 
            background-position: center;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex; 
            justify-content: center; 
            align-items: center; 
            padding: 40px 20px; /* Allow scrolling on mobile */
        }

        .glass-card {
            background: var(--glass-bg);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 40px 40px; 
            border-radius: 20px; 
            width: 100%;
            max-width: 450px; /* Slightly wider for form */
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            border: 1px solid var(--glass-border);
            text-align: center;
            color: var(--text-white);
            animation: slideUp 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
        }

        @keyframes slideUp { from { transform: translateY(30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        /* Logo */
        .login-logo { display: flex; flex-direction: column; align-items: center; margin-bottom: 20px; }
        .logo-mark {
            width: 50px; height: 50px; 
            background: linear-gradient(135deg, var(--primary), var(--accent));
            color: white; border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            font-size: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); margin-bottom: 10px;
        }
        .logo-main { font-size: 26px; font-weight: 800; line-height: 1; letter-spacing: -1px; }
        .logo-main span { color: var(--accent); }

        h2 { margin: 0 0 5px 0; font-weight: 600; font-size: 1.5rem; }
        p { color: var(--text-gray); font-size: 0.85rem; margin-bottom: 25px; margin-top: 5px; }

        /* Form */
        .form-grid { display: grid; gap: 15px; text-align: left; }
        .input-wrapper { position: relative; }
        
        /* Icon positioning */
        .input-wrapper i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: var(--text-gray); transition: 0.3s; font-size: 0.9rem; }
        
        /* Specific fix for Textarea icon */
        .input-wrapper textarea + i { top: 18px; transform: none; }

        input, textarea { 
            width: 100%; padding: 12px 15px 12px 45px; 
            background: rgba(255, 255, 255, 0.05); 
            border: 1px solid rgba(255, 255, 255, 0.15); 
            border-radius: 10px; box-sizing: border-box; 
            transition: 0.3s; color: white; font-family: inherit; font-size: 0.9rem;
        }
        textarea { resize: none; min-height: 80px; }
        
        input::placeholder, textarea::placeholder { color: rgba(255, 255, 255, 0.5); opacity: 1; }
        input:focus, textarea:focus { border-color: var(--accent); background: rgba(255, 255, 255, 0.1); outline: none; }
        input:focus + i, textarea:focus + i { color: var(--accent); }

        .btn-submit { 
            width: 100%; padding: 14px; margin-top: 25px;
            background: linear-gradient(135deg, var(--primary), #40916c); 
            color: white; border: none; border-radius: 10px; 
            font-weight: 700; cursor: pointer; font-size: 0.95rem; 
            box-shadow: 0 4px 15px rgba(45, 106, 79, 0.4); 
            transition: 0.3s;
        }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(45, 106, 79, 0.5); filter: brightness(1.1); }

        .footer-link { margin-top: 25px; font-size: 0.85rem; color: var(--text-gray); }
        .footer-link a { color: var(--accent); text-decoration: none; font-weight: 600; transition: 0.2s; }
        .footer-link a:hover { color: white; text-decoration: underline; }

        .alert { padding: 12px; border-radius: 10px; margin-bottom: 20px; font-size: 0.85rem; display: flex; align-items: center; justify-content: center; gap: 10px; }
        .error { background: rgba(220, 38, 38, 0.25); color: #fca5a5; border: 1px solid rgba(220, 38, 38, 0.4); }
    </style>
</head>
<body>

    <div class="glass-card">
        <div class="login-logo">
            <div class="logo-mark"><i class="fa-solid fa-house-chimney-window"></i></div>
            <div class="logo-main">i-<span>Desa</span></div>
        </div>

        <h2>Sertai Komuniti</h2>
        <p>Bina akaun penduduk i-Desa anda</p>
        
        <?php echo $message; ?>

        <form method="POST" class="form-grid">
            <div class="input-wrapper">
                <input type="text" name="full_name" required placeholder="Nama Penuh" autofocus>
                <i class="fas fa-id-card"></i>
            </div>
            
            <div class="input-wrapper">
                <input type="text" name="username" required placeholder="Nama Pengguna">
                <i class="fas fa-user"></i>
            </div>

            <div class="input-wrapper">
                <input type="email" name="email" required placeholder="Alamat Emel">
                <i class="fas fa-envelope"></i>
            </div>

            <div class="input-wrapper">
                <input type="password" name="password" required placeholder="Kata Laluan">
                <i class="fas fa-lock"></i>
            </div>

            <div class="input-wrapper">
                <input type="text" name="phone" required placeholder="No. Telefon (cth: 0123456789)">
                <i class="fas fa-phone"></i>
            </div>

            <div class="input-wrapper">
                <textarea name="address" required placeholder="Alamat Rumah Lengkap"></textarea>
                <i class="fas fa-map-marker-alt"></i>
            </div>

            <button type="submit" name="register" class="btn-submit">Daftar Akaun</button>
        </form>

        <div class="footer-link">
            Sudah menjadi ahli? <a href="login_page.php">Log Masuk</a>
        </div>
    </div>

</body>
</html>