<?php
// footer.php - Secured

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- SECURITY ENFORCEMENT ---
// 1. Check if user is logged in AND has a valid role (Admin, Resident, AJK)
// 2. We use JavaScript for redirection because headers are likely already sent by the main page.
// 3. We exclude 'login_page.php' and 'register.php' to prevent infinite loops.

$currentScript = basename($_SERVER['PHP_SELF']);
$publicPages   = ['login_page.php', 'register.php', 'homepage.php']; // Add 'homepage.php' here if you want it public

if (!isset($_SESSION['user_id']) || !in_array(($_SESSION['role'] ?? ''), ['Admin', 'AJK', 'Resident'])) {
    if (!in_array($currentScript, $publicPages)) {
        echo "<script>window.location.href = 'login_page.php';</script>";
        exit(); // Stop loading the rest of the footer
    }
}

if (!function_exists('h')) {
    function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

$role = $_SESSION['role'] ?? 'Guest';
$isLoggedIn = isset($_SESSION['user_id']);

/**
 * Role-aware "Buat Aduan" destination
 */
if ($isLoggedIn && ($role === 'AJK' || $role === 'Admin')) {
    $buatAduanLink = 'resident_add_report.php'; 
} else {
    $buatAduanLink = 'resident_add_report.php';
}
?>

<style>
/* ===== Footer scoped theme (no global :root pollution) ===== */
.idesa-footer{
    --footer-bg: #14452F;
    --footer-text: #9ca3af;
    --footer-head: #f3f4f6;
    --footer-accent: #22c55e;

    /* fallback if navbar var not present */
    --footer-border-accent: var(--nav-primary, #2d6a4f);

    background-color: var(--footer-bg);
    color: var(--footer-text);
    font-family: 'Poppins', system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
    padding-top: 56px;
    margin-top: 34px;
    border-top: 4px solid var(--footer-border-accent);
}

.footer-container{
    max-width: 1100px;
    margin: 0 auto;
    padding: 0 24px 36px;
    display: grid;
    grid-template-columns: 1.6fr 1fr 1fr 1.2fr;
    gap: 40px;
}

/* Brand */
.footer-brand h2{
    color: var(--footer-head);
    font-size: 24px;
    font-weight: 900;
    margin: 0 0 14px;
    display: flex;
    align-items: center;
    gap: 10px;
    letter-spacing: .2px;
}
.footer-brand p{
    line-height: 1.7;
    font-size: 14px;
    margin: 0 0 18px;
    max-width: 420px;
}

/* Section headings */
.footer-col h3{
    color: var(--footer-head);
    font-size: 13px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .08em;
    margin: 6px 0 16px;
}

/* Links */
.footer-links{
    list-style: none;
    padding: 0;
    margin: 0;
    display:flex;
    flex-direction: column;
    gap: 12px;
}

.footer-links a{
    text-decoration: none;
    color: var(--footer-text);
    font-size: 14px;
    font-weight: 700;
    transition: color .15s, transform .15s, opacity .15s;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    width: fit-content;
}
.footer-links a:hover{
    color: var(--footer-accent);
    transform: translateX(3px);
}
.footer-links a:focus-visible{
    outline: 3px solid rgba(34,197,94,.35);
    outline-offset: 3px;
    border-radius: 10px;
}

/* Contact */
.contact-row{
    display:flex;
    gap: 12px;
    margin-bottom: 14px;
    font-size: 14px;
    line-height: 1.6;
}
.contact-row i{
    color: var(--footer-accent);
    margin-top: 3px;
}
.contact-row a{
    color: var(--footer-text);
    text-decoration: none;
    font-weight: 800;
}
.contact-row a:hover{
    color: var(--footer-accent);
}

/* Social */
.social-links{
    display:flex;
    gap: 10px;
    margin-top: 16px;
}
.social-btn{
    width: 38px;
    height: 38px;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.10);
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius: 10px;
    color: #fff;
    text-decoration:none;
    transition: transform .15s, background .15s, border-color .15s;
}
.social-btn:hover{
    background: var(--footer-accent);
    border-color: rgba(34,197,94,.6);
    transform: translateY(-2px);
}
.social-btn:focus-visible{
    outline: 3px solid rgba(34,197,94,.35);
    outline-offset: 3px;
}

/* Bottom bar */
.footer-bottom{
    border-top: 1px solid rgba(255,255,255,0.10);
    padding: 18px 24px;
    text-align:center;
    font-size: 13px;
    color: #6b7280;
}

/* Responsive */
@media (max-width: 980px){
    .footer-container{ grid-template-columns: 1fr 1fr; }
}
@media (max-width: 620px){
    .footer-container{ grid-template-columns: 1fr; gap: 26px; }
    .idesa-footer{ padding-top: 44px; }
}
</style>

<footer class="idesa-footer" role="contentinfo">
    <div class="footer-container">

        <div class="footer-brand">
            <h2>
                <i class="fa-solid fa-house-chimney-window" aria-hidden="true" style="color:var(--footer-accent)"></i>
                i-Desa
            </h2>
            <p>
                Sistem komunikasi komuniti digital yang menghubungkan penduduk, AJK, dan pentadbir kampung
                dalam satu platform yang efisien serta telus.
            </p>

            <div class="social-links" aria-label="Pautan media sosial">
                <a href="#" class="social-btn" aria-label="Facebook i-Desa"><i class="fa-brands fa-facebook-f" aria-hidden="true"></i></a>
                <a href="#" class="social-btn" aria-label="WhatsApp i-Desa"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i></a>
                <a href="#" class="social-btn" aria-label="Instagram i-Desa"><i class="fa-brands fa-instagram" aria-hidden="true"></i></a>
            </div>
        </div>

        <div class="footer-col">
            <h3>Pautan Pantas</h3>
            <ul class="footer-links">
                <li><a href="homepage.php"><i class="fa-solid fa-angle-right" aria-hidden="true"></i> Halaman Utama</a></li>
                <li><a href="bulletin.php"><i class="fa-solid fa-angle-right" aria-hidden="true"></i> Buletin Komuniti</a></li>
                <li><a href="calendar.php"><i class="fa-solid fa-angle-right" aria-hidden="true"></i> Kalendar Aktiviti</a></li>
                <li><a href="facility_rental.php"><i class="fa-solid fa-angle-right" aria-hidden="true"></i> Tempahan Fasiliti</a></li>
                <li><a href="<?php echo h($buatAduanLink); ?>"><i class="fa-solid fa-angle-right" aria-hidden="true"></i> Buat Aduan</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h3>Sokongan</h3>
            <ul class="footer-links">
                <li><a href="help_center.php"><i class="fa-solid fa-angle-right" aria-hidden="true"></i> Pusat Bantuan (FAQ)</a></li>
                <li><a href="privacy_policy.php"><i class="fa-solid fa-angle-right" aria-hidden="true"></i> Dasar Privasi</a></li>
                <li><a href="terms.php"><i class="fa-solid fa-angle-right" aria-hidden="true"></i> Terma & Syarat</a></li>
            </ul>
        </div>

        <div class="footer-col">
            <h3>Hubungi Kami</h3>

            <div class="contact-row">
                <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                <span>
                    Kampung Teluk Kandit,<br>
                    05300 Alor Setar, Kedah.
                </span>
            </div>

            <div class="contact-row">
                <i class="fa-solid fa-phone" aria-hidden="true"></i>
                <span><a href="tel:+60387331234">+601-5111 6447</a></span>
            </div>

            <div class="contact-row">
                <i class="fa-solid fa-envelope" aria-hidden="true"></i>
                <span><a href="mailto:admin@idesa.com.my">admin@idesa.com.my</a></span>
            </div>
        </div>

    </div>

    <div class="footer-bottom">
        &copy; <?php echo date("Y"); ?> i-Desa Communication System. Hak Cipta Terpelihara.
    </div>
</footer>