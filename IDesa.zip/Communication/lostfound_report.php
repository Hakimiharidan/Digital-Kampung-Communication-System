<?php
session_start();
include "db_connect.php";

// 1. Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Laporan Hilang & Jumpa</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        /* --- CORE VARIABLES & RESET --- */
        :root { 
            --primary: #2d6a4f; 
            --primary-hover: #1b4332;
            --bg-body: #f8fafc;
            --bg-card: #ffffff;
            --text-main: #1f2937;
            --text-muted: #6b7280;
            --border: #e2e8f0;
            --shadow-sm: 0 1px 2px 0 rgba(0,0,0,0.05);
            --radius: 0.75rem;
        }

        * { box-sizing: border-box; }
        body { margin: 0; font-family: 'Poppins', sans-serif; background-color: var(--bg-body); color: var(--text-main); display: flex; flex-direction: column; min-height: 100vh; }

        /* --- WRAPPER --- */
        .wrap { flex: 1; width: 100%; max-width: 900px; margin: 0 auto; padding: 2rem 1.5rem; }

        /* --- HEADER --- */
        .page-header { margin-bottom: 2rem; text-align: center; }
        .page-title { font-size: 2rem; font-weight: 700; color: var(--primary); margin: 0; }
        .page-sub { margin-top: 0.5rem; color: var(--text-muted); font-size: 0.95rem; max-width: 600px; margin-left: auto; margin-right: auto; line-height: 1.6; }

        /* --- CARD & FORM --- */
        .card { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--radius); padding: 2rem; box-shadow: var(--shadow-sm); }
        
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
        @media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }

        .form-group { margin-bottom: 1rem; }
        .form-group.full { grid-column: 1 / -1; }

        label { display: block; font-size: 0.9rem; font-weight: 600; margin-bottom: 0.5rem; color: var(--text-main); }
        
        input, select, textarea {
            width: 100%; padding: 0.75rem 1rem; border: 1px solid var(--border); border-radius: 0.5rem;
            font-family: inherit; font-size: 0.95rem; outline: none; transition: border-color 0.2s;
            background: #fff;
        }
        input:focus, select:focus, textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45, 106, 79, 0.1); }
        
        textarea { min-height: 120px; resize: vertical; }
        
        .hint { font-size: 0.8rem; color: var(--text-muted); margin-top: 0.3rem; }

        /* --- FILE UPLOAD --- */
        .file-upload-wrapper {
            position: relative; border: 2px dashed var(--border); border-radius: 0.5rem;
            padding: 2rem; text-align: center; cursor: pointer; transition: 0.2s;
        }
        .file-upload-wrapper:hover { border-color: var(--primary); background: #f0fdf4; }
        .file-upload-wrapper input { position: absolute; width: 100%; height: 100%; top: 0; left: 0; opacity: 0; cursor: pointer; }
        .upload-icon { font-size: 2rem; color: var(--text-muted); margin-bottom: 0.5rem; }

        /* --- ACTIONS --- */
        .actions { display: flex; gap: 1rem; margin-top: 2rem; justify-content: flex-end; flex-wrap: wrap; }
        
        .btn {
            display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.75rem 1.5rem;
            border-radius: 0.5rem; font-weight: 600; font-size: 0.95rem; cursor: pointer;
            border: 1px solid transparent; transition: all 0.2s; text-decoration: none;
        }
        .btn:hover { transform: translateY(-1px); }
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-hover); }
        .btn-outline { background: white; border-color: var(--border); color: var(--text-main); }
        .btn-outline:hover { border-color: var(--text-muted); }
        .btn-danger { background: #fee2e2; color: #991b1b; border-color: #fecaca; }
        .btn-danger:hover { background: #fecaca; }

        /* --- ALERTS --- */
        .notice { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1.5rem; display: none; font-size: 0.9rem; font-weight: 500; }
        .notice.ok { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .notice.err { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }

        /* --- CHECKBOX --- */
        .checkbox-wrapper { display: flex; align-items: flex-start; gap: 0.75rem; background: #f9fafb; padding: 1rem; border-radius: 0.5rem; border: 1px solid var(--border); }
        .checkbox-wrapper input { width: auto; margin-top: 0.3rem; }
    </style>
</head>

<body>

<?php include "navbar.php"; ?>

<div class="wrap">
    
    <div class="page-header">
        <h1 class="page-title">Laporan Hilang & Jumpa</h1>
        <p class="page-sub">
            Sila isi butiran di bawah dengan lengkap. Laporan anda akan disemak oleh AJK sebelum dipaparkan kepada umum untuk tujuan keselamatan.
        </p>
    </div>

    <div class="card">
        <div id="notice" class="notice"></div>

        <form id="reportForm" enctype="multipart/form-data">
            <input type="hidden" name="action" value="submit_report">

            <div class="form-grid">
                
                <div>
                    <label for="type">Jenis Laporan <span style="color:red">*</span></label>
                    <select id="type" name="type" required>
                        <option value="">-- Sila Pilih --</option>
                        <option value="Lost">Saya Kehilangan Barang</option>
                        <option value="Found">Saya Menjumpai Barang</option>
                    </select>
                </div>

                <div>
                    <label for="category">Kategori Barang <span style="color:red">*</span></label>
                    <select id="category" name="category" required>
                        <option value="">-- Sila Pilih --</option>
                        <option value="Electronics">Elektronik (Telefon, Laptop)</option>
                        <option value="Documents">Dokumen Penting (IC, Kad Bank)</option>
                        <option value="Wallet/Purse">Dompet / Beg Duit</option>
                        <option value="Keys">Kunci (Rumah/Kereta)</option>
                        <option value="Pets">Haiwan Peliharaan</option>
                        <option value="Clothing">Pakaian / Aksesori</option>
                        <option value="Other">Lain-lain</option>
                    </select>
                </div>

                <div class="full">
                    <label for="item_name">Tajuk / Nama Barang <span style="color:red">*</span></label>
                    <input id="item_name" name="item_name" type="text" maxlength="100" placeholder="Contoh: Kunci Kereta Honda / Kucing Putih" required>
                </div>

                <div>
                    <label for="incident_date">Tarikh Kejadian <span style="color:red">*</span></label>
                    <input id="incident_date" name="incident_date" type="date" required max="<?php echo date('Y-m-d'); ?>">
                </div>

                <div>
                    <label for="location_detail">Lokasi Kejadian <span style="color:red">*</span></label>
                    <input id="location_detail" name="location_detail" type="text" maxlength="255" placeholder="Contoh: Padang Permainan / Surau" required>
                </div>

                <div class="full">
                    <label for="description">Penerangan Terperinci <span style="color:red">*</span></label>
                    <textarea id="description" name="description" placeholder="Sila nyatakan ciri-ciri unik, warna, jenama, atau sebarang tanda pengenalan..." required></textarea>
                    <div class="hint">Maklumat yang jelas memudahkan proses pengecaman.</div>
                </div>

                <div class="full">
                    <label>Muat Naik Gambar (Opsyenal)</label>
                    <div class="file-upload-wrapper">
                        <input id="image" name="image" type="file" accept=".jpg,.jpeg,.png">
                        <i class="fas fa-cloud-upload-alt upload-icon"></i>
                        <p style="margin:0; font-weight:500;">Klik atau seret gambar ke sini</p>
                        <div class="hint">Format: JPG, PNG (Maks 5MB)</div>
                    </div>
                </div>

                <div class="full">
                    <div class="checkbox-wrapper">
                        <input id="consent" name="contact_share_consent" type="checkbox" value="1">
                        <div>
                            <label for="consent" style="margin:0; cursor:pointer;">Benarkan Perkongsian Maklumat Hubungan</label>
                            <div class="hint" style="margin-top:0.2rem;">
                                Jika ditanda, nombor telefon anda akan dipaparkan kepada pengguna berdaftar lain untuk memudahkan urusan tuntutan. 
                                Jika tidak, urusan akan melalui perantaraan AJK.
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="actions">
                <button type="button" class="btn btn-danger" onclick="resetForm()">
                    <i class="fas fa-undo"></i> Reset
                </button>
                <a href="lostfound_board.php" class="btn btn-outline">
                    Batal
                </a>
                <button id="btnSubmit" class="btn btn-primary" type="submit">
                    <i class="fas fa-paper-plane"></i> Hantar Laporan
                </button>
            </div>

        </form>
    </div>
</div>

<?php include "footer.php"; ?>

<script>
    const form = document.getElementById("reportForm");
    const notice = document.getElementById("notice");
    const btnSubmit = document.getElementById("btnSubmit");

    function showNotice(type, msg){
        notice.className = "notice " + (type === "ok" ? "ok" : "err");
        notice.innerHTML = (type === "ok" ? '<i class="fas fa-check-circle"></i> ' : '<i class="fas fa-exclamation-triangle"></i> ') + msg;
        notice.style.display = "block";
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function resetForm(){
        if(confirm("Adakah anda pasti mahu mengosongkan borang?")) {
            form.reset();
            notice.style.display = "none";
        }
    }

    function validateForm(){
        const type = form.type.value;
        const category = form.category.value;
        const item = form.item_name.value.trim();
        const loc = form.location_detail.value.trim();
        const date = form.incident_date.value;
        const desc = form.description.value.trim();

        if(!type) return "Sila pilih jenis laporan.";
        if(!category) return "Sila pilih kategori barang.";
        if(item.length < 3) return "Tajuk terlalu pendek (min 3 huruf).";
        if(!date) return "Sila pilih tarikh kejadian.";
        if(loc.length < 3) return "Sila nyatakan lokasi dengan lebih jelas.";
        if(desc.length < 10) return "Sila berikan penerangan yang lebih lengkap (min 10 huruf).";

        // File validation
        const file = form.image.files[0];
        if(file){
            const validTypes = ["image/jpeg", "image/png", "image/jpg"];
            if(!validTypes.includes(file.type)) return "Hanya format JPG dan PNG dibenarkan.";
            if(file.size > 5 * 1024 * 1024) return "Saiz gambar terlalu besar (Maksimum 5MB).";
        }

        return null;
    }

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        // 1. Client-side Validation
        const err = validateForm();
        if(err){
            showNotice("err", err);
            return;
        }

        // 2. Prepare UI
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menghantar...';
        notice.style.display = 'none';

        try {
            // 3. Send AJAX Request
            const fd = new FormData(form);
            const res = await fetch("lostfound_ajax.php", {
                method: "POST",
                body: fd,
                credentials: "same-origin" // Important for Session Cookie
            });

            const data = await res.json();

            // 4. Handle Response
            if(data.ok){
                showNotice("ok", `Laporan berjaya dihantar! ID Laporan: #${data.report_id}. Anda akan dialihkan...`);
                form.reset();
                setTimeout(() => window.location.href = "lostfound_board.php", 2000);
            } else {
                throw new Error(data.error || "Ralat tidak diketahui.");
            }

        } catch(ex) {
            console.error(ex);
            showNotice("err", ex.message || "Gagal menghubungi pelayan.");
            btnSubmit.disabled = false;
            btnSubmit.innerHTML = '<i class="fas fa-paper-plane"></i> Hantar Laporan';
        }
    });
</script>

</body>
</html>