<?php
session_start();
include "db_connect.php";

// Security Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$flash = "";
$flash_type = "";

// --- ACTIONS ---

// 1. UPDATE Booking Status
if (isset($_GET['action'], $_GET['id']) && in_array($_GET['action'], ['verify','confirm','reject'], true)) {
    $booking_id = (int)$_GET['id'];
    $action = $_GET['action'];
    $new_status = 'Pending';
    
    if ($action === 'verify') $new_status = 'Awaiting Payment';
    if ($action === 'confirm') $new_status = 'Confirmed';
    if ($action === 'reject') $new_status = 'Rejected';

    $stmt = mysqli_prepare($conn, "UPDATE bookings SET status=? WHERE booking_id=?");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "si", $new_status, $booking_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $flash = "Status tempahan berjaya dikemaskini: {$new_status}";
        $flash_type = "success";
    } else {
        $flash = "Ralat: gagal kemaskini status.";
        $flash_type = "error";
    }
}

// 2. DELETE Booking (New Feature)
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete_booking') {
    $booking_id = (int)$_GET['id'];
    
    // Optional: Check status before delete to be safe (e.g., only Rejected/Completed)
    // For now, allow admin full control.
    $stmt = mysqli_prepare($conn, "DELETE FROM bookings WHERE booking_id=?");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $booking_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $flash = "Rekod tempahan berjaya dipadam.";
        $flash_type = "success";
    } else {
        $flash = "Ralat: gagal padam tempahan.";
        $flash_type = "error";
    }
}

// 3. DELETE Facility
if (isset($_GET['action'], $_GET['facility_id']) && $_GET['action'] === 'delete_facility') {
    $fid = (int)$_GET['facility_id'];

    // Check existing bookings
    $has = 0;
    $stmtc = mysqli_prepare($conn, "SELECT COUNT(*) AS c FROM bookings WHERE facility_id=?");
    if ($stmtc) {
        mysqli_stmt_bind_param($stmtc, "i", $fid);
        mysqli_stmt_execute($stmtc);
        $res = mysqli_stmt_get_result($stmtc);
        if ($res && ($r = mysqli_fetch_assoc($res))) $has = (int)$r['c'];
        mysqli_stmt_close($stmtc);
    }

    if ($has > 0) {
        $flash = "Tidak boleh padam fasiliti kerana terdapat tempahan berkaitan. Sila padam tempahan dahulu.";
        $flash_type = "error";
    } else {
        // Delete image
        $oldImage = null;
        $stmtg = mysqli_prepare($conn, "SELECT image_path FROM facilities WHERE facility_id=?");
        if ($stmtg) {
            mysqli_stmt_bind_param($stmtg, "i", $fid);
            mysqli_stmt_execute($stmtg);
            $resg = mysqli_stmt_get_result($stmtg);
            if ($resg && ($g = mysqli_fetch_assoc($resg))) $oldImage = $g['image_path'] ?? null;
            mysqli_stmt_close($stmtg);
        }

        $stmtd = mysqli_prepare($conn, "DELETE FROM facilities WHERE facility_id=?");
        if ($stmtd) {
            mysqli_stmt_bind_param($stmtd, "i", $fid);
            mysqli_stmt_execute($stmtd);
            mysqli_stmt_close($stmtd);

            if ($oldImage && !preg_match('/^https?:\/\//i', $oldImage)) {
                $oldAbs = __DIR__ . "/" . ltrim($oldImage, '/');
                if (file_exists($oldAbs)) @unlink($oldAbs);
            }
            $flash = "Fasiliti berjaya dipadam.";
            $flash_type = "success";
        } else {
            $flash = "Ralat: gagal padam fasiliti.";
            $flash_type = "error";
        }
    }
}

// 4. SAVE Facility
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_facility'])) {
    $facility_id = (int)($_POST['facility_id'] ?? 0);
    $name = trim((string)($_POST['name'] ?? ''));
    $description = trim((string)($_POST['description'] ?? ''));
    $rate = (float)($_POST['rate_per_hour'] ?? 0);
    $price_unit = $_POST['price_unit'] ?? 'Hour';
    $status = $_POST['status'] ?? 'Available';
    $image_url = trim((string)($_POST['image_url'] ?? ''));

    if ($name === '' || $rate <= 0) {
        $flash = "Sila isi nama dan kadar (RM).";
        $flash_type = "error";
    } else {
        if (!in_array($price_unit, ['Hour','Day'], true)) $price_unit = 'Hour';
        if (!in_array($status, ['Available','Maintenance'], true)) $status = 'Available';
        $description = ($description !== '') ? $description : null;

        // Image Upload
        $newImagePath = null;
        if (!empty($_FILES['image_file']['name']) && is_uploaded_file($_FILES['image_file']['tmp_name'])) {
            $uploadDir = __DIR__ . "/uploads/facilities";
            if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);

            $orig = basename($_FILES['image_file']['name']);
            $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
            $safeBase = preg_replace('/[^a-zA-Z0-9\-_.]+/', '_', pathinfo($orig, PATHINFO_FILENAME));
            $rand = bin2hex(random_bytes(4));
            $fileName = date('Ymd_His') . "_" . $safeBase . "_" . $rand . ($ext ? ".".$ext : "");
            $destAbs = $uploadDir . "/" . $fileName;
            $destRel = "uploads/facilities/" . $fileName;

            if (move_uploaded_file($_FILES['image_file']['tmp_name'], $destAbs)) {
                $newImagePath = $destRel;
            } else {
                $flash = "Ralat: gagal muat naik gambar.";
                $flash_type = "error";
            }
        } elseif ($image_url !== '') {
            $newImagePath = $image_url;
        }

        if ($flash === "") {
            if ($facility_id > 0) {
                // Update
                $stmt = mysqli_prepare($conn, "UPDATE facilities SET name=?, description=?, rate_per_hour=?, price_unit=?, status=?, image_path=COALESCE(?, image_path) WHERE facility_id=?");
                mysqli_stmt_bind_param($stmt, "ssdsssi", $name, $description, $rate, $price_unit, $status, $newImagePath, $facility_id);
                
                if (mysqli_stmt_execute($stmt)) {
                    $flash = "Fasiliti berjaya dikemaskini.";
                    $flash_type = "success";
                } else {
                    $flash = "Ralat Pangkalan Data.";
                    $flash_type = "error";
                }
                mysqli_stmt_close($stmt);
            } else {
                // Insert
                $imgToSave = $newImagePath ?? 'https://placehold.co/100x100?text=Tiada+Gambar';
                $stmt = mysqli_prepare($conn, "INSERT INTO facilities (name, description, rate_per_hour, price_unit, status, image_path) VALUES (?,?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt, "ssdsss", $name, $description, $rate, $price_unit, $status, $imgToSave);
                
                if (mysqli_stmt_execute($stmt)) {
                    $flash = "Fasiliti berjaya ditambah.";
                    $flash_type = "success";
                } else {
                    $flash = "Ralat Pangkalan Data.";
                    $flash_type = "error";
                }
                mysqli_stmt_close($stmt);
            }
        }
    }
}

// Edit Mode Fetch
$edit = null;
if (isset($_GET['edit_facility'])) {
    $fid = (int)$_GET['edit_facility'];
    $stmt = mysqli_prepare($conn, "SELECT * FROM facilities WHERE facility_id=?");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $fid);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        if ($res) $edit = mysqli_fetch_assoc($res);
        mysqli_stmt_close($stmt);
    }
}

// --- DATA FETCHING ---

// Facilities List
$facilities = [];
$res = mysqli_query($conn, "SELECT * FROM facilities ORDER BY status ASC, name ASC");
if ($res) while ($r = mysqli_fetch_assoc($res)) $facilities[] = $r;

// Bookings List (With Filters)
$bookings = [];
$filter_status = $_GET['filter_status'] ?? 'All';
$date_start = $_GET['date_start'] ?? '';
$date_end = $_GET['date_end'] ?? '';

$sqlb = "SELECT b.*, f.name AS facility_name, f.price_unit FROM bookings b JOIN facilities f ON b.facility_id=f.facility_id WHERE 1=1";
$params = [];
$types = "";

if ($filter_status !== 'All') {
    $sqlb .= " AND b.status = ?";
    $params[] = $filter_status;
    $types .= "s";
}

if ($date_start && $date_end) {
    $sqlb .= " AND b.booking_date BETWEEN ? AND ?";
    $params[] = $date_start;
    $params[] = $date_end;
    $types .= "ss";
}

$sqlb .= " ORDER BY b.created_at DESC LIMIT 50";

$stmt = mysqli_prepare($conn, $sqlb);
if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}
mysqli_stmt_execute($stmt);
$resb = mysqli_stmt_get_result($stmt);
if ($resb) while ($r = mysqli_fetch_assoc($resb)) $bookings[] = $r;
mysqli_stmt_close($stmt);

?>

<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Admin Sewa Fasiliti | i-Desa</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Global Reset */
    * { box-sizing: border-box; }
    :root { 
        --primary: #2d6a4f; 
        --dark: #143d29; 
        --bg: #f4f7f6; 
        --card: #fff; 
        --text: #333; 
        --muted: #6b7280; 
    }
    body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); display:flex; }

    /* Sidebar */
    .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; box-shadow: 4px 0 15px rgba(0,0,0,0.05); }
    .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
    .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
    .logo-text { display: flex; flex-direction: column; line-height: 1; }
    .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .logo-main span { color: #4ade80; }
    .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }
    .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
    .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
    .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
    .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
    .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

    /* Content */
    .content { margin-left: 250px; padding: 30px; width: calc(100% - 250px); }
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
    .header h1 { font-size: 24px; font-weight: 700; color: var(--dark); margin: 0; }

    /* Cards */
    .card { background: var(--card); border-radius: 16px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); margin-bottom: 20px; border: 1px solid #eee; }
    h3 { margin: 0 0 20px; font-size: 18px; color: var(--text); border-bottom: 1px solid #f0f0f0; padding-bottom: 10px; }

    /* Buttons */
    .btn { padding: 8px 16px; border-radius: 50px; border: 1px solid #ddd; background: #fff; color: #555; cursor: pointer; font-weight: 600; font-size: 13px; transition: 0.2s; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; }
    .btn:hover { background: #f9fafb; transform: translateY(-1px); }
    .btn.primary { background: var(--primary); border-color: var(--primary); color: #fff; }
    .btn.primary:hover { opacity: 0.9; }
    .btn.danger { background: #fee2e2; border-color: #fecaca; color: #b91c1c; }
    .btn.danger:hover { background: #fecaca; }
    .btn.secondary { background: #fff; color: var(--primary); border-color: var(--primary); }

    /* Forms */
    .row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px; }
    label { font-size: 13px; font-weight: 600; color: #444; display: block; margin-bottom: 6px; }
    input, select, textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; outline: none; transition: 0.2s; background: #fff; }
    input:focus, select:focus, textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }
    
    /* Tables */
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th { text-align: left; padding: 12px 15px; background: #f9fafb; color: #6b7280; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; border-bottom: 1px solid #e5e7eb; }
    td { padding: 14px 15px; border-bottom: 1px solid #f3f4f6; font-size: 14px; color: #374151; vertical-align: middle; }
    tr:hover td { background: #fafafa; }

    /* Badges */
    .pill { display: inline-flex; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; border: 1px solid transparent; }
    .pill.pending { background: #fff7ed; color: #c2410c; border-color: #fed7aa; }
    .pill.confirmed { background: #ecfdf5; color: #15803d; border-color: #bbf7d0; }
    .pill.rejected { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
    .pill.await { background: #eff6ff; color: #1d4ed8; border-color: #bfdbfe; }

    /* Filter Bar */
    .filter-bar { display: flex; gap: 10px; align-items: center; margin-bottom: 20px; flex-wrap: wrap; background: #f9fafb; padding: 15px; border-radius: 12px; border: 1px solid #eee; }
    .filter-item { flex: 1; min-width: 150px; }

    /* Alerts */
    .flash { padding: 12px 15px; border-radius: 10px; font-size: 14px; margin-bottom: 20px; font-weight: 500; display: flex; align-items: center; gap: 10px; }
    .flash.success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
    .flash.error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }

    @media (max-width: 900px) {
        .sidebar { display: none; }
        .content { margin: 0; width: 100%; padding: 20px; }
        .row { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_residents.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item active">
            <i class="fas fa-building"></i> <span>Sewa Fasiliti</span>
        </a>
        
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Kecemasan</span>
        </a>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>            
        </a>
        <?php endif; ?>
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<main class="content">
    <div class="header">
      <h1>Pengurusan Fasiliti & Sewaan</h1>
      <a class="btn secondary" href="facility_rental.php" target="_blank"><i class="fas fa-external-link-alt"></i> Paparan Awam</a>
    </div>

    <?php if ($flash): ?>
        <div class="flash <?php echo ($flash_type === 'error') ? 'error' : 'success'; ?>">
            <?php echo ($flash_type === 'error') ? '<i class="fas fa-circle-exclamation"></i>' : '<i class="fas fa-check-circle"></i>'; ?>
            <?php echo h($flash); ?>
        </div>
    <?php endif; ?>

    <section class="card">
      <h3><i class="fas fa-pen-to-square"></i> <?php echo $edit ? "Kemaskini Fasiliti" : "Tambah Fasiliti Baru"; ?></h3>
      
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="facility_id" value="<?php echo (int)($edit['facility_id'] ?? 0); ?>">

        <div class="row">
          <div>
            <label>Nama Fasiliti</label>
            <input type="text" name="name" required value="<?php echo h($edit['name'] ?? ''); ?>" placeholder="Contoh: Dewan Serbaguna">
          </div>
          <div>
            <label>Status Semasa</label>
            <select name="status">
                <option value="Available" <?php echo (($edit['status'] ?? '')==='Available')?'selected':''; ?>>Available (Boleh Disewa)</option>
                <option value="Maintenance" <?php echo (($edit['status'] ?? '')==='Maintenance')?'selected':''; ?>>Maintenance (Ditutup)</option>
            </select>
          </div>
        </div>

        <div class="row">
          <div>
            <label>Kadar Sewaan (RM)</label>
            <input type="number" step="0.01" name="rate_per_hour" required value="<?php echo h($edit['rate_per_hour'] ?? ''); ?>" placeholder="0.00">
          </div>
          <div>
            <label>Unit Harga</label>
            <select name="price_unit">
                <option value="Hour" <?php echo (($edit['price_unit'] ?? '')==='Hour')?'selected':''; ?>>Per Jam (Hour)</option>
                <option value="Day" <?php echo (($edit['price_unit'] ?? '')==='Day')?'selected':''; ?>>Per Hari (Day)</option>
            </select>
          </div>
        </div>

        <div style="margin-bottom:15px;">
            <label>Deskripsi & Info Fasiliti</label>
            <textarea name="description" rows="3" placeholder="Contoh: Muatan 200 orang, berhawa dingin..."><?php echo h($edit['description'] ?? ''); ?></textarea>
        </div>

        <div class="row">
            <div>
                <label>Muat Naik Gambar</label>
                <input type="file" name="image_file" accept="image/*">
                <?php if (!empty($edit['image_path'])): ?>
                    <div style="margin-top:5px; font-size:12px;"><a href="<?php echo h($edit['image_path']); ?>" target="_blank">Lihat Gambar Semasa</a></div>
                <?php endif; ?>
            </div>
            <div>
                <label>Atau Pautan Gambar (URL)</label>
                <input type="url" name="image_url" placeholder="https://example.com/image.jpg">
            </div>
        </div>

        <div style="display:flex; gap:10px; margin-top:20px;">
          <button class="btn primary" type="submit" name="save_facility"><i class="fas fa-save"></i> Simpan</button>
          
          <?php if ($edit): ?>
            <a class="btn" href="admin_rental.php">Batal</a>
            <a class="btn danger" href="admin_rental.php?action=delete_facility&facility_id=<?php echo (int)$edit['facility_id']; ?>" onclick="return confirm('Adakah anda pasti mahu memadam fasiliti ini?')"><i class="fas fa-trash"></i> Padam</a>
          <?php else: ?>
            <button class="btn" type="reset">Reset</button>
          <?php endif; ?>
        </div>
      </form>
    </section>

    <section class="card">
      <h3><i class="fas fa-building"></i> Senarai Fasiliti</h3>
      <div style="overflow-x:auto;">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama Fasiliti</th>
                <th>Unit Harga</th>
                <th>Kadar (RM)</th>
                <th>Status</th>
                <th>Tindakan</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($facilities)): ?>
                <tr><td colspan="6" style="text-align:center; padding:30px; color:#888;">Tiada fasiliti didaftarkan.</td></tr>
              <?php else: foreach ($facilities as $f): ?>
                <tr>
                  <td><?php echo (int)$f['facility_id']; ?></td>
                  <td><strong><?php echo h($f['name']); ?></strong></td>
                  <td><?php echo h($f['price_unit']); ?></td>
                  <td>RM <?php echo h(number_format((float)$f['rate_per_hour'],2)); ?></td>
                  <td>
                    <span class="pill" style="background:<?php echo ($f['status']=='Available')?'#ecfdf5':'#fff1f2'; ?>; color:<?php echo ($f['status']=='Available')?'#065f46':'#991b1b'; ?>;">
                        <?php echo h($f['status']); ?>
                    </span>
                  </td>
                  <td class="actions" style="display:flex; gap:5px;">
                    <a class="btn" style="padding:6px 10px;" href="admin_rental.php?edit_facility=<?php echo (int)$f['facility_id']; ?>"><i class="fas fa-pen"></i></a>
                    <a class="btn danger" style="padding:6px 10px;" href="admin_rental.php?action=delete_facility&facility_id=<?php echo (int)$f['facility_id']; ?>" onclick="return confirm('Padam fasiliti ini?')"><i class="fas fa-trash"></i></a>
                  </td>
                </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
      </div>
    </section>

    <section class="card">
      <h3><i class="fas fa-calendar-check"></i> Senarai Tempahan Terkini</h3>
      
      <form method="get" class="filter-bar">
          <div class="filter-item">
              <label>Status:</label>
              <select name="filter_status" onchange="this.form.submit()">
                  <option value="All" <?php echo ($filter_status === 'All') ? 'selected' : ''; ?>>Semua</option>
                  <option value="Pending" <?php echo ($filter_status === 'Pending') ? 'selected' : ''; ?>>Pending</option>
                  <option value="Confirmed" <?php echo ($filter_status === 'Confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                  <option value="Awaiting Payment" <?php echo ($filter_status === 'Awaiting Payment') ? 'selected' : ''; ?>>Awaiting Payment</option>
                  <option value="Rejected" <?php echo ($filter_status === 'Rejected') ? 'selected' : ''; ?>>Rejected</option>
              </select>
          </div>
          <div class="filter-item">
              <label>Dari Tarikh:</label>
              <input type="date" name="date_start" value="<?php echo h($date_start); ?>" onchange="this.form.submit()">
          </div>
          <div class="filter-item">
              <label>Hingga Tarikh:</label>
              <input type="date" name="date_end" value="<?php echo h($date_end); ?>" onchange="this.form.submit()">
          </div>
          <div style="align-self:flex-end;">
              <a href="admin_rental.php" class="btn secondary">Reset Filter</a>
          </div>
      </form>

      <div style="overflow-x:auto;">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Fasiliti</th>
                <th>Pemohon</th>
                <th>Tarikh & Masa</th>
                <th>Bayaran (RM)</th>
                <th>Status</th>
                <th>Tindakan</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($bookings)): ?>
                <tr><td colspan="7" style="text-align:center; padding:30px; color:#888;">Tiada tempahan ditemui.</td></tr>
              <?php else: foreach ($bookings as $b): 
                  $st = $b['status'] ?? 'Pending';
                  $cls = 'pending';
                  if ($st==='Confirmed') $cls='confirmed';
                  elseif ($st==='Rejected') $cls='rejected';
                  elseif ($st==='Awaiting Payment') $cls='await';
              ?>
                <tr>
                  <td>#<?php echo (int)$b['booking_id']; ?></td>
                  <td><?php echo h($b['facility_name']); ?></td>
                  <td>
                    <div style="font-weight:600;"><?php echo h($b['contact_name']); ?></div>
                    <div style="font-size:12px; color:#888;"><?php echo h($b['contact_phone']); ?></div>
                  </td>
                  <td>
                    <?php echo h(date("d M Y", strtotime($b['booking_date']))); ?><br>
                    <span style="font-size:12px; color:#666;">
                        <?php if (($b['price_unit'] ?? 'Hour') === 'Day'): ?>
                            <?php echo h((int)$b['duration_hours']/24); ?> Hari
                        <?php else: ?>
                            <?php echo h(substr($b['start_time'],0,5)); ?> • <?php echo h((int)$b['duration_hours']); ?> Jam
                        <?php endif; ?>
                    </span>
                  </td>
                  <td><strong><?php echo h(number_format((float)$b['total_amount'],2)); ?></strong></td>
                  <td><span class="pill <?php echo h($cls); ?>"><?php echo h($st); ?></span></td>
                  <td>
                    <div style="display:flex; gap:5px;">
                        <?php if ($st !== 'Confirmed' && $st !== 'Rejected'): ?>
                            <a class="btn" style="padding:6px 12px; font-size:12px;" href="admin_rental.php?action=verify&id=<?php echo (int)$b['booking_id']; ?>" title="Minta Bayaran"><i class="fas fa-file-invoice-dollar"></i></a>
                            <a class="btn secondary" style="padding:6px 12px; font-size:12px;" href="admin_rental.php?action=confirm&id=<?php echo (int)$b['booking_id']; ?>" title="Luluskan"><i class="fas fa-check"></i></a>
                            <a class="btn danger" style="padding:6px 12px; font-size:12px;" href="admin_rental.php?action=reject&id=<?php echo (int)$b['booking_id']; ?>" title="Tolak" onclick="return confirm('Tolak tempahan ini?')"><i class="fas fa-times"></i></a>
                        <?php else: ?>
                            <a class="btn danger" style="padding:6px 12px; font-size:12px;" href="admin_rental.php?action=delete_booking&id=<?php echo (int)$b['booking_id']; ?>" title="Padam Rekod" onclick="return confirm('Padam rekod tempahan ini secara kekal?')"><i class="fas fa-trash"></i></a>
                        <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
      </div>
    </section>

</main>

</body>
</html>