<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "communication_kampung";

$DB_ERROR = null;
$conn = @mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    $DB_ERROR = "DB connection failed. Pastikan database 'communication_kampung' telah di-import dan XAMPP/MySQL berjalan.";

    $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $isAjax = (strpos($script, 'ajax_') === 0) || ($script === 'ajax_calendar.php');

    // For AJAX endpoints → must return JSON + stop
    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(500);
        echo json_encode(["ok"=>false, "error"=>$DB_ERROR], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // For normal pages → DO NOT exit; allow page to render without DB
    $conn = null;
} else {
    mysqli_set_charset($conn, "utf8mb4");
}
?>

