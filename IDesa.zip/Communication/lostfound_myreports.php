<?php
session_start();
include "db_connect.php";
include "navbar.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Laporan Saya (Barang Hilang & Jumpa)</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --primary:#2d6a4f; --brown:#6d4c41; --text:#333; --muted:#6b7280; --bg:#f7faf7; --card:#fff; }
        body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text); }
        nav { display:flex; justify-content:space-between; align-items:center; padding:20px 8%; background:#fff; box-shadow:0 2px 10px rgba(0,0,0,0.05); position:sticky; top:0; z-index:1000; }
        .logo { font-size:28px; font-weight:bold; color:var(--primary); text-decoration:none; }
        .logo span { color:var(--brown); }
        .nav-links { display:flex; gap:18px; align-items:center; flex-wrap:wrap; }
        .nav-links a { text-decoration:none; color:#555; font-weight:500; transition:.2s; }
        .nav-links a:hover { color:var(--primary); }
        .btn-pill { background:var(--primary); color:white !important; padding:10px 18px; border-radius:999px; font-size:14px; }
        .btn-outline { border:1px solid var(--primary); color:var(--primary) !important; padding:10px 18px; border-radius:999px; font-size:14px; background:#fff; }

        .wrap { padding:26px 8% 70px; }
        .head { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; }
        .title { margin:0; font-size:28px; color:var(--primary); }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; max-width:920px; }

        .panel { margin-top:18px; background:var(--card); border:1px solid #eaeaea; border-radius:16px; padding:16px; box-shadow:0 8px 24px rgba(0,0,0,0.04); }
        .filters { display:flex; gap:10px; flex-wrap:wrap; align-items:center; justify-content:space-between; }
        .filters .left { display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
        select, input { padding:10px 12px; border-radius:12px; border:1px solid #e5e7eb; font-family:inherit; outline:none; background:#fff; }
        .pill { display:inline-flex; gap:6px; align-items:center; padding:6px 10px; border-radius:999px; border:1px solid #e5e7eb; background:#fff; font-size:13px; color:var(--muted); }

        .grid { margin-top:14px; display:grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap:14px; }
        .card { background:#fff; border:1px solid #eaeaea; border-radius:16px; overflow:hidden; box-shadow:0 10px 26px rgba(0,0,0,0.04); cursor:pointer; transition:.15s; }
        .card:hover { transform: translateY(-2px); border-color:#d7eadf; }
        .thumb { height:150px; background:#f3f4f6; display:flex; align-items:center; justify-content:center; color:#9ca3af; }
        .thumb img { width:100%; height:100%; object-fit:cover; display:block; }
        .card-body { padding:14px; }
        .item-title { margin:0; font-size:16px; font-weight:800; color:#111827; line-height:1.25; }
        .item-sub { margin:8px 0 0; color:var(--muted); font-size:13px; }
        .card-foot { margin-top:10px; display:flex; justify-content:space-between; align-items:center; gap:10px; color:var(--muted); font-size:12px; }

        .badge { display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border-radius:999px; font-weight:800; font-size:12px; }
        .badge-lost { background:#fff1f2; color:#9f1239; border:1px solid #fecdd3; }
        .badge-found { background:#ecfeff; color:#155e75; border:1px solid #a5f3fc; }
        .badge-pending { background:#fffbeb; color:#92400e; border:1px solid #fde68a; }
        .badge-published { background:#f0fdf4; color:#166534; border:1px solid #bbf7d0; }
        .badge-claimed { background:#eff6ff; color:#1e3a8a; border:1px solid #bfdbfe; }
        .badge-rejected { background:#fef2f2; color:#7f1d1d; border:1px solid #fecaca; }

        .state { margin-top:14px; text-align:center; color:var(--muted); padding:22px; border:1px dashed #d1d5db; border-radius:16px; background:#fff; display:none; }
        .btn { padding:10px 14px; border-radius:12px; border:0; cursor:pointer; font-weight:800; }
        .btn-soft { background:#ecf5ef; color:var(--primary); }

        /* Modal */
        .modal-backdrop { position:fixed; inset:0; background:rgba(0,0,0,.45); display:none; align-items:center; justify-content:center; padding:16px; z-index:2000; }
        .modal { width:min(920px, 100%); background:#fff; border-radius:18px; overflow:hidden; box-shadow:0 30px 70px rgba(0,0,0,.25); }
        .modal-head { padding:14px 16px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #eee; }
        .modal-head h3 { margin:0; font-size:16px; color:var(--primary); }
        .modal-close { background:transparent; border:0; cursor:pointer; font-size:18px; color:#6b7280; }
        .modal-body { padding:16px; display:grid; grid-template-columns: 1.05fr 0.95fr; gap:16px; }
        .modal-img { background:#f3f4f6; border-radius:14px; overflow:hidden; min-height:260px; display:flex; align-items:center; justify-content:center; color:#9ca3af; }
        .modal-img img { width:100%; height:100%; object-fit:cover; }
        .meta { display:flex; flex-wrap:wrap; gap:8px; margin:8px 0 10px; }
        .kv { margin:0; color:#111827; font-size:14px; }
        .kv span { color:var(--muted); font-weight:500; }
        .desc { margin-top:10px; padding:12px; border:1px solid #eee; border-radius:14px; background:#fafafa; white-space:pre-wrap; font-size:14px; }
        @media (max-width: 860px){ .modal-body{ grid-template-columns:1fr; } }
    </style>
</head>

<body>
    <a href="lostfound_report.php" class="btn-pill" style="display:inline-flex; align-items:center; gap:8px; margin: 20px 0 0 8%; text-decoration:none;">
        <i class="fa-solid fa-arrow-left-long"></i> Kembali
    </a>

<div class="wrap">
    <div class="head">
        <div>
            <h1 class="title">Laporan Saya</h1>
            <p class="sub">Semua laporan yang anda buat akan dipaparkan di sini bersama status semasa (Menunggu / Dipaparkan / Selesai / Ditolak).</p>
        </div>
    </div>

    <div class="panel">
        <div class="filters">
            <div class="left">
                <select id="status">
                    <option value="">Semua Status</option>
                    <option value="Pending">Menunggu</option>
                    <option value="Published">Dipaparkan</option>
                    <option value="Claimed">Selesai</option>
                    <option value="Rejected">Ditolak</option>
                </select>
                <span class="pill" id="countPill"><i class="fa-solid fa-list"></i> <span id="countText">Memuat...</span></span>
            </div>
            <button class="btn btn-soft" onclick="loadMyReports()"><i class="fa-solid fa-rotate"></i> Muat Semula</button>
        </div>

        <div id="grid" class="grid"></div>

        <div id="state" class="state">
            <i class="fa-regular fa-face-smile"></i>
            <div id="stateText">Tiada laporan.</div>
        </div>
    </div>
</div>

<div class="modal-backdrop" id="modalBackdrop" onclick="closeModal(event)">
    <div class="modal" onclick="event.stopPropagation();">
        <div class="modal-head">
            <h3 id="modalTitle">Butiran Laporan</h3>
            <button class="modal-close" onclick="hideModal()"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body">
            <div class="modal-img" id="modalImg">
                <div><i class="fa-regular fa-image"></i> Tiada Gambar</div>
            </div>
            <div>
                <div class="meta" id="modalBadges"></div>

                <p class="kv"><span>ID:</span> <span id="mId">-</span></p>
                <p class="kv"><span>Jenis:</span> <span id="mType">-</span></p>
                <p class="kv"><span>Kategori:</span> <span id="mCategory">-</span></p>
                <p class="kv"><span>Lokasi:</span> <span id="mLocation">-</span></p>
                <p class="kv"><span>Tarikh Kejadian:</span> <span id="mIncident">-</span></p>
                <p class="kv"><span>Status:</span> <span id="mStatus">-</span></p>
                <p class="kv"><span>Tarikh Laporan:</span> <span id="mCreated">-</span></p>

                <div class="desc" id="mDesc">-</div>

                <div style="margin-top:12px;">
                    <div style="font-weight:800; margin-bottom:6px;">Nota AJK (jika ada)</div>
                    <div class="desc" id="mRemarks" style="min-height:auto;">-</div>
                </div>

                <div class="small" style="margin-top:10px; color:var(--muted);">
                    * Jika AJK meminta maklumat tambahan, sila buat laporan baharu dengan maklumat lengkap (atau hubungi AJK).
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    const AJAX_URL = "lostfound_ajax.php";

    const CAT_BM = {
        "Electronics":"Elektronik","Documents":"Dokumen","Wallet/Purse":"Dompet / Beg","Keys":"Kunci",
        "Pets":"Haiwan","Clothing":"Pakaian","Other":"Lain-lain"
    };
    const TYPE_BM = { "Lost":"Hilang", "Found":"Jumpa" };

    const grid = document.getElementById("grid");
    const state = document.getElementById("state");
    const stateText = document.getElementById("stateText");
    const countText = document.getElementById("countText");
    const statusEl = document.getElementById("status");

    statusEl.addEventListener("change", loadMyReports);

    function esc(s){ return (s ?? "").toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

    function badgeType(type){
        const cls = (type === "Lost") ? "badge-lost" : "badge-found";
        const text = TYPE_BM[type] || type || "-";
        return `<span class="badge ${cls}"><i class="fa-solid fa-tag"></i> ${esc(text)}</span>`;
    }
    function badgeStatus(st){
        if(st === "Pending") return `<span class="badge badge-pending"><i class="fa-solid fa-hourglass-half"></i> Menunggu</span>`;
        if(st === "Published") return `<span class="badge badge-published"><i class="fa-solid fa-bullhorn"></i> Dipaparkan</span>`;
        if(st === "Claimed") return `<span class="badge badge-claimed"><i class="fa-solid fa-flag-checkered"></i> Selesai</span>`;
        if(st === "Rejected") return `<span class="badge badge-rejected"><i class="fa-solid fa-ban"></i> Ditolak</span>`;
        return `<span class="badge"><i class="fa-solid fa-circle"></i> ${esc(st || "-")}</span>`;
    }

    function render(items){
        if(!Array.isArray(items) || items.length === 0){
            grid.innerHTML = "";
            state.style.display = "block";
            stateText.textContent = "Tiada laporan untuk status yang dipilih.";
            countText.textContent = "0 rekod";
            return;
        }

        state.style.display = "none";
        countText.textContent = items.length + " rekod";

        grid.innerHTML = items.map(it => {
            const imgHtml = it.image_url
                ? `<img src="${esc(it.image_url)}" alt="Gambar">`
                : `<div><i class="fa-regular fa-image"></i> Tiada Gambar</div>`;

            const catText = CAT_BM[it.category] || it.category || "-";

            return `
                <div class="card" onclick="openDetail(${it.report_id})">
                    <div class="thumb">${imgHtml}</div>
                    <div class="card-body">
                        ${badgeType(it.type)} ${badgeStatus(it.status)}
                        <h3 class="item-title" style="margin-top:10px;">${esc(it.item_name || "-")}</h3>
                        <p class="item-sub"><i class="fa-solid fa-layer-group"></i> ${esc(catText)}</p>
                        <p class="item-sub"><i class="fa-solid fa-location-dot"></i> ${esc(it.location_detail || "-")}</p>
                        <div class="card-foot">
                            <span><i class="fa-regular fa-calendar"></i> ${esc(it.incident_date || "-")}</span>
                            <span><i class="fa-regular fa-eye"></i> Lihat</span>
                        </div>
                    </div>
                </div>
            `;
        }).join("");
    }

    async function loadMyReports(){
        grid.innerHTML = `<div class="state" style="grid-column:1/-1; display:block;"><i class="fa-solid fa-spinner fa-spin"></i><div>Memuatkan...</div></div>`;
        state.style.display = "none";
        countText.textContent = "Memuat...";

        try{
            const params = new URLSearchParams({ action:"myreports" });
            if(statusEl.value) params.append("status", statusEl.value);

            const res = await fetch(`${AJAX_URL}?${params.toString()}`, { credentials:"same-origin" });
            const data = await res.json();
            if(!data || data.ok !== true) throw new Error((data && data.error) ? data.error : "Gagal memuat laporan.");
            render(data.items || []);
        } catch(err){
            console.warn(err);
            grid.innerHTML = "";
            state.style.display = "block";
            stateText.textContent = "Ralat memuat laporan: " + (err.message || "Tidak diketahui");
            countText.textContent = "Ralat";
        }
    }

    // Modal detail (reuse detail endpoint)
    const modalBackdrop = document.getElementById("modalBackdrop");
    const modalTitle = document.getElementById("modalTitle");
    const modalImg = document.getElementById("modalImg");
    const modalBadges = document.getElementById("modalBadges");
    const mId = document.getElementById("mId");
    const mType = document.getElementById("mType");
    const mCategory = document.getElementById("mCategory");
    const mLocation = document.getElementById("mLocation");
    const mIncident = document.getElementById("mIncident");
    const mStatus = document.getElementById("mStatus");
    const mCreated = document.getElementById("mCreated");
    const mDesc = document.getElementById("mDesc");
    const mRemarks = document.getElementById("mRemarks");

    function showModal(){ modalBackdrop.style.display = "flex"; document.body.style.overflow = "hidden"; }
    function hideModal(){ modalBackdrop.style.display = "none"; document.body.style.overflow = ""; }
    function closeModal(e){ if(e.target === modalBackdrop) hideModal(); }

    async function openDetail(id){
        showModal();
        modalTitle.textContent = "Memuatkan...";
        modalImg.innerHTML = `<div><i class="fa-solid fa-spinner fa-spin"></i> Memuat...</div>`;
        modalBadges.innerHTML = "";
        mId.textContent = "-"; mType.textContent = "-"; mCategory.textContent = "-";
        mLocation.textContent = "-"; mIncident.textContent = "-"; mStatus.textContent = "-";
        mCreated.textContent = "-"; mDesc.textContent = "-"; mRemarks.textContent = "-";

        try{
            const res = await fetch(`${AJAX_URL}?action=detail&id=${id}`, { credentials:"same-origin" });
            const data = await res.json();
            if(!data || data.ok !== true) throw new Error((data && data.error) ? data.error : "Gagal memuat butiran.");
            const it = data.item;

            modalTitle.textContent = it.item_name || "Butiran Laporan";
            modalBadges.innerHTML = badgeType(it.type) + " " + badgeStatus(it.status);
            mId.textContent = "#" + it.report_id;
            mType.textContent = TYPE_BM[it.type] || it.type || "-";
            mCategory.textContent = CAT_BM[it.category] || it.category || "-";
            mLocation.textContent = it.location_detail || "-";
            mIncident.textContent = it.incident_date || "-";
            mStatus.innerHTML = badgeStatus(it.status);
            mCreated.textContent = it.created_at || "-";
            mDesc.textContent = it.description || "-";
            mRemarks.textContent = it.admin_remarks ? it.admin_remarks : "-";

            if(it.image_url){
                modalImg.innerHTML = `<img src="${esc(it.image_url)}" alt="Gambar">`;
            } else {
                modalImg.innerHTML = `<div><i class="fa-regular fa-image"></i> Tiada Gambar</div>`;
            }

        } catch(err){
            console.warn(err);
            modalTitle.textContent = "Ralat";
            modalImg.innerHTML = `<div><i class="fa-solid fa-triangle-exclamation"></i> Tidak dapat memuat butiran.</div>`;
            mDesc.textContent = err.message || "Ralat tidak dijangka.";
        }
    }

    // init
    loadMyReports();
</script>
</body>
</html>
<?php
include "footer.php";
?>