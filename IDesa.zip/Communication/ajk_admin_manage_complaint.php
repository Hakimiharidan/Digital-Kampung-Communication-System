<?php
session_start();
include "db_connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$role = $_SESSION['role'] ?? 'Resident';
if (!($role === 'AJK' || $role === 'Admin')) {
    header("Location: homepage.php");
    exit();
}

// If open with id → redirect to detail view page (admin_view_complaint)
$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    header("Location: admin_view_complaint.php?id=" . $id);
    exit();
}

// HTML escape helper
if (!function_exists('h')) {
  function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

/**
 * ✅ FIX: Proper dynamic bind helper
 */
if (!function_exists('bind_stmt_params')) {
    function bind_stmt_params($stmt, string $types, array &$params): bool {
        if (!$stmt) return false;

        $bind = [];
        $bind[] = $stmt;
        $bind[] = $types;

        foreach ($params as $k => $v) {
            $bind[] = &$params[$k];
        }

        return call_user_func_array('mysqli_stmt_bind_param', $bind);
    }
}

$full_name = $_SESSION['full_name'] ?? 'Pengguna';

$statusBM = [
    'New' => 'Baru',
    'Reviewed' => 'Disemak',
    'In Progress' => 'Dalam Tindakan',
    'Resolved' => 'Selesai',
];
$statusBadge = [
    'New' => 'b-new',
    'Reviewed' => 'b-reviewed',
    'In Progress' => 'b-progress',
    'Resolved' => 'b-resolved',
];

function countComplaintsGlobal($conn, $type) {
    if (!$conn) return 0;
    if ($type === 'new') {
        $sql = "SELECT COUNT(*) AS total FROM complaints WHERE (status = 'New' OR status = '' OR status IS NULL)";
    } elseif ($type === 'progress') {
        $sql = "SELECT COUNT(*) AS total FROM complaints WHERE status IN ('Reviewed','In Progress')";
    } elseif ($type === 'resolved') {
        $sql = "SELECT COUNT(*) AS total FROM complaints WHERE status = 'Resolved'";
    } else {
        $sql = "SELECT COUNT(*) AS total FROM complaints";
    }

    $res = mysqli_query($conn, $sql);
    $row = $res ? mysqli_fetch_assoc($res) : null;
    return (int)($row['total'] ?? 0);
}

// Filters
$filter = trim($_GET['status'] ?? 'all');
$q = trim($_GET['q'] ?? '');

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;

$where = " WHERE 1=1 ";
$types = "";
$params = [];

// Status filter
if ($filter === 'new') {
    $where .= " AND (c.status = 'New' OR c.status = '' OR c.status IS NULL) ";
} elseif ($filter === 'progress') {
    $where .= " AND c.status IN ('Reviewed','In Progress') ";
} elseif ($filter === 'resolved') {
    $where .= " AND c.status = 'Resolved' ";
} elseif (in_array($filter, ['New','Reviewed','In Progress','Resolved'], true)) {
    $where .= " AND c.status = ? ";
    $types .= "s";
    $params[] = $filter;
}

// Search
if ($q !== '') {
    $like = '%' . $q . '%';
    $where .= " AND (c.title LIKE ? OR c.description LIKE ? OR c.complaint_name LIKE ? OR COALESCE(u.full_name,'') LIKE ?) ";
    $types .= "ssss";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

// Count for pagination
$totalRows = 0;
$rows = [];

if ($conn) {
    $sqlCount = "SELECT COUNT(*) AS total
                 FROM complaints c
                 LEFT JOIN users u ON u.user_id = c.user_id" . $where;

    $stmtC = mysqli_prepare($conn, $sqlCount);
    if ($stmtC) {
        $paramsCount = $params; // copy so references are stable
        if ($types !== '') {
            bind_stmt_params($stmtC, $types, $paramsCount);
        }
        mysqli_stmt_execute($stmtC);
        $resC = mysqli_stmt_get_result($stmtC);
        $rowC = $resC ? mysqli_fetch_assoc($resC) : null;
        $totalRows = (int)($rowC['total'] ?? 0);
        mysqli_stmt_close($stmtC);
    }

    $sql = "SELECT c.id, c.title, c.status, c.created_at,
                   COALESCE(u.full_name, c.complaint_name) AS complainant
            FROM complaints c
            LEFT JOIN users u ON u.user_id = c.user_id" . $where . "
            ORDER BY c.created_at DESC
            LIMIT ? OFFSET ?";

    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        $types2 = $types . "ii";
        $params2 = $params;
        $params2[] = $perPage;
        $params2[] = $offset;

        bind_stmt_params($stmt, $types2, $params2);

        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($res && ($r = mysqli_fetch_assoc($res))) {
            $rows[] = $r;
        }
        mysqli_stmt_close($stmt);
    }
}

$totalPages = max(1, (int)ceil($totalRows / $perPage));
if ($page > $totalPages) { $page = $totalPages; }

$c_new = countComplaintsGlobal($conn, 'new');
$c_progress = countComplaintsGlobal($conn, 'progress');
$c_resolved = countComplaintsGlobal($conn, 'resolved');
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>i-Desa | Semak Aduan</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --primary-green:#2d6a4f; --accent-brown:#6d4c41; --text-dark:#333; --bg:#f7faf7; --card:#fff; --muted:#6b7280; }
        *{ box-sizing:border-box; }
        body { margin:0; font-family:'Poppins',sans-serif; background:var(--bg); color:var(--text-dark); }
        nav { display:flex; justify-content:space-between; align-items:center; padding:16px 8%; background:var(--card); box-shadow:0 4px 10px rgba(0,0,0,0.05); position:sticky; top:0; z-index:1000; }
        .logo { font-size:28px; font-weight:800; color:var(--primary-green); text-decoration:none; }
        .logo span { color:var(--accent-brown); }
        .nav-links { display:flex; gap:18px; align-items:center; flex-wrap:wrap; }
        .nav-links a { text-decoration:none; color:#555; font-weight:600; transition:.2s; }
        .nav-links a:hover { color:var(--primary-green); }
        .btn-pill { background:var(--primary-green); color:#fff !important; padding:10px 18px; border-radius:999px; font-size:14px; display:inline-flex; align-items:center; gap:8px; }
        .btn-outline { border:1px solid var(--primary-green); color:var(--primary-green) !important; padding:10px 18px; border-radius:999px; font-size:14px; background:#fff; display:inline-flex; align-items:center; gap:8px; }
        .wrap { padding:26px 8% 60px; }
        .head { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap; margin-bottom:18px; }
        .title { margin:0; font-size:28px; color:var(--primary-green); }
        .sub { margin:6px 0 0; color:var(--muted); font-size:14px; }
        .card { background:var(--card); border-radius:16px; padding:18px; box-shadow:0 8px 20px rgba(0,0,0,0.06); border:1px solid rgba(0,0,0,0.04); }
        .grid { display:grid; gap:14px; }
        .grid-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        @media (max-width: 980px){ .grid-3{ grid-template-columns:1fr; } nav{padding:14px 5%;} .wrap{padding:20px 5% 50px;} }
        .stat { display:flex; justify-content:space-between; align-items:flex-end; gap:12px; padding:18px; border-radius:16px; background:linear-gradient(180deg, rgba(45,106,79,0.08), rgba(45,106,79,0.02)); border:1px solid rgba(45,106,79,0.12); }
        .stat .k { font-size:12px; letter-spacing:.08em; text-transform:uppercase; color:var(--muted); font-weight:800; }
        .stat .v { font-size:40px; font-weight:900; line-height:1; color:#1f2937; margin-top:6px; }
        .stat .ico { font-size:22px; color:var(--primary-green); opacity:.9; }
        .table { width:100%; border-collapse:collapse; }
        .table th, .table td { padding:12px 12px; border-bottom:1px solid rgba(0,0,0,0.06); text-align:left; font-size:14px; }
        .table th { font-size:12px; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); }
        .row-actions a{ font-weight:800; color:var(--primary-green); text-decoration:none; }
        .row-actions a:hover{ text-decoration:underline; }
        .badge { display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:999px; font-weight:800; font-size:12px; }
        .b-new{ background:#f1f5f9; color:#334155; }
        .b-reviewed{ background:#fff7ed; color:#9a3412; }
        .b-progress{ background:#eff6ff; color:#1d4ed8; }
        .b-resolved{ background:#dcfce7; color:#166534; }
        .muted{ color:var(--muted); font-size:13px; }
        .filters { display:flex; gap:10px; flex-wrap:wrap; }
        .filters input, .filters select{ padding:10px 12px; border-radius:12px; border:1px solid rgba(0,0,0,0.12); font-family:inherit; }
        .pager{ display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-top:14px; }
        .panel { display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
        .panel .btn-pill, .panel .btn-outline { padding:10px 14px; }
        .footer { text-align:center; margin-top:26px; color:var(--muted); font-size:13px; }
    </style>
</head>
<body>

<nav>
    <a href="homepage.php" class="logo">i-<span>Desa</span></a>
    <div class="nav-links">
        <a href="homepage.php">Laman Utama</a>
        <a href="complaint.php" class="btn-outline"><i class="fa-solid fa-bullhorn"></i> Modul Aduan</a>
        <a href="ajk_dashboard.php" class="btn-pill"><i class="fa-solid fa-gauge"></i> Papan Pemuka</a>
        <a href="logout.php" title="Log Keluar"><i class="fas fa-sign-out-alt"></i></a>
    </div>
</nav>

<div class="wrap">
    <div class="head">
        <div>
            <h1 class="title">Urus / Semak Aduan</h1>
            <p class="sub">Selamat datang, <strong><?php echo h($full_name); ?></strong>. Gunakan carian & penapis untuk semak aduan dengan cepat.</p>
        </div>
        <div class="panel">
            <a class="btn-outline" href="complaint.php"><i class="fa-solid fa-house"></i> Ringkasan</a>
            <a class="btn-pill" href="ajk_admin_manage_complaint.php"><i class="fa-solid fa-screwdriver-wrench"></i> Urus Aduan</a>
        </div>
    </div>

    <div class="grid grid-3">
        <div class="stat"><div><div class="k">Aduan Baru</div><div class="v"><?php echo (int)$c_new; ?></div></div><div class="ico"><i class="fa-solid fa-circle-plus"></i></div></div>
        <div class="stat"><div><div class="k">Dalam Proses</div><div class="v"><?php echo (int)$c_progress; ?></div></div><div class="ico"><i class="fa-solid fa-spinner"></i></div></div>
        <div class="stat"><div><div class="k">Selesai</div><div class="v"><?php echo (int)$c_resolved; ?></div></div><div class="ico"><i class="fa-solid fa-circle-check"></i></div></div>
    </div>

    <div style="height:14px;"></div>

    <div class="card">
        <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; align-items:flex-end;">
            <div>
                <h2 style="margin:0; font-size:18px; color:var(--primary-green);">Senarai Aduan</h2>
                <p class="muted" style="margin:6px 0 0;">Klik <strong>Semak</strong> untuk lihat butiran & kemaskini status.</p>
            </div>
            <form method="GET" class="filters">
                <select name="status">
                    <option value="all" <?php echo ($filter==='all')?'selected':''; ?>>Semua Status</option>
                    <option value="new" <?php echo ($filter==='new')?'selected':''; ?>>Baru</option>
                    <option value="progress" <?php echo ($filter==='progress')?'selected':''; ?>>Dalam Proses</option>
                    <option value="resolved" <?php echo ($filter==='resolved')?'selected':''; ?>>Selesai</option>
                </select>
                <input type="text" name="q" placeholder="Cari tajuk / pengadu..." value="<?php echo h($q); ?>">
                <button class="btn-pill" type="submit" style="border:none; cursor:pointer;"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
            </form>
        </div>

        <div style="overflow:auto; margin-top:12px;">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pengadu</th>
                        <th>Tajuk</th>
                        <th>Tarikh</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="muted">Tiada rekod yang sepadan.</td></tr>
                <?php else: foreach ($rows as $r):
                    $stRaw = $r['status'] ?? 'New';
                    $st = ($stRaw === '' || $stRaw === null) ? 'New' : $stRaw;
                    $bm = $statusBM[$st] ?? $st;
                    $badge = $statusBadge[$st] ?? 'b-new';
                ?>
                    <tr>
                        <td>#AD-<?php echo (int)$r['id']; ?></td>
                        <td><?php echo h($r['complainant'] ?? '-'); ?></td>
                        <td><?php echo h($r['title'] ?? ''); ?></td>
                        <td><?php echo h(date('d/m/Y', strtotime($r['created_at'] ?? 'now'))); ?></td>
                        <td><span class="badge <?php echo h($badge); ?>"><?php echo h($bm); ?></span></td>
                        <td class="row-actions"><a href="ajk_admin_view_complaint.php?id=<?php echo (int)$r['id']; ?>">Semak</a></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>

        <div class="pager">
            <div class="muted">Jumlah rekod: <strong><?php echo (int)$totalRows; ?></strong></div>
            <div class="panel">
                <?php $base = "ajk_admin_manage_complaint.php?status=" . urlencode($filter) . "&q=" . urlencode($q); ?>
                <a class="btn-outline" href="<?php echo h($base . "&page=" . max(1, $page-1)); ?>" <?php echo ($page<=1)?'style="pointer-events:none; opacity:.55;"':''; ?>><i class="fa-solid fa-arrow-left"></i> Sebelum</a>
                <a class="btn-outline" href="<?php echo h($base . "&page=" . min($totalPages, $page+1)); ?>" <?php echo ($page>=$totalPages)?'style="pointer-events:none; opacity:.55;"':''; ?>>Seterus <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </div>
    </div>

    <div class="footer">Sistem Komunikasi Kampung &copy; <?php echo date('Y'); ?></div>
</div>

</body>
</html>
