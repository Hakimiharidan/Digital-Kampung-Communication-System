<?php
session_start();
$NAV_ACTIVE = 'privacy_policy.php';
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>i-Desa | Dasar Privasi</title>

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
    :root{
      --primary-green:#2d6a4f;
      --bg:#f7faf7;
      --card:#fff;
      --text:#1f2937;
      --muted:#6b7280;
      --border: rgba(0,0,0,.08);
    }
    *{ box-sizing:border-box; }
    body{
      margin:0;
      font-family:'Poppins',sans-serif;
      background:var(--bg);
      color:var(--text);
      min-height:100vh;
      display:flex;
      flex-direction:column;
    }
    .wrap{ padding: 26px 8% 20px; flex:1; }
    @media (max-width: 980px){ .wrap{ padding: 20px 5% 16px; } }

    .card{
      background: var(--card);
      border:1px solid var(--border);
      border-radius: 16px;
      padding: 18px;
      box-shadow: 0 10px 24px rgba(0,0,0,.06);
    }

    h1{
      margin:0 0 6px;
      color: var(--primary-green);
      font-size: 28px;
    }
    .sub{
      margin:0 0 14px;
      color: var(--muted);
      font-size: 14px;
      line-height:1.7;
    }

    .toc{
      display:flex;
      flex-wrap:wrap;
      gap: 10px;
      margin: 12px 0 16px;
    }
    .toc a{
      text-decoration:none;
      font-weight: 900;
      color: var(--primary-green);
      border:1px solid rgba(45,106,79,.20);
      background: rgba(45,106,79,.06);
      padding: 8px 12px;
      border-radius: 999px;
      font-size: 13px;
    }
    .toc a:hover{
      background: rgba(45,106,79,.10);
    }

    .section{
      padding-top: 8px;
    }
    .section h2{
      margin: 16px 0 8px;
      font-size: 18px;
      color: var(--primary-green);
    }
    .section p, .section li{
      color: var(--muted);
      line-height: 1.8;
      font-size: 14px;
    }
    ul{ margin: 8px 0 0 20px; }
    .hr{ height:1px; background:rgba(0,0,0,.07); margin: 14px 0; }
    .note{
      border:1px solid rgba(45,106,79,.20);
      background: rgba(45,106,79,.06);
      border-radius: 14px;
      padding: 12px 14px;
      font-size: 14px;
      color:#374151;
      line-height:1.7;
      margin-top: 10px;
    }
    .note strong{ color: var(--primary-green); }
  </style>
</head>

<body>
<?php include "navbar.php"; ?>

<div class="wrap">
  <div class="card">
    <h1>Dasar Privasi</h1>
    <p class="sub">
      Dokumen ini menerangkan bagaimana i-Desa mengumpul, menggunakan, menyimpan dan melindungi maklumat pengguna.
      Dengan menggunakan sistem ini, anda bersetuju dengan dasar privasi ini.
      <br><strong>Kemaskini terakhir:</strong> <?php echo date("d/m/Y"); ?>
    </p>

    <div class="toc" aria-label="Isi Kandungan">
      <a href="#data">Maklumat Dikumpul</a>
      <a href="#usage">Kegunaan</a>
      <a href="#sharing">Perkongsian</a>
      <a href="#security">Keselamatan</a>
      <a href="#retention">Penyimpanan</a>
      <a href="#rights">Hak Pengguna</a>
      <a href="#contact">Hubungi</a>
    </div>

    <div class="hr"></div>

    <div class="section" id="data">
      <h2>1) Maklumat yang Kami Kumpul</h2>
      <p>i-Desa mungkin mengumpul maklumat berikut apabila anda mendaftar dan menggunakan sistem:</p>
      <ul>
        <li>Maklumat profil: nama penuh, nombor telefon, peranan (Resident / AJK / Admin).</li>
        <li>Aktiviti sistem: rekod aduan, maklum balas, tempahan fasiliti, dan interaksi modul.</li>
        <li>Lampiran aduan: gambar yang dimuat naik (jika ada).</li>
      </ul>
    </div>

    <div class="section" id="usage">
      <h2>2) Bagaimana Kami Menggunakan Maklumat</h2>
      <ul>
        <li>Untuk pengesahan akaun dan kawalan akses mengikut peranan pengguna.</li>
        <li>Untuk pengurusan aduan dan komunikasi antara penduduk dan pihak pengurusan kampung.</li>
        <li>Untuk meningkatkan kualiti sistem melalui analisis maklum balas dan penggunaan modul.</li>
      </ul>
    </div>

    <div class="section" id="sharing">
      <h2>3) Perkongsian Maklumat</h2>
      <p>
        Maklumat anda tidak akan dijual kepada pihak ketiga. Namun, maklumat tertentu boleh diakses oleh
        AJK/Admin untuk tujuan pengurusan komuniti (contoh: semakan aduan dan tindakan).
      </p>
      <div class="note">
        <strong>Nota:</strong> Kandungan aduan dan maklum balas anda hanya digunakan untuk pengurusan sistem kampung
        dan penambahbaikan perkhidmatan.
      </div>
    </div>

    <div class="section" id="security">
      <h2>4) Keselamatan Data</h2>
      <ul>
        <li>Akses sistem dilindungi dengan login dan kawalan peranan.</li>
        <li>Maklumat disimpan dalam pangkalan data sistem dan hanya boleh diakses oleh pengguna yang dibenarkan.</li>
        <li>Kami menggalakkan penggunaan kata laluan yang kuat dan tidak dikongsi.</li>
      </ul>
    </div>

    <div class="section" id="retention">
      <h2>5) Tempoh Penyimpanan</h2>
      <p>
        Rekod akan disimpan selagi diperlukan untuk operasi sistem kampung, pematuhan audit dalaman,
        dan rujukan penyelesaian kes.
      </p>
    </div>

    <div class="section" id="rights">
      <h2>6) Hak Pengguna</h2>
      <ul>
        <li>Anda boleh mengemaskini maklumat profil melalui modul profil (jika disediakan).</li>
        <li>Anda boleh memohon pembetulan data jika maklumat tidak tepat.</li>
        <li>Anda boleh hubungi Admin untuk pertanyaan berkaitan data peribadi.</li>
      </ul>
    </div>

    <div class="section" id="contact">
      <h2>7) Hubungi Kami</h2>
      <p>
        Untuk pertanyaan berkaitan privasi, hubungi:
        <br><strong>Email:</strong> admin@idesa.com.my
        <br><strong>Telefon:</strong> +603-8733 1234
      </p>
    </div>

  </div>
</div>

<?php include "footer.php"; ?>
</body>
</html>
