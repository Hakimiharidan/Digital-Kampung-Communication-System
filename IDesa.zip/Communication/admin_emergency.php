<?php
session_start();
include "db_connect.php";

$role = $_SESSION['role'] ?? 'Resident';
if (!isset($_SESSION['user_id']) || !($role === 'AJK' || $role === 'Admin')) {
  header("Location: homepage.php");
  exit();
}

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$flash = "";
$flash_type = "";

// DELETE Logic
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
  $id = (int)$_GET['id'];
  $stmt = mysqli_prepare($conn, "DELETE FROM emergency_contacts WHERE id=?");
  if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    $flash = "Kenalan berjaya dipadam.";
    $flash_type = "success";
  } else {
    $flash = "Ralat: gagal padam kenalan.";
    $flash_type = "error";
  }
}

// SAVE Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_contact'])) {
  $id = (int)($_POST['id'] ?? 0);
  $category = trim((string)($_POST['category'] ?? ''));
  $contact_name = trim((string)($_POST['contact_name'] ?? ''));
  $phone_number = trim((string)($_POST['phone_number'] ?? ''));
  $address = trim((string)($_POST['address'] ?? ''));

  if ($category === '' || $contact_name === '' || $phone_number === '') {
    $flash = "Sila isi kategori, nama dan nombor telefon.";
    $flash_type = "error";
  } else {
    $address = ($address !== '') ? $address : null;

    if ($id > 0) {
      $stmt = mysqli_prepare($conn, "UPDATE emergency_contacts SET category=?, contact_name=?, phone_number=?, address=? WHERE id=?");
      if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssssi", $category, $contact_name, $phone_number, $address, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $flash = "Kenalan berjaya dikemaskini.";
        $flash_type = "success";
      } else {
        $flash = "Ralat: gagal kemaskini.";
        $flash_type = "error";
      }
    } else {
      $stmt = mysqli_prepare($conn, "INSERT INTO emergency_contacts (category, contact_name, phone_number, address) VALUES (?,?,?,?)");
      if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ssss", $category, $contact_name, $phone_number, $address);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $flash = "Kenalan berjaya ditambah.";
        $flash_type = "success";
      } else {
        $flash = "Ralat: gagal tambah.";
        $flash_type = "error";
      }
    }
  }
}

// EDIT Mode
$edit = null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  $stmt = mysqli_prepare($conn, "SELECT * FROM emergency_contacts WHERE id=?");
  if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($res) $edit = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);
  }
}

// List Contacts
$items = [];
$res = mysqli_query($conn, "SELECT * FROM emergency_contacts ORDER BY category ASC, contact_name ASC");
if ($res) while ($r = mysqli_fetch_assoc($res)) $items[] = $r;

?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <title>Admin Kenalan Kecemasan | i-Desa</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    /* Global Reset */
    * { box-sizing: border-box; }
    :root { 
        --primary: #2d6a4f; 
        --dark: #143d29; /* Deep Green Theme */
        --bg: #f4f7f6; 
        --card: #fff; 
        --text: #333; 
        --muted: #6b7280; 
    }
    
    body { margin:0; font-family:'Poppins', sans-serif; background:var(--bg); color:var(--text); display:flex; }

    /* --- SIDEBAR --- */
    .sidebar { width: 250px; height: 100vh; background: var(--dark); padding: 25px 18px; position: fixed; display: flex; flex-direction: column; color: #fff; z-index: 100; overflow-y: auto; box-shadow: 4px 0 15px rgba(0,0,0,0.05); }
    
    .idesa-logo { text-decoration: none; display: flex; align-items: center; gap: 10px; margin-bottom: 35px; padding-left: 5px; }
    .logo-mark { width: 38px; height: 38px; background: linear-gradient(135deg, #22c55e, #16a34a); color: #fff; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); }
    .logo-text { display: flex; flex-direction: column; line-height: 1; }
    .logo-main { font-size: 20px; font-weight: 800; color: #fff; letter-spacing: -0.5px; }
    .logo-main span { color: #4ade80; }
    .logo-sub { font-size: 9px; font-weight: 600; color: #a3b1aa; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px; }

    .nav-menu { display: flex; flex-direction: column; gap: 6px; flex: 1; }
    .nav-item { display: flex; align-items: center; gap: 14px; padding: 12px 18px; color: #b4cfc0; text-decoration: none; border-radius: 12px; font-size: 14px; font-weight: 500; transition: all 0.2s ease; }
    .nav-item:hover { color: #fff; background: rgba(255, 255, 255, 0.05); transform: translateX(3px); }
    .nav-item.active { background: rgba(255, 255, 255, 0.15); color: #ffffff; font-weight: 600; box-shadow: 0 4px 12px rgba(0,0,0,0.1); backdrop-filter: blur(5px); }
    .nav-item i { width: 18px; text-align: center; font-size: 16px; }
    .divider { height: 1px; background: rgba(255,255,255,0.1); margin: 15px 10px; }

    /* --- CONTENT AREA --- */
    .content { margin-left: 250px; padding: 30px; width: calc(100% - 250px); }
    
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
    .header h1 { font-size: 24px; font-weight: 700; color: var(--dark); margin: 0; }

    /* Cards */
    .card { background: var(--card); border-radius: 16px; padding: 25px; box-shadow: 0 4px 6px rgba(0,0,0,0.02); margin-bottom: 20px; border: 1px solid #eee; }
    h3 { margin: 0 0 20px; font-size: 18px; color: var(--text); border-bottom: 1px solid #f0f0f0; padding-bottom: 10px; }

    /* Buttons */
    .btn { padding: 10px 20px; border-radius: 50px; border: 1px solid #ddd; background: #fff; color: #555; cursor: pointer; font-weight: 600; font-size: 14px; transition: 0.2s; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; }
    .btn:hover { background: #f9fafb; transform: translateY(-1px); }
    .btn.primary { background: var(--primary); border-color: var(--primary); color: #fff; }
    .btn.primary:hover { opacity: 0.9; }
    .btn.danger { background: #fee2e2; border-color: #fecaca; color: #b91c1c; }
    .btn.danger:hover { background: #fecaca; }
    .btn.secondary { background: #fff; color: var(--primary); border-color: var(--primary); }

    /* Forms */
    .row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px; }
    label { font-size: 13px; font-weight: 600; color: #444; display: block; margin-bottom: 6px; }
    input, textarea { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 10px; font-size: 14px; outline: none; transition: 0.2s; background: #fff; }
    input:focus, textarea:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(45,106,79,0.1); }
    
    /* Table */
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th { text-align: left; padding: 12px 15px; background: #f9fafb; color: #6b7280; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; border-bottom: 1px solid #e5e7eb; }
    td { padding: 14px 15px; border-bottom: 1px solid #f3f4f6; font-size: 14px; color: #374151; vertical-align: middle; }
    tr:hover td { background: #fafafa; }

    .actions { display: flex; gap: 8px; }
    
    /* Alerts */
    .flash { padding: 12px 15px; border-radius: 10px; font-size: 14px; margin-bottom: 20px; font-weight: 500; display: flex; align-items: center; gap: 10px; }
    .flash.success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
    .flash.error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }

    @media (max-width: 900px) {
        .sidebar { display: none; }
        .content { margin: 0; width: 100%; padding: 20px; }
        .row { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>

<aside class="sidebar">
    <a href="homepage.php" class="idesa-logo">
        <div class="logo-mark"><i class="fas fa-house-chimney-window"></i></div>
        <div class="logo-text">
            <div class="logo-main">i-<span>Desa</span></div>
            <div class="logo-sub">Gerbang Komuniti Pintar</div>
        </div>
    </a>

    <div class="nav-menu">
        <a href="ajk_dashboard.php" class="nav-item active">
            <i class="fas fa-chart-pie"></i> <span>Dashboard</span>
        </a>

        <?php if($role === 'Admin'): ?>
            <a href="manage_users.php" class="nav-item">
                <i class="fas fa-users-cog"></i> <span>Urus Pengguna</span>
            </a>
        <?php endif; ?>

        <a href="manage_notices.php" class="nav-item">
            <i class="fas fa-newspaper"></i> <span>Urus Buletin</span>
        </a>

        <a href="admin_rental.php" class="nav-item">
            <i class="fas fa-building"></i> <span>Tetapan Sewa Fasiliti</span>
        </a>

        
        <?php if($role === 'Admin'): ?>
        <a href="admin_emergency.php" class="nav-item">
            <i class="fas fa-phone-alt"></i> <span>Tetapan Kecemasan</span>
        </a>
         <?php endif; ?>
        
        <a href="ajk_lostfound.php" class="nav-item">
            <i class="fas fa-search"></i> <span>Hilang/Jumpa</span>
        </a>
        
        <a href="ajk_admin_calendar.php" class="nav-item">
            <i class="fas fa-calendar-days"></i> <span>Urus Kalendar</span>
        </a>
        
        <a href="complaint.php" class="nav-item">
            <i class="fas fa-clipboard"></i> <span>Urus Aduan</span>
        </a>
        
        <?php if($role === 'Admin'): ?>
        <a href="report.php" class="nav-item">
            <i class="fas fa-file"></i> <span>Laporan</span>           
        </a>
         <?php endif; ?>
        
    </div>

    <div class="divider"></div>
    <a href="logout.php" class="nav-item">
        <i class="fas fa-sign-out-alt"></i> <span>Log Keluar</span>
    </a>
</aside>

<main class="content">
    <div class="header">
      <h1>Pengurusan Kenalan Kecemasan</h1>
      <a class="btn secondary" href="emergency_contacts.php" target="_blank"><i class="fas fa-external-link-alt"></i> Lihat Paparan Awam</a>
    </div>

    <?php if ($flash): ?>
        <div class="flash <?php echo ($flash_type === 'error') ? 'error' : 'success'; ?>">
            <?php echo ($flash_type === 'error') ? '<i class="fas fa-circle-exclamation"></i>' : '<i class="fas fa-check-circle"></i>'; ?>
            <?php echo h($flash); ?>
        </div>
    <?php endif; ?>

    <section class="card">
      <h3><i class="fas fa-pen-to-square"></i> <?php echo $edit ? "Kemaskini Kenalan" : "Tambah Kenalan Baru"; ?></h3>
      
      <form method="post">
        <input type="hidden" name="id" value="<?php echo (int)($edit['id'] ?? 0); ?>">

        <div class="row">
          <div>
            <label>Kategori</label>
            <input type="text" name="category" required value="<?php echo h($edit['category'] ?? ''); ?>" placeholder="Contoh: Polis / Bomba / Klinik">
          </div>
          <div>
            <label>Nama Kenalan / Organisasi</label>
            <input type="text" name="contact_name" required value="<?php echo h($edit['contact_name'] ?? ''); ?>" placeholder="Contoh: Balai Polis Kampung Baru">
          </div>
        </div>

        <div class="row">
          <div>
            <label>Nombor Telefon</label>
            <input type="text" name="phone_number" required value="<?php echo h($edit['phone_number'] ?? ''); ?>" placeholder="Contoh: 03-12345678">
          </div>
          <div>
            <label>Alamat (Opsyenal)</label>
            <input type="text" name="address" value="<?php echo h($edit['address'] ?? ''); ?>" placeholder="Alamat atau lokasi pejabat">
          </div>
        </div>

        <div style="display:flex; gap:10px; margin-top:20px;">
          <button class="btn primary" type="submit" name="save_contact"><i class="fas fa-save"></i> Simpan</button>
          
          <?php if ($edit): ?>
            <a class="btn secondary" href="admin_emergency.php">Batal</a>
            <a class="btn danger" href="admin_emergency.php?action=delete&id=<?php echo (int)$edit['id']; ?>" onclick="return confirm('Adakah anda pasti mahu memadam kenalan ini?')"><i class="fas fa-trash"></i> Padam</a>
          <?php else: ?>
            <button class="btn secondary" type="reset">Reset</button>
          <?php endif; ?>
        </div>
      </form>
    </section>

    <section class="card">
      <h3><i class="fas fa-list-ul"></i> Senarai Kenalan</h3>
      <div style="overflow-x:auto;">
          <table>
            <thead>
              <tr>
                <th width="50">ID</th>
                <th width="150">Kategori</th>
                <th width="200">Nama</th>
                <th width="150">Telefon</th>
                <th>Alamat</th>
                <th width="120">Tindakan</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($items)): ?>
                <tr><td colspan="6" style="text-align:center; padding:30px; color:#888;">Tiada rekod ditemui.</td></tr>
              <?php else: foreach ($items as $c): ?>
                <tr>
                  <td><?php echo (int)$c['id']; ?></td>
                  <td><span class="badge" style="background:#f3f4f6; padding:4px 8px; border-radius:4px; font-weight:600; font-size:12px;"><?php echo h($c['category']); ?></span></td>
                  <td><strong><?php echo h($c['contact_name']); ?></strong></td>
                  <td><a href="tel:<?php echo h($c['phone_number']); ?>" style="color:var(--primary); text-decoration:none; font-weight:600;"><?php echo h($c['phone_number']); ?></a></td>
                  <td><?php echo h($c['address'] ?? '-'); ?></td>
                  <td class="actions">
                    <a class="btn secondary" style="padding:6px 10px; font-size:12px;" href="admin_emergency.php?edit=<?php echo (int)$c['id']; ?>"><i class="fas fa-pen"></i></a>
                    <a class="btn danger" style="padding:6px 10px; font-size:12px;" href="admin_emergency.php?action=delete&id=<?php echo (int)$c['id']; ?>" onclick="return confirm('Padam kenalan ini?')"><i class="fas fa-trash"></i></a>
                  </td>
                </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
      </div>
    </section>
</main>

</body>
</html>