<?php
// ajax_calendar_notification.php
session_start();
header('Content-Type: application/json; charset=utf-8');

include "db_connect.php";

/* --- HELPERS --- */
function json_out(array $arr, int $code = 200): void {
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit();
}
function json_ok(array $data = []): void { json_out(["ok" => true, "data" => $data], 200); }
function json_fail(string $error, int $code = 400): void { json_out(["ok" => false, "error" => $error], $code); }

function require_login(): void {
    if (!isset($_SESSION['user_id'])) json_fail("Sila log masuk terlebih dahulu.", 401);
}

function current_user_role(): string {
    return (string)($_SESSION['role'] ?? 'Resident');
}

function require_role(array $roles): void {
    $r = current_user_role();
    if (!in_array($r, $roles, true)) json_fail("Akses tidak dibenarkan.", 403);
}

function get_calendar_setting($conn, string $key, $default = null) {
    $stmt = mysqli_prepare($conn, "SELECT setting_value FROM calendar_settings WHERE setting_key = ? LIMIT 1");
    if (!$stmt) return $default;
    mysqli_stmt_bind_param($stmt, "s", $key);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = $res ? mysqli_fetch_assoc($res) : null;
    mysqli_stmt_close($stmt);
    if (!$row) return $default;
    return $row['setting_value'];
}

function pick_notification_type_for_calendar($conn): string {
    // Try to use a nicer category (Calendar) if the DB enum allows it.
    $fallbacks = ['Calendar', 'Reminder', 'System', 'General'];
    $res = mysqli_query($conn, "SHOW COLUMNS FROM notifications LIKE 'type'");
    if (!$res) return 'System';
    $row = mysqli_fetch_assoc($res);
    if (!$row || empty($row['Type'])) return 'System';

    $typeDef = (string)$row['Type'];
    if (stripos($typeDef, 'enum(') !== 0) return 'System';

    preg_match_all("/'([^']+)'/", $typeDef, $m);
    $allowed = $m[1] ?? [];
    foreach ($fallbacks as $t) {
        if (in_array($t, $allowed, true)) return $t;
    }
    // If enum list exists but none match, use first allowed.
    return $allowed[0] ?? 'System';
}

function normalize_phone_e164(string $raw): string {
    // Best-effort: Malaysia default (60). Accepts 0XXXXXXXXX, 60XXXXXXXXX, +60XXXXXXXXX.
    $digits = preg_replace('/\D+/', '', $raw);
    if (!$digits) return '';
    if (strpos($digits, '00') === 0) $digits = substr($digits, 2);
    if (strpos($digits, '60') === 0) return $digits;
    if (strpos($digits, '0') === 0) return '60' . substr($digits, 1);
    // If user stored without prefix, assume MY
    return '60' . $digits;
}

function send_plain_email(string $to, string $subject, string $body, ?string &$error = null): bool {
    $error = null;
    if (trim($to) === '') { $error = 'No email'; return false; }
    // Use basic mail(). For production, swap to PHPMailer with SMTP.
    $from = getenv('IDESANOREPLY') ?: 'no-reply@i-desa.local';
    $headers = "From: {$from}\r\n";
    $headers .= "Reply-To: {$from}\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    $ok = @mail($to, $subject, $body, $headers);
    if (!$ok) $error = 'mail() failed (SMTP not configured?)';
    return $ok;
}

function whatsapp_cloud_send(string $toE164, string $message, ?string &$error = null): bool {
    // WhatsApp Cloud API (Meta). Requires:
    // - env WHATSAPP_TOKEN
    // - env WHATSAPP_PHONE_NUMBER_ID
    // NOTE: This sends a TEXT message. Your WhatsApp template rules may apply.
    $error = null;
    $token = getenv('WHATSAPP_TOKEN') ?: '';
    $phoneId = getenv('WHATSAPP_PHONE_NUMBER_ID') ?: '';
    if ($token === '' || $phoneId === '') {
        $error = 'WhatsApp credentials not configured';
        return false;
    }
    if ($toE164 === '') { $error = 'No phone'; return false; }

    $url = "https://graph.facebook.com/v18.0/{$phoneId}/messages";
    $payload = json_encode([
        'messaging_product' => 'whatsapp',
        'to' => $toE164,
        'type' => 'text',
        'text' => ['preview_url' => false, 'body' => $message],
    ], JSON_UNESCAPED_UNICODE);

    if (!function_exists('curl_init')) {
        $error = 'cURL not available on server';
        return false;
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $token,
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $resp = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($resp === false) {
        $error = $curlErr ?: 'Unknown cURL error';
        return false;
    }
    if ($http < 200 || $http >= 300) {
        $error = "HTTP {$http}: " . (string)$resp;
        return false;
    }
    return true;
}

// Current User Context
$uid = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;
$action = $_POST['action'] ?? ($_GET['action'] ?? '');

if (!$action) json_fail("Action required.");
require_login();

/* =========================================
   1. FETCH NOTIFICATIONS (Enhanced with Search & Filter)
   ========================================= */
if ($action === 'fetch_notifications') {
    $filter = $_POST['filter'] ?? 'inbox'; // inbox, unread, archived
    $search = trim($_POST['search'] ?? '');

    $sql = "SELECT * FROM notifications WHERE user_id = ?";
    $params = [$uid];
    $types = "i";

    // 1. Apply Folder Filters
    if ($filter === 'archived') {
        $sql .= " AND is_archived = 1";
    } elseif ($filter === 'unread') {
        $sql .= " AND is_read = 0 AND is_archived = 0";
    } else {
        // Default 'inbox': Show non-archived only
        $sql .= " AND is_archived = 0";
    }

    // 2. Apply Search
    if (!empty($search)) {
        $sql .= " AND message LIKE ?";
        $params[] = "%" . $search . "%";
        $types .= "s";
    }

    $sql .= " ORDER BY created_at DESC LIMIT 50";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    
    $data = [];
    while ($row = mysqli_fetch_assoc($res)) {
        $data[] = $row;
    }
    json_ok(["notifications" => $data]);
}

/* =========================================
   2. SINGLE ACTIONS (Mark Read, Archive, Delete)
   ========================================= */
if ($action === 'mark_read') {
    $nid = (int)$_POST['notification_id'];
    $stmt = mysqli_prepare($conn, "UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $nid, $uid);
    mysqli_stmt_execute($stmt);
    json_ok(["message" => "Updated"]);
}

if ($action === 'archive_notification') {
    $nid = (int)$_POST['notification_id'];
    $stmt = mysqli_prepare($conn, "UPDATE notifications SET is_archived = 1 WHERE notification_id = ? AND user_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $nid, $uid);
    mysqli_stmt_execute($stmt);
    json_ok(["message" => "Diarkibkan"]);
}

if ($action === 'delete_notification') {
    $nid = (int)$_POST['notification_id'];
    $stmt = mysqli_prepare($conn, "DELETE FROM notifications WHERE notification_id = ? AND user_id = ?");
    mysqli_stmt_bind_param($stmt, "ii", $nid, $uid);
    mysqli_stmt_execute($stmt);
    json_ok(["message" => "Dipadam"]);
}

/* =========================================
   3. BULK ACTIONS (Mark All, Clear)
   ========================================= */
if ($action === 'mark_all_read') {
    $stmt = mysqli_prepare($conn, "UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_archived = 0");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    json_ok(["message" => "Semua telah dibaca"]);
}

if ($action === 'clear_old_notifications') {
    // Deletes READ and NON-ARCHIVED notifications (Inbox cleanup)
    $stmt = mysqli_prepare($conn, "DELETE FROM notifications WHERE user_id = ? AND is_read = 1 AND is_archived = 0");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    $count = mysqli_stmt_affected_rows($stmt);
    json_ok(["message" => "$count notifikasi lama telah dipadam."]);
}

/* =========================================
   4. LOGS (Existing)
   ========================================= */
if ($action === 'fetch_my_activities') {
    $stmt = mysqli_prepare($conn, "SELECT action_details, created_at FROM activities WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $data = [];
    while ($row = mysqli_fetch_assoc($res)) $data[] = $row;
    json_ok(["logs" => $data]);
}

if ($action === 'fetch_my_bookings') {
    // [Keep existing booking logic from previous code here...]
    // For brevity, using the previous logic for getting email/phone and fetching bookings
    $uStmt = mysqli_prepare($conn, "SELECT email, phone FROM users WHERE user_id = ?");
    mysqli_stmt_bind_param($uStmt, "i", $uid);
    mysqli_stmt_execute($uStmt);
    $uRes = mysqli_stmt_get_result($uStmt);
    $uRow = mysqli_fetch_assoc($uRes);
    $email = $uRow['email'] ?? '';
    $phone = $uRow['phone'] ?? '';

    $sql = "SELECT b.*, f.name as facility_name 
            FROM bookings b 
            JOIN facilities f ON b.facility_id = f.facility_id 
            WHERE b.contact_email = ? OR b.contact_phone = ? 
            ORDER BY b.created_at DESC LIMIT 50";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $email, $phone);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $data = [];
    while ($row = mysqli_fetch_assoc($res)) $data[] = $row;
    json_ok(["bookings" => $data]);
}

/* =========================================
   5. SEND EVENT REMINDERS (AJK/Admin)
   Used by: ajk_admin_calendar_reminders.php
   Sends:
   - In-app notifications (notifications table) -> visible in my_notifications_calendar.php
   - Email (best-effort via mail())
   - WhatsApp (optional via WhatsApp Cloud API if configured)
   ========================================= */
if ($action === 'send_reminders') {
    require_role(['AJK','Admin']);

    $mode = (string)($_POST['mode'] ?? 'upcoming');
    $extra = trim((string)($_POST['extra_message'] ?? ''));
    if (function_exists('mb_substr')) {
        if (mb_strlen($extra) > 1000) $extra = mb_substr($extra, 0, 1000);
    } else {
        if (strlen($extra) > 1000) $extra = substr($extra, 0, 1000);
    }

    $sendInapp = (string)($_POST['send_inapp'] ?? '1') === '1';
    $sendEmail = (string)($_POST['send_email'] ?? '1') === '1';
    $sendWA    = (string)($_POST['send_whatsapp'] ?? '1') === '1';

    // Resolve reminder days from DB settings
    $reminderDays = (int)(get_calendar_setting($conn, 'reminder_days', 3) ?? 3);
    if ($reminderDays < 1) $reminderDays = 1;
    if ($reminderDays > 60) $reminderDays = 60;

    $rangeStart = '';
    $rangeEnd   = '';

    if ($mode === 'range') {
        $rangeStart = trim((string)($_POST['start_date'] ?? ''));
        $rangeEnd   = trim((string)($_POST['end_date'] ?? ''));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $rangeStart) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $rangeEnd)) {
            json_fail('Sila pilih julat tarikh yang sah.');
        }
        if (strtotime($rangeEnd) < strtotime($rangeStart)) {
            json_fail('Tarikh tamat mesti selepas tarikh mula.');
        }
        $startTs = $rangeStart . ' 00:00:00';
        $endTs   = $rangeEnd   . ' 23:59:59';
    } else {
        // upcoming
        $startTs = date('Y-m-d H:i:s');
        $endTs   = date('Y-m-d H:i:s', strtotime("+{$reminderDays} days"));
    }

    // Fetch eligible events (includes transferred events because they are stored in `events`)
    $stmtE = mysqli_prepare($conn, "
        SELECT event_id, title, location, start_datetime, end_datetime, status
        FROM events
        WHERE start_datetime >= ? AND start_datetime <= ?
          AND status <> 'Cancelled'
          AND status <> 'Completed'
        ORDER BY start_datetime ASC
        LIMIT 200
    ");
    if (!$stmtE) json_fail('Ralat DB (events).', 500);
    mysqli_stmt_bind_param($stmtE, 'ss', $startTs, $endTs);
    mysqli_stmt_execute($stmtE);
    $resE = mysqli_stmt_get_result($stmtE);

    $events = [];
    while ($r = mysqli_fetch_assoc($resE)) {
        $events[] = $r;
    }
    mysqli_stmt_close($stmtE);

    if (count($events) === 0) {
        json_ok(["message" => "Tiada acara layak dalam julat yang dipilih.", "stats" => ["events" => 0]]);
    }

    // Build one combined message (less spam)
    $lines = [];
    foreach ($events as $ev) {
        $title = $ev['title'] ?? 'Acara';
        $loc   = trim((string)($ev['location'] ?? ''));
        $sdt   = (string)($ev['start_datetime'] ?? '');
        $edt   = (string)($ev['end_datetime'] ?? '');
        $s = $sdt ? date('d/m/Y H:i', strtotime($sdt)) : '-';
        $e = $edt ? date('d/m/Y H:i', strtotime($edt)) : '-';
        $line = "• {$title} — {$s} hingga {$e}";
        if ($loc !== '') $line .= " @ {$loc}";
        $lines[] = $line;
    }

    $header = "[PERINGATAN ACARA i-Desa]\n";
    $body = $header . "\n" . implode("\n", $lines);
    if ($extra !== '') {
        $body .= "\n\nMesej tambahan:\n" . $extra;
    }
    $body .= "\n\nTerima kasih.";

    // Recipients
    $users = [];
    $resU = mysqli_query($conn, "SELECT user_id, email, phone, pref_event_reminders FROM users WHERE account_status = 'Active'");
    if ($resU) {
        while ($u = mysqli_fetch_assoc($resU)) {
            $users[] = $u;
        }
    }

    $notifType = pick_notification_type_for_calendar($conn);

    // 1) In-app notifications (notifications table)
    $inappSent = 0;
    if ($sendInapp) {
        $ins = mysqli_prepare($conn, "
            INSERT INTO notifications (user_id, event_id, message, type, is_read, is_archived, created_at)
            VALUES (?, NULL, ?, ?, 0, 0, NOW())
        ");
        if ($ins) {
            foreach ($users as $u) {
                $toId = (int)($u['user_id'] ?? 0);
                if ($toId <= 0) continue;
                mysqli_stmt_bind_param($ins, 'iss', $toId, $body, $notifType);
                if (@mysqli_stmt_execute($ins)) $inappSent++;
            }
            mysqli_stmt_close($ins);
        }
    }

    // 2) Email reminders (respects users.pref_event_reminders)
    $emailOk = 0; $emailFail = 0;
    if ($sendEmail) {
        $subject = 'Peringatan Acara i-Desa';
        foreach ($users as $u) {
            $pref = (int)($u['pref_event_reminders'] ?? 1);
            if ($pref !== 1) continue;
            $to = trim((string)($u['email'] ?? ''));
            if ($to === '') continue;
            $err = null;
            if (send_plain_email($to, $subject, $body, $err)) $emailOk++; else $emailFail++;
        }
    }

    // 3) WhatsApp reminders (respects users.pref_event_reminders)
    $waOk = 0; $waFail = 0; $waSkipped = 0; $waSkipReason = null;
    if ($sendWA) {
        foreach ($users as $u) {
            $pref = (int)($u['pref_event_reminders'] ?? 1);
            if ($pref !== 1) continue;
            $phoneRaw = trim((string)($u['phone'] ?? ''));
            $toE164 = normalize_phone_e164($phoneRaw);
            if ($toE164 === '') continue;

            $err = null;
            if (whatsapp_cloud_send($toE164, $body, $err)) {
                $waOk++;
            } else {
                // If credentials are not configured, count as skipped (not failed)
                if ($err && stripos($err, 'not configured') !== false) {
                    $waSkipped++;
                    $waSkipReason = $err;
                } else {
                    $waFail++;
                }
            }
        }
    }

    // Optional log
    $log = "CAL_REMINDER_SEND|mode={$mode}|events=" . count($events) . "|inapp={$inappSent}|email_ok={$emailOk}|email_fail={$emailFail}|wa_ok={$waOk}|wa_fail={$waFail}|wa_skipped={$waSkipped}";
    $ls = @mysqli_prepare($conn, "INSERT INTO activities (user_id, action_details) VALUES (?, ?)");
    if ($ls) {
        mysqli_stmt_bind_param($ls, 'is', $uid, $log);
        @mysqli_stmt_execute($ls);
        mysqli_stmt_close($ls);
    }

    $msg = "Selesai: " . count($events) . " acara dijumpai.";
    if ($sendInapp) $msg .= " Notifikasi in-app dihantar: {$inappSent}.";
    if ($sendEmail) $msg .= " E-mel: {$emailOk} berjaya, {$emailFail} gagal.";
    if ($sendWA) {
        if ($waSkipped > 0 && $waOk === 0 && $waFail === 0) {
            $msg .= " WhatsApp: tidak dihantar (belum dikonfigurasi).";
        } else {
            $msg .= " WhatsApp: {$waOk} berjaya, {$waFail} gagal.";
        }
    }

    json_ok([
        "message" => $msg,
        "stats" => [
            "events" => count($events),
            "inapp_sent" => $inappSent,
            "email_ok" => $emailOk,
            "email_fail" => $emailFail,
            "whatsapp_ok" => $waOk,
            "whatsapp_fail" => $waFail,
            "whatsapp_skipped" => $waSkipped,
            "whatsapp_skip_reason" => $waSkipReason,
            "notification_type" => $notifType,
            "window_start" => $startTs,
            "window_end" => $endTs,
        ]
    ]);
}

json_fail("Invalid action.");
?>