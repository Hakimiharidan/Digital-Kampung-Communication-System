<?php
// ajax_calendar_proposal.php (SYNC version for i-Desa: session + db_connect.php + mysqli)
session_start();
header('Content-Type: application/json; charset=utf-8');

include "db_connect.php";

/* -------------------------
   JSON helpers
------------------------- */
function json_ok(array $data = [], int $code = 200): void {
    http_response_code($code);
    echo json_encode(["ok" => true, "data" => $data], JSON_UNESCAPED_UNICODE);
    exit();
}
function json_fail(string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(["ok" => false, "error" => $msg], JSON_UNESCAPED_UNICODE);
    exit();
}

/* -------------------------
   Auth helpers
------------------------- */
function require_login(): void {
    if (!isset($_SESSION['user_id'])) json_fail("Sila log masuk terlebih dahulu.", 401);
}
function current_user_id(): int {
    return (int)($_SESSION['user_id'] ?? 0);
}
function current_user_role(): string {
    return (string)($_SESSION['role'] ?? 'Resident');
}
function current_user_name(): string {
    $n = $_SESSION['full_name'] ?? $_SESSION['username'] ?? '';
    if (trim($n) === '') $n = "User#" . current_user_id();
    return $n;
}
function require_role(array $roles): void {
    $role = current_user_role();
    if (!in_array($role, $roles, true)) json_fail("Akses tidak dibenarkan.", 403);
}

/* -------------------------
   Utils
------------------------- */
function safe_trim($s, int $maxLen = 255): string {
    $s = trim((string)$s);
    if (function_exists('mb_strlen')) {
        if (mb_strlen($s) > $maxLen) $s = mb_substr($s, 0, $maxLen);
    } else {
        if (strlen($s) > $maxLen) $s = substr($s, 0, $maxLen);
    }
    return $s;
}
function valid_datetime(string $dt): bool {
    return (bool)preg_match('/^\d{4}-\d{2}-\d{2}(\s|T)\d{2}:\d{2}(:\d{2})?$/', $dt);
}
function normalize_datetime(string $dt): string {
    // Convert "YYYY-MM-DDTHH:MM" -> "YYYY-MM-DD HH:MM:00"
    $dt = trim($dt);
    if (strpos($dt, 'T') !== false) {
        $dt = str_replace('T', ' ', $dt);
        if (preg_match('/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}$/', $dt)) $dt .= ':00';
    }
    return $dt;
}

/* -------------------------
   Notifications helpers
   (assume notifications columns: user_id, event_id, message, type, is_read)
------------------------- */
function notify_user($conn, int $user_id, string $message, string $type = 'System', $event_id = null): void {
    $stmt = mysqli_prepare($conn, "INSERT INTO notifications (user_id, event_id, message, type, is_read) VALUES (?, ?, ?, ?, 0)");
    if (!$stmt) return;

    // event_id can be NULL
    if ($event_id === null) {
        $null = null;
        mysqli_stmt_bind_param($stmt, "isss", $user_id, $null, $message, $type); // may warn on strict types but works in mysqli
    } else {
        $eid = (int)$event_id;
        mysqli_stmt_bind_param($stmt, "iiss", $user_id, $eid, $message, $type);
    }
    @mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

function notify_roles($conn, array $roles, string $message, string $type = 'System'): void {
    if (count($roles) === 0) return;

    $in = implode(",", array_fill(0, count($roles), "?"));
    $sql = "SELECT user_id FROM users WHERE role IN ($in) AND account_status = 'Active'";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return;

    $types = str_repeat("s", count($roles));
    mysqli_stmt_bind_param($stmt, $types, ...$roles);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $ins = mysqli_prepare($conn, "INSERT INTO notifications (user_id, event_id, message, type, is_read) VALUES (?, NULL, ?, ?, 0)");
    if (!$ins) {
        mysqli_stmt_close($stmt);
        return;
    }

    while ($row = mysqli_fetch_assoc($res)) {
        $uid = (int)$row['user_id'];
        mysqli_stmt_bind_param($ins, "iss", $uid, $message, $type);
        @mysqli_stmt_execute($ins);
    }
    mysqli_stmt_close($ins);
    mysqli_stmt_close($stmt);
}

/* -------------------------
   Proposal encoding in activities.action_details (no DB changes)
   Format:
   CAL_PROPOSAL|STATUS=<PENDING/APPROVED/REJECTED/TRANSFERRED>|PAYLOAD=<base64(json)>
------------------------- */
function build_proposal_action_details(string $status, array $payload): string {
    $status = strtoupper(trim($status));
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    $b64 = base64_encode($json ?: '{}');
    return "CAL_PROPOSAL|STATUS={$status}|PAYLOAD={$b64}";
}

function parse_proposal_action_details(string $details): ?array {
    if (strpos($details, "CAL_PROPOSAL|") !== 0) return null;

    // try new format
    if (preg_match('/STATUS=([A-Z_]+)\|PAYLOAD=([A-Za-z0-9+\/=]+)/', $details, $m)) {
        $status = $m[1];
        $payloadJson = base64_decode($m[2], true);
        if ($payloadJson === false) $payloadJson = '{}';
        $payload = json_decode($payloadJson, true);
        if (!is_array($payload)) $payload = [];
        return ["status" => $status, "payload" => $payload];
    }

    // fallback: if old data existed, try best-effort JSON after prefix
    $pos = strpos($details, "|");
    if ($pos !== false) {
        $maybe = substr($details, $pos + 1);
        $p = json_decode($maybe, true);
        if (is_array($p)) return ["status" => "PENDING", "payload" => $p];
    }
    return null;
}

/* -------------------------
   Activity logging (optional)
------------------------- */
function activity_log($conn, string $action_details): void {
    $uid = current_user_id();
    if ($uid <= 0) return;

    $stmt = @mysqli_prepare($conn, "INSERT INTO activities (user_id, action_details) VALUES (?, ?)");
    if (!$stmt) return;
    mysqli_stmt_bind_param($stmt, "is", $uid, $action_details);
    @mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/* -------------------------
   Routing
------------------------- */
require_login();
$action = $_POST['action'] ?? ($_GET['action'] ?? '');
$action = trim($action);

if ($action === '') json_fail("Action tidak sah.");

/* =========================================================
   submit_proposal (Resident)
   POST: title, description, location, start_datetime, end_datetime, category
   FILE: attachment (optional)
========================================================= */
if ($action === 'submit_proposal') {
    $payload = [
        "title" => safe_trim($_POST['title'] ?? '', 160),
        "description" => trim((string)($_POST['description'] ?? '')),
        "location" => safe_trim($_POST['location'] ?? '', 180),
        "start_datetime" => normalize_datetime($_POST['start_datetime'] ?? ''),
        "end_datetime" => normalize_datetime($_POST['end_datetime'] ?? ''),
        "category" => safe_trim($_POST['category'] ?? 'Social', 50),
        "submitted_at" => date('Y-m-d H:i:s'),
        "attachment" => null,
        "ajk_note" => null,
        "decision_at" => null,
        "reviewed_by" => null,
        "transferred_event_id" => null,
    ];

    if ($payload["title"] === '' || $payload["start_datetime"] === '' || $payload["end_datetime"] === '') {
        json_fail("Sila lengkapkan tajuk & tarikh/masa.");
    }
    if (!valid_datetime($payload["start_datetime"]) || !valid_datetime($payload["end_datetime"])) {
        json_fail("Format tarikh/masa tidak sah.");
    }
    if (strtotime($payload["end_datetime"]) < strtotime($payload["start_datetime"])) {
        json_fail("Tarikh tamat mesti selepas tarikh mula.");
    }

    // Optional attachment upload
    if (isset($_FILES['attachment']) && is_array($_FILES['attachment']) && $_FILES['attachment']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['attachment']['error'] !== UPLOAD_ERR_OK) json_fail("Gagal muat naik lampiran.");

        $allowedExt = ['pdf','jpg','jpeg','png'];
        $orig = $_FILES['attachment']['name'] ?? '';
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExt, true)) json_fail("Lampiran hanya dibenarkan PDF/JPG/PNG.");

        $uploadDir = __DIR__ . "/uploads/proposals";
        if (!is_dir($uploadDir)) @mkdir($uploadDir, 0775, true);

        $safeBase = preg_replace('/[^a-zA-Z0-9._-]/', '_', pathinfo($orig, PATHINFO_FILENAME));
        $safeName = "proposal_" . date("Ymd_His") . "_" . bin2hex(random_bytes(4)) . "_" . $safeBase . "." . $ext;
        $target = $uploadDir . "/" . $safeName;

        if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $target)) {
            json_fail("Gagal simpan lampiran.");
        }
        $payload["attachment"] = $safeName;
    }

    $details = build_proposal_action_details("PENDING", $payload);

    $stmt = mysqli_prepare($conn, "INSERT INTO activities (user_id, action_details) VALUES (?, ?)");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    $uid = current_user_id();
    mysqli_stmt_bind_param($stmt, "is", $uid, $details);
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        json_fail("Gagal simpan cadangan.", 500);
    }
    $activityId = (int)mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);

    // Notify proposer
    notify_user($conn, $uid, "Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.", "System", null);

    // Notify AJK/Admin
    notify_roles($conn, ['AJK','Admin'], "Cadangan acara baharu menunggu semakan. (Proposal ID: #{$activityId})", "System");

    json_ok(["message" => "Cadangan berjaya dihantar.", "proposal_activity_id" => $activityId]);
}

/* =========================================================
   my_proposals (Resident)
========================================================= */
if ($action === 'my_proposals') {
    $uid = current_user_id();

    $stmt = mysqli_prepare($conn, "
        SELECT activity_id, action_details, created_at
        FROM activities
        WHERE user_id = ?
          AND action_details LIKE 'CAL_PROPOSAL|%'
        ORDER BY created_at DESC
        LIMIT 200
    ");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $items = [];
    while ($r = mysqli_fetch_assoc($res)) {
        $parsed = parse_proposal_action_details($r['action_details']);
        if (!$parsed) continue;
        $items[] = [
            "activity_id" => (int)$r['activity_id'],
            "status" => $parsed['status'],
            "created_at" => $r['created_at'],
            "proposal" => $parsed['payload'],
        ];
    }
    mysqli_stmt_close($stmt);

    json_ok(["items" => $items]);
}

/* =========================================================
   all_proposals (AJK/Admin)
========================================================= */
if ($action === 'all_proposals') {
    require_role(['AJK','Admin']);

    $stmt = mysqli_prepare($conn, "
        SELECT a.activity_id, a.user_id, a.action_details, a.created_at,
               u.full_name, u.email
        FROM activities a
        JOIN users u ON u.user_id = a.user_id
        WHERE a.action_details LIKE 'CAL_PROPOSAL|%'
        ORDER BY a.created_at DESC
        LIMIT 500
    ");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);

    $items = [];
    while ($r = mysqli_fetch_assoc($res)) {
        $parsed = parse_proposal_action_details($r['action_details']);
        if (!$parsed) continue;

        $items[] = [
            "activity_id" => (int)$r['activity_id'],
            "user_id" => (int)$r['user_id'],
            "full_name" => $r['full_name'],
            "email" => $r['email'],
            "status" => $parsed['status'],
            "created_at" => $r['created_at'],
            "proposal" => $parsed['payload'],
        ];
    }
    mysqli_stmt_close($stmt);

    json_ok(["items" => $items]);
}

/* =========================================================
   review_proposal (AJK/Admin)
   POST: activity_id, decision (APPROVED/REJECTED), ajk_note(optional)
========================================================= */
if ($action === 'review_proposal') {
    require_role(['AJK','Admin']);

    $activityId = (int)($_POST['activity_id'] ?? 0);
    $decision = strtoupper(trim((string)($_POST['decision'] ?? ''))); // APPROVED / REJECTED
    $note = trim((string)($_POST['ajk_note'] ?? ''));

    if ($activityId <= 0) json_fail("ID cadangan tidak sah.");
    if (!in_array($decision, ['APPROVED','REJECTED'], true)) json_fail("Keputusan tidak sah.");

    // Load activity
    $stmt = mysqli_prepare($conn, "SELECT activity_id, user_id, action_details FROM activities WHERE activity_id = ? LIMIT 1");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    mysqli_stmt_bind_param($stmt, "i", $activityId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_fail("Cadangan tidak dijumpai.", 404);

    $parsed = parse_proposal_action_details($row['action_details']);
    if (!$parsed) json_fail("Format cadangan tidak sah.", 400);

    // Do not allow review after transferred
    if (($parsed['status'] ?? '') === 'TRANSFERRED') {
        json_fail("Cadangan ini sudah dipindah ke jadual rasmi.", 400);
    }

    $payload = $parsed['payload'];
    $payload['ajk_note'] = ($note === '' ? null : $note);
    $payload['decision_at'] = date('Y-m-d H:i:s');
    $payload['reviewed_by'] = "AJK i-Desa (" . current_user_name() . ")"; // privasi OK (tiada phone)

    $newDetails = build_proposal_action_details($decision, $payload);

    $up = mysqli_prepare($conn, "UPDATE activities SET action_details = ? WHERE activity_id = ?");
    if (!$up) json_fail("Ralat DB (prepare).", 500);

    mysqli_stmt_bind_param($up, "si", $newDetails, $activityId);
    if (!mysqli_stmt_execute($up)) {
        mysqli_stmt_close($up);
        json_fail("Gagal simpan keputusan.", 500);
    }
    mysqli_stmt_close($up);

    // Notify proposer
    $proposerId = (int)$row['user_id'];
    $msg = ($decision === 'APPROVED')
        ? "Cadangan acara anda telah DILULUSKAN oleh AJK."
        : "Cadangan acara anda telah DITOLAK oleh AJK.";
    if ($note !== '') $msg .= " Catatan: " . $note;

    notify_user($conn, $proposerId, $msg, "System", null);

    // Log reviewer action
    activity_log($conn, "CAL_PROPOSAL_REVIEW|activity_id={$activityId}|decision={$decision}");

    json_ok(["message" => "Keputusan disimpan."]);
}

/* =========================================================
   transfer_to_schedule (AJK/Admin)
   POST: activity_id
========================================================= */
if ($action === 'transfer_to_schedule') {
    require_role(['AJK','Admin']);

    $activityId = (int)($_POST['activity_id'] ?? 0);
    if ($activityId <= 0) json_fail("ID cadangan tidak sah.");

    // Load activity
    $stmt = mysqli_prepare($conn, "SELECT activity_id, user_id, action_details FROM activities WHERE activity_id = ? LIMIT 1");
    if (!$stmt) json_fail("Ralat DB (prepare).", 500);

    mysqli_stmt_bind_param($stmt, "i", $activityId);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) json_fail("Cadangan tidak dijumpai.", 404);

    $parsed = parse_proposal_action_details($row['action_details']);
    if (!$parsed) json_fail("Format cadangan tidak sah.", 400);

    if (($parsed['status'] ?? '') !== 'APPROVED') {
        json_fail("Hanya cadangan APPROVED boleh dipindah ke jadual rasmi.");
    }

    $p = $parsed['payload'];

    $title = safe_trim($p['title'] ?? '', 160);
    $desc  = trim((string)($p['description'] ?? ''));
    $loc   = safe_trim($p['location'] ?? '', 180);
    $start = normalize_datetime($p['start_datetime'] ?? '');
    $end   = normalize_datetime($p['end_datetime'] ?? '');
    $cat   = safe_trim($p['category'] ?? 'Social', 50);
    $att   = $p['attachment'] ?? null;

    if ($title === '' || $start === '' || $end === '') json_fail("Data cadangan tidak lengkap.");
    if (!valid_datetime($start) || !valid_datetime($end)) json_fail("Format tarikh/masa cadangan tidak sah.");

    // Create official event
    $createdBy = current_user_id();
    $stmt2 = mysqli_prepare($conn, "
        INSERT INTO events (title, description, attachment, location, start_datetime, end_datetime, category, status, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Scheduled', ?)
    ");
    if (!$stmt2) json_fail("Ralat DB (prepare).", 500);

    $descDb = ($desc === '' ? null : $desc);
    $locDb  = ($loc === '' ? null : $loc);

    mysqli_stmt_bind_param($stmt2, "sssssssi",
        $title, $descDb, $att, $locDb, $start, $end, $cat, $createdBy
    );

    if (!mysqli_stmt_execute($stmt2)) {
        mysqli_stmt_close($stmt2);
        json_fail("Gagal pindah ke jadual rasmi.", 500);
    }
    $eventId = (int)mysqli_insert_id($conn);
    mysqli_stmt_close($stmt2);

    // Update proposal status to TRANSFERRED (prevent repeat)
    $payload = $parsed['payload'];
    $payload['transferred_event_id'] = $eventId;

    $newDetails = build_proposal_action_details("TRANSFERRED", $payload);

    $up = mysqli_prepare($conn, "UPDATE activities SET action_details = ? WHERE activity_id = ?");
    if ($up) {
        mysqli_stmt_bind_param($up, "si", $newDetails, $activityId);
        @mysqli_stmt_execute($up);
        mysqli_stmt_close($up);
    }

    // Notify proposer
    $proposerId = (int)$row['user_id'];
    notify_user($conn, $proposerId, "Cadangan anda telah dimasukkan ke dalam jadual rasmi. Terima kasih!", "System", $eventId);

    // Log action
    activity_log($conn, "CAL_PROPOSAL_TRANSFER|activity_id={$activityId}|event_id={$eventId}");

    json_ok(["message" => "Berjaya pindah ke jadual rasmi.", "event_id" => $eventId]);
}

/* -------------------------
   Unknown action
------------------------- */
json_fail("Action tidak sah.");
