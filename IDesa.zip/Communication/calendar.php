<?php
/**
 * calendar.php
 * * Main Community Calendar Interface.
 * Features:
 * 1. Public Event Calendar (Grid/List)
 * 2. User RSVP Management (My Presence)
 * 3. User Proposal Tracking (My Proposals)
 * 4. Admin/AJK Dashboard Shortcuts
 */

session_start();
include "db_connect.php";

// --- 1. SESSION & AUTH ---
$isLoggedIn = isset($_SESSION['user_id']);
$role = $_SESSION['role'] ?? 'Resident';
$userId = $isLoggedIn ? (int)$_SESSION['user_id'] : 0;
$isAdminOrAjk = ($role === 'AJK' || $role === 'Admin');

// --- 2. NOTIFICATIONS ---
$unreadNotif = 0;
if ($isLoggedIn) {
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS c FROM notifications WHERE user_id=? AND is_read=0");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $userId);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        if ($r = mysqli_fetch_assoc($res)) $unreadNotif = (int)$r['c'];
        mysqli_stmt_close($stmt);
    }
}
$notifBadge = ($unreadNotif > 99) ? "99+" : (string)$unreadNotif;

?>
<!doctype html>
<html lang="ms">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>i-Desa | Kalendar Komuniti</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    /* =========================================
       1. CORE VARIABLES & RESET
       ========================================= */
    :root {
        --primary: #2d6a4f;
        --primary-hover: #1b4332;
        --secondary: #40916c;
        --accent: #d8f3dc;
        
        --bg-body: #f8fafc;
        --bg-card: #ffffff;
        
        --text-main: #1f2937;
        --text-muted: #6b7280;
        --text-light: #9ca3af;
        
        --border: #e5e7eb;
        --shadow-sm: 0 1px 2px 0 rgba(0,0,0,0.05);
        --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1);
        --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1);
        
        /* Category Colors */
        --c-social: #ec4899;
        --c-meeting: #f59e0b;
        --c-gotong: #10b981;
        --c-sports: #3b82f6;
        --c-religious: #8b5cf6;
        --c-emergency: #ef4444;
    }

    * { box-sizing: border-box; }
    
    body {
        margin: 0;
        font-family: 'Poppins', sans-serif;
        background-color: var(--bg-body);
        color: var(--text-main);
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        -webkit-font-smoothing: antialiased;
    }

    /* =========================================
       2. LAYOUT STRUCTURE
       ========================================= */
    .main-wrapper {
        flex: 1;
        width: 100%;
        max-width: 1400px;
        margin: 0 auto;
        padding: 2rem 5%;
    }

    .grid-layout {
        display: grid;
        grid-template-columns: 3fr 1.2fr;
        gap: 2rem;
        margin-top: 1.5rem;
    }

    @media (max-width: 1024px) {
        .grid-layout { grid-template-columns: 1fr; }
    }

    /* =========================================
       3. COMPONENTS: CARDS & HEADERS
       ========================================= */
    .card {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 1rem;
        padding: 1.5rem;
        box-shadow: var(--shadow-sm);
        transition: box-shadow 0.2s ease;
    }
    
    .card:hover {
        box-shadow: var(--shadow-md);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        flex-wrap: wrap;
        gap: 1.5rem;
        margin-bottom: 2rem;
        border-bottom: 1px solid var(--border);
        padding-bottom: 1.5rem;
    }

    .page-title h1 {
        margin: 0;
        font-size: 2rem;
        color: var(--primary-hover);
        font-weight: 700;
        letter-spacing: -0.5px;
    }

    .page-title p {
        margin: 0.5rem 0 0;
        color: var(--text-muted);
        font-size: 0.95rem;
        max-width: 600px;
        line-height: 1.6;
    }

    /* =========================================
       4. NAVIGATION TABS (User Journey)
       ========================================= */
    .tabs-nav {
        display: flex;
        gap: 0.5rem;
        background: #e2e8f0;
        padding: 0.3rem;
        border-radius: 0.75rem;
        width: fit-content;
        margin-bottom: 1.5rem;
    }

    .tab-btn {
        padding: 0.6rem 1.2rem;
        border-radius: 0.5rem;
        border: none;
        background: transparent;
        color: var(--text-muted);
        font-weight: 600;
        font-size: 0.9rem;
        cursor: pointer;
        transition: all 0.2s ease;
    }

    .tab-btn:hover {
        color: var(--text-main);
        background: rgba(255,255,255,0.5);
    }

    .tab-btn.active {
        background: var(--bg-card);
        color: var(--primary);
        box-shadow: var(--shadow-sm);
    }

    /* =========================================
       5. CONTROLS & SEARCH
       ========================================= */
    .controls {
        display: flex;
        gap: 1rem;
        align-items: center;
        flex-wrap: wrap;
    }

    .search-box {
        position: relative;
        min-width: 280px;
    }

    .search-input {
        width: 100%;
        padding: 0.7rem 1rem 0.7rem 2.5rem;
        border-radius: 99px;
        border: 1px solid var(--border);
        font-family: inherit;
        outline: none;
        transition: border-color 0.2s;
    }

    .search-input:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(45, 106, 79, 0.1);
    }

    .search-icon {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--text-light);
    }

    /* =========================================
       6. BUTTONS
       ========================================= */
    .btn {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.7rem 1.2rem;
        border-radius: 0.75rem;
        font-weight: 600;
        font-size: 0.9rem;
        text-decoration: none;
        cursor: pointer;
        border: 1px solid transparent;
        transition: all 0.2s;
    }

    .btn:hover { transform: translateY(-1px); }
    .btn:active { transform: translateY(0); }

    .btn-primary { background: var(--primary); color: white; }
    .btn-primary:hover { background: var(--primary-hover); }

    .btn-outline { background: white; border-color: var(--border); color: var(--text-main); }
    .btn-outline:hover { border-color: var(--primary); color: var(--primary); }

    .btn-danger { background: #fee2e2; color: #b91c1c; }
    .btn-danger:hover { background: #fecaca; }

    .btn-admin { background: var(--primary-hover); color: white; box-shadow: 0 4px 10px rgba(27, 67, 50, 0.2); }

    /* =========================================
       7. CALENDAR GRID (Left Panel)
       ========================================= */
    .cal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1.5rem;
    }

    .month-nav { display: flex; gap: 0.5rem; align-items: center; }
    .month-title { font-size: 1.5rem; font-weight: 700; color: var(--primary-hover); min-width: 200px; }

    .dow-row {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        margin-bottom: 0.5rem;
    }
    .dow { text-align: center; font-size: 0.8rem; font-weight: 700; color: var(--text-light); text-transform: uppercase; }

    .days-grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        border: 1px solid var(--border);
        border-radius: 1rem;
        overflow: hidden;
        background: var(--bg-card);
    }

    .day {
        min-height: 120px;
        padding: 0.5rem;
        border-right: 1px solid var(--border);
        border-bottom: 1px solid var(--border);
        cursor: pointer;
        transition: background 0.2s;
        position: relative;
    }
    
    .day:nth-child(7n) { border-right: none; }
    .day:hover { background: #f9fafb; }
    
    .day.other-month { background: #f8fafc; color: #d1d5db; }
    .day.today { background: #f0fdf4; }
    .day.selected { background: #fff; box-shadow: inset 0 0 0 2px var(--primary); }

    .day-num { font-weight: 600; font-size: 0.9rem; margin-bottom: 0.5rem; display: block; text-align: right; }
    
    /* Event Indicators */
    .evt-pill {
        font-size: 0.7rem;
        padding: 2px 6px;
        border-radius: 4px;
        margin-bottom: 2px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        color: var(--text-main);
        background: #f3f4f6;
        border-left: 3px solid #ccc;
    }
    /* Cat Colors */
    .cat-Social { border-left-color: var(--c-social); background: #fdf2f8; }
    .cat-Meeting { border-left-color: var(--c-meeting); background: #fffbeb; }
    .cat-Gotong-royong { border-left-color: var(--c-gotong); background: #ecfdf5; }
    .cat-Sports { border-left-color: var(--c-sports); background: #eff6ff; }
    .cat-Religious { border-left-color: var(--c-religious); background: #f5f3ff; }
    .cat-Emergency { border-left-color: var(--c-emergency); background: #fef2f2; }

    /* =========================================
       8. SIDE PANEL (Right Panel)
       ========================================= */
    .side-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--text-main);
        margin-bottom: 1rem;
        padding-bottom: 0.5rem;
        border-bottom: 2px solid var(--accent);
    }

    .selected-date { color: var(--primary); }

    .event-card {
        background: white;
        border: 1px solid var(--border);
        border-radius: 0.75rem;
        padding: 1rem;
        margin-bottom: 1rem;
        cursor: pointer;
        transition: transform 0.2s, border-color 0.2s;
    }
    .event-card:hover { transform: translateX(4px); border-color: var(--primary); }
    
    .event-time { font-size: 0.8rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.4rem; margin-bottom: 0.3rem; }
    .event-title { font-weight: 700; color: var(--primary-hover); font-size: 1rem; margin-bottom: 0.3rem; }
    .event-cat { display: inline-block; font-size: 0.7rem; padding: 2px 8px; border-radius: 99px; background: var(--bg-body); color: var(--text-muted); font-weight: 600; }

    /* =========================================
       9. LISTS & TABLES (My Proposals/RSVP)
       ========================================= */
    .data-table { width: 100%; border-collapse: collapse; }
    .data-table th { text-align: left; padding: 1rem; background: #f8fafc; color: var(--text-muted); font-size: 0.85rem; text-transform: uppercase; font-weight: 600; border-bottom: 1px solid var(--border); }
    .data-table td { padding: 1rem; border-bottom: 1px solid var(--border); font-size: 0.95rem; }
    .data-table tr:hover { background: #fcfcfc; }

    .status-badge { padding: 4px 10px; border-radius: 99px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; }
    .st-pending { background: #fff7ed; color: #c2410c; }
    .st-approved { background: #ecfdf5; color: #15803d; }
    .st-rejected { background: #fef2f2; color: #991b1b; }
    .st-transferred { background: #eff6ff; color: #1e40af; } /* Transferred Event */

    /* =========================================
       10. MODAL / DIALOG
       ========================================= */
    dialog {
        border: none; border-radius: 1rem; padding: 0; width: 90%; max-width: 600px;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    }
    dialog::backdrop { background: rgba(0, 0, 0, 0.5); backdrop-filter: blur(4px); }
    
    .modal-head { display: flex; justify-content: space-between; align-items: center; padding: 1.5rem; border-bottom: 1px solid var(--border); }
    .modal-head h3 { margin: 0; color: var(--primary-hover); font-size: 1.25rem; }
    .modal-close { background: none; border: none; font-size: 1.5rem; color: var(--text-muted); cursor: pointer; }
    
    .modal-body { padding: 1.5rem; max-height: 70vh; overflow-y: auto; }
    
    .info-group { margin-bottom: 1rem; }
    .info-label { font-size: 0.8rem; color: var(--text-muted); font-weight: 600; text-transform: uppercase; margin-bottom: 0.2rem; }
    .info-value { font-size: 1rem; color: var(--text-main); font-weight: 500; }

    .modal-foot { padding: 1rem 1.5rem; background: #f8fafc; border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 1rem; }

    /* =========================================
       11. UTILITIES & PRINT
       ========================================= */
    .hidden { display: none !important; }
    .empty-state { text-align: center; padding: 3rem; color: var(--text-muted); }
    .empty-state i { font-size: 3rem; margin-bottom: 1rem; opacity: 0.3; }

    /* Legend */
    .legend { display: flex; gap: 1rem; flex-wrap: wrap; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border); }
    .legend-item { display: flex; align-items: center; gap: 0.4rem; font-size: 0.8rem; color: var(--text-muted); }
    .legend-color { width: 10px; height: 10px; border-radius: 50%; }

    @media print {
        nav, .controls-bar, .tab-btn, .modal-close { display: none !important; }
        .main-wrapper { padding: 0; max-width: 100%; }
        .grid-layout { display: block; }
        .card { box-shadow: none; border: 1px solid #000; }
        .days-grid { border-color: #000; }
        .day { border-color: #000; }
        .rightCard { display: none; } /* Hide sidebar in print to save paper */
    }
    
    
</style>
</head>
<body>

<?php include "navbar.php"; ?>

<div class="main-wrapper">
    
    <div class="page-header">
        <div class="page-title">
            <h1>Kalendar Komuniti</h1>
            <p>Pusat sehenti aktiviti kampung. Semak jadual, urus kehadiran, dan cadangkan program menarik untuk komuniti.</p>
        </div>
        
        <div class="controls">
            <div class="search-box">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="searchInput" class="search-input" placeholder="Cari acara...">
            </div>

            <?php if ($isAdminOrAjk): ?>
                <a href="ajk_admin_calendar.php" class="btn btn-admin">
                    <i class="fas fa-user-shield"></i> Panel Admin
                </a>
            <?php endif; ?>

            <?php if ($isLoggedIn): ?>
                <button class="btn btn-primary" onclick="openProposalModal()"><i class="fas fa-plus-circle"></i> Cadang Acara</button>
                <a href="request_cancel_event.php" class="btn btn-danger"><i class="fas fa-ban"></i> Batal</a>
            <?php else: ?>
                <a href="login_page.php" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i> Log Masuk</a>
            <?php endif; ?>
            
            <button class="btn btn-outline" onclick="window.print()"><i class="fas fa-print"></i></button>
        </div>
    </div>

    <nav class="tabs-nav">
        <button class="tab-btn active" onclick="switchTab('calendar')"><i class="far fa-calendar-alt"></i> Kalendar Awam</button>
        <?php if ($isLoggedIn): ?>
            <button class="tab-btn" onclick="switchTab('my_rsvp')"><i class="far fa-check-circle"></i> Kehadiran Saya</button>
            <button class="tab-btn" onclick="switchTab('my_proposals')"><i class="far fa-lightbulb"></i> Cadangan Saya</button>
        <?php endif; ?>
    </nav>

    <div id="tab-calendar" class="tab-content">
        <div class="grid-layout">
            
            <div class="card">
                <div class="cal-header">
                    <div class="month-nav">
                        <button class="btn btn-outline sm" onclick="changeMonth(-1)"><i class="fas fa-chevron-left"></i></button>
                        <div class="month-title" id="monthLabel">Loading...</div>
                        <button class="btn btn-outline sm" onclick="changeMonth(1)"><i class="fas fa-chevron-right"></i></button>
                        <button class="btn btn-outline sm" onclick="goToToday()">Hari Ini</button>
                    </div>
                    
                    <div style="display:flex; gap:0.5rem; flex-wrap:wrap;">
                        <select id="catFilter" class="search-input" style="padding:0.4rem 1rem; width:auto;" onchange="renderCalendar()">
                            <option value="all">Semua Kategori</option>
                            <option value="Social">Sosial</option>
                            <option value="Meeting">Perjumpaan</option>
                            <option value="Sports">Sukan</option>
                            <option value="Religious">Agama</option>
                            <option value="Emergency">Kecemasan</option>
                            <option value="Perkahwinan">Perkahwinan</option>
                        </select>
                    </div>
                </div>

                <div class="dow-row">
                    <div class="dow">Isnin</div><div class="dow">Selasa</div><div class="dow">Rabu</div>
                    <div class="dow">Khamis</div><div class="dow">Jumaat</div><div class="dow">Sabtu</div><div class="dow">Ahad</div>
                </div>

                <div id="calGrid" class="days-grid"></div>

                <div class="legend">
                    <div class="legend-item"><div class="legend-color" style="background:var(--c-social)"></div> Sosial</div>
                    <div class="legend-item"><div class="legend-color" style="background:var(--c-meeting)"></div> Meeting</div>
                    <div class="legend-item"><div class="legend-color" style="background:var(--c-gotong)"></div> Gotong-Royong</div>
                    <div class="legend-item"><div class="legend-color" style="background:var(--c-sports)"></div> Sukan</div>
                    <div class="legend-item"><div class="legend-color" style="background:var(--c-religious)"></div> Agama</div>
                    <div class="legend-item"><div class="legend-color" style="background:var(--c-emergency)"></div> Kecemasan</div>
                </div>
            </div>

            <div class="card rightCard">
                <h3 class="side-title">Acara: <span id="selectedDateText" class="selected-date">Hari Ini</span></h3>
                <div id="sideEventsList">
                    <p class="text-muted">Pilih tarikh untuk melihat acara.</p>
                </div>
                
                <?php if (!$isLoggedIn): ?>
                    <div style="margin-top:2rem; padding:1rem; background:#fff7ed; border-radius:0.5rem; font-size:0.85rem; color:#c2410c; border:1px solid #fed7aa;">
                        <i class="fas fa-lock"></i> <strong>Akses Terhad</strong><br>
                        Sila log masuk untuk mengesahkan kehadiran atau menghantar cadangan acara.
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <div id="tab-my_rsvp" class="tab-content hidden">
        <div class="card">
            <h3 class="side-title">Jadual Kehadiran Saya</h3>
            <p class="text-muted" style="margin-bottom:1.5rem;">Senarai acara yang anda telah tandakan sebagai "Hadir" atau "Berminat".</p>
            <div style="overflow-x:auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Tarikh</th>
                            <th>Acara</th>
                            <th>Kategori</th>
                            <th>Status Kehadiran</th>
                            <th>Lokasi</th>
                            <th>Tindakan</th>
                        </tr>
                    </thead>
                    <tbody id="tbodyRsvp">
                        <tr><td colspan="6" class="text-center p-4">Memuatkan...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="tab-my_proposals" class="tab-content hidden">
        <div class="card">
            <h3 class="side-title">Status Cadangan Saya</h3>
            <p class="text-muted" style="margin-bottom:1.5rem;">Pantau status kelulusan untuk acara yang anda cadangkan.</p>
            <div style="overflow-x:auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Tarikh Hantar</th>
                            <th>Tajuk Cadangan</th>
                            <th>Tarikh Acara</th>
                            <th>Status</th>
                            <th>Catatan AJK</th>
                        </tr>
                    </thead>
                    <tbody id="tbodyProposals">
                        <tr><td colspan="5" class="text-center p-4">Memuatkan...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<?php include "footer.php"; ?>

<dialog id="dlgEvent">
    <div class="modal-head">
        <h3 id="evtTitle">Butiran Acara</h3>
        <button class="modal-close" onclick="dlgEvent.close()">&times;</button>
    </div>
    <div class="modal-body" id="evtBody"></div>
    
    <?php if ($isLoggedIn): ?>
    <div class="modal-foot">
        <div style="display:flex; align-items:center; gap:10rem; width:100%; justify-content:space-between;">
            <span style="font-size:0.85rem; font-weight:600; color:var(--text-muted);">Status Kehadiran Anda:</span>
            <div style="display:flex; gap:0.5rem;">
                <select id="rsvpSelect" class="search-input" style="padding:0.5rem 1rem; width:auto;">
                    <option value="Going">Hadir (Going)</option>
                    <option value="Interested">Berminat (Interested)</option>
                    <option value="Not Going">Tidak Hadir</option>
                </select>
                <button class="btn btn-primary btn-sm" id="btnSaveRsvp">Simpan</button>
            </div>
        </div>
    </div>
    <?php endif; ?>
</dialog>

<dialog id="dlgProposal">
    <div class="modal-head">
        <h3>Cadang Acara Baru</h3>
        <button class="modal-close" onclick="dlgProposal.close()">&times;</button>
    </div>
    <form id="formProposal">
        <div class="modal-body">
            <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:1rem;">
                Cadangan anda akan disemak oleh AJK. Jika diluluskan, status akan bertukar kepada <strong>APPROVED</strong> dan kemudian <strong>TRANSFERRED</strong> apabila dimasukkan ke kalendar rasmi.
            </p>
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                <div>
                    <label style="font-size:0.85rem; font-weight:700;">Tajuk</label>
                    <input name="title" class="search-input" style="border-radius:0.5rem;" required>
                </div>
                <div>
                    <label style="font-size:0.85rem; font-weight:700;">Kategori</label>
                    <select name="category" class="search-input" style="border-radius:0.5rem;">
                        <option>Sosial</option><option>Meeting</option><option>Gotong-royong</option><option>Sukan</option><option>Keagamaan</option><option>Perkahwinan</option>
                    </select>
                </div>
            </div>
            
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem; margin-bottom:1rem;">
                <div>
                    <label style="font-size:0.85rem; font-weight:700;">Mula</label>
                    <input type="datetime-local" name="start_datetime" class="search-input" style="border-radius:0.5rem;" required>
                </div>
                <div>
                    <label style="font-size:0.85rem; font-weight:700;">Tamat</label>
                    <input type="datetime-local" name="end_datetime" class="search-input" style="border-radius:0.5rem;" required>
                </div>
            </div>

            <div style="margin-bottom:1rem;">
                <label style="font-size:0.85rem; font-weight:700;">Lokasi</label>
                <input name="location" class="search-input" style="border-radius:0.5rem;" placeholder="Contoh: Dewan Serbaguna">
            </div>

            <div style="margin-bottom:1rem;">
                <label style="font-size:0.85rem; font-weight:700;">Penerangan</label>
                <textarea name="description" rows="3" class="search-input" style="border-radius:0.5rem; height:auto;"></textarea>
            </div>
            
            <div>
                <label style="font-size:0.85rem; font-weight:700;">Lampiran (PDF/IMG)</label>
                <input type="file" name="attachment" class="search-input" style="border-radius:0.5rem; padding:0.5rem;">
            </div>
            <div id="propMsg" style="margin-top:0.5rem; font-size:0.85rem; text-align:right;"></div>
        </div>
        <div class="modal-foot">
            <button type="button" class="btn btn-outline" onclick="dlgProposal.close()">Batal</button>
            <button type="submit" class="btn btn-primary">Hantar Cadangan</button>
        </div>
    </form>
</dialog>

<script>
// --- CONFIGURATION ---
const API_CAL = "ajax_calendar.php";
const API_RSVP = "ajax_calendar_attendance.php";
const API_PROP = "ajax_calendar_proposal.php";
const IS_LOGGED_IN = <?php echo $isLoggedIn ? 'true' : 'false'; ?>;
const USER_ID = <?php echo $userId; ?>;

// --- STATE ---
let currentDate = new Date(); // Tracks displayed month
currentDate.setDate(1); 
let allEvents = []; // Cache events
let selectedDate = new Date();
let openedEventId = null;

// --- INITIALIZATION ---
document.addEventListener("DOMContentLoaded", () => {
    fetchEvents();
});

// --- TABS LOGIC ---
function switchTab(tabId) {
    // Hide all
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    
    // Show selected
    document.getElementById('tab-' + tabId).classList.remove('hidden');
    
    // Highlight btn
    // Note: Simple finding by onclick text or index. For now simple toggle:
    const btns = document.querySelectorAll('.tab-btn');
    if(tabId === 'calendar') btns[0].classList.add('active');
    if(tabId === 'my_rsvp') { btns[1].classList.add('active'); loadMyRSVP(); }
    if(tabId === 'my_proposals') { btns[2].classList.add('active'); loadMyProposals(); }
}

// --- CALENDAR LOGIC ---
async function fetchEvents() {
    const start = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const end = new Date(currentDate.getFullYear(), currentDate.getMonth()+1, 0);
    
    // Expand buffer
    start.setDate(start.getDate() - 7);
    end.setDate(end.getDate() + 14);
    
    const sStr = fmtDate(start) + " 00:00:00";
    const eStr = fmtDate(end) + " 23:59:59";

    try {
        const res = await fetch(`${API_CAL}?action=fetch_events&start=${encodeURIComponent(sStr)}&end=${encodeURIComponent(eStr)}`);
        const json = await res.json();
        if (json.ok) {
            allEvents = json.data.events;
            renderCalendar();
        }
    } catch(e) { console.error(e); }
}

function renderCalendar() {
    // Label
    document.getElementById('monthLabel').textContent = currentDate.toLocaleString('ms-MY', { month:'long', year:'numeric' });
    
    const grid = document.getElementById('calGrid');
    grid.innerHTML = "";
    
    // Date Maths
    const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const startGrid = new Date(firstDay);
    const dow = (startGrid.getDay() + 6) % 7; // Mon=0
    startGrid.setDate(startGrid.getDate() - dow);
    
    const todayStr = fmtDate(new Date());
    const selStr = fmtDate(selectedDate);
    const catFilter = document.getElementById('catFilter').value;

    for (let i = 0; i < 42; i++) {
        const d = new Date(startGrid);
        d.setDate(startGrid.getDate() + i);
        const dStr = fmtDate(d);
        
        const isMonth = d.getMonth() === currentDate.getMonth();
        const cell = document.createElement('div');
        cell.className = `day ${!isMonth ? 'other-month' : ''} ${dStr === todayStr ? 'today' : ''} ${dStr === selStr ? 'selected' : ''}`;
        
        // Filter events
        let dayEvs = allEvents.filter(e => e.start_datetime.startsWith(dStr));
        if (catFilter !== 'all') {
            dayEvs = dayEvs.filter(e => e.category === catFilter);
        }

        let pills = "";
        dayEvs.slice(0,3).forEach(e => {
            pills += `<div class="evt-pill cat-${esc(e.category)}">${esc(e.title)}</div>`;
        });
        if(dayEvs.length > 3) pills += `<div style="font-size:0.7rem; color:#999; text-align:center;">+${dayEvs.length-3} lagi</div>`;

        cell.innerHTML = `<span class="day-num">${d.getDate()}</span>${pills}`;
        cell.onclick = () => selectDate(d);
        grid.appendChild(cell);
    }
    
    // Refresh sidebar
    selectDate(selectedDate, true);
}

function selectDate(d, skipRender = false) {
    selectedDate = d;
    document.getElementById('selectedDateText').textContent = d.toLocaleDateString('ms-MY', { weekday:'long', day:'numeric', month:'long' });
    
    if(!skipRender) renderCalendar(); // update border highlight

    const dStr = fmtDate(d);
    const catFilter = document.getElementById('catFilter').value;
    let evs = allEvents.filter(e => e.start_datetime.startsWith(dStr));
    if (catFilter !== 'all') evs = evs.filter(e => e.category === catFilter);

    const list = document.getElementById('sideEventsList');
    if (evs.length === 0) {
        list.innerHTML = `<div class="empty-state" style="padding:1rem;"><i class="far fa-calendar-times" style="font-size:2rem;"></i><br>Tiada acara.</div>`;
    } else {
        list.innerHTML = evs.map(e => `
            <div class="event-card" onclick="openEventDetails(${e.event_id})">
                <div class="event-time">
                    <i class="far fa-clock"></i> ${e.start_datetime.substr(11,5)}
                    <span class="event-cat cat-${esc(e.category)}" style="margin-left:auto;">${esc(e.category)}</span>
                </div>
                <div class="event-title">${esc(e.title)}</div>
                <div style="font-size:0.85rem; color:var(--text-muted);">
                    <i class="fas fa-map-marker-alt"></i> ${esc(e.location || 'Lokasi tidak dinyatakan')}
                </div>
            </div>
        `).join('');
    }
}

// --- MODALS & DETAILS ---
async function openEventDetails(id) {
    openedEventId = id;
    const dlg = document.getElementById('dlgEvent');
    dlg.showModal();
    document.getElementById('evtBody').innerHTML = "<p>Memuatkan...</p>";

    try {
        const res = await fetch(`${API_CAL}?action=get_event_detail&event_id=${id}`);
        const json = await res.json();
        if(!json.ok) throw new Error("Gagal");
        
        const e = json.data.event;
        document.getElementById('evtTitle').innerText = e.title;
        document.getElementById('evtBody').innerHTML = `
            <div class="info-group">
                <div class="info-label">Masa</div>
                <div class="info-value">${e.start_datetime} <span style="font-size:0.8rem; color:#888;">hingga</span> ${e.end_datetime}</div>
            </div>
            <div class="info-group">
                <div class="info-label">Lokasi</div>
                <div class="info-value">${esc(e.location || '-')}</div>
            </div>
            <div class="info-group">
                <div class="info-label">Kategori</div>
                <div class="info-value"><span class="status-badge" style="background:#f3f4f6;">${esc(e.category)}</span></div>
            </div>
            <div class="info-group">
                <div class="info-label">Penerangan</div>
                <div class="info-value" style="font-size:0.95rem; line-height:1.6;">${esc(e.description || '-')}</div>
            </div>
            ${e.attachment ? `<div class="info-group"><a href="download.php?file=${encodeURIComponent(e.attachment)}" target="_blank" class="btn btn-outline sm">Lihat Lampiran</a></div>` : ''}
        `;
    } catch(e) { document.getElementById('evtBody').innerText = "Ralat memuat data."; }
}

// --- RSVP HANDLER ---
const btnRsvp = document.getElementById('btnSaveRsvp');
if (btnRsvp) {
    btnRsvp.onclick = async () => {
        const status = document.getElementById('rsvpSelect').value;
        const fd = new FormData();
        fd.append('action', 'set_presence');
        fd.append('event_id', openedEventId);
        fd.append('rsvp_status', status);
        
        const res = await fetch(API_RSVP, {method:'POST', body:fd});
        const json = await res.json();
        if(json.ok) { alert("Kehadiran disimpan!"); document.getElementById('dlgEvent').close(); }
        else alert("Ralat: " + json.error);
    }
}

// --- PROPOSAL HANDLER ---
function openProposalModal() { document.getElementById('dlgProposal').showModal(); }
document.getElementById('formProposal').onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    fd.append('action', 'submit_proposal');
    const msg = document.getElementById('propMsg');
    msg.innerText = "Menghantar...";
    
    const res = await fetch(API_PROP, {method:'POST', body:fd});
    const json = await res.json();
    if(json.ok) {
        msg.style.color = "green";
        msg.innerText = "Berjaya dihantar! Menunggu semakan.";
        setTimeout(() => { document.getElementById('dlgProposal').close(); e.target.reset(); msg.innerText=""; }, 2000);
    } else {
        msg.style.color = "red";
        msg.innerText = json.error || "Gagal.";
    }
}

// --- MY DATA LOADERS ---
async function loadMyRSVP() {
    if(!IS_LOGGED_IN) return;
    const t = document.getElementById('tbodyRsvp');
    // Using existing API? Or fetch logic. Assuming 'fetch_user_rsvp' exists or we reuse 'all_proposals' pattern.
    // Since we don't have a direct 'my_rsvp' endpoint in previous chat, I will assume we implement it in ajax_calendar_attendance.php
    // For now, let's simulate fetching event details where user ID matches.
    // REAL IMPLEMENTATION: We need specific backend logic. I will use a placeholder here.
    
    // Note: You must ensure ajax_calendar_attendance.php has 'get_user_rsvp'. 
    // If not, add it. (Code below assumes standard fetch logic)
    
    try {
        const res = await fetch(`${API_RSVP}?action=get_user_rsvp`); 
        const json = await res.json();
        if(json.ok && json.data.length > 0) {
            t.innerHTML = json.data.map(r => `
                <tr>
                    <td>${r.start_datetime.slice(0,10)}</td>
                    <td><b>${esc(r.title)}</b></td>
                    <td>${esc(r.category)}</td>
                    <td><span class="status-badge st-approved">${esc(r.rsvp_status)}</span></td>
                    <td>${esc(r.location)}</td>
                    <td><button class="btn btn-outline sm" onclick="openEventDetails(${r.event_id})">Lihat</button></td>
                </tr>
            `).join('');
        } else {
            t.innerHTML = `<tr><td colspan="6" class="text-center p-4">Tiada rekod kehadiran.</td></tr>`;
        }
    } catch(e) { t.innerHTML = `<tr><td colspan="6" class="text-center p-4">Tiada data / API belum sedia.</td></tr>`; }
}

async function loadMyProposals() {
    if(!IS_LOGGED_IN) return;
    const t = document.getElementById('tbodyProposals');
    try {
        const res = await fetch(`${API_PROP}?action=my_proposals`);
        const json = await res.json();
        if(json.ok && json.data.items.length > 0) {
            t.innerHTML = json.data.items.map(p => {
                let stClass = 'st-pending';
                if(p.status === 'APPROVED') stClass = 'st-approved';
                if(p.status === 'REJECTED') stClass = 'st-rejected';
                if(p.status === 'TRANSFERRED') stClass = 'st-transferred'; // Specific handling for transferred
                
                return `
                <tr>
                    <td>${p.created_at.slice(0,10)}</td>
                    <td><b>${esc(p.proposal.title)}</b></td>
                    <td>${p.proposal.start_datetime}</td>
                    <td><span class="status-badge ${stClass}">${esc(p.status)}</span></td>
                    <td>${esc(p.proposal.ajk_note || '-')}</td>
                </tr>
            `}).join('');
        } else {
            t.innerHTML = `<tr><td colspan="5" class="text-center p-4">Tiada cadangan dibuat.</td></tr>`;
        }
    } catch(e) { t.innerHTML = `<tr><td colspan="5" class="text-center p-4">Ralat memuat data.</td></tr>`; }
}

// --- UTILS ---
function changeMonth(dir) {
    currentDate.setMonth(currentDate.getMonth() + dir);
    fetchEvents();
}
function goToToday() {
    currentDate = new Date();
    currentDate.setDate(1);
    selectedDate = new Date();
    fetchEvents();
}
function fmtDate(d) {
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function esc(s){ return (s||'').toString().replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

// Search
document.getElementById('searchInput').addEventListener('input', (e) => {
    const v = e.target.value.toLowerCase();
    const hits = allEvents.filter(ev => ev.title.toLowerCase().includes(v));
    const sRes = document.getElementById('eventSearchResults'); // You need to add this div back if you want dropdown search
    // For this layout, maybe highlight grid? Or just filter grid?
    // Let's filter the GRID for better UX
    const cells = document.querySelectorAll('.day .evt-pill');
    cells.forEach(c => {
        if(c.textContent.toLowerCase().includes(v)) c.style.opacity = '1';
        else c.style.opacity = '0.2';
    });
});

</script>
</body>
</html>