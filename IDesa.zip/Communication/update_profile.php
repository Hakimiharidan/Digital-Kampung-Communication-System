<?php 
session_start(); 
include "db_connect.php"; 

if(!isset($_SESSION['user_id'])) {
    header("Location: login_page.php");
    exit();
}

$uid = $_SESSION['user_id'];
$message = "";

if (isset($_POST['update'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email     = mysqli_real_escape_string($conn, $_POST['email']);
    $phone     = mysqli_real_escape_string($conn, $_POST['phone']);
    $address   = mysqli_real_escape_string($conn, $_POST['address']);

    $update_sql = "UPDATE users SET full_name='$full_name', email='$email', phone='$phone', address='$address' WHERE user_id='$uid'";
    
    if (mysqli_query($conn, $update_sql)) {
        // Activity logging has been removed from here to keep your timeline clean!
        $message = "<div class='alert success'><i class='fas fa-check-circle'></i> Profil berjaya dikemas kini!</div>";
    } else {
        $message = "<div class='alert error'><i class='fas fa-exclamation-circle'></i> Error: " . mysqli_error($conn) . "</div>";
    }
}

$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE user_id='$uid'"));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>i-Desa | Edit Profil</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root { --p-green: #2d6a4f; --dark: #1b4332; --accent: #74c69d; }
        
        body { 
            margin: 0; 
            font-family: 'Poppins', sans-serif; 
            background: #f4f7f4; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
        }

        .container {
            display: flex;
            width: 900px;
            height: 600px;
            background: white;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
        }

        .side-panel {
            flex: 1;
            background: linear-gradient(rgba(45, 106, 79, 0.8), rgba(27, 67, 50, 0.8)), 
                        url('village.png');
            background-size: cover;
            background-position: center;
            padding: 40px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .side-panel h1 { font-size: 2.5rem; margin-bottom: 10px; }
        .side-panel p { opacity: 0.8; line-height: 1.6; }

        .form-panel {
            flex: 1.2;
            padding: 50px;
            overflow-y: auto;
        }

        .form-panel h2 { color: var(--dark); margin-bottom: 30px; }

        .form-group { margin-bottom: 20px; position: relative; }
        .form-group i { 
            position: absolute; 
            left: 15px; 
            top: 40px; 
            color: var(--p-green); 
        }

        label { 
            display: block; 
            font-size: 0.85rem; 
            font-weight: 600; 
            color: #666; 
            margin-bottom: 8px; 
        }

        input, textarea { 
            width: 100%; 
            padding: 12px 15px 12px 45px; 
            border: 2px solid #eee; 
            border-radius: 12px; 
            box-sizing: border-box; 
            font-family: inherit;
            transition: 0.3s;
        }

        input:focus, textarea:focus { 
            border-color: var(--p-green); 
            outline: none; 
            background: #f9fffb;
        }

        .btn-update { 
            width: 100%; 
            padding: 15px; 
            background: var(--p-green); 
            color: white; 
            border: none; 
            border-radius: 12px; 
            font-weight: bold; 
            cursor: pointer; 
            font-size: 1rem;
            transition: 0.3s;
        }

        .btn-update:hover { background: var(--dark); transform: translateY(-2px); }

        .back-link { 
            display: block; 
            text-align: center; 
            margin-top: 20px; 
            color: #888; 
            text-decoration: none; 
            font-size: 0.9rem; 
        }

        .alert { 
            padding: 15px; 
            border-radius: 12px; 
            margin-bottom: 20px; 
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .success { background: #e7f5ee; color: #2d6a4f; border: 1px solid #c2e7d6; }
        .error { background: #fff0f0; color: #d63031; border: 1px solid #ffdbdb; }

    </style>
</head>
<body>

<div class="container">
    <div class="side-panel">
        <h1>i-Desa</h1>
        <p>Mengemas kini maklumat profil anda membantu jawatankuasa kampung menghubungi anda untuk berita dan acara komuniti yang penting.</p>
    </div>

    <div class="form-panel">
        <h2>Edit Profil</h2>
        
        <?php echo $message; ?>

        <form method="POST">
            <div class="form-group">
                <label>Nama Penuh</label>
                <i class="fas fa-user"></i>
                <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
            </div>

            <div class="form-group">
                <label>Alamat Emel</label>
                <i class="fas fa-envelope"></i>
                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            </div>

            <div class="form-group">
                <label>Nombor Telefon</label>
                <i class="fas fa-phone"></i>
                <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="012-3456789">
            </div>

            <div class="form-group">
                <label>Alamat Penuh</label>
                <i class="fas fa-map-marker-alt"></i>
                <textarea name="address" rows="3" style="padding-left: 45px;"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
            </div>

            <button type="submit" name="update" class="btn-update">Kemaskini Profil</button>
            <a href="profile_management.php" class="back-link">Kembali ke Papan Pemuka</a>
        </form>
    </div>
</div>

</body>
</html>