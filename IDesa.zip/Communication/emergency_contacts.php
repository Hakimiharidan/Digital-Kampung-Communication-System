<?php
session_start();
include "db_connect.php";
include "navbar.php";

$role = $_SESSION['role'] ?? 'Resident';
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Get Contacts
$contacts = [];
$res = mysqli_query($conn, "SELECT * FROM emergency_contacts ORDER BY category ASC, contact_name ASC");
if ($res) while ($r = mysqli_fetch_assoc($res)) $contacts[] = $r;

// Group by category
$grouped = [];
foreach ($contacts as $c) {
  $cat = $c['category'] ?: 'Lain-lain';
  if (!isset($grouped[$cat])) $grouped[$cat] = [];
  $grouped[$cat][] = $c;
}

function wa_link($phone){
  $digits = preg_replace('/\D+/', '', (string)$phone);
  if (strpos($digits, '0') === 0) $digits = '60' . substr($digits, 1);
  return "https://wa.me/" . $digits;
}

// Helper to get icon based on category (Visual Candy)
function getCategoryIcon($catName) {
    $cat = strtolower($catName);
    if (strpos($cat, 'polis') !== false || strpos($cat, 'balai') !== false) return 'fa-shield-alt';
    if (strpos($cat, 'hospital') !== false || strpos($cat, 'klinik') !== false || strpos($cat, 'medic') !== false) return 'fa-hospital';
    if (strpos($cat, 'bomba') !== false || strpos($cat, 'api') !== false) return 'fa-fire-extinguisher';
    if (strpos($cat, 'jmb') !== false || strpos($cat, 'pejabat') !== false) return 'fa-building';
    if (strpos($cat, 'keselamatan') !== false || strpos($cat, 'guard') !== false) return 'fa-user-shield';
    return 'fa-phone-alt'; // Default
}
?>
<!DOCTYPE html>
<html lang="ms">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kenalan Kecemasan | i-Desa</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <style>
    :root{
      --primary: #166534;
      --bg-soft: #f8fafc;
      --card-bg: #ffffff;
      --text-main: #1e293b;
      --text-muted: #64748b;
      --danger: #ef4444; /* Red for Call */
      --whatsapp: #22c55e; /* Green for WA */
      --border: #e2e8f0;
    }
    
    body { margin:0; font-family:'Inter', sans-serif; background:var(--bg-soft); color:var(--text-main); }
    
    .main-wrap { 
        max-width: 1000px; 
        margin: 0 auto; 
        padding: 30px 20px 80px; 
    }

    /* Header Section */
    .page-header {
        background: #fff;
        padding: 24px;
        border-radius: 16px;
        border: 1px solid var(--border);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 15px;
        margin-bottom: 30px;
    }
    .header-content h1 { margin: 0; font-size: 24px; font-weight: 800; color: #dc2626; display: flex; align-items: center; gap: 10px; }
    .header-content p { margin: 6px 0 0; color: var(--text-muted); font-size: 14px; }
    
    .admin-btn {
        background: #1e293b; color: white; padding: 10px 18px; 
        border-radius: 10px; font-weight: 600; text-decoration: none; 
        font-size: 13px; display: inline-flex; align-items: center; gap: 8px;
        transition: 0.2s;
    }
    .admin-btn:hover { background: #0f172a; transform: translateY(-1px); }

    /* Category Section */
    .category-section { margin-bottom: 25px; }
    .cat-title { 
        display: flex; align-items: center; gap: 10px; 
        font-size: 16px; font-weight: 700; color: var(--text-muted); 
        margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px;
    }
    .cat-icon-box {
        width: 32px; height: 32px; background: #e2e8f0; border-radius: 8px;
        display: flex; align-items: center; justify-content: center; color: var(--text-main);
    }

    /* Grid Layout */
    .contact-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(340px, 1fr));
        gap: 16px;
    }

    /* Contact Card - Realistic Design */
    .contact-card {
        background: var(--card-bg);
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 15px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.02);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .contact-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.06);
        border-color: #cbd5e1;
    }

    .info-col { flex: 1; }
    .contact-name { font-size: 16px; font-weight: 700; color: var(--text-main); line-height: 1.3; }
    .contact-phone { 
        font-size: 18px; font-weight: 800; color: var(--text-main); 
        margin: 4px 0; letter-spacing: -0.5px; 
    }
    .contact-address { font-size: 12px; color: var(--text-muted); line-height: 1.4; display: flex; align-items: flex-start; gap: 4px; }

    /* Action Buttons */
    .actions-col {
        display: flex;
        flex-direction: column;
        gap: 8px;
        min-width: 100px;
    }
    .btn-action {
        display: flex; align-items: center; justify-content: center; gap: 8px;
        text-decoration: none; padding: 10px 12px; border-radius: 10px;
        font-weight: 600; font-size: 13px; transition: 0.2s;
    }
    
    /* Call Button - High Visibility Red */
    .btn-call {
        background: #fef2f2; color: var(--danger); border: 1px solid #fecaca;
    }
    .btn-call:hover { background: var(--danger); color: white; border-color: var(--danger); }
    
    /* WhatsApp Button */
    .btn-wa {
        background: #f0fdf4; color: var(--whatsapp); border: 1px solid #bbf7d0;
    }
    .btn-wa:hover { background: var(--whatsapp); color: white; border-color: var(--whatsapp); }

    /* Mobile Responsive */
    @media (max-width: 600px) {
        .contact-card { flex-direction: column; align-items: flex-start; }
        .actions-col { flex-direction: row; width: 100%; margin-top: 10px; }
        .btn-action { flex: 1; padding: 12px; font-size: 14px; }
        .page-header { text-align: center; justify-content: center; }
    }
  </style>
</head>
<body>

  <div class="main-wrap">
    
    <div class="page-header">
      <div class="header-content">
        <h1><i class="fa-solid fa-triangle-exclamation"></i> Kenalan Kecemasan</h1>
        <p>Senarai nombor penting untuk komuniti. Klik butang untuk tindakan pantas.</p>
      </div>
      <?php if ($role === 'AJK' || $role === 'Admin'): ?>
        <a class="admin-btn" href="admin_emergency.php">
            <i class="fa-solid fa-pen-to-square"></i> Urus Kenalan
        </a>
      <?php endif; ?>
    </div>

    <?php if (empty($grouped)): ?>
        <div style="text-align: center; padding: 40px; color: var(--text-muted);">
            <i class="fa-solid fa-folder-open" style="font-size: 40px; margin-bottom: 10px;"></i>
            <p>Tiada data kenalan kecemasan buat masa ini.</p>
        </div>
    <?php else: ?>
        
        <?php foreach ($grouped as $cat => $rows): 
            $icon = getCategoryIcon($cat); // Get dynamic icon
        ?>
            <div class="category-section">
                <div class="cat-title">
                    <div class="cat-icon-box"><i class="fa-solid <?php echo $icon; ?>"></i></div>
                    <?php echo h($cat); ?>
                </div>

                <div class="contact-grid">
                    <?php foreach ($rows as $c): ?>
                        <div class="contact-card">
                            <div class="info-col">
                                <div class="contact-name"><?php echo h($c['contact_name']); ?></div>
                                <div class="contact-phone"><?php echo h($c['phone_number']); ?></div>
                                <?php if (!empty($c['address'])): ?>
                                    <div class="contact-address">
                                        <i class="fa-solid fa-location-dot" style="margin-top:2px;"></i>
                                        <?php echo h($c['address']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="actions-col">
                                <a class="btn-action btn-call" href="tel:<?php echo h($c['phone_number']); ?>">
                                    <i class="fa-solid fa-phone"></i> Panggil
                                </a>
                                <a class="btn-action btn-wa" target="_blank" rel="noopener" href="<?php echo h(wa_link($c['phone_number'])); ?>">
                                    <i class="fa-brands fa-whatsapp"></i> WhatsApp
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

    <?php endif; ?>

  </div>

<?php include "footer.php"; ?>

</body>
</html>