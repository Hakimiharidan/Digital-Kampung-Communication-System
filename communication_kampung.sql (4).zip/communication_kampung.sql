-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2026 at 07:06 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `communication_kampung`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_details` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`activity_id`, `user_id`, `action_details`, `created_at`) VALUES
(8, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6IkZlc3RhIE1ha2FuIFJha3lhdCIsImRlc2NyaXB0aW9uIjoiTWVueWFzYXJrYW4gcGVuZ2xpYmF0YW4gb3JhbmcgbXVkYSB1bnR1ayBNa2FuYSIsImxvY2F0aW9uIjoiS3VsaW0sIEtlZGFoLCBNYWxheXNpYSIsInN0YXJ0X2RhdGV0aW1lIjoiMjAyNi0wMS0xNSAxMzo0NzowMCIsImVuZF9kYXRldGltZSI6IjIwMjYtMDEtMTYgMDY6NDk6MDAiLCJjYXRlZ29yeSI6IlNvY2lhbCIsInN1Ym1pdHRlZF9hdCI6IjIwMjUtMTItMzEgMTA6NDg6NTEiLCJhdHRhY2htZW50IjoicHJvcG9zYWxfMjAyNTEyMzFfMTA0ODUxXzFhZDkyY2U2X0ZHVl9GaW5hbmNpYWxfUmVwb3J0XzIwMjRfX0ludGVyYWN0aXZlXy5wZGYiLCJhamtfbm90ZSI6Imx1bHVzIiwiZGVjaXNpb25fYXQiOiIyMDI1LTEyLTMxIDEwOjU1OjA1IiwicmV2aWV3ZWRfYnkiOiJBSksgaS1EZXNhIChTYWxpbSBLYWlkYXIpIiwidHJhbnNmZXJyZWRfZXZlbnRfaWQiOjN9', '2025-12-31 09:48:51'),
(9, 13, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6IjEyMzQ1Njc4OSIsImRlc2NyaXB0aW9uIjoiYXNmZGdmaGdqaGtyZXd3ZXJ0IiwibG9jYXRpb24iOiIxMjM0NTY3OCIsInN0YXJ0X2RhdGV0aW1lIjoiMjAyNS0xMi0xOCAxNzo1MjowMCIsImVuZF9kYXRldGltZSI6IjIwMjUtMTItMjUgMTc6NTI6MDAiLCJjYXRlZ29yeSI6IlJlbGlnaW91cyIsInN1Ym1pdHRlZF9hdCI6IjIwMjUtMTItMzEgMTA6NTI6NTEiLCJhdHRhY2htZW50IjpudWxsLCJhamtfbm90ZSI6bnVsbCwiZGVjaXNpb25fYXQiOiIyMDI1LTEyLTMxIDE1OjMwOjM2IiwicmV2aWV3ZWRfYnkiOiJBSksgaS1EZXNhIChKYWhpbTAzKSIsInRyYW5zZmVycmVkX2V2ZW50X2lkIjoyfQ==', '2025-12-31 09:52:51'),
(10, 13, 'CAL_PROPOSAL_REVIEW|activity_id=8|decision=APPROVED', '2025-12-31 09:55:05'),
(11, 4, 'CAL_NOTIF_MARK_ALL_READ|affected=8', '2025-12-31 14:25:17'),
(12, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6IkFjYXJhIE1lbWFuY2luZyIsImRlc2NyaXB0aW9uIjoiSGFkaWFoIGJvbmFuemEgUk0xMDAwMDAiLCJsb2NhdGlvbiI6IktvbGFtIFBhayBUZWgiLCJzdGFydF9kYXRldGltZSI6IjIwMjYtMDEtMDIgMjI6Mjg6MDAiLCJlbmRfZGF0ZXRpbWUiOiIyMDI2LTAxLTAzIDIyOjI4OjAwIiwiY2F0ZWdvcnkiOiJTb2NpYWwiLCJzdWJtaXR0ZWRfYXQiOiIyMDI1LTEyLTMxIDE1OjI4OjI5IiwiYXR0YWNobWVudCI6bnVsbCwiYWprX25vdGUiOm51bGwsImRlY2lzaW9uX2F0IjoiMjAyNS0xMi0zMSAxNToyOToyNCIsInJldmlld2VkX2J5IjoiQUpLIGktRGVzYSAoSmFoaW0wMykiLCJ0cmFuc2ZlcnJlZF9ldmVudF9pZCI6MX0=', '2025-12-31 14:28:29'),
(13, 15, 'CAL_PROPOSAL_REVIEW|activity_id=12|decision=APPROVED', '2025-12-31 14:29:11'),
(14, 15, 'CAL_PROPOSAL_REVIEW|activity_id=12|decision=APPROVED', '2025-12-31 14:29:24'),
(15, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=12|event_id=1', '2025-12-31 14:29:25'),
(16, 15, 'CAL_RSVP|event_id=1|status=Not Going', '2025-12-31 14:30:19'),
(17, 15, 'CAL_PROPOSAL_REVIEW|activity_id=9|decision=APPROVED', '2025-12-31 14:30:36'),
(18, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=9|event_id=2', '2025-12-31 14:30:39'),
(19, 15, 'CAL_REMINDER_SEND|mode=upcoming|days=3|notes=2|emails=0', '2025-12-31 14:31:22'),
(20, 15, 'CAL_RSVP|event_id=1|status=Interested', '2025-12-31 14:36:13'),
(21, 13, 'CAL_PROPOSAL_TRANSFER|activity_id=8|event_id=3', '2025-12-31 15:39:03'),
(22, 15, 'CAL_CANCEL_REQUEST|request_id=1|event_id=3', '2025-12-31 16:13:48'),
(23, 15, 'CAL_EVENT_CANCEL_APPROVED|request_id=1|event_id=3|notif=2', '2025-12-31 16:14:11'),
(24, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6IktvbnNlcnQgQnJ1bm8gTWFycyIsImRlc2NyaXB0aW9uIjoiYnJ1bm8gZmVybmFuZGVzIGRhdGFuZyBrYW1wdW5nIiwibG9jYXRpb24iOiIiLCJzdGFydF9kYXRldGltZSI6IjIwMjYtMDEtMDIgMDA6MzM6MDAiLCJlbmRfZGF0ZXRpbWUiOiIyMDI2LTAxLTAzIDAwOjMzOjAwIiwiY2F0ZWdvcnkiOiJTb2NpYWwiLCJzdWJtaXR0ZWRfYXQiOiIyMDI1LTEyLTMxIDE3OjM0OjE3IiwiYXR0YWNobWVudCI6InByb3Bvc2FsXzIwMjUxMjMxXzE3MzQxN19jMmJiY2ZiYV8yMzExMy5wbmciLCJhamtfbm90ZSI6bnVsbCwiZGVjaXNpb25fYXQiOiIyMDI1LTEyLTMxIDE3OjM1OjE1IiwicmV2aWV3ZWRfYnkiOiJBSksgaS1EZXNhIChKYWhpbTAzKSIsInRyYW5zZmVycmVkX2V2ZW50X2lkIjo0fQ==', '2025-12-31 16:34:17'),
(25, 15, 'CAL_PROPOSAL_REVIEW|activity_id=24|decision=APPROVED', '2025-12-31 16:35:15'),
(26, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=24|event_id=4', '2025-12-31 16:35:22'),
(27, 4, 'CAL_RSVP|event_id=4|status=Not Going', '2025-12-31 16:42:48'),
(28, 4, 'CAL_CANCEL_REQUEST|request_id=2|event_id=4', '2025-12-31 16:43:11'),
(29, 13, 'CAL_EVENT_CANCEL_APPROVED|request_id=2|event_id=4|notif=2', '2025-12-31 16:44:15'),
(30, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6IkZhbWlseSBkYXkiLCJkZXNjcmlwdGlvbiI6ImZhbWlseSBzZW11YSIsImxvY2F0aW9uIjoiS3VsaW0sIEtlZGFoLCBNYWxheXNpYSIsInN0YXJ0X2RhdGV0aW1lIjoiMjAyNi0wMS0wNCAwMDo1OTowMCIsImVuZF9kYXRldGltZSI6IjIwMjYtMDEtMDQgMTI6NTk6MDAiLCJjYXRlZ29yeSI6Ik1lZXRpbmciLCJzdWJtaXR0ZWRfYXQiOiIyMDI1LTEyLTMxIDE4OjAwOjEwIiwiYXR0YWNobWVudCI6InByb3Bvc2FsXzIwMjUxMjMxXzE4MDAxMF8wNmU3Zjg2YV9NSVNJX0VuaGFuY2VkX0RhdGFiYXNlLnBuZyIsImFqa19ub3RlIjpudWxsLCJkZWNpc2lvbl9hdCI6IjIwMjUtMTItMzEgMTg6MDE6MDgiLCJyZXZpZXdlZF9ieSI6IkFKSyBpLURlc2EgKEphaGltMDMpIiwidHJhbnNmZXJyZWRfZXZlbnRfaWQiOjV9', '2025-12-31 17:00:10'),
(31, 15, 'CAL_PROPOSAL_REVIEW|activity_id=30|decision=APPROVED', '2025-12-31 17:01:08'),
(32, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=30|event_id=5', '2025-12-31 17:01:13'),
(33, 4, 'CAL_CANCEL_REQUEST|request_id=3|event_id=5', '2025-12-31 17:23:01'),
(34, 15, 'CAL_NOTIF_MARK_ALL_READ|affected=18', '2025-12-31 17:23:15'),
(35, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6IjMzNDU2NzgiLCJkZXNjcmlwdGlvbiI6InEydzM0NTY3ODkiLCJsb2NhdGlvbiI6IjEyMzQ1Njc4Iiwic3RhcnRfZGF0ZXRpbWUiOiIyMDI2LTAxLTAyIDAxOjI2OjAwIiwiZW5kX2RhdGV0aW1lIjoiMjAyNi0wMS0yMyAwMToyNjowMCIsImNhdGVnb3J5IjoiUmVsaWdpb3VzIiwic3VibWl0dGVkX2F0IjoiMjAyNS0xMi0zMSAxODoyNjozMSIsImF0dGFjaG1lbnQiOm51bGwsImFqa19ub3RlIjpudWxsLCJkZWNpc2lvbl9hdCI6IjIwMjYtMDEtMDcgMDg6MzE6MzQiLCJyZXZpZXdlZF9ieSI6IkFKSyBpLURlc2EgKEphaGltMDMpIiwidHJhbnNmZXJyZWRfZXZlbnRfaWQiOjh9', '2025-12-31 17:26:31'),
(36, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6Im1lbWFzYWsiLCJkZXNjcmlwdGlvbiI6IjEyMzQ1Njc4OXNkZmdoIiwibG9jYXRpb24iOiJLb2xhbSBQYWsgVGVoIiwic3RhcnRfZGF0ZXRpbWUiOiIyMDI2LTAxLTA4IDEyOjAxOjAwIiwiZW5kX2RhdGV0aW1lIjoiMjAyNi0wMS0wOSAxMjowMTowMCIsImNhdGVnb3J5IjoiU29jaWFsIiwic3VibWl0dGVkX2F0IjoiMjAyNi0wMS0wMSAwNTowMTo0NCIsImF0dGFjaG1lbnQiOiJwcm9wb3NhbF8yMDI2MDEwMV8wNTAxNDRfMWQzNDZiYmFfTUNEQV9FY29wbG9yZV9FdmFsdWF0aW9uX1JlcG9ydC5wZGYiLCJhamtfbm90ZSI6bnVsbCwiZGVjaXNpb25fYXQiOiIyMDI2LTAxLTAxIDA1OjAyOjI5IiwicmV2aWV3ZWRfYnkiOiJBSksgaS1EZXNhIChKYWhpbTAzKSIsInRyYW5zZmVycmVkX2V2ZW50X2lkIjo2fQ==', '2026-01-01 04:01:44'),
(37, 15, 'CAL_PROPOSAL_REVIEW|activity_id=36|decision=APPROVED', '2026-01-01 04:02:29'),
(38, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=36|event_id=6', '2026-01-01 04:02:41'),
(39, 4, 'CAL_CANCEL_REQUEST|request_id=4|event_id=6', '2026-01-01 04:03:31'),
(40, 15, 'CAL_EVENT_CANCEL_APPROVED|request_id=4|event_id=6|notif=2', '2026-01-01 04:04:02'),
(41, 13, 'CAL_NOTIF_MARK_ALL_READ|affected=14', '2026-01-01 04:26:26'),
(42, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6ImtlbmR1cmkiLCJkZXNjcmlwdGlvbiI6ImFuYWsga2F3aW4iLCJsb2NhdGlvbiI6IlJ1bWFoIFBhayBMZW1hbiIsInN0YXJ0X2RhdGV0aW1lIjoiMjAyNi0wMS0xMCAxMjo0MzowMCIsImVuZF9kYXRldGltZSI6IjIwMjYtMDEtMTAgMTI6NDM6MDAiLCJjYXRlZ29yeSI6IlNvY2lhbCIsInN1Ym1pdHRlZF9hdCI6IjIwMjYtMDEtMDEgMDU6NDQ6MTMiLCJhdHRhY2htZW50IjoicHJvcG9zYWxfMjAyNjAxMDFfMDU0NDEzXzZkMzE5NDRmX01DREFfRWNvcGxvcmVfRXZhbHVhdGlvbl9SZXBvcnQucGRmIiwiYWprX25vdGUiOm51bGwsImRlY2lzaW9uX2F0IjoiMjAyNi0wMS0wMSAwNTo0NTo0NCIsInJldmlld2VkX2J5IjoiQUpLIGktRGVzYSAoSmFoaW0wMykiLCJ0cmFuc2ZlcnJlZF9ldmVudF9pZCI6N30=', '2026-01-01 04:44:13'),
(43, 15, 'CAL_PROPOSAL_REVIEW|activity_id=42|decision=APPROVED', '2026-01-01 04:45:44'),
(44, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=42|event_id=7', '2026-01-01 04:45:57'),
(45, 4, 'CAL_CANCEL_REQUEST|request_id=5|event_id=7', '2026-01-01 04:47:25'),
(46, 15, 'CAL_EVENT_CANCEL_APPROVED|request_id=5|event_id=7|notif=2', '2026-01-01 04:48:04'),
(47, 15, 'CAL_EVENT_CANCEL_APPROVED|request_id=3|event_id=5|notif=2', '2026-01-07 07:31:27'),
(48, 15, 'CAL_PROPOSAL_REVIEW|activity_id=35|decision=APPROVED', '2026-01-07 07:31:34'),
(49, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=35|event_id=8', '2026-01-07 10:20:23'),
(50, 15, 'CAL_RSVP|event_id=1|status=Going', '2026-01-07 11:40:37'),
(51, 4, 'CAL_RSVP|event_id=1|status=Going', '2026-01-07 12:06:39'),
(52, 4, 'CAL_NOTIF_MARK_ALL_READ|affected=9', '2026-01-07 15:33:15'),
(53, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6IlBlcnRhbmRpbmdhbiBNZXdhcm5hIiwiZGVzY3JpcHRpb24iOiJQZXJ0YW5kaW5nYW4gTWV3YXJuYSBDYXdhbmdhbiBCYXJhdCIsImxvY2F0aW9uIjoiVGFiaWthIEtlbWFzIiwic3RhcnRfZGF0ZXRpbWUiOiIyMDI2LTAxLTExIDEwOjAwOjAwIiwiZW5kX2RhdGV0aW1lIjoiMjAyNi0wMS0xMiAwMDoxMzowMCIsImNhdGVnb3J5IjoiU29jaWFsIiwic3VibWl0dGVkX2F0IjoiMjAyNi0wMS0wNyAxNzoxNDozOCIsImF0dGFjaG1lbnQiOiJwcm9wb3NhbF8yMDI2MDEwN18xNzE0MzhfODgwMWJlNTVfUE9TVEVSLVBFUlRBTkRJTkdBTi1NRVdBUk5BLURBTi1NRUxVS0lTLU1ZLURPT0RMRS5qcGciLCJhamtfbm90ZSI6bnVsbCwiZGVjaXNpb25fYXQiOiIyMDI2LTAxLTA3IDE3OjE4OjIyIiwicmV2aWV3ZWRfYnkiOiJBSksgaS1EZXNhIChKYWhpbTAzKSIsInRyYW5zZmVycmVkX2V2ZW50X2lkIjo5fQ==', '2026-01-07 16:14:38'),
(54, 15, 'CAL_PROPOSAL_REVIEW|activity_id=53|decision=APPROVED', '2026-01-07 16:18:22'),
(55, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=53|event_id=9', '2026-01-07 16:18:28'),
(56, 15, 'CAL_CANCEL_REQUEST|request_id=6|event_id=8', '2026-01-08 02:47:36'),
(57, 15, 'CAL_EVENT_CANCEL_APPROVED|req_id=6|event_id=8', '2026-01-08 02:47:42'),
(58, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6Ik1hamxpcyBLYWh3aW4gTWVrIEVzYWgiLCJkZXNjcmlwdGlvbiI6IkplbXB1dGxhaCBrZSBtYWpsaXMgcGVya2Fod2lpbmFuIGthbWkiLCJsb2NhdGlvbiI6IlJ1bWFoIFBhayBMZW1hbiIsInN0YXJ0X2RhdGV0aW1lIjoiMjAyNi0wMS0xMCAxMTowOTowMCIsImVuZF9kYXRldGltZSI6IjIwMjYtMDEtMTAgMTc6MDk6MDAiLCJjYXRlZ29yeSI6IlBlcmthaHdpbmFuIiwic3VibWl0dGVkX2F0IjoiMjAyNi0wMS0wOCAwNDoxMDo1NyIsImF0dGFjaG1lbnQiOiJwcm9wb3NhbF8yMDI2MDEwOF8wNDEwNTdfMjk1Y2UyMjBfa2F0ZXJpbmcta2Fod2luLTEwMjR4NzI3LnBuZyIsImFqa19ub3RlIjpudWxsLCJkZWNpc2lvbl9hdCI6IjIwMjYtMDEtMDggMDQ6MTE6MjEiLCJyZXZpZXdlZF9ieSI6IkFKSyBpLURlc2EgKEphaGltMDMpIiwidHJhbnNmZXJyZWRfZXZlbnRfaWQiOjEwfQ==', '2026-01-08 03:10:57'),
(59, 15, 'CAL_PROPOSAL_REVIEW|activity_id=58|decision=APPROVED', '2026-01-08 03:11:21'),
(60, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=58|event_id=10', '2026-01-08 03:11:26'),
(61, 15, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6IlBlcmxhd2FuYW4gRnV0c2FsIEthbXB1bmciLCJkZXNjcmlwdGlvbiI6IlBlcmxhd2FuYW4gcGVyc2FoYWJhdGFuICBmdXRzYWwgYW50YXJhIGthbXB1bmciLCJsb2NhdGlvbiI6IkdlbGFuZ2dhbmcgRnV0c2FsIiwic3RhcnRfZGF0ZXRpbWUiOiIyMDI2LTAxLTE3IDA5OjEyOjAwIiwiZW5kX2RhdGV0aW1lIjoiMjAyNi0wMS0xOCAxMToxMjowMCIsImNhdGVnb3J5IjoiU3VrYW4iLCJzdWJtaXR0ZWRfYXQiOiIyMDI2LTAxLTA4IDA0OjEzOjQwIiwiYXR0YWNobWVudCI6InByb3Bvc2FsXzIwMjYwMTA4XzA0MTM0MF9jNjdlOTI1Zl9zdG9jay12ZWN0b3ItZnV0c2FsLXR5cG9ncmFwaGljLXZpbnRhZ2Utc3R5bGUtcG9zdGVyLXJldHJvLXZlY3Rvci1pbGx1c3RyYXRpb24tMjA5NjI4NjY4OC5qcGciLCJhamtfbm90ZSI6bnVsbCwiZGVjaXNpb25fYXQiOiIyMDI2LTAxLTA4IDA0OjEzOjU2IiwicmV2aWV3ZWRfYnkiOiJBSksgaS1EZXNhIChKYWhpbTAzKSIsInRyYW5zZmVycmVkX2V2ZW50X2lkIjoxMX0=', '2026-01-08 03:13:40'),
(62, 15, 'CAL_PROPOSAL_REVIEW|activity_id=61|decision=APPROVED', '2026-01-08 03:13:56'),
(63, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=61|event_id=11', '2026-01-08 03:14:02'),
(64, 4, 'CAL_RSVP|event_id=10|status=Going', '2026-01-08 04:56:25'),
(65, 4, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6Ik1ha2FuIE1hbGFtIiwiZGVzY3JpcHRpb24iOiJlcmEgbXV6aWsgaGl0IHRlcmJhaWsiLCJsb2NhdGlvbiI6Ikt1bGltLCBLZWRhaCwgTWFsYXlzaWEiLCJzdGFydF9kYXRldGltZSI6IjIwMjYtMDEtMTkgMDQ6NTg6MDAiLCJlbmRfZGF0ZXRpbWUiOiIyMDI2LTAxLTIxIDA0OjU4OjAwIiwiY2F0ZWdvcnkiOiJTb3NpYWwiLCJzdWJtaXR0ZWRfYXQiOiIyMDI2LTAxLTE3IDIxOjU5OjEwIiwiYXR0YWNobWVudCI6InByb3Bvc2FsXzIwMjYwMTE3XzIxNTkxMF81ZTA0MzBlYl93d2V3ZS5qcGciLCJhamtfbm90ZSI6bnVsbCwiZGVjaXNpb25fYXQiOiIyMDI2LTAxLTE3IDIyOjAwOjA5IiwicmV2aWV3ZWRfYnkiOiJBSksgaS1EZXNhIChKYWhpbTAzKSIsInRyYW5zZmVycmVkX2V2ZW50X2lkIjoxMn0=', '2026-01-17 20:59:10'),
(66, 15, 'CAL_PROPOSAL_REVIEW|activity_id=65|decision=APPROVED', '2026-01-17 21:00:09'),
(67, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=65|event_id=12', '2026-01-17 21:00:14'),
(68, 15, 'CAL_REMINDER_SEND|mode=upcoming|events=1|inapp=4|email_ok=0|email_fail=4|wa_ok=0|wa_fail=0|wa_skipped=4', '2026-01-17 23:28:21'),
(69, 4, 'CAL_RSVP|event_id=1|status=Not Going', '2026-01-17 23:51:47'),
(70, 15, 'CAL_CANCEL_REQUEST|request_id=7|event_id=12', '2026-01-17 23:58:31'),
(71, 15, 'CAL_EVENT_CANCEL_APPROVED|req_id=7|event_id=12', '2026-01-17 23:58:37'),
(72, 18, 'CAL_PROPOSAL|STATUS=TRANSFERRED|PAYLOAD=eyJ0aXRsZSI6Ik1hamxpcyBLYWh3aW4iLCJkZXNjcmlwdGlvbiI6IkRpamVtcHV0IFNlbXVhIGhhZGlyIiwibG9jYXRpb24iOiJEZXdhbiBLYW1wdW5nIiwic3RhcnRfZGF0ZXRpbWUiOiIyMDI2LTAxLTMxIDExOjAwOjAwIiwiZW5kX2RhdGV0aW1lIjoiMjAyNi0wMS0zMSAyMDozMzowMCIsImNhdGVnb3J5IjoiUGVya2Fod2luYW4iLCJzdWJtaXR0ZWRfYXQiOiIyMDI2LTAxLTE4IDAxOjM0OjE0IiwiYXR0YWNobWVudCI6InByb3Bvc2FsXzIwMjYwMTE4XzAxMzQxNF9iOWRlYTM0Yl9TeWFmaXEucG5nIiwiYWprX25vdGUiOm51bGwsImRlY2lzaW9uX2F0IjoiMjAyNi0wMS0xOCAwMTozNjoyOCIsInJldmlld2VkX2J5IjoiQUpLIGktRGVzYSAoSmFoaW0wMykiLCJ0cmFuc2ZlcnJlZF9ldmVudF9pZCI6MTN9', '2026-01-18 00:34:14'),
(73, 15, 'CAL_PROPOSAL_REVIEW|activity_id=72|decision=APPROVED', '2026-01-18 00:36:28'),
(74, 15, 'CAL_PROPOSAL_TRANSFER|activity_id=72|event_id=13', '2026-01-18 00:36:32');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `contact_name` varchar(100) NOT NULL,
  `contact_phone` varchar(20) NOT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `user_origin` enum('Resident','Outsider') DEFAULT 'Resident',
  `facility_id` int(11) NOT NULL,
  `booking_date` date NOT NULL,
  `start_time` time NOT NULL,
  `duration_hours` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `status` enum('Pending','Awaiting Payment','Confirmed','Rejected') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `contact_name`, `contact_phone`, `contact_email`, `user_origin`, `facility_id`, `booking_date`, `start_time`, `duration_hours`, `total_amount`, `purpose`, `status`, `created_at`) VALUES
(1, 'MUHAMMAD FIRAS FAIQ BIN KHATTULANUAR', '0184047860', 'faiqfiras71@gmail.com', 'Resident', 1, '2026-01-24', '00:00:00', 24, 50.00, '123', 'Confirmed', '2026-01-04 21:29:39'),
(0, 'Jahim03', '0142356799922', 'rotikayacair@gmail.com', 'Resident', 1, '2026-01-09', '00:00:00', 72, 150.00, '222', 'Confirmed', '2026-01-07 16:28:37');

-- --------------------------------------------------------

--
-- Table structure for table `bulletin_feedback`
--

CREATE TABLE `bulletin_feedback` (
  `feedback_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `feedback_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bulletin_feedback`
--

INSERT INTO `bulletin_feedback` (`feedback_id`, `post_id`, `feedback_text`, `created_at`) VALUES
(3, 12, 'alhamdulillah', '2026-01-04 19:28:41'),
(4, 12, 'Noted', '2026-01-06 14:35:37'),
(5, 16, 'terbaik', '2026-01-08 04:54:54');

-- --------------------------------------------------------

--
-- Table structure for table `bulletin_posts`
--

CREATE TABLE `bulletin_posts` (
  `post_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category` enum('News','Event') NOT NULL DEFAULT 'News',
  `content` text NOT NULL,
  `event_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `location_link` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `program_date` date DEFAULT NULL,
  `is_pinned` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bulletin_posts`
--

INSERT INTO `bulletin_posts` (`post_id`, `title`, `category`, `content`, `event_date`, `created_at`, `location_link`, `attachment`, `program_date`, `is_pinned`) VALUES
(10, 'Laporan: Program Kembali ke Sekolah 2026', 'Event', 'Alhamdulillah, seramai 50 orang anak-anak kampung telah menerima bantuan beg sekolah dan alat tulis hasil sumbangan penduduk. Terima kasih kepada semua penyumbang.', NULL, '2025-12-29 01:00:00', 'http://googleusercontent.com/maps.google.com/hall', NULL, '2025-12-28', 0),
(11, 'Selesai: Pembaikan Jalan Masuk Utama', '', 'Kerja-kerja menurap semula jalan di pintu masuk utama kampung telah selesai sepenuhnya pada minggu lepas. Penduduk diminta memandu dengan berhemah.', NULL, '2025-12-15 06:30:00', NULL, NULL, NULL, 0),
(12, 'Kenduri Kesyukuran Akhir Tahun', 'Event', 'Majlis tahlil dan doa selamat sempena penutup tahun 2025 telah berjalan lancar di Masjid Jamek. Kehadiran mencecah 200 orang penduduk.', NULL, '2026-01-01 00:00:00', 'http://googleusercontent.com/maps.google.com/masjid', NULL, '2025-12-31', 0),
(13, 'Gotong-Royong Membersih Longkang (Pasca Banjir)', 'Event', 'Terima kasih kepada semua AJK dan belia yang turun padang membersihkan longkang tersumbat akibat hujan lebat bulan lepas.', NULL, '2025-11-21 02:00:00', NULL, NULL, '2025-11-20', 0),
(14, 'Keputusan Pertandingan Memancing', 'Event', 'Tahniah kepada Encik Rosli kerana menjuarai pertandingan memancing sungai kampung dengan tangkapan seberat 3kg. Hadiah telah disampaikan oleh Ketua Kampung.', NULL, '2025-10-16 04:00:00', 'http://googleusercontent.com/maps.google.com/sungai', NULL, '2025-10-15', 0),
(15, '🚨 [EMERGENCY] Amaran RIbut Taufan', 'News', 'Ribut Taufan Berskala 6 akan melanda kampung kita', NULL, '2026-01-07 16:31:11', NULL, NULL, NULL, 1),
(16, 'gotong royong', 'Event', 'baru selesai', '2026-01-07', '2026-01-08 04:54:34', NULL, 'uploads/bulletin/20260108_055434_stock-vector-futsal-typographic-vintage-style-poster-retro-vector-illustration-2096286688_e3cca630.jpg', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `calendar_settings`
--

CREATE TABLE `calendar_settings` (
  `setting_id` int(11) NOT NULL,
  `setting_key` varchar(50) NOT NULL COMMENT 'e.g., max_events_per_day',
  `setting_value` varchar(255) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calendar_settings`
--

INSERT INTO `calendar_settings` (`setting_id`, `setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES
(1, 'allow_conflicting_events', 'FALSE', 1, '2025-12-30 09:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `complaint_name` varchar(255) NOT NULL,
  `complaint_phone` varchar(20) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('New','Reviewed','In Progress','Resolved') DEFAULT 'New',
  `reply` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `user_id`, `complaint_name`, `complaint_phone`, `title`, `description`, `image`, `status`, `reply`, `created_at`, `updated_at`) VALUES
(4, 1, 'Syam Dany', '011-5436789', 'Masalah Longkang Tersumbat', 'Longkang di lorong 2 tersumbat dan berbau.', NULL, 'In Progress', '', '2026-01-04 17:16:15', '2026-01-06 10:33:36'),
(5, NULL, 'MOHAMAD ZAIDAN', '0107966760', 'KEROSAKAN JALAN', 'SEBELAH RUMAH CIK JAH', '', 'New', NULL, '2026-01-04 17:40:58', '2026-01-05 17:04:16'),
(6, 4, 'Rahim', '01423567999', 'kerosakan jalan raya', 'sebelah rumah cik jah', '1767548837_logo_uum.png', 'Resolved', 'Selesai', '2026-01-04 17:47:17', '2026-01-06 14:05:02'),
(7, NULL, '', '', 'kerosakan jalan raya', 'berhadapan rumah cik jah', '1767551721_logo_uum.png', 'Resolved', 'dah selesai', '2026-01-04 18:35:21', '2026-01-05 17:12:22'),
(12, NULL, '', '', 'basikal jatuh', 'depan kedai ah chong', '1767555117_download.jpg', 'In Progress', '', '2026-01-04 19:31:57', '2026-01-05 19:52:40'),
(13, 4, 'Rahim', '01423567999', 'wert', 'qwerty', '', 'In Progress', '', '2026-01-05 16:22:17', '2026-01-06 10:32:23'),
(14, 4, '', '', 'Bosan', 'Nothing Feels better', '', 'In Progress', '', '2026-01-05 17:20:55', '2026-01-06 13:47:02'),
(15, 4, 'Rahim', '01423567999', 'Myvi Terbang', 'simpang 4', 'complaints/complaint_20260106_111948_bb5bc2e3.png', 'New', '', '2026-01-06 10:19:48', '2026-01-06 14:17:28'),
(16, 13, 'Salim Kaidar', '223232332', 'Sajo', 'Testing1', 'complaints/complaint_20260106_153038_bef423a6.jpg', 'Resolved', '', '2026-01-06 14:30:38', '2026-01-07 07:29:33');

-- --------------------------------------------------------

--
-- Table structure for table `emergency_contacts`
--

CREATE TABLE `emergency_contacts` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `contact_name` varchar(100) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emergency_contacts`
--

INSERT INTO `emergency_contacts` (`id`, `category`, `contact_name`, `phone_number`, `address`, `created_at`) VALUES
(1, 'Security', 'Balai Polis Alor Setar', '04-7321222', 'Balai Polis Alor Setar Polis Diraja Malaysia Jalan Raja, 05560 Alor Setar. Kedah', '2026-01-04 17:33:40'),
(2, 'Security', 'Station Chief Balai Bomba dan Penyelamat Alor Setar', '04 – 734 4444', 'Jalan Tun Razak, 05200 Alor Setar, Kedah', '2026-01-04 17:33:40'),
(3, 'Medical', 'Hospital Sultanah Bahiyah', '04-7406233', 'KM 6, Jln Langgar, Alor Setar Alor Setar, Kedah05460 Alor Setar,Kedah', '2026-01-04 17:33:40'),
(4, 'Medical', 'Klinik Kesihatan Alor Mengkudu', '04-7340078', 'Jalan Alor Mengkudu, Alor Setar, 05100, Kota Setar, Kedah', '2026-01-04 17:33:40'),
(5, 'Village Admin', 'Ketua Kampung (Mr. Hakimi)', '012-345 6789', 'Pejabat JKKK', '2026-01-04 17:33:40'),
(6, 'Utilities', 'Tenaga Nasional Berhad (Alor Setar)', '15454', '887, Jalan Sehala, Bandar Alor Setar, 05200 Alor Setar, Kedah', '2026-01-04 17:33:40'),
(7, 'Utilities', 'Syarikat Air (SADA)', '1-300-88-001', 'Hotline', '2026-01-04 17:33:40'),
(8, 'Village Admin', 'Ketua Daerah (Tuan Zaidan)', '015-6789012', 'Rumah No 93', '2026-01-04 17:46:11');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `event_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL COMMENT 'Stores filename e.g. event_101.pdf or poster_fest.jpg',
  `location` varchar(255) DEFAULT NULL COMMENT 'e.g., Dewan Orang Ramai, Padang Bola',
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `category` enum('Meeting','Gotong-royong','Sport','Religious','Social','Emergency','Perkahwinan') NOT NULL DEFAULT 'Social',
  `status` enum('Scheduled','Postponed','Cancelled','Completed') DEFAULT 'Scheduled',
  `created_by` int(11) NOT NULL COMMENT 'The Admin or AJK who created the event',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `title`, `description`, `attachment`, `location`, `start_datetime`, `end_datetime`, `category`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Acara Memancing', 'Hadiah bonanza RM100000', NULL, 'Kolam Pak Teh', '2026-01-02 22:28:00', '2026-01-03 22:28:00', '', 'Scheduled', 15, '2025-12-31 14:29:25', '2025-12-31 14:29:25'),
(9, 'Pertandingan Mewarna', 'Pertandingan Mewarna Cawangan Barat', 'proposal_20260107_171438_8801be55_POSTER-PERTANDINGAN-MEWARNA-DAN-MELUKIS-MY-DOODLE.jpg', 'Tabika Kemas', '2026-01-11 10:00:00', '2026-01-12 00:13:00', '', 'Scheduled', 15, '2026-01-07 16:18:28', '2026-01-07 16:18:28'),
(10, 'Majlis Kahwin Mek Esah', 'Jemputlah ke majlis perkahwiinan kami', 'proposal_20260108_041057_295ce220_katering-kahwin-1024x727.png', 'Rumah Pak Leman', '2026-01-10 11:09:00', '2026-01-10 17:09:00', 'Perkahwinan', 'Scheduled', 15, '2026-01-08 03:11:26', '2026-01-08 03:11:26'),
(13, 'Majlis Kahwin', 'Dijemput Semua hadir', 'proposal_20260118_013414_b9dea34b_Syafiq.png', 'Dewan Kampung', '2026-01-31 11:00:00', '2026-01-31 20:33:00', 'Perkahwinan', 'Scheduled', 15, '2026-01-18 00:36:32', '2026-01-18 00:36:32');

-- --------------------------------------------------------

--
-- Table structure for table `event_attendance`
--

CREATE TABLE `event_attendance` (
  `attendance_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rsvp_status` enum('Going','Interested','Not Going') DEFAULT 'Going',
  `reminder_sent` tinyint(1) DEFAULT 0 COMMENT '0 = No reminder sent yet, 1 = Reminder sent',
  `rsvp_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `checked_in_at` timestamp NULL DEFAULT NULL COMMENT 'Time when presence was verified by AJK or QR scan'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_attendance`
--

INSERT INTO `event_attendance` (`attendance_id`, `event_id`, `user_id`, `rsvp_status`, `reminder_sent`, `rsvp_date`, `checked_in_at`) VALUES
(1, 1, 15, 'Going', 0, '2026-01-07 11:40:37', NULL),
(5, 1, 4, 'Not Going', 0, '2026-01-17 23:51:47', NULL),
(6, 10, 4, 'Going', 0, '2026-01-08 04:56:25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `event_cancellation_requests`
--

CREATE TABLE `event_cancellation_requests` (
  `request_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `requested_by` int(11) NOT NULL,
  `reason` text NOT NULL,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `reviewer_note` text DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `requested_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `facility_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `rate_per_hour` decimal(10,2) NOT NULL,
  `price_unit` enum('Hour','Day') NOT NULL DEFAULT 'Hour',
  `status` enum('Available','Maintenance') DEFAULT 'Available',
  `image_path` varchar(255) DEFAULT 'https://placehold.co/100x100?text=Tiada+Gambar'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`facility_id`, `name`, `description`, `rate_per_hour`, `price_unit`, `status`, `image_path`) VALUES
(1, 'Dewan Serbaguna', 'Dewan utama untuk majlis perkahwinan dan acara komuniti.', 50.00, 'Day', 'Available', 'uploads/facilities/20260108_034529_IMG_0099_0904ade3.jpg'),
(2, 'Gelanggang Badminton', 'Gelanggang sukan komuniti berbumbung.', 10.00, 'Hour', 'Available', 'uploads/facilities/20260108_034540_1GvakrL2zGtyq63AB48pURAJWJk7DC63IcyQ5NI1_2a055313.jpg'),
(3, 'Set Sistem PA', 'Sistem audio mudah alih untuk ceramah atau majlis kecil.', 20.00, 'Day', 'Available', 'uploads/facilities/20260108_034619_pa-system1_20e173a7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `lost_found_reports`
--

CREATE TABLE `lost_found_reports` (
  `report_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'The resident submitting the report',
  `type` enum('Lost','Found') NOT NULL COMMENT 'Is the user looking for this or did they find it?',
  `item_name` varchar(100) NOT NULL,
  `description` text NOT NULL COMMENT 'Color, brand, distinct features',
  `category` enum('Electronics','Documents','Wallet/Purse','Keys','Pets','Clothing','Other') DEFAULT 'Other',
  `location_detail` varchar(255) NOT NULL COMMENT 'Where it was last seen or found',
  `incident_date` date NOT NULL,
  `image_path` varchar(255) DEFAULT NULL COMMENT 'Path to uploaded photo (Essential for identification)',
  `status` enum('Pending','Published','Claimed','Rejected') DEFAULT 'Pending' COMMENT 'Pending = Waiting for AJK approval. Published = Visible to all.',
  `contact_share_consent` tinyint(1) DEFAULT 0 COMMENT '1 = Allow other users to see my phone number to contact me directly',
  `admin_remarks` text DEFAULT NULL COMMENT 'Reason for rejection or notes on resolution',
  `resolved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lost_found_reports`
--

INSERT INTO `lost_found_reports` (`report_id`, `user_id`, `type`, `item_name`, `description`, `category`, `location_detail`, `incident_date`, `image_path`, `status`, `contact_share_consent`, `admin_remarks`, `resolved_at`, `created_at`, `updated_at`) VALUES
(1, 4, 'Found', 'Mesin Basuh', 'Warna ungu', 'Electronics', 'Pejabat Pos', '2025-12-30', 'uploads/lostfound/lf_20251230_151736_db1c7373.png', 'Claimed', 1, 'Kes telah diselesaikan oleh AJK.', '2025-12-30 14:38:25', '2025-12-30 14:17:36', '2025-12-30 14:38:25'),
(2, 15, 'Lost', 'Baju tidur', 'Corak Hello Kitty', 'Clothing', 'Rumah Afdal', '2025-12-30', 'uploads/lostfound/lf_20251230_154536_bd2fcdf4.jpg', 'Claimed', 1, '[CLAIM 2025-12-30 16:40:57] Jahim03 (UID:15): saya sudah memebritahu penjumpa tersebut\n[DONE 2025-12-30 16:41:42] [CLAIM 2025-12-30 16:40:57] Jahim03 (UID:15): saya sudah memebritahu penjumpa tersebut', '2025-12-30 15:41:42', '2025-12-30 14:45:36', '2025-12-30 15:41:42'),
(3, 15, 'Found', 'Sijil Nikah', 'sijil nikah mad isa', 'Documents', 'Pejabat Pos', '2025-12-29', 'uploads/lostfound/lf_20251230_160827_a6bbef52.png', 'Claimed', 1, '[CLAIM 2025-12-30 16:23:13] Jahim03 (UID:15): 79399002233232\n[DONE 2025-12-30 16:23:53] [CLAIM 2025-12-30 16:23:13] Jahim03 (UID:15): 79399002233232', '2025-12-30 15:23:53', '2025-12-30 15:08:27', '2025-12-30 15:23:53'),
(4, 4, 'Found', 'baju dalam', 'baju caler biru dgn tompok2', 'Clothing', 'Rumah Timah', '2025-12-30', 'uploads/lostfound/lf_20251230_165715_f78dc86f.png', 'Rejected', 1, '[REQUEST 2025-12-30 16:58:21] tolong terangkan secara jelas lagi.\n\n[REJECT 2025-12-30 18:19:30]\n[REQUEST 2025-12-30 16:58:21] tolong terangkan secara jelas lagi.\nDisemak oleh: AJK i-Desa (Jahim03)', NULL, '2025-12-30 15:57:15', '2025-12-30 17:19:30'),
(5, 4, 'Lost', '222', '2222232343567890987654', 'Keys', 'Pejabat Pos', '2025-12-26', NULL, 'Rejected', 1, '[REQUEST 2025-12-30 18:13:31]\n[REQUEST 2025-12-31 01:13:05]\r\nSila jelaskan ciri barang dengan lebih terperinci: warna, jenama, saiz, tanda khas, dan jika ada nombor siri.\r\nDisemak oleh: AJK i-Desa (Man)\nDisemak oleh: AJK i-Desa (Jahim03)\n\n[REJECT 2025-12-30 18:19:28]\n[REQUEST 2025-12-30 18:13:31]\r\n[REQUEST 2025-12-31 01:13:05]\r\nSila jelaskan ciri barang dengan lebih terperinci: warna, jenama, saiz, tanda khas, dan jika ada nombor siri.\r\nDisemak oleh: AJK i-Desa (Man)\r\nDisemak oleh: AJK i-Desa (Jahim03)\nDisemak oleh: AJK i-Desa (Jahim03)', NULL, '2025-12-30 17:12:38', '2025-12-30 17:19:28'),
(6, 4, 'Found', 'motorsikal', 'wardasfdghnjhnfdsa', 'Other', 'Rumah Afdal', '2025-12-31', NULL, 'Rejected', 1, '[REQUEST 2025-12-30 18:18:04]\nSila jelaskan ciri barang dengan lebih terperinci: warna, jenama, saiz, tanda khas, dan jika ada nombor siri.\nDisemak oleh: AJK i-Desa (Jahim03)\n\n[REJECT 2025-12-30 18:19:25]\n[REQUEST 2025-12-30 18:18:04]\r\nSila jelaskan ciri barang dengan lebih terperinci: warna, jenama, saiz, tanda khas, dan jika ada nombor siri.\r\nDisemak oleh: AJK i-Desa (Jahim03)\nDisemak oleh: AJK i-Desa (Jahim03)', NULL, '2025-12-30 17:15:45', '2025-12-30 17:19:25'),
(7, 4, 'Found', 'Sijil SPM', 'sdfghjklkjhgf', 'Documents', 'Rumah Timah', '2026-01-22', 'uploads/lostfound/lf_20260101_050730_7f2f83dd.png', 'Claimed', 1, '[CLAIM 2026-01-01 05:08:14] Jahim03 (UID:15): dsdffsdfsfs\n\n[DONE 2026-01-01 05:08:28]\n[CLAIM 2026-01-01 05:08:14] Jahim03 (UID:15): dsdffsdfsfs\nDisemak oleh: AJK i-Desa (Jahim03)', '2026-01-01 04:08:28', '2026-01-01 04:07:30', '2026-01-01 04:08:28'),
(8, 4, 'Found', 'Lembu', 'makan tanaman saya', 'Pets', 'Rumah Afdal', '2026-01-01', 'uploads/lostfound/lf_20260101_055353_b8b52658.png', 'Published', 1, NULL, NULL, '2026-01-01 04:53:53', '2026-01-07 16:26:42'),
(9, 4, 'Found', 'q23e45rt', '23456765432q2345yui', 'Documents', 'Rumah Timah', '2026-01-07', NULL, 'Claimed', 1, '[DONE 2026-01-08 03:48:15]\nKes telah diselesaikan oleh AJK.\nDisemak oleh: AJK i-Desa (Jahim03)', '2026-01-08 02:48:15', '2026-01-07 07:30:41', '2026-01-08 02:48:15'),
(10, 17, 'Lost', 'Sijil Nikah', 'dalam fail', 'Documents', 'rumah saya', '2026-01-08', 'uploads/lostfound/lf_20260108_054614_c0d0fa0f.jpg', 'Published', 1, NULL, NULL, '2026-01-08 04:46:14', '2026-01-08 04:48:07');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL COMMENT 'Receiver of the notification',
  `event_id` int(11) DEFAULT NULL COMMENT 'Link to event if this is a reminder',
  `message` text NOT NULL,
  `type` enum('Reminder','Emergency','General','System') DEFAULT 'General',
  `is_read` tinyint(1) DEFAULT 0 COMMENT '0 = Unread, 1 = Read',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_archived` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `user_id`, `event_id`, `message`, `type`, `is_read`, `created_at`, `is_archived`) VALUES
(2, 13, NULL, 'TUNTUTAN PEMILIK diterima untuk item (ID: #1) [Mesin Basuh] daripada Salim Kaidar. Maklumat: aeddwqeq3eq3e', 'System', 1, '2025-12-30 14:29:19', 0),
(3, 4, NULL, 'Status laporan anda telah ditetapkan sebagai SELESAI. Nota: Kes telah diselesaikan oleh AJK. (ID: #1)', 'System', 1, '2025-12-30 14:38:25', 0),
(4, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #2)', 'System', 1, '2025-12-30 14:45:36', 0),
(5, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #2)', 'System', 1, '2025-12-30 14:45:36', 0),
(6, 15, NULL, 'Laporan anda telah diluluskan dan dipaparkan di papan Barang Hilang & Jumpa. (ID: #2)', 'System', 1, '2025-12-30 14:49:25', 0),
(7, 13, NULL, 'TUNTUTAN PEMILIK diterima untuk item (ID: #2) [Baju tidur] daripada Jahim03. Maklumat: 12345t6y789098765432', 'System', 1, '2025-12-30 14:50:03', 0),
(8, 15, NULL, 'TUNTUTAN PEMILIK diterima untuk item (ID: #2) [Baju tidur] daripada Jahim03. Maklumat: 12345t6y789098765432', 'System', 1, '2025-12-30 14:50:03', 0),
(9, 13, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:16', 0),
(10, 15, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:16', 0),
(11, 13, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:19', 0),
(12, 15, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:19', 0),
(13, 13, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:24', 0),
(14, 15, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:24', 0),
(15, 13, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:35', 0),
(16, 15, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:35', 0),
(17, 13, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:42', 0),
(18, 15, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:07:42', 0),
(19, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #3)', 'System', 1, '2025-12-30 15:08:27', 0),
(20, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #3)', 'System', 1, '2025-12-30 15:08:27', 0),
(21, 15, NULL, 'Laporan anda telah diluluskan dan dipaparkan di papan Barang Hilang & Jumpa. (ID: #3)', 'System', 1, '2025-12-30 15:09:07', 0),
(22, 13, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:09:11', 0),
(23, 15, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:09:11', 0),
(24, 13, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:09:20', 0),
(25, 15, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:09:20', 0),
(26, 13, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:09:27', 0),
(27, 15, NULL, 'CLAIM_LF:# | Item:  | Oleh: Jahim03 (UID:15) | ', 'System', 1, '2025-12-30 15:09:27', 0),
(28, 13, NULL, 'CLAIM_LF:#3 | Item: Sijil Nikah | Oleh: Jahim03 (UID:15) | 79399002233232', 'System', 1, '2025-12-30 15:23:13', 0),
(29, 15, NULL, 'CLAIM_LF:#3 | Item: Sijil Nikah | Oleh: Jahim03 (UID:15) | 79399002233232', 'System', 1, '2025-12-30 15:23:13', 0),
(30, 15, NULL, 'Status laporan anda telah ditetapkan sebagai SELESAI. Nota: [CLAIM 2025-12-30 16:23:13] Jahim03 (UID:15): 79399002233232 (ID: #3)', 'System', 1, '2025-12-30 15:23:53', 0),
(31, 13, NULL, 'CLAIM_LF:#2 | Item: Baju tidur | Oleh: Jahim03 (UID:15) | saya sudah memebritahu penjumpa tersebut', 'System', 1, '2025-12-30 15:40:57', 0),
(32, 15, NULL, 'CLAIM_LF:#2 | Item: Baju tidur | Oleh: Jahim03 (UID:15) | saya sudah memebritahu penjumpa tersebut', 'System', 1, '2025-12-30 15:40:57', 0),
(33, 15, NULL, 'Status laporan anda telah ditetapkan sebagai SELESAI. Nota: [CLAIM 2025-12-30 16:40:57] Jahim03 (UID:15): saya sudah memebritahu penjumpa tersebut (ID: #2)', 'System', 1, '2025-12-30 15:41:42', 0),
(34, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #4)', 'System', 1, '2025-12-30 15:57:15', 0),
(35, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #4)', 'System', 1, '2025-12-30 15:57:15', 0),
(37, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #5)', 'System', 1, '2025-12-30 17:12:38', 0),
(38, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #5)', 'System', 1, '2025-12-30 17:12:38', 0),
(39, 4, NULL, 'AJK memerlukan maklumat tambahan untuk laporan anda:\n[REQUEST 2025-12-30 18:13:31]\n[REQUEST 2025-12-31 01:13:05]\r\nSila jelaskan ciri barang dengan lebih terperinci: warna, jenama, saiz, tanda khas, dan jika ada nombor siri.\r\nDisemak oleh: AJK i-Desa (Man)\nDisemak oleh: AJK i-Desa (Jahim03)\n(ID: #5)', 'System', 1, '2025-12-30 17:13:31', 0),
(40, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #6)', 'System', 1, '2025-12-30 17:15:45', 0),
(41, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #6)', 'System', 1, '2025-12-30 17:15:45', 0),
(42, 4, NULL, 'AJK memerlukan maklumat tambahan untuk laporan anda:\n[REQUEST 2025-12-30 18:18:04]\nSila jelaskan ciri barang dengan lebih terperinci: warna, jenama, saiz, tanda khas, dan jika ada nombor siri.\nDisemak oleh: AJK i-Desa (Jahim03)\n(ID: #6)', 'System', 1, '2025-12-30 17:18:04', 0),
(43, 4, NULL, 'Laporan anda telah ditolak.\n[REJECT 2025-12-30 18:19:25]\n[REQUEST 2025-12-30 18:18:04]\r\nSila jelaskan ciri barang dengan lebih terperinci: warna, jenama, saiz, tanda khas, dan jika ada nombor siri.\r\nDisemak oleh: AJK i-Desa (Jahim03)\nDisemak oleh: AJK i-Desa (Jahim03)\n(ID: #6)', 'System', 1, '2025-12-30 17:19:25', 0),
(44, 4, NULL, 'Laporan anda telah ditolak.\n[REJECT 2025-12-30 18:19:28]\n[REQUEST 2025-12-30 18:13:31]\r\n[REQUEST 2025-12-31 01:13:05]\r\nSila jelaskan ciri barang dengan lebih terperinci: warna, jenama, saiz, tanda khas, dan jika ada nombor siri.\r\nDisemak oleh: AJK i-Desa (Man)\r\nDisemak oleh: AJK i-Desa (Jahim03)\nDisemak oleh: AJK i-Desa (Jahim03)\n(ID: #5)', 'System', 1, '2025-12-30 17:19:28', 0),
(45, 4, NULL, 'Laporan anda telah ditolak.\n[REJECT 2025-12-30 18:19:30]\n[REQUEST 2025-12-30 16:58:21] tolong terangkan secara jelas lagi.\nDisemak oleh: AJK i-Desa (Jahim03)\n(ID: #4)', 'System', 1, '2025-12-30 17:19:30', 0),
(46, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2025-12-31 09:48:51', 0),
(47, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #8)', 'System', 1, '2025-12-31 09:48:51', 0),
(48, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #8)', 'System', 1, '2025-12-31 09:48:51', 0),
(49, 13, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2025-12-31 09:52:51', 0),
(50, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #9)', 'System', 1, '2025-12-31 09:52:51', 0),
(51, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #9)', 'System', 1, '2025-12-31 09:52:51', 0),
(52, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK. Catatan: lulus', 'System', 1, '2025-12-31 09:55:05', 0),
(53, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2025-12-31 14:28:29', 0),
(54, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #12)', 'System', 1, '2025-12-31 14:28:29', 0),
(55, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #12)', 'System', 1, '2025-12-31 14:28:29', 0),
(56, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2025-12-31 14:29:11', 0),
(57, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2025-12-31 14:29:24', 0),
(58, 4, 1, 'Cadangan anda telah dimasukkan ke dalam jadual rasmi. Terima kasih!', 'System', 1, '2025-12-31 14:29:25', 0),
(59, 13, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2025-12-31 14:30:36', 0),
(61, 13, 1, 'Peringatan Acara i-Desa:\n- Tajuk: Acara Memancing\n- Masa: 2026-01-02 22:28:00 hingga 2026-01-03 22:28:00\n- Lokasi: Kolam Pak Teh\n\nTerima kasih.', 'Reminder', 1, '2025-12-31 14:31:22', 0),
(62, 15, 1, 'Peringatan Acara i-Desa:\n- Tajuk: Acara Memancing\n- Masa: 2026-01-02 22:28:00 hingga 2026-01-03 22:28:00\n- Lokasi: Kolam Pak Teh\n\nTerima kasih.', 'Reminder', 1, '2025-12-31 14:31:22', 0),
(66, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2025-12-31 16:34:17', 0),
(67, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #24)', 'System', 1, '2025-12-31 16:34:17', 0),
(68, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #24)', 'System', 1, '2025-12-31 16:34:17', 0),
(69, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2025-12-31 16:35:15', 0),
(73, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2025-12-31 17:00:10', 0),
(74, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #30)', 'System', 1, '2025-12-31 17:00:10', 0),
(75, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #30)', 'System', 1, '2025-12-31 17:00:10', 0),
(76, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2025-12-31 17:01:08', 0),
(78, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2025-12-31 17:26:31', 0),
(79, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #35)', 'System', 1, '2025-12-31 17:26:31', 0),
(80, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #35)', 'System', 0, '2025-12-31 17:26:31', 0),
(81, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2026-01-01 04:01:44', 0),
(82, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #36)', 'System', 1, '2026-01-01 04:01:44', 0),
(83, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #36)', 'System', 0, '2026-01-01 04:01:44', 0),
(84, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2026-01-01 04:02:29', 0),
(88, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #7)', 'System', 1, '2026-01-01 04:07:30', 0),
(89, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #7)', 'System', 0, '2026-01-01 04:07:30', 0),
(90, 4, NULL, 'Laporan anda telah diluluskan dan dipaparkan di papan Barang Hilang & Jumpa. (ID: #7)', 'System', 1, '2026-01-01 04:07:59', 0),
(91, 13, NULL, 'CLAIM_LF:#7 | Item: Sijil SPM | Oleh: Jahim03 (UID:15) | dsdffsdfsfs', 'System', 1, '2026-01-01 04:08:14', 0),
(92, 15, NULL, 'CLAIM_LF:#7 | Item: Sijil SPM | Oleh: Jahim03 (UID:15) | dsdffsdfsfs', 'System', 1, '2026-01-01 04:08:14', 0),
(93, 4, NULL, 'Status laporan anda telah ditetapkan sebagai SELESAI.\n[DONE 2026-01-01 05:08:28]\n[CLAIM 2026-01-01 05:08:14] Jahim03 (UID:15): dsdffsdfsfs\nDisemak oleh: AJK i-Desa (Jahim03)\n(ID: #7)', 'System', 1, '2026-01-01 04:08:28', 0),
(94, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2026-01-01 04:44:13', 0),
(95, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #42)', 'System', 1, '2026-01-01 04:44:13', 0),
(96, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #42)', 'System', 1, '2026-01-01 04:44:13', 0),
(97, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2026-01-01 04:45:44', 0),
(101, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #8)', 'System', 1, '2026-01-01 04:53:53', 0),
(102, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #8)', 'System', 0, '2026-01-01 04:53:53', 0),
(103, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #9)', 'System', 1, '2026-01-07 07:30:41', 0),
(104, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #9)', 'System', 1, '2026-01-07 07:30:41', 0),
(107, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2026-01-07 07:31:34', 0),
(109, 3, NULL, 'Berita i-Desa: Laporan: Program Kembali ke Sekolah 2026\nSila ambil Maklum', '', 0, '2026-01-07 15:32:58', 0),
(110, 13, NULL, 'Berita i-Desa: Laporan: Program Kembali ke Sekolah 2026\nSila ambil Maklum', '', 0, '2026-01-07 15:32:58', 0),
(111, 15, NULL, 'Berita i-Desa: Laporan: Program Kembali ke Sekolah 2026\nSila ambil Maklum', '', 1, '2026-01-07 15:32:58', 0),
(112, 16, NULL, 'Berita i-Desa: Laporan: Program Kembali ke Sekolah 2026\nSila ambil Maklum', '', 0, '2026-01-07 15:32:58', 0),
(113, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2026-01-07 16:14:38', 0),
(114, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #53)', 'System', 0, '2026-01-07 16:14:38', 0),
(115, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #53)', 'System', 1, '2026-01-07 16:14:38', 0),
(116, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 0, '2026-01-07 16:18:22', 0),
(117, 4, 9, 'Cadangan anda telah dimasukkan ke dalam jadual rasmi. Terima kasih!', 'System', 1, '2026-01-07 16:18:28', 0),
(118, 4, NULL, 'Laporan anda telah diluluskan dan dipaparkan di papan Barang Hilang & Jumpa. (ID: #9)', 'System', 1, '2026-01-07 16:26:40', 0),
(119, 4, NULL, 'Laporan anda telah diluluskan dan dipaparkan di papan Barang Hilang & Jumpa. (ID: #8)', 'System', 1, '2026-01-07 16:26:42', 0),
(120, 3, NULL, '🚨 Berita i-Desa: 🚨 [EMERGENCY] Amaran RIbut Taufan\nSEGERA', 'Emergency', 0, '2026-01-07 16:31:31', 0),
(121, 13, NULL, '🚨 Berita i-Desa: 🚨 [EMERGENCY] Amaran RIbut Taufan\nSEGERA', 'Emergency', 0, '2026-01-07 16:31:31', 0),
(122, 15, NULL, '🚨 Berita i-Desa: 🚨 [EMERGENCY] Amaran RIbut Taufan\nSEGERA', 'Emergency', 1, '2026-01-07 16:31:31', 0),
(123, 16, NULL, '🚨 Berita i-Desa: 🚨 [EMERGENCY] Amaran RIbut Taufan\nSEGERA', 'Emergency', 0, '2026-01-07 16:31:31', 0),
(128, 4, NULL, 'Status laporan anda telah ditetapkan sebagai SELESAI.\n[DONE 2026-01-08 03:48:15]\nKes telah diselesaikan oleh AJK.\nDisemak oleh: AJK i-Desa (Jahim03)\n(ID: #9)', 'System', 0, '2026-01-08 02:48:15', 0),
(129, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 0, '2026-01-08 03:10:57', 0),
(130, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #58)', 'System', 0, '2026-01-08 03:10:57', 0),
(131, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #58)', 'System', 1, '2026-01-08 03:10:57', 0),
(132, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 0, '2026-01-08 03:11:21', 0),
(133, 4, 10, 'Cadangan anda telah dimasukkan ke dalam jadual rasmi. Terima kasih!', 'System', 0, '2026-01-08 03:11:26', 0),
(134, 15, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2026-01-08 03:13:40', 0),
(135, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #61)', 'System', 0, '2026-01-08 03:13:40', 0),
(137, 15, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2026-01-08 03:13:56', 0),
(139, 13, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #10)', 'System', 0, '2026-01-08 04:46:14', 0),
(140, 15, NULL, 'Laporan Barang Hilang/Jumpa baharu menunggu pengesahan. (ID: #10)', 'System', 1, '2026-01-08 04:46:14', 0),
(141, 17, NULL, 'Laporan anda telah diluluskan dan dipaparkan di papan Barang Hilang & Jumpa. (ID: #10)', 'System', 0, '2026-01-08 04:48:07', 0),
(142, 4, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 1, '2026-01-17 20:59:10', 0),
(143, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #65)', 'System', 0, '2026-01-17 20:59:10', 0),
(144, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #65)', 'System', 1, '2026-01-17 20:59:10', 0),
(145, 4, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 1, '2026-01-17 21:00:09', 0),
(147, 3, NULL, '[PERINGATAN ACARA i-Desa]\n\n• Makan Malam — 19/01/2026 04:58 hingga 21/01/2026 04:58 @ Kulim, Kedah, Malaysia\n\nTerima kasih.', 'Reminder', 0, '2026-01-17 23:28:12', 0),
(148, 13, NULL, '[PERINGATAN ACARA i-Desa]\n\n• Makan Malam — 19/01/2026 04:58 hingga 21/01/2026 04:58 @ Kulim, Kedah, Malaysia\n\nTerima kasih.', 'Reminder', 0, '2026-01-17 23:28:12', 0),
(149, 15, NULL, '[PERINGATAN ACARA i-Desa]\n\n• Makan Malam — 19/01/2026 04:58 hingga 21/01/2026 04:58 @ Kulim, Kedah, Malaysia\n\nTerima kasih.', 'Reminder', 1, '2026-01-17 23:28:12', 0),
(150, 16, NULL, '[PERINGATAN ACARA i-Desa]\n\n• Makan Malam — 19/01/2026 04:58 hingga 21/01/2026 04:58 @ Kulim, Kedah, Malaysia\n\nTerima kasih.', 'Reminder', 0, '2026-01-17 23:28:12', 0),
(155, 18, NULL, 'Cadangan acara anda telah dihantar dan sedang disemak oleh AJK.', 'System', 0, '2026-01-18 00:34:14', 0),
(156, 13, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #72)', 'System', 1, '2026-01-18 00:34:14', 0),
(157, 15, NULL, 'Cadangan acara baharu menunggu semakan. (Proposal ID: #72)', 'System', 1, '2026-01-18 00:34:14', 0),
(158, 18, NULL, 'Cadangan acara anda telah DILULUSKAN oleh AJK.', 'System', 0, '2026-01-18 00:36:28', 0),
(159, 18, 13, 'Cadangan anda telah dimasukkan ke dalam jadual rasmi. Terima kasih!', 'System', 1, '2026-01-18 00:36:32', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT 'default_avatar.png',
  `password` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('Resident','AJK','Admin') DEFAULT 'Resident',
  `account_status` enum('Pending','Active','Suspended') DEFAULT 'Pending',
  `pref_general_announcements` tinyint(1) DEFAULT 0 COMMENT '1 = Receive email for general news, 0 = Do not send',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `pref_event_reminders` tinyint(1) DEFAULT 1 COMMENT '1 = Receive email for event reminders, 0 = Do not send'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `username`, `email`, `profile_picture`, `password`, `address`, `phone`, `role`, `account_status`, `pref_general_announcements`, `created_at`, `last_login`, `pref_event_reminders`) VALUES
(1, 'Syam Dany', 'Syam', 'Syam@gmail.com', 'default_avatar.png', '$2y$10$6OtYWi0AEnLP2/KekpYAneXt7oKLSQkOpArL9cYfMaydSUAQtsthO', 'Teluk Kandis', '011-5436789', 'Resident', 'Pending', 0, '2025-12-22 05:56:33', NULL, 1),
(2, 'Khatijah', 'Khatijah', 'khatijah@gmail.com', 'default_avatar.png', '$2y$10$fAiP24VBLGNEQEl6nxhOT.HcOEeXbupapXBmNBl6h05Ilmo5MWjlS', 'Teluk Kandis', '0167754789', 'AJK', 'Pending', 0, '2025-12-22 10:59:26', NULL, 1),
(3, 'Lina Syam', 'Lina22', 'lina@gmail.com', 'default_avatar.png', '$2y$10$gJo0uVNLAVaozjuHqn3wK.s6gN.wLkqEFA2yb.o0zzwuutTISDoJ2', 'Teluk Kandis', '01245678876', 'Resident', 'Active', 0, '2025-12-26 17:35:53', NULL, 1),
(4, 'Rahim', 'rahim03', 'rotikayacair4@gmail.com', 'profile_4_1767242976.jpg', '$2y$10$vwz5vMCKfec4fSjL1HfBBOHcnlw7dGfwCGFblKlFNyl/Z/OAqp8mi', 'No 14334', '014268990202', 'Resident', 'Pending', 0, '2025-12-30 09:48:27', NULL, 1),
(13, 'Salim Kaidar', 'Salim03', 'salim03@gmail.com', 'default_avatar.png', '$2y$10$rKjlEuMotxW4x86g6iGYHuucwkTnfCYp2zwV8sYqAj.SPccV1xkgK', '1sdw', '223232332', 'Admin', 'Active', 0, '2025-12-30 14:26:44', NULL, 1),
(15, 'Jahim03', 'Jahim Anak AJK', 'rotikayacair@gmail.com', 'profile_15_1767806239.png', '$2y$10$3ImOygj97G1uMhupJgp3b.KyLzJ1b5PlhtCQgXBjsyZHndKVUGQNW', '22', '0142356799922', 'AJK', 'Active', 0, '2025-12-30 14:36:19', NULL, 1),
(16, 'Kimi', 'kimikimo', 'salim03@gmail.com', 'default_avatar.png', '$2y$10$idxfV2d1COWLVvQfeY8IxONnPmLb0Km8RhJnlTW2SM.ojX0suCsNK', 'weftyuiouytr', '0332335465', 'Resident', 'Active', 0, '2026-01-01 04:39:07', NULL, 1),
(17, 'hakimi', 'hakimi7', 'hakimi@gmail.com', 'default_avatar.png', '$2y$10$jLuntrNPOEHxUibjFPp2v.AcmaP6ytTCqDMZ.R1ymFMdVAgBfZQs6', 'Teluk Kandis', '0134567892', 'Resident', 'Pending', 0, '2026-01-08 04:42:32', NULL, 1),
(18, 'Razak', 'Razak02', 'roticamera@gmail.com', 'default_avatar.png', '$2y$10$UE7CkK5cno6GWSf0O.rIuucq/M0QPnpwny3P4TS.3QQHMxCgrsYAW', 'rumah no 4, Jalan Munawir 4', '01151116447', 'Resident', 'Pending', 0, '2026-01-18 00:32:55', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `bulletin_feedback`
--
ALTER TABLE `bulletin_feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `bulletin_posts`
--
ALTER TABLE `bulletin_posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `calendar_settings`
--
ALTER TABLE `calendar_settings`
  ADD PRIMARY KEY (`setting_id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`),
  ADD KEY `fk_setting_editor` (`updated_by`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_complaints_user_id` (`user_id`);

--
-- Indexes for table `emergency_contacts`
--
ALTER TABLE `emergency_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `idx_start_date` (`start_datetime`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `event_attendance`
--
ALTER TABLE `event_attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD UNIQUE KEY `unique_user_event` (`event_id`,`user_id`),
  ADD KEY `fk_attendance_user` (`user_id`);

--
-- Indexes for table `event_cancellation_requests`
--
ALTER TABLE `event_cancellation_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `idx_event` (`event_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_requested_by` (`requested_by`),
  ADD KEY `idx_reviewed_by` (`reviewed_by`);

--
-- Indexes for table `lost_found_reports`
--
ALTER TABLE `lost_found_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_type` (`type`),
  ADD KEY `fk_lf_user` (`user_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `idx_user_read` (`user_id`,`is_read`),
  ADD KEY `fk_notif_event` (`event_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `bulletin_feedback`
--
ALTER TABLE `bulletin_feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bulletin_posts`
--
ALTER TABLE `bulletin_posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `calendar_settings`
--
ALTER TABLE `calendar_settings`
  MODIFY `setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `emergency_contacts`
--
ALTER TABLE `emergency_contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `event_attendance`
--
ALTER TABLE `event_attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `event_cancellation_requests`
--
ALTER TABLE `event_cancellation_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `lost_found_reports`
--
ALTER TABLE `lost_found_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `activities_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `bulletin_feedback`
--
ALTER TABLE `bulletin_feedback`
  ADD CONSTRAINT `bulletin_feedback_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `bulletin_posts` (`post_id`) ON DELETE CASCADE;

--
-- Constraints for table `calendar_settings`
--
ALTER TABLE `calendar_settings`
  ADD CONSTRAINT `fk_setting_editor` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `fk_complaints_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `fk_event_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_attendance`
--
ALTER TABLE `event_attendance`
  ADD CONSTRAINT `fk_attendance_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_attendance_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `event_cancellation_requests`
--
ALTER TABLE `event_cancellation_requests`
  ADD CONSTRAINT `fk_cancel_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cancel_requested_by` FOREIGN KEY (`requested_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cancel_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `lost_found_reports`
--
ALTER TABLE `lost_found_reports`
  ADD CONSTRAINT `fk_lf_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notif_event` FOREIGN KEY (`event_id`) REFERENCES `events` (`event_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
